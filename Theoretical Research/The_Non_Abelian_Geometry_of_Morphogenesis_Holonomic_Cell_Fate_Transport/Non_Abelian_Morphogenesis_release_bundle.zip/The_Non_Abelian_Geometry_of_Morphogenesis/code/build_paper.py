#!/usr/bin/env python3
"""Builds the morphogenesis research PDF from results/ and figures/."""
import json
import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "paper", "The_Non_Abelian_Geometry_of_Morphogenesis.pdf")

FD = "/usr/share/fonts/truetype/dejavu/"
for name, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"),
                 ("Serif-I", "DejaVuSerif-Italic.ttf"), ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"),
                 ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
                 ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")

S = json.load(open(os.path.join(RES, "summary.json")))
E1 = json.load(open(os.path.join(RES, "E1_order_and_area.json")))
E2 = json.load(open(os.path.join(RES, "E2_gauge_invariance.json")))
E3 = json.load(open(os.path.join(RES, "E3_defect_stokes.json")))
E4 = json.load(open(os.path.join(RES, "E4_fate_and_order.json")))
E5 = json.load(open(os.path.join(RES, "E5_levy_mechanism.json")))

NAVY = colors.HexColor("#1f4e79")
GREY = colors.HexColor("#555555")
LIGHT = colors.HexColor("#eef3f8")

body = ParagraphStyle("body", fontName="Serif", fontSize=9.6, leading=14.2, alignment=TA_JUSTIFY, spaceAfter=6.5)
small = ParagraphStyle("small", parent=body, fontSize=8.3, leading=11.3, spaceAfter=3)
cap = ParagraphStyle("cap", parent=body, fontSize=8.0, leading=10.6, textColor=GREY, spaceBefore=3, spaceAfter=11)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=13, leading=17, textColor=NAVY, spaceBefore=14, spaceAfter=7)
h2 = ParagraphStyle("h2", fontName="Sans-B", fontSize=10.5, leading=14, textColor=NAVY, spaceBefore=9, spaceAfter=4)
title = ParagraphStyle("title", fontName="Sans-B", fontSize=18, leading=24, alignment=TA_CENTER, textColor=NAVY, spaceAfter=10)
subtitle = ParagraphStyle("subtitle", fontName="Serif-I", fontSize=10.5, leading=14.5, alignment=TA_CENTER, textColor=GREY, spaceAfter=6)
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER)
eqs = ParagraphStyle("eqs", fontName="Serif-I", fontSize=9.6, leading=14, alignment=TA_CENTER, spaceBefore=3, spaceAfter=8)
cell = ParagraphStyle("cell", fontName="Serif", fontSize=7.7, leading=9.8)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Serif-B")


def P(t, s=body):
    return Paragraph(t, s)


def H1(t):
    return Paragraph(t, h1)


def H2(t):
    return Paragraph(t, h2)


def EQ(t):
    return Paragraph(t, eqs)


def IMG(name, caption, width_cm=16.0):
    path = os.path.join(FIG, name + ".png")
    iw, ih = ImageReader(path).getSize()
    w = width_cm * cm
    return KeepTogether([Image(path, width=w, height=w * ih / iw), Paragraph(caption, cap)])


def TABLE(rows, widths):
    data = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                           ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def BOX(text):
    t = Table([[Paragraph(text, small)]], colWidths=[16.0 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def f(x, nd=3):
    if x is None or (isinstance(x, float) and x != x):
        return "n/a"
    return f"{x:.{nd}f}"


def pct(x):
    return f"{100 * x:.0f}%"


AUC = S["E4_auc"]
LL = S["E4_logloss"]
CF = S["E4_counterfactual"]
N_IDX = -1
story = []

# ================================================================= title
story += [Spacer(1, 0.6 * cm),
          P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 9 NOVEMBER 2026", center),
          Spacer(1, 0.4 * cm),
          P("The Non-Abelian Geometry of Morphogenesis", title),
          P("Holonomic cell-fate transport through active p-atic topological defects and causal neural operators", subtitle),
          Spacer(1, 0.2 * cm),
          P("Devanik Debnath · Xylia (AI research scientist, multi-agent research system)", center),
          Spacer(1, 0.3 * cm)]

story.append(BOX(
    "<b>About the author.</b> Electronics and Communication Engineering graduate and independent AI researcher exploring how "
    "physical and mathematical structure can improve learning and modeling. Work spans gamma-ray burst reconstruction at the "
    "National Astronomical Observatory of Japan (NAOJ), physics-inspired signal classification, reinforcement learning, neural "
    "quantum-state methods, causal emergence, morphogenetic neural architectures, and computational artificial life. The research "
    "style combines algorithm design with explicit assumptions, code-based checks, and disclosure of unresolved limitations. "
    "<i>Devanik Debnath</i> is a Scientific Machine Learning and AI Architectures researcher; B.Tech, Electronics and Communication "
    "Engineering, National Institute of Technology Agartala (2026); Samsung Grade I Fellowship, Cohort 7; completed the IISc-led India "
    "Semiconductor Workforce Development Program (ISWDP) Level 1 evaluation at the 98.58th percentile. Links: github.com/Devanik21, "
    "orcid.org/0009-0001-8310-6921."))
story.append(Spacer(1, 0.35 * cm))

story.append(BOX(
    "<b>Scope.</b> This paper is a theory-plus-simulation study of abstract models. It defines a matrix-valued connection over a "
    "space of intervention histories, computes its holonomy and curvature consequences, and tests whether ordering information "
    "is recoverable by order-aware predictors. <b>It does not model any organism, tissue or patient, and it makes no claim that "
    "biological tissue contains a physical gauge field.</b> The gauge structure is a mathematical representation of order-dependent "
    "transport. No experiment on living material is reported. All numbers come from <font face='Mono'>code/morpho_experiments.py</font> "
    "with seed 20261110."))
story.append(Spacer(1, 0.35 * cm))

story.append(P(
    "<b>Abstract.</b> A cell that receives a mechanical stimulus and then a chemical one may end in a different state from a cell that "
    "receives the same two stimuli in the opposite order, with identical total exposure. Any model whose state transport commutes "
    "cannot represent this. We propose that order dependence is the curvature of a matrix-valued connection on the space of "
    "control states, so that closed intervention loops have holonomy operators whose deviation from the identity measures "
    "noncommutativity. We prove four results. The first-order order effect between two intervention orders is the commutator of the "
    "generators, and it scales as the square of the step size. The holonomy of a rectangular loop deviates from the identity by its "
    "area times the curvature. Plaquette holonomy traces are gauge invariant. Integer holonomies of a p-atic director field satisfy a "
    "discrete Stokes identity, so defect charges enter only through their residues modulo p. A central point of the paper is that the "
    "p-atic sector alone is Abelian: its holonomy group is Z<sub>p</sub>, so noncommuting holonomy must come from the transport "
    "generators or from a non-Abelian extension, and we state that extension as a conjecture. In numerical experiments, the order effect "
    f"scales with exponent {S['E1_order_slope']:.2f}; the loop deviation with exponent {S['E1_loop_slope']:.2f}; gauge-invariance error is "
    f"{S['E2_max_trace_change']:.0e}; the Stokes identity holds on {S['E3_loops']} of {S['E3_loops']} loops; and in a model with fixed "
    f"exposure, {pct(S['E4_order_flip_main'])} of cells change fate under reversal while a commuting control changes none. An order-aware "
    f"logistic model on the discrete Lévy area reaches held-out AUC {AUC['levy'][-1]:.2f} against {AUC['exposure'][-1]:.2f} for an "
    "order-blind exposure model, at the ceiling set by the label noise (about 0.90). The Lévy-area model matches a 12-feature positional "
    "model and outperforms a bigram model. Counterfactual reversal accuracy is "
    f"{CF['levy']:.2f} for the Lévy-area model. A sensitivity sweep over 300 random generic initial states and observables, however, "
    f"shows that these strong effects are specific to the chosen pair: the median fraction of fates that flip under reversal is "
    f"{S['E6_flip_median']:.2f} (10th to 90th percentile {S['E6_flip_q10']:.2f} to {S['E6_flip_q90']:.2f}), and the sign-of-Lévy-area "
    f"rule has median accuracy {S['E6_sign_rule_median']:.2f}, which is chance. We stress that the causal claims concern the counterfactual predictions of a "
    "stylised generative model; no intervention in living tissue is performed. The paper closes with a pre-registrable falsification "
    "programme on epithelial perturbation data, which has not been run.", body))
story.append(P("<b>Keywords:</b> holonomy · curvature · path-ordered exponentials · Lévy area · p-atic order · Z<sub>p</sub> gauge "
               "field · discrete Stokes theorem · causal neural operators · intervention order", small))
story.append(PageBreak())

# ================================================================= contents
story.append(H1("Contents"))
for t in ["1  Introduction", "2  Mathematical background", "3  The model", "4  Theoretical results",
          "5  Numerical study", "6  What is and is not established", "7  The causal operator: what was and was not built",
          "8  A falsification programme on epithelial perturbation data", "9  Limitations",
          "10  Open problems", "11  Discussion and scope", "12  Conclusion", "Appendix A  Proofs",
          "Appendix B  Parameters, seeds and protocol", "Appendix C  Disclosure and corrections", "References"]:
    story.append(P(t, small))
story.append(PageBreak())

# ================================================================= 1
story.append(H1("1  Introduction"))
story.append(H2("1.1  The question"))
story.append(P(
    "Developmental biology has long recognised that the outcome of a tissue depends on the history of signals it receives, not only on "
    "their current values. Mechanical strain and biochemical signalling are coupled through the cytoskeleton, through cell–cell junctions, "
    "and through the geometry of the tissue itself. A cell that has been stretched and then exposed to a morphogen can end in a state that "
    "differs from one that met the same two inputs in reverse. Many models describe the cell by a scalar state, such as a concentration, a "
    "level of a transcription factor, or a cumulative dose. Such models are commutative in the following precise sense: if the cell's state "
    "is a function of the total exposure to each signal, then reordering the signals changes nothing. Whether reordering changes the outcome "
    "is therefore a sharp empirical question, and the answer is a property of the model class."))
story.append(P(
    "This paper asks a narrower mathematical version of that question. Suppose the admissible perturbations of a cell form a family of "
    "transport operators that do not commute. Then the state transported along a sequence of perturbations depends on the order of the "
    "sequence, and the failure of commutativity is measured by a curvature. We ask four questions. What is the leading-order form of the "
    "order effect, and does it deserve the name curvature? Can closed perturbation loops detect curvature in a gauge-invariant way? Does "
    "the topology of an active p-atic field add a further, measurable layer of memory? And can an order-aware predictor, fitted to ordered "
    "intervention data, identify the order statistic that generates fate, and predict what happens under reordering?"))
story.append(H2("1.2  What is established and what is not"))
story.append(P(
    "The results split into three kinds. Theorems 1 to 4 and Proposition 5 are exact statements about the model defined in Section 3. "
    "Numerical results in Section 5 measure the same model, with seeds, sizes and tests stated. Conjectures in Sections 4 and 10 are "
    "unproved. Nothing in the paper is a biological finding. The mathematical objects are representations. A gauge field in this paper is a "
    "bookkeeping device that makes order dependence local and computable, and its existence in tissue is an empirical question that the "
    "paper does not answer."))
story.append(H2("1.3  A correction to the founding analogy"))
story.append(P(
    "The proposal that motivated this work joined three areas: non-Abelian gauge geometry, p-atic order in active matter, and causal neural "
    "operators. It was suggested that the p-atic defects of the tissue would couple to a matrix-valued connection and generate "
    "non-Abelian holonomy. Working through the algebra shows that this coupling, on its own, cannot do that. A p-atic director field has "
    "a discrete symmetry group Z<sub>p</sub> of rotations by multiples of 2π/p. Its link variables take values in Z<sub>p</sub>, and Z<sub>p</sub> is "
    "Abelian. A holonomy group that is a product of commuting rotations gives a commuting holonomy. A p-atic sector therefore contributes "
    "topological charge, quantised in units of 1/p, but it contributes no noncommutativity by itself. Section 6 shows this numerically, "
    "and Conjecture 1 states the condition under which noncommutativity could arise from the defect sector, which is an extension of the "
    "group to the dihedral group D<sub>p</sub> when the director is allowed to reverse orientation."))
story.append(P(
    "The non-Abelian structure in this paper therefore comes from the transport generators of the cell's control states. Those generators "
    "are not measured in any biological system here. They are parameters of the model, chosen to be generic, and the results hold for a "
    "class of generators rather than for one tissue."))
story.append(H2("1.4  Contributions"))
for t in [
    "<b>C1.</b> A formulation of intervention-order dependence as the curvature of a matrix-valued connection, with the leading-order "
    "law of the order effect (Theorem 1) and the area law for loops (Theorem 2).",
    "<b>C2.</b> A gauge-invariance theorem for plaquette traces (Theorem 3) and a discrete Stokes identity for integer p-atic holonomy, "
    "with a precise statement of what the identity does and does not show (Proposition 4).",
    "<b>C3</b>. An identifiability result: under balanced exposure, the order-dependent part of the second signature level is the Lévy "
    "area, and models depending on that level are functions of it (Proposition 5). A reversal law for the Lévy area gives a sharp "
    "counterfactual prediction (Proposition 6).",
    "<b>C4.</b> A numerical programme with a commuting null model, a generic-state diagnostic that rules out a symmetry-induced null, "
    "and a counterfactual reversal test. Order-aware predictors are compared with an order-blind model and a bigram model.",
    "<b>C5.</b> A falsification design for epithelial data, with pre-specified outcomes and failure conditions (Section 8)."]:
    story.append(P(t))

# ================================================================= 2
story.append(H1("2  Mathematical background"))
story.append(H2("2.1  Connections, holonomy and curvature"))
story.append(P(
    "Let G be a matrix Lie group with Lie algebra 𝔤. A connection on a principal G-bundle over a base manifold M is specified by a "
    "𝔤-valued one-form 𝒜. For a smooth curve γ with tangent γ′, parallel transport solves the linear equation dg/dt = −𝒜(γ′) g, and "
    "the holonomy of a closed loop is the group element W(γ) returned by transport around the loop. The curvature is the Lie-algebra-"
    "valued two-form 𝓕 = d𝒜 + 𝒜 ∧ 𝒜, which satisfies the Bianchi identity d𝓕 + [𝒜, 𝓕] = 0 (Kobayashi and Nomizu 1963). For a small loop of "
    "area A bounding a region with constant curvature, the holonomy is approximately exp(−A 𝓕), so holonomy deviation from the identity "
    "measures curvature. This is the standard Ambrose–Singer picture, and it is the mechanism that the area law of Theorem 2 makes explicit."))
story.append(H2("2.2  Path-ordered exponentials"))
story.append(P(
    "When the generators are constant along a piecewise linear path, transport is a product of matrix exponentials, ordered by time. For two "
    "generators X and Y and step size ε, the transport of the word XY is e<super>εX</super>e<super>εY</super>, and the transport of the word YX is "
    "e<super>εY</super>e<super>εX</super>. The Baker–Campbell–Hausdorff formula gives log(e<super>A</super>e<super>B</super>) = A + B + ½[A, B] + … , so "
    "the difference between the two orders is governed at leading order by the commutator. This is the algebraic core of Theorem 1."))
story.append(H2("2.3  Signatures and Lévy area"))
story.append(P(
    "For a path in ℝ<super>d</super> with increments, the signature collects iterated integrals of the coordinate increments (Chen 1958; Lyons "
    "1998). The first level is the total increment. The second level is the matrix of iterated integrals S<super>ij</super> = ∫ (X<super>i</super><sub>s</sub> − "
    "X<super>i</super><sub>0</sub>) dX<super>j</super><sub>s</sub>. Its antisymmetric part is the Lévy area, which for a closed path equals the signed area it "
    "encloses (Lévy 1951). For discrete two-letter words, the Lévy area is one half of the signed count of inversions between the two "
    "letters. This quantity is the order statistic that the paper's predictors use."))
story.append(H2("2.4  p-atic order and Z<sub>p</sub> holonomy"))
story.append(P(
    "A p-atic liquid crystal is a two-dimensional orientational order with p-fold rotational symmetry (Bowick and Giomi 2009; Kamien 2002). "
    "The local orientation is defined only up to rotation by 2π/p, so the physical order parameter is exp(ipθ). Topological defects carry "
    "charges quantised in units of 1/p, and the Mermin topological theory classifies them by the homotopy of the order-parameter space "
    "(Mermin 1979). In the discrete setting used here, the link variable between neighbouring sites is the integer number of 2π/p sectors "
    "crossed by the director. Around a closed loop these integers sum to an integer that is defined modulo p, which is the Z<sub>p</sub> holonomy."))
story.append(H2("2.5  Causal intervention and neural operators"))
story.append(P(
    "Pearl's framework distinguishes observing a variable from intervening on it, and it defines counterfactuals as outcomes under "
    "interventions that differ from the realised ones (Pearl 2009). Neural operators learn maps between function spaces and have been "
    "used for families of partial differential equations (Kovachki et al. 2023; Li et al. 2021). In this paper, the order-aware predictors "
    "are logistic models on engineered features of ordered intervention histories. They are a deliberately modest stand-in for a neural "
    "operator, and Section 7 explains what that substitution does and does not test."))

# ================================================================= 3
story.append(H1("3  The model"))
story.append(H2("3.1  Control states and generators"))
story.append(P(
    "The control state of a cell is a point of a two-dimensional complex Hilbert space ℂ<super>2</super>, with normalised vectors representing "
    "states up to phase. Two intervention channels act on it. A mechanical channel M acts by U<sub>M</sub> = exp(εX), and a chemical channel C "
    "acts by U<sub>C</sub> = exp(εY), where X and Y are the anti-Hermitian Pauli generators (i/2)σ<sub>x</sub> and (i/2)σ<sub>y</sub>. Their commutator is "
    "[X, Y] = −½ σ<sub>z</sub>, which has Frobenius norm 1/√2 ≈ 0.7071. The step size is ε = 0.6, large enough that the second-order "
    "term is not negligible."))
story.append(H2("3.2  Intervention histories"))
story.append(P(
    "An intervention history is a word w = w<sub>1</sub>…w<sub>L</sub> over {M, C}. In the main experiment L = 6, and every history contains "
    "three M and three C. The total exposure to each channel is therefore identical for every history, so no model that depends only on "
    "exposure can distinguish them. The state after the history is ψ(w) = U<sub>w<sub>L</sub></sub> ⋯ U<sub>w<sub>1</sub></sub> ψ<sub>0</sub>, with a fixed "
    "initial state ψ<sub>0</sub> = (cos a, e<super>ib</super> sin a) where a = 0.3238 and b = 2.8074."))
story.append(H2("3.3  Fate observable and outcome law"))
story.append(P(
    "Fate is read out by a fixed Hermitian observable O = Σ<sub>k</sub> n<sub>k</sub>σ<sub>k</sub>, with the unit vector n = (0.334, −0.942, 0.014). "
    "The noiseless fate is the sign of z(w) = ⟨ψ(w)|O|ψ(w)⟩. The observed label flips the noiseless fate independently with probability "
    "0.1, which models measurement error in the outcome. The constant 0.1 bounds achievable discrimination, as Section 5 shows."))
story.append(H2("3.4  The commuting null model"))
story.append(P(
    "The null model replaces the chemical generator by 0.7 X, so that both channels are multiples of X and commute. Its final state depends "
    "on the word only through the counts of M and C, which are fixed. Its fate is therefore order-invariant. This control is what makes "
    "order dependence in the main arm attributable to noncommutativity rather than to some other feature of the design."))
story.append(H2("3.5  Discrete connection on a lattice"))
story.append(P(
    "For the p-atic experiments, the director angle θ is a function on the sites of an L × L grid. For a link from site a to site b, the "
    "discrete connection is the integer n<sub>ab</sub> = round(p(θ<sub>b</sub> − θ<sub>a</sub>)/2π), which counts the 2π/p sectors crossed. "
    "The integer holonomy of a closed loop of links is the sum of its link integers, and its residue modulo p is the Z<sub>p</sub> holonomy. "
    "Plaquette loops are the boundaries of unit squares, and the loop integers of rectangles are the sums over their boundary links."))

# ================================================================= 4
story.append(H1("4  Theoretical results"))
story.append(P(
    "Every statement in this section has a proof in Appendix A. Where a result depends on a hypothesis, the hypothesis is stated in the "
    "result. Theorem 1 is the leading-order order effect. Theorem 2 is the area law. Theorem 3 is gauge invariance. Proposition 4 is the "
    "discrete Stokes identity. Proposition 5 is identifiability under balanced exposure. Proposition 6 is the reversal law."))
story.append(EQ("Theorem 1 (order effect).  e<super>εX</super>e<super>εY</super> − e<super>εY</super>e<super>εX</super> = ε²[X, Y] + O(ε³)."))
story.append(P(
    "The order effect between the two orders of the same two channels is a curvature, and its size scales as the square of the step size. "
    "Consequently a model whose outcome depends on the transport operator is order-sensitive at order ε² unless [X, Y] = 0. The commuting "
    "null model is precisely the case [X, Y] = 0 at all orders."))
story.append(EQ("Theorem 2 (area law).  e<super>aX</super>e<super>bY</super>e<super>−aX</super>e<super>−bY</super> = I + ab[X, Y] + O((a+b)³)."))
story.append(P(
    "The deviation of a rectangular holonomy from the identity equals the enclosed area ab times the curvature [X, Y]. Its Frobenius norm is "
    "therefore linear in the area. This is the discrete form of the Ambrose–Singer relation for a constant-curvature patch."))
story.append(EQ("Theorem 3 (gauge invariance).  tr W<sub>p</sub> is invariant under U<sub>e</sub> → g<sub>a</sub> U<sub>e</sub> g<sub>b</sub><super>−1</super> for all gauge fields g."))
story.append(P(
    "Plaquette traces, and hence any function of the holonomy trace, are gauge invariant. A quantity that depends on the holonomy only "
    "through its trace is therefore a well-defined observable of the connection, not of the chosen gauge."))
story.append(EQ("Proposition 4 (discrete Stokes identity).  Σ<sub>∂R</sub> n<sub>e</sub> = Σ<sub>p∈R</sub> Σ<sub>∂p</sub> n<sub>e</sub>, and n<sub>ba</sub> = −n<sub>ab</sub>."))
story.append(P(
    "For any lattice field and any rectangle R, the integer loop charge around the boundary equals the sum of the integer plaquette charges "
    "inside. The identity is exact and follows from the antisymmetry of the link integers, so it holds for every configuration. Its content "
    "lies in what the plaquette charges measure. In the planted configurations, a plaquette charge is nonzero where and only where a "
    "defect of charge c/p sits. The experiments in Section 5 test this localisation and find that the integer loop charge equals the planted "
    "charge in every one of 294 loops."))
story.append(EQ("Proposition 5 (identifiability under balanced exposure)."))
story.append(P(
    "Let words have n<sub>M</sub> = n<sub>C</sub> = 3. Then the second-level signature has entries S<sup>MM</sup> = 9/2, S<sup>CC</sup> = 9/2 and "
    "S<sup>MC</sup> + S<sup>CM</sup> = 9, so the only word-dependent second-level quantity is the antisymmetric part, which equals the Lévy area "
    "A(w) = ½(#MC − #CM). Any model whose predictions depend only on the second signature level is therefore a function of A(w) alone. The "
    "result is an identity about the signature, and it does not claim that the true outcome depends only on the second level."))
story.append(P(
    "<i>Proof.</i> For a word with three of each letter, the total number of ordered pairs of distinct letter positions is 9, and each pair is "
    "either MC or CM. Hence S<sup>MC</sup> + S<sup>CM</sup> = 9 and S<sup>MC</sup> − S<sup>CM</sup> = 2A(w). The diagonal entries are fixed by the counts "
    "(n<sub>M</sub><super>2</super>/2 and n<sub>C</sub><super>2</super>/2). ∎"))
story.append(EQ("Proposition 6 (reversal law).  A(w<super>rev</super>) = −A(w), and the commuting null model satisfies z(w<super>rev</super>) = z(w)."))
story.append(P(
    "Reversing a word exchanges the roles of earlier and later positions, so every MC pair becomes a CM pair. A model linear in A therefore "
    "predicts that reversal flips the sign of its linear predictor. For the commuting null model the outcome is order-invariant, so reversal "
    "changes nothing. These statements make the counterfactual test of Section 5.6 a real test: a model that uses order information must "
    "predict the reversed outcome, and a model that does not must fail on it."))
story.append(H2("4.1  Conjectures"))
story.append(P(
    "<b>Conjecture 1 (dihedral p-atic holonomy).</b> If the director is allowed to reverse orientation across a link, the holonomy takes "
    "values in the dihedral group D<sub>p</sub>. Holonomies of loops enclosing two defects then fail to commute whenever the defects carry "
    "charges that are not multiples of p, so the defect sector alone generates noncommutative holonomy. The conjecture is unproved and is "
    "stated as a precise open problem in Section 10."))
story.append(P(
    "<b>Conjecture 2 (signature sufficiency).</b> For the generic model of Section 3, the fate is determined by the second signature level "
    "up to the label noise. Section 5.7 gave evidence for the chosen pair, but Section 5.8 shows that the sign rule fails across generic "
    "pairs, so Conjecture 2 is refuted in its general form and survives only for that pair. We keep it as stated, with this status."))

# ================================================================= 5
story.append(H1("5  Numerical study"))
story.append(P(
    "All experiments run in one script with seed 20261110. Each experiment writes its raw data to results/ and its figure to figures/ in "
    "PNG and SVG. The parameters are listed in Appendix B. Where a number depends on sampling, the number of trials and the spread are "
    "reported. We did not tune any parameter to a desired result, except for the choice of generic initial state and observable described "
    "in Section 5.5, which was selected in a diagnostic run and reported as such."))
story.append(IMG("fig01_architecture",
                 "<b>Figure 1.</b> Architecture of the proposal as implemented here. Control states carry a matrix connection whose curvature "
                 "gives the holonomy of intervention loops. The p-atic sector contributes Z<sub>p</sub> charges. The causal operator is an "
                 "order-aware predictor, tested by counterfactual reversal."))
story.append(H2("5.1  Order effect and area law (E1)"))
story.append(IMG("fig02_order_and_area_law",
                 "<b>Figure 2.</b> (a) Order effect ‖e<super>εX</super>e<super>εY</super> − e<super>εY</super>e<super>εX</super>‖ against step size, log–log, with the "
                 "theoretical line ε²‖[X, Y]‖. (b) Holonomy deviation of rectangular loops against area, with the area law line."))
story.append(P(
    f"<b>Numerical result.</b> The fitted exponent of the order effect is {S['E1_order_slope']:.3f} against the theoretical 2, over "
    "fourteen step sizes between 0.01 and 0.25. The loop deviation has exponent "
    f"{S['E1_loop_slope']:.3f} against the theoretical 1 over twelve areas. The fitted area coefficient is {S['E1_area_coeff']:.4f}, against "
    f"‖[X, Y]‖<sub>F</sub> = {S['comm_norm']:.4f}, a relative difference of "
    f"{100 * abs(S['E1_area_coeff'] - S['comm_norm']) / S['comm_norm']:.1f}%. These are the two laws of Theorems 1 and 2, measured on the "
    "exact matrix exponentials."))
story.append(H2("5.2  Gauge invariance (E2)"))
story.append(IMG("fig03_gauge_invariance",
                 "<b>Figure 3.</b> (a) Log-scale histogram of the change in plaquette trace after a random gauge transformation, over 400 "
                 "plaquettes on an 8 × 8 lattice. (b) The curvature signal |tr W − 2| of the same plaquettes, to show that the "
                 "invariance is not trivial."))
story.append(P(
    f"<b>Numerical result.</b> The largest change in plaquette trace over 400 plaquettes is {S['E2_max_trace_change']:.1e}, which is at "
    "machine precision. The median curvature signal is "
    f"{S['E2_median_curvature']:.3f}, so the plaquettes are curved and the invariance is a genuine test. This is Theorem 3, verified."))
story.append(H2("5.3  p-atic defects and the discrete Stokes identity (E3)"))
story.append(IMG("fig04_padic_defect_holonomy",
                 "<b>Figure 4.</b> (a) A p = 3 director field with two planted defects of charges −1/3 and 1/3, and a rectangular loop. "
                 "(b) Fraction of loops for which the integer holonomy equals the enclosed charge, by p."))
rows = [["p", "Loops", "Exact integer agreement", "Agreement mod p"]]
for p in ["2", "3", "4", "6"]:
    n = E3["loops_by_p"][p]
    rows.append([p, n, pct(E3["accuracy_by_p"][p]), pct(E3["accuracy_by_p"][p])])
rows.append(["all", E3["loops"], pct(E3["accuracy_exact_integer"]), pct(E3["accuracy"])])
story.append(TABLE(rows, [2.0, 3.0, 5.0, 5.0]))
story.append(P("<b>Table 1.</b> Agreement between integer loop holonomy and enclosed planted charge, by p.", cap))
story.append(IMG("fig05_stokes_scatter",
                 "<b>Figure 5.</b> Loop holonomy against enclosed charge, both reduced modulo p. Points cluster on the identity line, with "
                 "jitter added for visibility."))
story.append(P(
    "<b>Numerical result and its reading.</b> The integer loop charge equals the planted charge in every loop, for every p, under the "
    "stated noise of 0.02 radians. Proposition 4 makes this exact by construction in the sense that the boundary sum equals the interior "
    "sum. The non-trivial content is that the planted defects are localised as plaquette charges, and that the rounding scheme does not "
    "smear them at the lattice scale used. We do not claim the identity tests a physical field, only that it localises the charges we "
    "planted."))
story.append(H2("5.4  Intervention order and fate (E4, part one)"))
story.append(IMG("fig06_order_sensitivity",
                 "<b>Figure 6.</b> Final observable under forward and reversed intervention orders for the main arm (a) and the commuting "
                 "control (b), for 600 cells each. Reversal changes the sign of the observable for many cells in the main arm and for none in "
                 "the control."))
story.append(P(
    f"<b>Numerical result.</b> In the main arm, {pct(S['E4_order_flip_main'])} of the 4000 balanced histories change sign under reversal, "
    f"so their fate is order-dependent. In the commuting control, {pct(S['E4_order_flip_control'])} change sign. Both arms have identical "
    "exposure by construction. The contrast isolates noncommutativity as the source of order dependence."))
story.append(P(
    "<b>Why the initial state and observable were chosen.</b> A first run used the initial state |0⟩ and the observable σ<sub>z</sub>. In that "
    "configuration reversal left every fate unchanged, so the main arm was not a test of order at all. A diagnostic over 40 random initial "
    "states and observables found pairs for which between 20% and 90% of histories flipped. We report the pair with the largest flip fraction, "
    "0.9 across all twenty balanced orderings. The chosen pair is generic: it is not aligned with any symmetry of the generators."))
story.append(H2("5.5  Predictors and their comparison (E4, part two)"))
story.append(IMG("fig07_predictor_comparison",
                 "<b>Figure 7.</b> Held-out discrimination (a) and calibration (b) of four predictors as the number of cells grows. Error "
                 "bars are standard deviations over eight random splits. The dotted line marks AUC 0.5."))
rows = [["Predictor", "Features", "AUC, N = 6400", "Log-loss, N = 6400"]]
desc = {"exposure": "total M and C counts (order-blind)", "position": "12 position-specific indicators",
        "bigram": "4 adjacent-pair counts", "levy": "1 discrete Lévy area"}
for m in ["exposure", "position", "bigram", "levy"]:
    rows.append([m, desc[m], f(AUC[m][-1], 3), f(LL[m][-1], 3)])
story.append(TABLE(rows, [2.6, 6.0, 3.2, 3.6]))
story.append(P("<b>Table 2.</b> Held-out performance at the largest sample size. Labels carry 10% noise, so the Bayes-optimal AUC is about 0.90.", cap))
story.append(P(
    f"<b>Numerical result.</b> The order-blind exposure model is at chance, as Proposition 5 requires for balanced histories. The one-feature "
    f"Lévy-area model reaches AUC {AUC['levy'][-1]:.3f} and the twelve-feature positional model {AUC['position'][-1]:.3f}. Both are at the "
    "label-noise ceiling. The bigram model reaches "
    f"{AUC['bigram'][-1]:.3f}, below the ceiling. The Lévy-area model therefore captures the order information that a much larger "
    "positional model captures, with one feature. This is the parsimony result that motivates Proposition 5 in practice."))
story.append(H2("5.6  Counterfactual reversal (E4, part three)"))
story.append(IMG("fig08_counterfactual",
                 "<b>Figure 8.</b> Accuracy of each predictor, trained on forward histories, in predicting the noiseless outcome of the "
                 "reversed history. The dotted line marks chance."))
story.append(P(
    f"<b>Numerical result.</b> The Lévy-area model predicts reversed outcomes with accuracy {CF['levy']:.3f} and the positional model with "
    f"{CF['position']:.3f}. The exposure model, which cannot see order, scores {CF['exposure']:.3f}, close to chance, and the bigram model scores "
    f"{CF['bigram']:.3f}. Proposition 6 predicts the sign flip that the Lévy-area model implements, and the result confirms it at the level "
    "of accuracy. A model that merely fitted the forward data without capturing order would fail this test."))
story.append(H2("5.7  Mechanism: the Lévy area and fate (E5)"))
story.append(IMG("fig09_levy_fate",
                 "<b>Figure 9.</b> Probability of a positive noiseless fate as a function of the discrete Lévy area, with the number of cells "
                 "at each value annotated. The count of cells at each value is shown above each point."))
levy_vals = sorted(float(k) for k in E5["P_fate_positive_given_levy"].keys())
rows = [["Lévy area", "Cells", "P(fate positive)"]]
for v in levy_vals:
    k = str(v)
    rows.append([f(v, 1), E5["counts"][k], f(E5["P_fate_positive_given_levy"][k], 3)])
story.append(TABLE(rows, [3.4, 3.4, 4.2]))
story.append(P("<b>Table 3.</b> Fate as a function of the discrete Lévy area, over 6400 balanced histories with noiseless outcomes.", cap))
story.append(P(
    "<b>Numerical result.</b> For every history with negative Lévy area at or below −0.5, the noiseless fate is positive. For every history "
    "with area at or above 1.5 the fate is negative. Histories at area 0.5 split, with about a third positive. The fate is therefore close to "
    "a deterministic function of the sign of the second-level signature, which supports Conjecture 2 for this model. The exception at area 0.5 "
    "shows that the second level is not sufficient on its own. Higher signature levels, or the position of the first and last letters, "
    "decide the outcome in that band."))

story.append(H2("5.8  Sensitivity across generic pairs (E6)"))
story.append(IMG("fig10_sensitivity_sweep",
                 "<b>Figure 10.</b> Across 300 random generic pairs of initial state and observable: (a) the fraction of the twenty balanced "
                 "histories whose fate flips under reversal; (b) the held-out-free accuracy of the sign-of-Lévy-area rule identified in Section 5.7."))
rows = [["Quantity", "Median", "10th percentile", "90th percentile"],
        ["Flip fraction under reversal", f(S["E6_flip_median"], 2), f(S["E6_flip_q10"], 2), f(S["E6_flip_q90"], 2)],
        ["Sign-of-Lévy-area accuracy", f(S["E6_sign_rule_median"], 2), f(S["E6_sign_rule_q10"], 2), "n/a"]]
story.append(TABLE(rows, [6.0, 3.0, 3.5, 3.5]))
story.append(P("<b>Table 5.</b> Distribution over 300 generic (initial state, observable) pairs. "
               f"A fraction {S['E6_frac_flip_above_0.2']:.2f} of pairs have more than 20% of fates flipping under reversal.", cap))
story.append(P(
    "<b>Numerical result and correction.</b> The main-arm result of 91% flipped fates is therefore an outlier of the family rather than "
    "its typical value. For most generic pairs the order matters for a minority of histories, and the rule that predicted fate from the "
    "Lévy area for the chosen pair has chance-level accuracy across the family. The Lévy-area model remains a valid order statistic, since "
    "Proposition 5 and Proposition 6 hold for every pair. What fails is the claim that the fate is generically a function of the second "
    "signature level. Reporting this distribution is the purpose of the sweep: a single favourable pair would otherwise look like a general law."))

# ================================================================= 6
story.append(H1("6  What is and is not established"))
story.append(P(
    "The mathematical results are Theorems 1 to 3, Propositions 4 to 6, and their proofs. The numerical results establish that the algebra "
    "is implemented correctly and that the model behaves as the theory predicts. The results establish three further points.",))
for t in [
    "The p-atic sector, computed as a Z<sub>p</sub> gauge theory, localises and recovers planted charges exactly. It does not generate "
    "noncommuting holonomy. Any non-Abelian content must come from elsewhere, and the generator structure of Section 3 is one source.",
    "Order dependence is measurable as a curvature effect and is absent in the commuting control. Its size is controlled by the "
    "commutator, as Theorem 1 says. Its fraction of affected histories varies widely across generic pairs (Section 5.8).",
    "For the chosen pair, an order-aware predictor based on the Lévy area recovers the order information that a much larger positional "
    "model recovers, and predicts counterfactual reversals accurately. Across generic pairs the sign rule fails, so the second signature "
    "level is a compact representation of order but not a sufficient one for fate."]:
    story.append(P(t))
story.append(P(
    "What the results do not establish is equally important. They do not show that any tissue has the generator structure assumed here, that "
    "any cell responds to mechanical and chemical stimuli through commuting or noncommuting transport, or that fate in any living system is a "
    "function of a signature. Those are empirical questions. Section 8 specifies the data that would be needed to ask them."))

# ================================================================= 7
story.append(H1("7  The causal operator: what was and was not built"))
story.append(P(
    "The proposal named a causal neural operator that would reconstruct nonlinear spatiotemporal dynamics and infer intervention-dependent "
    "structure from cell-resolved observations. The study here does not build that object. The order-aware predictors of Section 5 are "
    "logistic models on fixed features. They are a lower bound on what a neural operator would do: they show that the relevant order "
    "information exists and is compact, and they supply a baseline for a neural operator to beat."))
story.append(P(
    "The counterfactual test is the piece of causal reasoning that was implemented. It checks whether a predictor, fitted to forward "
    "histories, reproduces the outcome of a reversed history that it did not see. This is an interventional prediction within the model, "
    "not a causal discovery claim about a real system. A causal graph is not learned, and no confounding structure is tested. Causal "
    "discovery from observational tissue data would require assumptions about unmeasured variables that this model does not supply."))
story.append(P(
    "A neural operator implementation is the first extension named in Section 10. Its test would be the same counterfactual protocol, "
    "with the operator trained on forward histories and scored on reversed ones, against the Lévy-area baseline reported here."))

# ================================================================= 8
story.append(H1("8  A falsification programme on epithelial perturbation data"))
story.append(P(
    "The hypotheses of this paper can be tested on real data, and the test should be designed before the data are analysed. We state the "
    "predictions, the data they require, and the outcomes that would count against them. No such data were analysed in this study."))
story.append(H2("8.1  Predictions"))
for t in [
    "<b>P1.</b> In an epithelium under sequenced mechanical and chemical perturbation, cells that receive the same totals of each "
    "perturbation in opposite orders differ in their fate reporter more than cells receiving the same orders in replicate measurements. "
    "Falsified if the between-order difference is not larger than the replicate noise.",
    "<b>P2</b>. The order effect scales with the step size of the perturbation as ε² for small steps. Falsified if the fitted exponent is "
    "not compatible with 2 once the measurement error is propagated.",
    "<b>P3.</b> An order-aware model on the Lévy area of each cell's perturbation history predicts held-out fates better than a model on "
    "exposure totals alone. Falsified if the difference is within the sampling spread of the held-out estimate.",
    "<b>P4.</b> The Lévy-area model predicts fates of reversed-order perturbations that were not used for training, above chance and above "
    "the exposure model. Falsified if it does not.",
    "<b>P5.</b> In a commuting control, where two perturbations are designed to commute in their effect on the reporter, order has no "
    "detectable effect. Falsified if an order effect appears in the control at the same size as in the main arm."]:
    story.append(P(t))
story.append(H2("8.2  Data requirements"))
story.append(P(
    "The experiment needs (i) live imaging of an epithelium, with cell-resolved segmentation; (ii) perturbations that are applied in a "
    "controlled sequence, with recorded order and timing; (iii) a fate reporter with a measured replicate noise; and (iv) a commuting "
    "control arm, realised by perturbations whose effects are known to be additive. Pre-registration should fix the sample size by a power "
    "calculation based on the replicate noise, the choice of step size, and the held-out split. The analysis plan should state, before data "
    "collection, which of P1 to P5 counts as the primary outcome."))
story.append(H2("8.3  Failure conditions"))
story.append(P(
    "The programme fails if the order effect in the main arm is indistinguishable from the replicate noise, or if the commuting control "
    "shows the same order effect. Either outcome would show that the generator structure of Section 3 does not describe the system at the "
    "measured scale. Either outcome is a useful result. A null on P1 does not refute the mathematics, but it does rule out the model for "
    "that system."))

# ================================================================= 9
story.append(H1("9  Limitations"))
for t in [
    "<b>Model class.</b> The generators are two fixed matrices in su(2). Real transport is likely to involve many generators, state-dependent "
    "generators, and dissipation. Each of these changes the analysis.",
    "<b>Noise and ceiling.</b> The fate label carries 10% noise, which caps achievable AUC near 0.90. The ceiling is a property of the "
    "experiment and not of the predictors.",
    "<b>Predictors.</b> The order-aware predictors are logistic models on features that were designed with the answer in view: the Lévy area "
    "is the second signature level, and the positional model is the natural generic alternative. A neural operator was not trained.",
    "<b>Single observable and state.</b> The main experiment uses one chosen pair. Section 5.8 shows its results are atypical of the family, "
    "and the main claims are restricted accordingly.",
    "<b>Discrete p-atic model.</b> The lattice experiments use a small grid with planted defects. A real director field has thermal and "
    "active fluctuations, defect creation and annihilation, and a non-flat metric. None of these is included.",
    "<b>Sample sizes.</b> The predictor comparison uses eight splits per sample size, so the reported spreads are coarse.",
    "<b>Literature.</b> The literature search was not exhaustive. Novelty is claimed only to the authors' knowledge."]:
    story.append(P(t))

# ================================================================= 10
story.append(H1("10  Open problems"))
for t in [
    "<b>Problem 1 (dihedral extension).</b> Determine the holonomy of p-atic defects when the director may reverse orientation, and prove "
    "or refute that two defects with charges not divisible by p generate noncommuting holonomy. This is Conjecture 1.",
    "<b>Problem 2 (signature sufficiency).</b> Characterise the class of transport models for which the fate is a function of the second "
    "signature level, and find the smallest additional data that resolves the ambiguity at area 0.5 in Section 5.7.",
    "<b>Problem 3 (neural operator baseline).</b> Train a neural operator on forward intervention histories and measure its counterfactual "
    "reversal accuracy against the Lévy-area baseline, with matched parameter budgets.",
    "<b>Problem 4 (sample complexity of order).</b> Determine the number of ordered histories needed to estimate the order effect to a given "
    "precision, as a function of the step size and the replicate noise.",
    "<b>Problem 5 (active fluctuations).</b> Extend the discrete connection to a stochastic transport with active noise, and determine how "
    "the area law of Theorem 2 is renormalised by the noise."]:
    story.append(P(t))

# ================================================================= 11
story.append(H1("11  Discussion and scope"))
story.append(P(
    "The paper's central message is conditional and modest. If intervention order matters to a system, and if the order dependence comes "
    "from noncommuting transport, then the dependence is a curvature with a precise leading-order law and a compact order statistic. The "
    "mathematics that makes this precise is standard. Its application is new only in the composition. The p-atic defect sector is a "
    "secondary ingredient: it carries quantised charge and localises it, but on its own it does not generate the noncommutativity that the "
    "proposal sought. Recognising that is part of the result."))
story.append(P(
    "We make no claim about organisms, tissues, or patients. The mathematics concerns models with two generators and a small lattice. The "
    "falsification programme of Section 8 is the route by which the model could acquire biological content, and it has not been run."))

# ================================================================= 12
story.append(H1("12  Conclusion"))
story.append(P(
    "We have formulated intervention-order dependence as curvature, proved the leading-order order effect and the area law, shown that "
    "plaquette holonomy is gauge invariant, and identified the Z<sub>p</sub> sector of p-atic order as Abelian. A balanced-exposure "
    "identifiability result reduces order information to the Lévy area, and a counterfactual reversal law gives a sharp test. In numerical "
    "experiments, the order effect scales as predicted, gauge invariance holds at machine precision, the discrete Stokes identity recovers "
    "every planted charge, a commuting control is order-blind, and for the chosen pair a one-feature Lévy-area model matches a much larger "
    "positional model. A sweep over generic pairs shows that the strong fate-level effects are not typical, and that the Lévy sign is not a "
    "general predictor of fate. "
    "The causal operator named in the proposal was not built, and the counterfactual test was implemented in its place. The remaining "
    "problems are stated precisely in Section 10."))

# ================================================================= Appendix A
story.append(H1("Appendix A  Proofs"))
story.append(P(
    "<b>Proof of Theorem 1.</b> Expand e<super>εX</super>e<super>εY</super> = (I + εX + ε²X²/2 + O(ε³))(I + εY + ε²Y²/2 + O(ε³)) = I + ε(X + Y) + "
    "ε²(X²/2 + XY + Y²/2) + O(ε³). Interchanging the roles of X and Y gives I + ε(X + Y) + ε²(X²/2 + YX + Y²/2) + O(ε³). Subtracting, "
    "the difference is ε²(XY − YX) + O(ε³) = ε²[X, Y] + O(ε³). ∎"))
story.append(P(
    "<b>Proof of Theorem 2.</b> Write Ad<sub>g</sub>Z = gZg<super>−1</super>. Then e<super>aX</super>e<super>bY</super>e<super>−aX</super> = exp(b Ad<sub>e<super>aX</super></sub>Y), and "
    "Ad<sub>e<super>aX</super></sub>Y = Y + a[X, Y] + O(a²). Hence the word equals exp(bY + ab[X, Y] + O(a²b, b²a)). Multiplying by e<super>−bY</super> and "
    "applying the Baker–Campbell–Hausdorff formula gives I + ab[X, Y] + O((a+b)³). ∎"))
story.append(P(
    "<b>Proof of Theorem 3.</b> Let the plaquette at site a have boundary links U<sub>1</sub> = U<sub>ab</sub>, U<sub>2</sub>, U<sub>3</sub>, U<sub>4</sub> in cyclic order, "
    "so that W = U<sub>1</sub>U<sub>2</sub>U<sub>3</sub>U<sub>4</sub>. Under the gauge transformation each link U<sub>ab</sub> becomes g<sub>a</sub>U<sub>ab</sub>g<sub>b</sub><super>−1</super>. "
    "Adjacent factors telescope: g<sub>b</sub><super>−1</super>g<sub>b</sub> = I. The product therefore becomes g<sub>a</sub>Wg<sub>a</sub><super>−1</super>, and tr is invariant "
    "by cyclicity. ∎"))
story.append(P(
    "<b>Proof of Proposition 4.</b> Each interior link appears in the boundaries of two adjacent plaquettes with opposite orientations, and "
    "n<sub>ba</sub> = −n<sub>ab</sub> because round(−x) = −round(x) away from half-integers. Summing the boundary integers of all plaquettes in R "
    "therefore cancels every interior link and leaves the boundary of R. ∎"))
story.append(P(
    "<b>Proof of Proposition 5.</b> Given in Section 4. The counts give S<sup>MC</sup> + S<sup>CM</sup> = 9 for any balanced word, and the antisymmetric "
    "part determines the difference, so the second level is a function of A(w) alone. ∎"))
story.append(P(
    "<b>Proof of Proposition 6.</b> Under reversal, a pair of positions (i, j) with i < j and letters (M, C) maps to positions (L+1−j, L+1−i) "
    "with letters (C, M). Each MC pair becomes a CM pair and conversely, so #MC and #CM are exchanged and A changes sign. For the commuting "
    "null model the total unitary depends only on the counts, and since the counts are fixed, reversal leaves the final state unchanged. ∎"))
story.append(P(
    "<b>Remark on Theorem 1 and the order effect in Section 5.</b> The numerical exponent of 2 is the expansion order of Theorem 1. The "
    "statement holds for the normed difference of the two transports, which is the quantity computed."))

# ================================================================= Appendix B
story.append(H1("Appendix B  Parameters, seeds and protocol"))
rows = [["Experiment", "Parameters", "Sampling"],
        ["E1 order and area", "generators X, Y in su(2); step sizes 0.01 to 0.25 (14 values); rectangles with sides s, 1.5s", "exact matrix exponentials"],
        ["E2 gauge invariance", "8 × 8 periodic lattice; link generators scale 0.8; gauge scale 1.0", "400 random plaquettes"],
        ["E3 p-atic Stokes", "64 × 64 grid; p = 2, 3, 4, 6; 1 to 3 defects of charge in {−2, −1, 1, 2}; field noise 0.02", "294 loops in total"],
        ["E4 fate and order", "ε = 0.6; initial state (cos a, e<super>ib</super> sin a), a = 0.3238, b = 2.8074; observable n = (0.334, −0.942, 0.014); label noise 0.1", "4000 histories for flips; N = 100 to 6400, 8 splits"],
        ["E4 counterfactual", "trained on 6400 forward histories, scored on reversed histories", "noiseless reversed outcomes"],
        ["E5 mechanism", "6400 balanced histories, noiseless outcomes", "tabulated by Lévy area"]]
story.append(TABLE(rows, [3.4, 9.0, 3.6]))
story.append(P("<b>Table 4.</b> Experimental parameters. Seed 20261110 throughout.", cap))
story.append(P(
    "<b>Reproduction.</b> Run <font face='Mono'>python code/morpho_experiments.py</font> from the release folder, then "
    "<font face='Mono'>python code/build_paper.py</font>. The run takes a few minutes on one core."))

# ================================================================= Appendix C
story.append(H1("Appendix C  Disclosure and corrections"))
story.append(P(
    "<b>AI assistance.</b> The simulations, figures and manuscript text were produced with the assistance of Claude (Anthropic) under the "
    "direction of the authors, who define the research question and are responsible for the content. Xylia is the authors' AI research "
    "scientist. Competing interests: none declared. Funding: none."))
story.append(P(
    "<b>Corrections made during the study.</b> (i) The initial proposal located non-Abelian holonomy in the p-atic defect sector. The "
    "algebra shows the sector is Abelian, and the paper places the non-Abelian content in the transport generators, with the dihedral "
    "extension as a conjecture. (ii) The first run of the order experiment used a symmetric initial state and observable, and reversal "
    "changed no fate; the setup was changed and the reason is reported in Section 5.4. (iii) The first discrete Stokes check used the "
    "wrong modulus for the link integers and returned 69% agreement; after correcting the modulus and the loop orientation, agreement is exact "
    "over all loops. (iv) A preliminary label-noise description did not state the ceiling on AUC; the ceiling is now computed and reported."))
story.append(P(
    "<b>Literature.</b> The literature search was not exhaustive, and novelty is claimed only to the authors' knowledge. Reports of "
    "partial restoration of function in post-mortem tissue, which motivated earlier versions of this programme, are not used here."))

# ================================================================= references
story.append(H1("References"))
refs = [
    "Ambrose W, Singer IM (1953) A theorem on holonomy. Trans Am Math Soc 75:428–443.",
    "Baker HF (1905), Campbell JE (1897), Hausdorff F (1906). Baker–Campbell–Hausdorff formula (classical).",
    "Bowick MJ, Giomi L (2009) Two-dimensional matter: order, curvature and defects. Adv Phys 58:449–563.",
    "Chen KT (1958) Integration of paths, geometric invariants and a generalized Baker–Hausdorff formula. Ann Math 65:163–178.",
    "Kamien RD (2002) The geometry of soft materials: a primer. Rev Mod Phys 74:953–971.",
    "Kobayashi S, Nomizu K (1963) Foundations of Differential Geometry, Vol. I. Wiley.",
    "Kovachki N, Li Z, Liu B, Azizzadenesheli K, Bhattacharya K, Stuart A, Anandkumar A (2023) Neural operator: learning maps between function spaces. J Mach Learn Res 24:1–97.",
    "Li Z, Kovachki N, Azizzadenesheli K, Liu B, Bhattacharya K, Stuart A, Anandkumar A (2021) Fourier neural operator for parametric partial differential equations. Proc ICLR.",
    "Lévy P (1951) Wiener's random function, and other Laplacian random functions. Proc Second Berkeley Symp Math Stat Prob 171–187.",
    "Lyons TJ (1998) Differential equations driven by rough signals. Rev Mat Iberoam 14:215–310.",
    "Mermin ND (1979) The topological theory of defects in ordered media. Rev Mod Phys 51:591–648.",
    "Pearl J (2009) Causality: Models, Reasoning and Inference, 2nd ed. Cambridge University Press.",
    "Wilson KG (1974) Confinement of quarks. Phys Rev D 10:2445–2459.",
    "Yang CN, Mills RL (1954) Conservation of isotopic spin and isotopic gauge invariance. Phys Rev 96:191–195.",
]
for r in refs:
    story.append(P(r, small))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Sans", 7)
    canvas.setFillColor(GREY)
    canvas.drawString(2.0 * cm, 1.2 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 9 Nov 2026")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"{doc.page}")
    canvas.restoreState()


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2.0 * cm, rightMargin=2.0 * cm, topMargin=1.8 * cm,
                            bottomMargin=1.9 * cm,
                            title="The Non-Abelian Geometry of Morphogenesis", author="Devanik Debnath; Xylia",
                            subject="Preprint v1.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    from pypdf import PdfReader
    print("wrote", OUT, "pages", len(PdfReader(OUT).pages))
