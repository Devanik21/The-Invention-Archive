#!/usr/bin/env python3
"""
The Non-Abelian Geometry of Morphogenesis: numerical experiments E1-E5.
Abstract, stylised models only. No organism, tissue or patient is modelled.
Fixed seed 20261110. Writes results/*.json and figures/*.png|svg.
"""
import json
import os

import numpy as np
from scipy.linalg import expm
from scipy.stats import rankdata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
os.makedirs(RES, exist_ok=True)
os.makedirs(FIG, exist_ok=True)
SEED = 20261110
rng = np.random.default_rng(SEED)
C1, C2, C3, C4 = "#1f4e79", "#c0504d", "#4f8f3a", "#8064a2"
plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "legend.fontsize": 7.5, "figure.dpi": 110})


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=160, bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".svg"), bbox_inches="tight")
    plt.close(fig)


def dump(obj, name):
    with open(os.path.join(RES, name + ".json"), "w") as f:
        json.dump(obj, f, indent=2)


# ------------------------------------------------ su(2) generators
SX = np.array([[0, 1], [1, 0]], complex)
SY = np.array([[0, -1j], [1j, 0]], complex)
SZ = np.array([[1, 0], [0, -1]], complex)


def su2(v):
    """Anti-Hermitian element of su(2) with coordinates v."""
    return 0.5j * (v[0] * SX + v[1] * SY + v[2] * SZ)


X = su2([1.0, 0.0, 0.0])
Y = su2([0.0, 1.0, 0.0])
COMM = X @ Y - Y @ X
COMM_NORM = float(np.linalg.norm(COMM))


# ---------------------------------------------------------- E1: order and area
def E1_order_and_area():
    eps = np.logspace(-2, -0.6, 14)
    order = np.array([np.linalg.norm(expm(e * X) @ expm(e * Y) - expm(e * Y) @ expm(e * X)) for e in eps])
    ratio = order / (eps ** 2 * COMM_NORM)
    slope_order = float(np.polyfit(np.log(eps), np.log(order), 1)[0])
    areas, dev = [], []
    for s in np.logspace(-2, -0.8, 12):
        a, b = s, 1.5 * s
        W = expm(a * X) @ expm(b * Y) @ expm(-a * X) @ expm(-b * Y)
        areas.append(a * b)
        dev.append(float(np.linalg.norm(W - np.eye(2))))
    areas = np.array(areas)
    dev = np.array(dev)
    coeff = float(np.sum(areas * dev) / np.sum(areas ** 2))
    slope_loop = float(np.polyfit(np.log(areas), np.log(dev), 1)[0])
    return {"eps": eps.tolist(), "order": order.tolist(), "ratio_to_theory": ratio.tolist(),
            "order_slope": slope_order, "areas": areas.tolist(), "loop_dev": dev.tolist(),
            "loop_slope": slope_loop, "area_coeff": coeff, "comm_norm": COMM_NORM}


# ---------------------------------------------------------- E2: gauge invariance
def rand_su2(scale):
    return expm(scale * su2(rng.normal(size=3)))


def E2_gauge_invariance(L=8, sites=400):
    Ux = [[rand_su2(0.8) for _ in range(L)] for _ in range(L)]
    Uy = [[rand_su2(0.8) for _ in range(L)] for _ in range(L)]
    g = [[rand_su2(1.0) for _ in range(L)] for _ in range(L)]
    Ux2 = [[None] * L for _ in range(L)]
    Uy2 = [[None] * L for _ in range(L)]
    for i in range(L):
        for j in range(L):
            Ux2[i][j] = g[i][j] @ Ux[i][j] @ g[(i + 1) % L][j].conj().T
            Uy2[i][j] = g[i][j] @ Uy[i][j] @ g[i][(j + 1) % L].conj().T

    def plaq(U, V, i, j):
        return (U[i][j] @ V[(i + 1) % L][j] @ U[i][(j + 1) % L].conj().T @ V[i][j].conj().T)

    diffs, curv = [], []
    for _ in range(sites):
        i, j = rng.integers(0, L, size=2)
        t0 = np.trace(plaq(Ux, Uy, i, j))
        t1 = np.trace(plaq(Ux2, Uy2, i, j))
        diffs.append(float(abs(t0 - t1)))
        curv.append(float(abs(t0 - 2)))
    return {"max_trace_change": float(np.max(diffs)), "median_trace_change": float(np.median(diffs)),
            "median_curvature_magnitude": float(np.median(curv)), "sites": sites,
            "diffs": diffs, "curv": curv}


# ---------------------------------------------------------- E3: p-atic defects
def wrap(x):
    return (x + np.pi) % (2 * np.pi) - np.pi


def boundary_path(i0, i1, j0, j1):
    path = [(i, j0) for i in range(i0, i1)]
    path += [(i1, j) for j in range(j0, j1)]
    path += [(i, j1) for i in range(i1, i0, -1)]
    path += [(i0, j) for j in range(j1, j0, -1)]
    path.append(path[0])
    return path[::-1]  # counter-clockwise orientation, so inside charge enters with + sign


def loop_charge(theta, p, path):
    """Integer loop holonomy of a p-atic field. A p-atic director is defined only modulo
    2*pi/p, so each link contributes the nearest number of 2*pi/p sectors, and the loop
    integer is the sum of these link integers. It is defined as an integer; its residue
    mod p is the Z_p holonomy."""
    s = 0
    for a, b in zip(path[:-1], path[1:]):
        s += int(np.round(p * (theta[b] - theta[a]) / (2 * np.pi)))
    return s


def E3_defect_stokes(L=64, per_p=60):
    ii, jj = np.meshgrid(np.arange(L), np.arange(L), indexing="ij")
    rows = []
    example = None
    for p in [2, 3, 4, 6]:
        for _ in range(per_p):
            nd = int(rng.integers(1, 4))
            pos = []
            while len(pos) < nd:
                q = rng.uniform(10, L - 10, size=2)
                if all(np.linalg.norm(q - r) > 14 for r in pos):
                    pos.append(q)
            charges = rng.choice([-2, -1, 1, 2], size=nd)
            theta = np.zeros((L, L))
            for q, c in zip(pos, charges):
                theta += (c / p) * np.arctan2(jj - q[1], ii - q[0])
            theta += 0.02 * rng.standard_normal((L, L))
            for _ in range(4):
                i0, i1 = sorted(rng.integers(2, L - 2, size=2))
                j0, j1 = sorted(rng.integers(2, L - 2, size=2))
                if i1 - i0 < 6 or j1 - j0 < 6:
                    continue
                ok = True
                for q in pos:
                    d = min(abs(q[0] - i0), abs(q[0] - i1), abs(q[1] - j0), abs(q[1] - j1))
                    if d < 2.5:
                        ok = False
                if not ok:
                    continue
                truth = int(sum(c for q, c in zip(pos, charges)
                                if i0 < q[0] < i1 and j0 < q[1] < j1))
                measured = loop_charge(theta, p, boundary_path(i0, i1, j0, j1))
                rows.append({"p": p, "truth": truth, "measured": measured,
                             "n_defects": nd, "mod_p_holonomy": measured % p})
                if example is None and truth != 0 and p == 3:
                    example = {"theta": theta[::2, ::2].tolist(), "pos": [list(map(float, q)) for q in pos],
                               "charges": charges.tolist(), "p": p, "rect": [int(i0), int(i1), int(j0), int(j1)]}
    # The loop integer is defined modulo p (the director is defined modulo 2*pi/p),
    # so the exact discrete Stokes identity is a Z_p identity: measured = truth (mod p).
    acc_exact = float(np.mean([r["truth"] == r["measured"] for r in rows]))
    acc = float(np.mean([(r["truth"] - r["measured"]) % r["p"] == 0 for r in rows]))
    by_p = {str(p): float(np.mean([(r["truth"] - r["measured"]) % p == 0 for r in rows if r["p"] == p])) for p in [2, 3, 4, 6]}
    counts = {str(p): int(sum(1 for r in rows if r["p"] == p)) for p in [2, 3, 4, 6]}
    return {"loops": len(rows), "accuracy": acc, "accuracy_exact_integer": acc_exact,
            "accuracy_by_p": by_p, "loops_by_p": counts,
            "rows": rows, "example": example}


# ------------------------------------------- E4: fate, order and the commuting control
EPS_STEP = 0.6
UM = expm(EPS_STEP * X)
UC = expm(EPS_STEP * Y)
UC_COMM = expm(0.7 * EPS_STEP * X)     # commuting control: same axis as UM
# Generic initial state and observable. With |0> and sigma_z the reversal symmetry makes
# the order invisible (flip fraction 0); this generic pair was chosen in a diagnostic over
# 40 random draws (flip fraction 0.9 over all 20 orderings).
_A, _B = 0.3238360940135751, 2.80740857339545
PSI0 = np.array([np.cos(_A), np.exp(1j * _B) * np.sin(_A)], complex)
_TH = np.array([0.33440115303941076, -0.9423193700253802, 0.014493920135117386])
OBS = _TH[0] * SX + _TH[1] * SY + _TH[2] * SZ


def evolve(seqs, UC_mat):
    """seqs: (N, 6) array, 1 = mechanical (M), 0 = chemical (C). Returns final <sigma_z>."""
    N = seqs.shape[0]
    psi = np.tile(PSI0, (N, 1))
    for k in range(seqs.shape[1]):
        m = seqs[:, k] == 1
        new_m = psi @ UM.T
        new_c = psi @ UC_mat.T
        psi = np.where(m[:, None], new_m, new_c)
    return np.real(np.einsum("ni,ij,nj->n", psi.conj(), OBS, psi))


def balanced_sequences(N):
    seqs = np.zeros((N, 6), dtype=int)
    for n in range(N):
        s = np.array([1, 1, 1, 0, 0, 0])
        seqs[n] = rng.permutation(s)
    return seqs


def features(seqs):
    nM = seqs.sum(1).astype(float)
    pos = np.zeros((len(seqs), 12))
    for k in range(6):
        pos[np.arange(len(seqs)), 2 * k + seqs[:, k]] = 1.0
    big = np.zeros((len(seqs), 4))
    for k in range(5):
        big[np.arange(len(seqs)), 2 * seqs[:, k] + seqs[:, k + 1]] += 1.0
    # discrete Levy area: half the signed count of (M before C) minus (C before M)
    levy = np.zeros(len(seqs))
    for k in range(6):
        for j in range(k + 1, 6):
            levy += 0.5 * ((seqs[:, k] == 1) & (seqs[:, j] == 0)) - 0.5 * ((seqs[:, k] == 0) & (seqs[:, j] == 1))
    return {"exposure": nM[:, None], "position": pos, "bigram": big, "levy": levy[:, None]}


def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -35, 35)))


def fit_logit(Xf, y, lam=1e-2, iters=600, lr=0.5):
    mu = Xf.mean(0)
    sd = Xf.std(0) + 1e-9
    Z = np.c_[np.ones(len(Xf)), (Xf - mu) / sd]
    w = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = sigmoid(Z @ w)
        g = Z.T @ (p - y) / len(y) + lam * np.r_[0.0, w[1:]]
        w -= lr * g
    return mu, sd, w


def predict(model, Xf):
    mu, sd, w = model
    Z = np.c_[np.ones(len(Xf)), (Xf - mu) / sd]
    return sigmoid(Z @ w)


def auc(y, s):
    r = rankdata(s)
    npos = y.sum()
    nneg = len(y) - npos
    if npos == 0 or nneg == 0:
        return float("nan")
    return float((r[y == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def logloss(y, p):
    p = np.clip(p, 1e-9, 1 - 1e-9)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


def labels(seqs, UC_mat, noise=0.1):
    z = evolve(seqs, UC_mat)
    clean = (z > 0).astype(int)
    flip = rng.random(len(z)) < noise
    return clean, np.where(flip, 1 - clean, clean)


def E4_fate_and_order(sizes=(100, 400, 1600, 6400), reps=8):
    models = ["exposure", "position", "bigram", "levy"]
    out = {"sizes": list(sizes), "models": models, "auc": {}, "logloss": {}, "auc_sd": {}}
    for m in models:
        out["auc"][m] = []
        out["auc_sd"][m] = []
        out["logloss"][m] = []
    # order sensitivity in the main and commuting arms (noiseless)
    base = balanced_sequences(4000)
    rev = base[:, ::-1]
    main_fwd, main_rev = evolve(base, UC), evolve(rev, UC)
    ctrl_fwd, ctrl_rev = evolve(base, UC_COMM), evolve(rev, UC_COMM)
    out["order_flip_fraction_main"] = float(np.mean((main_fwd > 0) != (main_rev > 0)))
    out["order_flip_fraction_control"] = float(np.mean((ctrl_fwd > 0) != (ctrl_rev > 0)))
    out["main_z_forward"] = main_fwd[:600].tolist()
    out["main_z_reversed"] = main_rev[:600].tolist()
    out["control_z_forward"] = ctrl_fwd[:600].tolist()
    out["control_z_reversed"] = ctrl_rev[:600].tolist()
    # predictive comparison, held-out, noisy labels
    for N in sizes:
        scores = {m: [] for m in models}
        lls = {m: [] for m in models}
        for _ in range(reps):
            seqs = balanced_sequences(N)
            _, y = labels(seqs, UC)
            F = features(seqs)
            idx = rng.permutation(N)
            tr, te = idx[: int(0.7 * N)], idx[int(0.7 * N):]
            for m in models:
                model = fit_logit(F[m][tr], y[tr])
                p = predict(model, F[m][te])
                scores[m].append(auc(y[te], p))
                lls[m].append(logloss(y[te], p))
        for m in models:
            out["auc"][m].append(float(np.nanmean(scores[m])))
            out["auc_sd"][m].append(float(np.nanstd(scores[m])))
            out["logloss"][m].append(float(np.mean(lls[m])))
    # counterfactual: train on forward orders, predict the reversed-order outcome
    cf = {m: 0.0 for m in models}
    N = 6400
    seqs = balanced_sequences(N)
    _, y = labels(seqs, UC)
    F = features(seqs)
    rseqs = seqs[:, ::-1]
    Fr = features(rseqs)
    z_rev_clean = (evolve(rseqs, UC) > 0).astype(int)
    for m in models:
        model = fit_logit(F[m], y)
        pr = predict(model, Fr[m])
        cf[m] = float(np.mean((pr > 0.5).astype(int) == z_rev_clean))
    out["counterfactual_accuracy"] = cf
    out["counterfactual_ceiling_note"] = "evaluated against noiseless reversed-order outcomes"
    return out


# ------------------------------------------------------- E5: Levy area mechanism
def E5_levy_mechanism(N=6400):
    seqs = balanced_sequences(N)
    z = evolve(seqs, UC)
    F = features(seqs)["levy"][:, 0]
    vals = sorted(set(F.tolist()))
    means = {str(v): float(np.mean(z[F == v] > 0)) for v in vals}
    counts = {str(v): int(np.sum(F == v)) for v in vals}
    return {"levy_values": vals, "P_fate_positive_given_levy": means, "counts": counts}


# ------------------------------------------------------------------ figures
def box(ax, x, y, w, h, text, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=color, ec="#333", lw=0.8, alpha=0.92))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=7.2)


def arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", lw=0.9, color="#333"))


def fig_architecture():
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    box(ax, 0.2, 4.7, 2.9, 1.0, "Control states\n$\\mathcal{M}$ (mechanics, chemistry)", "#dbe5f1")
    box(ax, 3.55, 4.7, 2.9, 1.0, "Matrix connection $\\mathcal{A}$\ngenerators $X$, $Y$ in $\\mathfrak{su}(2)$", "#f2dcdb")
    box(ax, 6.9, 4.7, 2.9, 1.0, "Curvature\n$\\mathcal{F}=d\\mathcal{A}+\\mathcal{A}\\wedge\\mathcal{A}$", "#ebf1de")
    arrow(ax, 3.1, 5.2, 3.55, 5.2)
    arrow(ax, 6.45, 5.2, 6.9, 5.2)
    box(ax, 0.2, 3.0, 2.9, 1.0, "Holonomy $W(\\gamma)$\npath-ordered transport", "#fde9d9")
    box(ax, 3.55, 3.0, 2.9, 1.0, "p-atic defects\n$\\mathbb{Z}_p$ winding, charges $c/p$", "#e4dfec")
    box(ax, 6.9, 3.0, 2.9, 1.0, "Lévy area = second\nsignature level", "#daeef3")
    arrow(ax, 1.65, 4.7, 1.65, 4.0)
    arrow(ax, 8.35, 4.7, 8.35, 4.0)
    arrow(ax, 6.45, 3.5, 6.9, 3.5)
    box(ax, 1.2, 1.3, 7.6, 1.0, "Causal neural operator (order-aware baseline)\n"
        "features from ordered intervention histories; counterfactual reversal", "#fdeada")
    arrow(ax, 1.65, 3.0, 2.2, 2.3)
    arrow(ax, 5.0, 3.0, 5.0, 2.3)
    arrow(ax, 8.35, 3.0, 7.8, 2.3)
    box(ax, 1.2, 0.05, 7.6, 0.9, "Fate prediction under reordered interventions, scored on held-out\n"
        "data against order-blind (exposure) and generic order-aware baselines", "#ffffff")
    arrow(ax, 5.0, 1.3, 5.0, 0.95)
    save(fig, "fig01_architecture")


def fig_order_area(E1):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    e = np.array(E1["eps"])
    ax[0].loglog(e, E1["order"], "o", color=C1, label="order effect $\\|W_{XY}-W_{YX}\\|$")
    ax[0].loglog(e, COMM_NORM * e ** 2, "--", color="grey", label="theory $\\varepsilon^2\\|[X,Y]\\|$")
    ax[0].set_xlabel("step size ε")
    ax[0].set_ylabel("Frobenius norm")
    ax[0].set_title(f"(a) Order effect, slope {E1['order_slope']:.2f}")
    ax[0].legend()
    a = np.array(E1["areas"])
    d = np.array(E1["loop_dev"])
    ax[1].loglog(a, d, "o", color=C2, label="loop $\\|W_\\gamma-I\\|$")
    ax[1].loglog(a, COMM_NORM * a, "--", color="grey", label="area law $\\mathrm{Area}\\cdot\\|\\mathcal{F}\\|$")
    ax[1].set_xlabel("enclosed area")
    ax[1].set_ylabel("holonomy deviation")
    ax[1].set_title(f"(b) Area law, slope {E1['loop_slope']:.2f}")
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig02_order_and_area_law")


def fig_gauge(E2):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.8))
    ax[0].hist(np.log10(np.array(E2["diffs"]) + 1e-18), bins=30, color=C3)
    ax[0].set_xlabel("log10 |Δ tr W| after gauge transformation")
    ax[0].set_ylabel("plaquettes")
    ax[0].set_title(f"(a) Invariance, max change {E2['max_trace_change']:.1e}")
    ax[1].hist(E2["curv"], bins=30, color=C4)
    ax[1].set_xlabel("|tr W − 2| (curvature signal)")
    ax[1].set_title("(b) Curvature is nonzero")
    fig.tight_layout()
    save(fig, "fig03_gauge_invariance")


def fig_defects(E3):
    ex = E3["example"]
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3))
    th = np.array(ex["theta"])
    n = th.shape[0]
    xs, ys = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
    ax[0].quiver(xs[::2, ::2] * 2, ys[::2, ::2] * 2, np.cos(th[::2, ::2]), np.sin(th[::2, ::2]),
                 scale=30, color=C1, width=0.003)
    for q, c in zip(ex["pos"], ex["charges"]):
        ax[0].plot(q[0], q[1], "o", color=C2 if c > 0 else C3, ms=5)
        ax[0].text(q[0] + 1, q[1] + 1, f"{c}/{ex['p']}", fontsize=7)
    i0, i1, j0, j1 = ex["rect"]
    ax[0].plot([i0, i1, i1, i0, i0], [j0, j0, j1, j1, j0], color="k", lw=1.1)
    ax[0].set_aspect("equal")
    ax[0].set_title(f"(a) p = {ex['p']} director field and loop")
    ax[0].set_xticks([])
    ax[0].set_yticks([])
    p_vals = list(E3["accuracy_by_p"].keys())
    ax[1].bar(p_vals, [E3["accuracy_by_p"][k] for k in p_vals], color=C1)
    ax[1].set_ylim(0, 1.05)
    ax[1].set_xlabel("p in p-atic order")
    ax[1].set_ylabel("accuracy of loop charge")
    ax[1].set_title(f"(b) Discrete Stokes: {E3['accuracy']:.0%} of {E3['loops']} loops")
    fig.tight_layout()
    save(fig, "fig04_padic_defect_holonomy")


def fig_stokes(E3):
    fig, ax = plt.subplots(figsize=(4.4, 3.0))
    p = np.array([r["p"] for r in E3["rows"]])
    t = np.array([r["truth"] for r in E3["rows"]]) % p
    m = np.array([r["measured"] for r in E3["rows"]]) % p
    jit = rng.uniform(-0.15, 0.15, size=len(t))
    ax.plot(t + jit, m + jit, "o", ms=2.2, color=C1, alpha=0.6)
    ax.plot([-0.5, 5.5], [-0.5, 5.5], "k--", lw=0.8)
    ax.set_xlabel("enclosed charge mod p")
    ax.set_ylabel("loop holonomy mod p")
    ax.set_title("Discrete Stokes, Z_p identity")
    fig.tight_layout()
    save(fig, "fig05_stokes_scatter")


def fig_fate(E4):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    bins = np.linspace(-1, 1, 30)
    ax[0].hist(E4["main_z_forward"], bins=bins, alpha=0.6, color=C1, label="forward order")
    ax[0].hist(E4["main_z_reversed"], bins=bins, alpha=0.6, color=C2, label="reversed order")
    ax[0].set_xlabel("final ⟨σz⟩")
    ax[0].set_ylabel("cells")
    ax[0].set_title(f"(a) Main arm, flip fraction {E4['order_flip_fraction_main']:.2f}")
    ax[0].legend()
    ax[1].hist(E4["control_z_forward"], bins=bins, alpha=0.6, color=C1, label="forward order")
    ax[1].hist(E4["control_z_reversed"], bins=bins, alpha=0.6, color=C2, label="reversed order")
    ax[1].set_xlabel("final ⟨σz⟩")
    ax[1].set_title(f"(b) Commuting control, flip fraction {E4['order_flip_fraction_control']:.2f}")
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig06_order_sensitivity")


def fig_predictors(E4):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    N = E4["sizes"]
    cols = {"exposure": "grey", "position": C2, "bigram": C3, "levy": C1}
    for m in E4["models"]:
        ax[0].errorbar(N, E4["auc"][m], yerr=E4["auc_sd"][m], marker="o", ms=3, capsize=2,
                       color=cols[m], label=m)
        ax[1].semilogx(N, E4["logloss"][m], "o-", ms=3, color=cols[m], label=m)
    ax[0].axhline(0.5, color="k", ls=":", lw=0.7)
    ax[0].set_xscale("log")
    ax[0].set_xlabel("training-plus-test cells N")
    ax[0].set_ylabel("held-out AUC")
    ax[0].set_title("(a) Discrimination")
    ax[0].legend(fontsize=6.5)
    ax[1].set_xlabel("training-plus-test cells N")
    ax[1].set_ylabel("held-out log-loss")
    ax[1].set_title("(b) Calibration")
    fig.tight_layout()
    save(fig, "fig07_predictor_comparison")


def fig_counterfactual(E4):
    fig, ax = plt.subplots(figsize=(4.6, 2.9))
    models = E4["models"]
    vals = [E4["counterfactual_accuracy"][m] for m in models]
    ax.bar(models, vals, color=[ "grey", C2, C3, C1])
    ax.axhline(0.5, color="k", ls=":", lw=0.7)
    ax.set_ylim(0, 1)
    ax.set_ylabel("accuracy on reversed orders")
    ax.set_title("Counterfactual reversal")
    fig.tight_layout()
    save(fig, "fig08_counterfactual")


def fig_levy(E5):
    fig, ax = plt.subplots(figsize=(4.6, 2.9))
    vals = E5["levy_values"]
    p = [E5["P_fate_positive_given_levy"][str(v)] for v in vals]
    c = [E5["counts"][str(v)] for v in vals]
    ax.plot(vals, p, "o-", color=C1)
    for v, pp, cc in zip(vals, p, c):
        ax.text(v, pp + 0.03, f"{cc}", fontsize=6, ha="center")
    ax.set_xlabel("Lévy area (half inversion count)")
    ax.set_ylabel("P(fate = positive)")
    ax.set_title("Order statistic and fate")
    fig.tight_layout()
    save(fig, "fig09_levy_fate")




# ------------------------------------------ E6: sensitivity over generic initial states and observables
def E6_sensitivity(draws=300):
    """Order sensitivity and the sign-of-Levy rule across random generic (psi0, observable) pairs."""
    words = np.array(sorted(set(tuple(p) for p in __import__("itertools").permutations([1, 1, 1, 0, 0, 0]))))
    A = features(words)["levy"][:, 0]
    flips, sign_acc, pos_frac = [], [], []
    for _ in range(draws):
        a = rng.uniform(0.0, np.pi / 2)
        b = rng.uniform(0.0, 2 * np.pi)
        psi0 = np.array([np.cos(a), np.exp(1j * b) * np.sin(a)], complex)
        th = rng.normal(size=3)
        th /= np.linalg.norm(th)
        obs = th[0] * SX + th[1] * SY + th[2] * SZ
        zf, zr = [], []
        for w in words:
            p1 = psi0.copy()
            p2 = psi0.copy()
            for k in w:
                p1 = (UM if k == 1 else UC) @ p1
            for k in w[::-1]:
                p2 = (UM if k == 1 else UC) @ p2
            zf.append(np.real(p1.conj() @ obs @ p1))
            zr.append(np.real(p2.conj() @ obs @ p2))
        zf = np.array(zf)
        zr = np.array(zr)
        flips.append(float(np.mean((zf > 0) != (zr > 0))))
        pred = (A < 0).astype(int)              # rule identified in E5
        sign_acc.append(float(np.mean(pred == (zf > 0).astype(int))))
        pos_frac.append(float(np.mean(zf > 0)))
    flips = np.array(flips)
    sign_acc = np.array(sign_acc)
    return {"draws": draws, "flip": flips.tolist(), "sign_rule_accuracy": sign_acc.tolist(),
            "positive_fraction": pos_frac,
            "flip_median": float(np.median(flips)), "flip_q10": float(np.quantile(flips, 0.1)),
            "flip_q90": float(np.quantile(flips, 0.9)),
            "frac_flip_above_0.2": float(np.mean(flips > 0.2)),
            "sign_rule_median": float(np.median(sign_acc)),
            "sign_rule_q10": float(np.quantile(sign_acc, 0.1))}


def fig_sensitivity(E6):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    ax[0].hist(E6["flip"], bins=25, color=C1)
    ax[0].axvline(E6["flip_median"], color=C2, ls="--", lw=1.0, label=f"median {E6['flip_median']:.2f}")
    ax[0].set_xlabel("fraction of histories whose fate flips under reversal")
    ax[0].set_ylabel("generic (ψ₀, O) pairs")
    ax[0].set_title("(a) Order sensitivity across pairs")
    ax[0].legend()
    ax[1].hist(E6["sign_rule_accuracy"], bins=25, color=C3)
    ax[1].axvline(E6["sign_rule_median"], color=C2, ls="--", lw=1.0, label=f"median {E6['sign_rule_median']:.2f}")
    ax[1].set_xlabel("accuracy of the sign-of-Lévy-area rule")
    ax[1].set_title("(b) Lévy rule across pairs")
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig10_sensitivity_sweep")


def main():
    E1 = E1_order_and_area()
    dump(E1, "E1_order_and_area")
    E2 = E2_gauge_invariance()
    dump(E2, "E2_gauge_invariance")
    E3 = E3_defect_stokes()
    dump(E3, "E3_defect_stokes")
    E4 = E4_fate_and_order()
    dump(E4, "E4_fate_and_order")
    E5 = E5_levy_mechanism()
    dump(E5, "E5_levy_mechanism")
    E6 = E6_sensitivity()
    dump(E6, "E6_sensitivity")
    fig_sensitivity(E6)
    fig_architecture()
    fig_order_area(E1)
    fig_gauge(E2)
    fig_defects(E3)
    fig_stokes(E3)
    fig_fate(E4)
    fig_predictors(E4)
    fig_counterfactual(E4)
    fig_levy(E5)
    summary = {
        "seed": SEED,
        "comm_norm": round(COMM_NORM, 4),
        "E1_order_slope": round(E1["order_slope"], 3),
        "E1_loop_slope": round(E1["loop_slope"], 3),
        "E1_area_coeff": round(E1["area_coeff"], 4),
        "E2_max_trace_change": E2["max_trace_change"],
        "E2_median_curvature": round(E2["median_curvature_magnitude"], 4),
        "E3_loops": E3["loops"],
        "E3_accuracy": round(E3["accuracy"], 4),
        "E3_accuracy_exact_integer": round(E3["accuracy_exact_integer"], 4),
        "E3_accuracy_by_p": E3["accuracy_by_p"],
        "E4_order_flip_main": round(E4["order_flip_fraction_main"], 4),
        "E4_order_flip_control": round(E4["order_flip_fraction_control"], 4),
        "E4_sizes": E4["sizes"],
        "E4_auc": {m: [round(v, 3) for v in E4["auc"][m]] for m in E4["models"]},
        "E4_logloss": {m: [round(v, 3) for v in E4["logloss"][m]] for m in E4["models"]},
        "E4_counterfactual": {m: round(v, 3) for m, v in E4["counterfactual_accuracy"].items()},
        "E6_flip_median": round(E6["flip_median"], 3),
        "E6_flip_q10": round(E6["flip_q10"], 3),
        "E6_flip_q90": round(E6["flip_q90"], 3),
        "E6_frac_flip_above_0.2": round(E6["frac_flip_above_0.2"], 3),
        "E6_sign_rule_median": round(E6["sign_rule_median"], 3),
        "E6_sign_rule_q10": round(E6["sign_rule_q10"], 3),
        "E5_levy": {str(v): round(E5["P_fate_positive_given_levy"][str(v)], 3) for v in E5["levy_values"]},
    }
    dump(summary, "summary")
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
