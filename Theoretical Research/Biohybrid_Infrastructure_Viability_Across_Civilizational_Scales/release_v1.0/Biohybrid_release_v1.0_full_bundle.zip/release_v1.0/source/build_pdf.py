import json, os, re
import numpy as np
import math
import html as _html
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Image,
                                Table, TableStyle, PageBreak, KeepTogether, NextPageTemplate)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.utils import ImageReader

OUT = "/home/claude/build"
FIG = os.path.join(OUT, "figs")
EQD = os.path.join(OUT, "eqs")
os.makedirs(EQD, exist_ok=True)
PDF_PATH = "/mnt/user-data/outputs/Biohybrid_Infrastructure_Viability_Preprint_v1.0.pdf"
os.makedirs("/mnt/user-data/outputs", exist_ok=True)

R = json.load(open(os.path.join(OUT, "results.json")))

# ---- extra figures generated from stored results (used in Sections 4.5, 5.1, 16)
def make_extra_figs():
    NAVY_ = "#1B2A4A"; TEAL_ = "#0F7C86"; CORAL_ = "#E0643E"; GOLD_ = "#E8A33D"; VIOLET_ = "#6B4C9A"; GREEN_ = "#4C9A5B"
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False})
    # thermodynamic floors
    DG_ = {"H2O(l)": -237.1, "CO2(g)": -394.4, "CH4(g)": -50.5, "C6H12O6": -910.0}
    vals = [237.1 / 2.016 / 3.6, 474.2 / 32.0 / 3.6,
            -(DG_["CH4(g)"] - (DG_["CO2(g)"] + 2 * DG_["H2O(l)"])) / 16.04 / 3.6,
            -(DG_["C6H12O6"] - (6 * DG_["CO2(g)"] + 6 * DG_["H2O(l)"])) / 180.16 / 3.6]
    labs = ["H$_2$", "O$_2$", "CH$_4$", "Glucose"]
    fig, ax = plt.subplots(figsize=(6.4, 2.3))
    bars = ax.bar(labs, vals, color=[TEAL_, GREEN_, GOLD_, CORAL_], width=0.55)
    for b_, v_ in zip(bars, vals):
        ax.text(b_.get_x() + b_.get_width() / 2, v_ * 1.05, f"{v_:.2f} kWh/kg", ha="center", fontsize=7.2)
    ax.set_yscale("log"); ax.set_ylabel("minimum work [kWh per kg]")
    ax.set_ylim(0.5, 100)
    ax.set_title("Reversible work floors (route-independent) for four products")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig17_thermo.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)
    # growth-time curves
    gs = np.linspace(0.002, 0.05, 200)
    fig, ax = plt.subplots(figsize=(6.4, 2.5))
    for PT, lab_, c_ in [(1e16, "K = 1", TEAL_), (1e26, "K = 2", CORAL_), (1e36, "K = 3", VIOLET_)]:
        yrs = np.log(PT / 1.9e13) / np.log(1 + gs)
        ax.plot(100 * gs, yrs, color=c_, lw=1.6, label=lab_)
    ax.set_yscale("log"); ax.set_xlabel("constant growth rate of power [% per year]")
    ax.set_ylabel("years from 1.9×10$^{13}$ W"); ax.legend(fontsize=7)
    ax.set_title("Arithmetic growth times to each scenario power (not a forecast)")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig18_growth.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)
    # convergence (Monte Carlo and grid)
    fig, (c1, c2) = plt.subplots(1, 2, figsize=(6.6, 2.4))
    ns = [r_["n"] for r_ in R["conv_mc"]]
    c1.semilogx(ns, [r_["hybrid_share_lam1"] for r_ in R["conv_mc"]], "o-", color=CORAL_, ms=3, lw=1.3, label="hybrid, λ = 1")
    c1.semilogx(ns, [r_["bio_cheaper"] for r_ in R["conv_mc"]], "s-", color=GREEN_, ms=3, lw=1.3, label="bio cheaper (energy)")
    c1.set_xlabel("Monte Carlo draws n"); c1.set_ylabel("share"); c1.legend(fontsize=6.5); c1.set_title("Monte Carlo convergence")
    gN = [r_["Ng"] for r_ in R["conv_grid"]]
    c2.plot(gN, [r_["robust_fraction"] for r_ in R["conv_grid"]], "o-", color=TEAL_, ms=3, lw=1.3)
    c2.set_xlabel("grid points per axis N"); c2.set_ylabel("robust kernel fraction"); c2.set_title("Grid convergence")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig16_conv.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)

make_extra_figs()


# ---------------------------------------------------------------- fonts
FD = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("Serif", FD + "DejaVuSerif.ttf"))
pdfmetrics.registerFont(TTFont("Serif-Bold", FD + "DejaVuSerif-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Serif-Italic", FD + "DejaVuSerif-Italic.ttf"))
pdfmetrics.registerFont(TTFont("Serif-BoldItalic", FD + "DejaVuSerif-BoldItalic.ttf"))
pdfmetrics.registerFont(TTFont("Sans", FD + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("Sans-Bold", FD + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Mono", FD + "DejaVuSansMono.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("Serif", normal="Serif", bold="Serif-Bold", italic="Serif-Italic", boldItalic="Serif-BoldItalic")
registerFontFamily("Sans", normal="Sans", bold="Sans-Bold", italic="Sans", boldItalic="Sans-Bold")

NAVY = colors.HexColor("#1B2A4A"); TEAL = colors.HexColor("#0F7C86"); CORAL = colors.HexColor("#E0643E")
GOLD = colors.HexColor("#E8A33D"); VIOLET = colors.HexColor("#6B4C9A"); GREEN = colors.HexColor("#4C9A5B")
GREY = colors.HexColor("#8A8F98"); LIGHT = colors.HexColor("#F4F6FA"); TEAL_L = colors.HexColor("#E6F3F4")
CORAL_L = colors.HexColor("#FCEDE7"); GOLD_L = colors.HexColor("#FDF4E3"); VIO_L = colors.HexColor("#F1EDF8")

# ---------------------------------------------------------------- styles (dense)
BODY = 9.2; LEAD = 12.5
S = {}
S["body"] = ParagraphStyle("body", fontName="Serif", fontSize=BODY, leading=LEAD, alignment=TA_JUSTIFY, spaceAfter=3.2)
S["bodyL"] = ParagraphStyle("bodyL", parent=S["body"], alignment=TA_LEFT)
S["small"] = ParagraphStyle("small", parent=S["body"], fontSize=7.9, leading=9.9, spaceAfter=1.5)
S["cap"] = ParagraphStyle("cap", parent=S["body"], fontSize=7.8, leading=9.7, textColor=NAVY, spaceBefore=2, spaceAfter=6)
S["tcell"] = ParagraphStyle("tcell", fontName="Serif", fontSize=7.6, leading=9.2, alignment=TA_LEFT)
S["tcellB"] = ParagraphStyle("tcellB", parent=S["tcell"], fontName="Serif-Bold", textColor=colors.white)
S["h1"] = ParagraphStyle("h1", fontName="Sans-Bold", fontSize=13.2, leading=16, textColor=NAVY, spaceBefore=9, spaceAfter=4)
S["h1c"] = ParagraphStyle("h1c", fontName="Sans-Bold", fontSize=13.2, leading=16, textColor=NAVY, spaceBefore=9, spaceAfter=4)
S["h2"] = ParagraphStyle("h2", fontName="Sans-Bold", fontSize=9.6, leading=12, textColor=TEAL, spaceBefore=5, spaceAfter=2.5)
S["h3"] = ParagraphStyle("h3", fontName="Sans-Bold", fontSize=8.4, leading=10.5, textColor=VIOLET, spaceBefore=3, spaceAfter=1.5)
S["title"] = ParagraphStyle("title", fontName="Sans-Bold", fontSize=21, leading=26, textColor=NAVY, alignment=TA_CENTER)
S["subtitle"] = ParagraphStyle("subtitle", fontName="Serif-Italic", fontSize=11, leading=14.5, textColor=TEAL, alignment=TA_CENTER, spaceAfter=4)
S["center"] = ParagraphStyle("center", parent=S["body"], alignment=TA_CENTER)
S["meta"] = ParagraphStyle("meta", fontName="Sans", fontSize=8.2, leading=11, alignment=TA_CENTER, textColor=NAVY)
S["boxT"] = ParagraphStyle("boxT", fontName="Sans-Bold", fontSize=8.2, leading=10.5, textColor=NAVY, spaceAfter=1.5)
S["toc1"] = ParagraphStyle("toc1", fontName="Sans-Bold", fontSize=8.4, leading=11.5, leftIndent=0)
S["toc2"] = ParagraphStyle("toc2", fontName="Serif", fontSize=8, leading=10.5, leftIndent=12)
S["ref"] = ParagraphStyle("ref", fontName="Serif", fontSize=7.6, leading=9.4, leftIndent=14, firstLineIndent=-14, spaceAfter=1.2)

TEXTW = A4[0] - 2 * 1.45 * cm
EQSTYLE = {"num": ParagraphStyle("num", fontName="Sans", fontSize=7.8, leading=9, alignment=TA_CENTER, textColor=NAVY)}

# ---------------------------------------------------------------- markup helpers
def _ent(m):
    if m.group(1) in ("amp", "lt", "gt"):
        return m.group(0)
    return _html.unescape(m.group(0))

def mk(text):
    """Convert HTML entities to Unicode, escape bare & and <, keep a small set of tags."""
    text = re.sub(r"&([A-Za-z][A-Za-z0-9]*);", _ent, text)
    text = re.sub(r"&(?!amp;|lt;|gt;|#)", "&amp;", text)
    text = re.sub(r"<(?!/?(i|b|sub|super|font|br)\b)", "&lt;", text)
    return text

def P(text, st="body"):
    return Paragraph(mk(text), S[st])

def H1(text):
    return Paragraph(mk(text), S["h1"])

def H2(text):
    return Paragraph(mk(text), S["h2"])

def H3(text):
    return Paragraph(mk(text), S["h3"])

# ---------------------------------------------------------------- equations via mathtext
plt.rcParams["mathtext.fontset"] = "cm"
_eq_count = {"n": 0}

def EQ(tex, label=None):
    _eq_count["n"] += 1
    n = _eq_count["n"]
    path = os.path.join(EQD, f"eq{n:03d}.png")
    fig = plt.figure(figsize=(1, 1))
    fig.text(0, 0, f"${tex}$", fontsize=10.5, color="#1B2A4A")
    fig.savefig(path, dpi=300, bbox_inches="tight", pad_inches=0.04, facecolor="white")
    plt.close(fig)
    w, h = ImageReader(path).getSize()
    scale = 0.5  # 300 dpi -> points
    img_w, img_h = w * 72 / 300, h * 72 / 300
    maxw = TEXTW - 1.6 * cm
    if img_w > maxw:
        f = maxw / img_w
        img_w, img_h = img_w * f, img_h * f
    img = Image(path, width=img_w, height=img_h)
    lab = Paragraph(f"({label if label else n})", EQSTYLE["num"])
    t = Table([[img, lab]], colWidths=[TEXTW - 1.4 * cm, 1.4 * cm])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (0, 0), (0, 0), "CENTER"),
                           ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5),
                           ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    return t

# ---------------------------------------------------------------- boxes, tables, figures
def BOX(title, paras, bg=TEAL_L, edge=TEAL):
    inner = [Paragraph(mk(title), S["boxT"])] + [P(p, "small") if isinstance(p, str) else p for p in paras]
    t = Table([[inner]], colWidths=[TEXTW])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), bg),
                           ("LINEBEFORE", (0, 0), (0, -1), 2.6, edge),
                           ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return [Spacer(1, 2), t, Spacer(1, 4)]

_fig_n = {"n": 0}
def FIGURE(fname, caption, width_frac=1.0, label=None):
    if label is None:
        _fig_n["n"] += 1
        label = str(_fig_n["n"])
    path = os.path.join(FIG, fname)
    w, h = ImageReader(path).getSize()
    tw = TEXTW * width_frac
    scale = tw / w
    img = Image(path, width=tw, height=h * scale)
    cap = Paragraph(mk(f"<b>Figure {label}.</b> " + caption), S["cap"])
    return KeepTogether([Spacer(1, 2), img, cap])

def TABLE(rows, colw, caption=None, header=True, zebra=True, fs=None):
    data = []
    for r_i, row in enumerate(rows):
        cells = []
        for c in row:
            st = S["tcellB"] if (header and r_i == 0) else S["tcell"]
            cells.append(Paragraph(mk(str(c)), st))
        data.append(cells)
    t = Table(data, colWidths=[w * TEXTW for w in colw], repeatRows=1 if header else 0)
    style = [("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
             ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9CED8")),
             ("TOPPADDING", (0, 0), (-1, -1), 1.9), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.9),
             ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), NAVY))
    if zebra:
        for i in range(1 if header else 0, len(rows)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), LIGHT))
    t.setStyle(TableStyle(style))
    out = []
    if caption:
        out.append(Paragraph(mk(caption), S["cap"]))
    out.append(t)
    out.append(Spacer(1, 5))
    return KeepTogether(out)

def ff(x, d=3):
    return f"{x:.{d}f}"

def fe(x, d=2):
    return f"{x:.{d}e}"

def pct(x, d=1):
    return f"{100 * x:.{d}f}%"

# ---------------------------------------------------------------- derived numbers (from results.json)
pareto = R["pareto"]
lam = R["lambda_sweep"]
bioc = R["bio_extraction_cheaper_by_gravity"]
viab = R["viability"]
sens = R["sensitivity"]
sw = R["swarm"]
atl = R["atlas_tag_counts"]
phase_tags = R["atlas_phase_tags"]

def swarm_threshold(k):
    arr = sw[str(k)]["p_connected"]
    fr = sw["fail_fracs"]
    for f_, p_ in zip(fr, arr):
        if p_ < 0.5:
            return f_
    return None

TYPE3_RATIO = 1e36 / 3.828e26
TYPE2_RATIO = 1e26 / 3.828e26
SUN_L = 3.828e26
M_MERCURY = 3.301e23
M_EARTH = 5.972e24
AREA_SHELL = 4 * 3.141592653589793 * (1.495978707e11) ** 2

# sensitivity sorted list
sens_sorted = sorted(sens.items(), key=lambda kv: -kv[1]["range"])
sens_label = {
    "p0_A": "abiotic failure base rate p0_A", "Phi_B": "biological feedstock penalty Phi_B",
    "mhw_B": "biological hardware mass m_B", "kA": "abiotic radiation coefficient k_A",
    "kB": "biological radiation coefficient k_B", "c_B": "biological extraction energy c_B",
    "delta_sw": "switching overhead delta", "p0_B": "biological failure base rate p0_B",
    "rho_B0": "biological recovery rho_B0", "z_ug": "abiotic microgravity yield z_ug",
}

# ---------------------------------------------------------------- document template with TOC
class Doc(BaseDocTemplate):
    def __init__(self, fn, **kw):
        super().__init__(fn, **kw)
        self.toc_entries = []
        self._tocn = 0
    def handle_documentBegin(self):
        self._tocn = 0
        super().handle_documentBegin()
    def afterFlowable(self, f):
        if isinstance(f, Paragraph):
            st = f.style.name
            if st in ("h1", "h2"):
                txt = re.sub(r"<[^>]+>", "", f.getPlainText())
                txt = txt.replace(",", "").replace("'", "\u2019").replace("\xa0", " ")
                self._tocn = getattr(self, "_tocn", 0) + 1
                lvl = 0 if st == "h1" else 1
                key = "k%d" % self._tocn
                self.canv.bookmarkPage(key)
                self.canv.addOutlineEntry(txt, key, level=lvl, closed=(lvl > 0))
                self.notify("TOCEntry", (lvl, txt, self.page, key))

def on_page(canv, doc):
    canv.saveState()
    if doc.page > 1:
        canv.setStrokeColor(NAVY); canv.setLineWidth(0.5)
        canv.line(1.45 * cm, A4[1] - 1.05 * cm, A4[0] - 1.45 * cm, A4[1] - 1.05 * cm)
        canv.setFont("Sans-Bold", 6.6); canv.setFillColor(NAVY)
        canv.drawString(1.45 * cm, A4[1] - 0.9 * cm, "Biohybrid Infrastructure Viability Across Civilizational Scales")
        canv.setFont("Sans", 6.6)
        canv.drawRightString(A4[0] - 1.45 * cm, A4[1] - 0.9 * cm, "PREPRINT · NOT PEER REVIEWED · v1.0 · 21 November 2026")
        canv.line(1.45 * cm, 1.0 * cm, A4[0] - 1.45 * cm, 1.0 * cm)
        canv.setFont("Sans", 6.6)
        canv.drawString(1.45 * cm, 0.6 * cm, "Debnath & Xylia · in silico results only · no claim about human lifespan or clinical use")
        canv.drawRightString(A4[0] - 1.45 * cm, 0.6 * cm, f"{doc.page}")
    canv.restoreState()

def on_first(canv, doc):
    canv.saveState()
    canv.setFillColor(NAVY)
    canv.rect(0, A4[1] - 3.1 * cm, A4[0], 3.1 * cm, stroke=0, fill=1)
    canv.setFillColor(GOLD)
    canv.rect(0, A4[1] - 3.2 * cm, A4[0], 0.1 * cm, stroke=0, fill=1)
    canv.setFillColor(colors.white)
    canv.setFont("Sans-Bold", 8)
    canv.drawString(1.45 * cm, A4[1] - 1.4 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 21 NOVEMBER 2026")
    canv.setFont("Sans", 7.5)
    canv.drawString(1.45 * cm, A4[1] - 2.1 * cm, "Theoretical and computational research · Biological engineering · Systems and control · Astrobiology")
    canv.restoreState()

story = []

# ================================================================ TITLE PAGE
story.append(Spacer(1, 3.4 * cm))
story.append(Paragraph("Biohybrid Infrastructure Viability", S["title"]))
story.append(Paragraph("Across Civilizational Scales", S["title"]))
story.append(Spacer(1, 8))
story.append(Paragraph("A thermodynamic–ecological network framework for where living, biomimetic and abiotic engineering belongs, from planetary life support to stellar collector fields", S["subtitle"]))
story.append(Spacer(1, 10))
story.append(Paragraph("Devanik Debnath<super>1</super> · Xylia<super>2</super>", S["meta"]))
story.append(Spacer(1, 3))
story.append(Paragraph("<super>1</super> Independent researcher &nbsp;&nbsp; <super>2</super> Xylia, AI research scientist (multi-agent research system)", ParagraphStyle("m2", parent=S["meta"], fontName="Serif", fontSize=7.8, leading=10)))
story.append(Spacer(1, 12))

story += BOX("Status and scope", [
    "This preprint is theoretical and computational. Every number is produced by the formulas, parameter ranges and seeds stated in this document (Appendix D). Quantities marked as <i>evidence</i> are reproduced from published or press-reported measurements with their source. Quantities marked as <i>stylised</i> depend on parameter ranges we chose and are conditional on those ranges. No result is a prediction for a living organism, a space mission or a human population.",
], bg=GOLD_L, edge=GOLD)

story += BOX("Abstract", [
    "We ask where the functions of future infrastructure should be carried out by living processes, by biomimetic or hybrid engineering, or by abiotic machinery. We formalise infrastructure as a conserved resource network with three process classes, impose material, energy and radiative-heat constraints, and treat damage and repair as a robust viability problem. Four results are exact: (i) a capture-geometry law showing that a full-coverage collector shell at any radius captures at most a fraction &eta;&middot;f<sub>cov</sub> of stellar luminosity, so a Type&nbsp;II flux of 10<super>26</super>&nbsp;W needs &eta;&middot;f<sub>cov</sub>&nbsp;&ge;&nbsp;%s; (ii) a radiative equilibrium law T<sub>sh</sub>&nbsp;&prop;&nbsp;r<super>-1/2</super> for collector shells; (iii) a Murray exponent of 1/3 for cost-minimising branching; (iv) a Type&nbsp;III capture requirement of about %.2e solar luminosities. Numerically, a robust viability kernel of a two-channel repair system shrinks from %s of admissible states to %s under adversarial disturbance, and, at default parameters, neither single repair channel is robustly viable on its own (Section 10.1). In a stylised architecture model, biological extraction is cheaper in energy than abiotic extraction in %s of microgravity draws and in none of the draws at Earth or Mars gravity, a consequence of the chosen parameter ranges. The hybrid architecture wins %s of draws on mass and energy alone and %s when failure is weighted tenfold. Its reliability benefit is large (median factor %.1f) and is paid for in import mass. The biological-extraction result rests on one reported microgravity experiment, and its threshold location depends on the interpolation shape (Section 7.2); partial-gravity data are the decisive missing measurement." % (
    pct(R["eta_fcov_required_TypeII_pct"]/100, 1), TYPE3_RATIO, pct(viab["K0_fraction"]), pct(viab["kernel_robust_fraction"]),
    pct(bioc["g<1e-5.5"], 0), pct(lam["0.0"]["overall"]["C"], 0), pct(lam["10.0"]["overall"]["C"], 0), pareto["median_failure_reduction_factor_C_vs_best_single"]),
], bg=TEAL_L, edge=TEAL)
story.append(Paragraph("<b>Keywords.</b> infrastructure viability · biohybrid systems · erasure and redundancy · capture geometry · radiative equilibrium · robust viability kernels · max-plus scheduling · network algebraic connectivity · Pareto decision analysis · biomining · bioregenerative life support · planetary protection", S["small"]))
story.append(Spacer(1, 6))

# headline numbers strip
hl = [["Exact (P)", "Numerical (N) / stylised (S)", "Evidence (E)"],
      [f"Type II capture: &eta;&middot;f<sub>cov</sub> &ge; {pct(R['eta_fcov_required_TypeII_pct']/100)}",
       f"Robust kernel: {pct(viab['kernel_robust_fraction'])} of K; bio-only and abiotic-only: {pct(viab['robust_bio_only_fraction'])} each (S)",
       f"Biophotovoltaics: {R['bpv_best_gap_factor']:.0f}&times; below ideal PV at best (E)"],
      [f"T<sub>sh</sub> = {R['T_bare_blackbody_1AU_K']:.1f} K (bare blackbody, 1 AU)",
       f"Biological extraction cheaper in µg: {pct(bioc['g<1e-5.5'],0)} of draws (S)",
       f"Abiotic Pd yield falls {R['Pd_abiotic_ratio_1g_over_ug']:.1f}&times; in µg vs 1 g (E)"],
      [f"Murray exponent {R['murray_fitted_exponent']:.4f} vs 1/3 (N)",
       f"Hybrid median failure reduction {pareto['median_failure_reduction_factor_C_vs_best_single']:.1f}&times; (S)",
       f"Fungus Pd in µg {R['Pd_fungus_over_abiotic_ug']:.1f}&times; abiotic µg (E)"]]
story.append(TABLE(hl, [0.33, 0.37, 0.30], caption="<b>Table 0.</b> Headline results, labelled by epistemic status: P = proved, N = numerical result, S = stylised model, E = evidence reproduced from a published or press-reported measurement."))

story.append(NextPageTemplate("body"))
story.append(PageBreak())

# ================================================================ CONTENTS
story.append(Paragraph("Contents", S["h1c"]))
toc = TableOfContents()
toc.levelStyles = [S["toc1"], S["toc2"]]
story.append(toc)
story.append(Spacer(1, 6))
story.append(P("Figures are numbered in order of appearance and tables in order of appearance. Equations are numbered consecutively; cross-references use the number in parentheses. Appendices A to E hold proofs, the full 110-concept atlas, the parameter table, reproducibility details and the data tables.", "small"))
story.append(PageBreak())

# ================================================================ 1 INTRODUCTION
story.append(Paragraph("1&nbsp;&nbsp;Introduction and the decision problem", S["h1"]))
story.append(P("Proposals for large-scale engineering increasingly invoke living systems. Photosynthesis, microbial metabolism, fungal growth and vascular branching are presented as templates for orbital habitats, asteroid processing, solar collection and interstellar infrastructure. The enthusiasm is understandable, because biology already performs energy conversion, self-repair, distributed manufacturing and resource recycling at a scale and efficiency that engineers still struggle to match. But the question that matters for design is not whether biology is impressive. It is which function should be performed by which kind of system, under which environmental conditions, and at what cost in mass, energy and reliability."))
story.append(P("We address that question as a decision problem with an explicit physical substrate. Infrastructure is a resource network whose process rates are split among three classes: biological (<i>B</i>), biomimetic or biohybrid (<i>H</i>) and abiotic (<i>A</i>). Every class is subject to the same conservation accounting, the same energy budget and the same heat-rejection limit, so that no class gains an advantage by having its waste streams or inputs left out of the balance. Damage accumulates in modules and is repaired by a finite repair machinery. An architecture is viable when the damage and resource states can be kept admissible under every disturbance in a set we specify. The architecture question becomes: which allocation of functions to classes is Pareto-efficient in import mass, energy and failure probability, across the environmental vector <i>&theta;</i>?"))
story.append(P("We make six contributions, each labelled by its epistemic status.", "body"))
story.append(P("<b>C1</b> (P). A capture-geometry law for any full-coverage collector shell: the captured fraction of stellar luminosity is independent of radius and equals the product of collector efficiency and coverage (Proposition 1). Consequences for the Kardashev scales follow exactly. <b>C2</b> (P). A radiative equilibrium law for collector shells, with the scaling of temperature with orbital radius (Proposition 2). <b>C3</b> (P). A material circularity identity showing that recovery fractions of 0.99 leave a linearly growing external replacement burden (Proposition 3). <b>C4</b> (P/N). A proof that cost-minimising branching gives Murray's exponent of 1/3, verified numerically (Proposition 4). <b>C5</b> (N). A robust viability kernel for a two-channel repair system, showing that adversarial disturbance can remove viability from every single-channel strategy in the stylised model (Section 10). <b>C6</b> (S/E). A three-architecture Pareto analysis conditioned on the gravity dependence of extraction, with an explicit test of where biological extraction is cheaper in energy and a failure-weight sweep that separates reliability gains from mass and energy costs (Section 11)."))
story.append(FIGURE("fig01_framework.png", "The framework. Constraints (conservation, heat rejection), dynamics (damage and repair), network robustness and the architecture decision are linked as described in Sections 3 to 11. Arrows indicate the direction of dependence used in the analysis.", 0.92))
story.append(P("Three things are <i>not</i> claimed. We do not claim that bacteria or fungi can build a stellar collector, that photosynthesis can exceed thermodynamic limits, or that any stylised parameter transfers to a real system. The earlier research draft that motivated this work listed a 110-concept atlas and ten detailed modules. We retain the atlas as an audited design space (Section 12) and do not present its concepts as validated."))

# ================================================================ 2 RELATED WORK & CORRECTIONS
story.append(H1("2&nbsp;&nbsp;Literature position and corrections to the research draft"))
story.append(P("The relevant evidence base is spread across space life-support engineering, biomining, biophotovoltaics, mycelium and biocement materials, control theory and classical astrophysical engineering. A few anchors are essential. The 2026 BioAsteroid experiment on the International Space Station tested bacterial, fungal and mixed-consortium leaching of an L-chondrite meteorite, under microgravity and matched terrestrial controls [8]. Qi and colleagues' 2024 systematic analysis reports whole-cell biophotovoltaic power densities from 10<super>-4</super> to 10<super>3</super>&nbsp;mW&nbsp;m<super>-2</super> across studied devices [7]. The bioregenerative life-support literature treats coupled in-situ resource utilisation and regenerative loops as architecturally coupled but operationally distinct subsystems [9, 10, 11, 12]. Dyson's 1960 proposal concerns detection of large-scale energy conversion through waste-heat signatures [2], O'Neill's 1974 study of paired cylinders concerns structure and material requirements [3], and Kardashev's 1964 classification defines scales by power [1]."))
story.append(P("Writing the atlas and the model against the primary sources exposed several places where the earlier draft was imprecise or overstated. Table 1 lists them. None of these changes alters the qualitative conclusions, but each changes what can be claimed, and the corrected version is what this paper uses."))
corr = [["Topic in draft", "What the source supports", "Status in this paper"],
        ["BioAsteroid described as relevant to Mars gravity", "The ISS arm ran in microgravity with a 1 g terrestrial control. No partial-gravity arm is reported in the sources we retrieved.", "Corrected. Gravity dependence is treated as an unresolved interval (Section 7)."],
        ["5.5-fold palladium gain with <i>P. simplicissimum</i>", "Reported as 5.5-fold relative to the abiotic control under microgravity. Variability is large; the consortium's palladium yield in microgravity is reported lower.", "Retained with the variability and the consortium result stated."],
        ["Gravity effect not quantified", "Abiotic palladium leaching is reported as 13.6-fold higher on Earth than in microgravity.", "Added. This is the main evidential basis for the gravity-dependent model."],
        ["Radiative balance written without area factors", "A sphere-shell absorbs over its projected disk and emits over its full surface.", "Corrected to a steady-state identity (Proposition 2)."],
        ["Esposito et al. (2026) review cited for a throughput-versus-regeneration trade-off", "The review exists and frames coupled ISRU–BLSS architectures. The specific trade-off wording could not be verified from the retrieved text.", "Cited for architecture framing only; the trade-off is tested here rather than attributed."],
        ["MELiSSA water recovery of 92–95%", "Stated in a 2025 review of space manufacturing, not verified against a primary MELiSSA report.", "Not used as a quantitative input."],
        ["2021 Nature Communications study on Martian 2,3-butanediol", "Not retrieved or verified during this work.", "Removed from the evidence base."],
        ["2025 review of MICP for Martian construction", "Not retrieved or verified during this work.", "Removed; MICP claims are qualitative."],
        ["Kardashev Types IV to VI", "Not standardised. Sagan's continuous index applies only to power levels up to Type III.", "Scenario bands labelled as our extrapolations."]]
story.append(TABLE(corr, [0.25, 0.44, 0.31], caption="<b>Table 1.</b> Corrections to the research draft. Each row states what the cited source supports and what this paper retains."))
story.append(H2("2.1 Field-by-field state of the evidence"))
story.append(P("<b>Space life support.</b> Bioregenerative life-support work has moved from closed-ecology experiments toward integrated compartments in which algal, microbial and plant loops exchange gases, water and nutrients. The main limitation is not chemistry but integration: each compartment is stable alone, and coupled operation under disturbance, crew variation and component loss is far less characterised [9, 10, 11]. Nitrogen recovery is a representative case, in which urine treatment, nitrification and product purification must be balanced against energy and maintenance [12]. This matches the replacement-burden result of Section 6: the value of closure lies in the loss fraction, which integration rarely drives to zero."))
story.append(P("<b>Biomining.</b> Microbial and fungal leaching of metals is established on Earth at industrial scale for some ores, and the space experiments extend the question to microgravity and to meteoritic substrates [8]. The key observation for this paper is that abiotic and biological yields respond differently to gravity, which makes biomining a candidate for a comparative-advantage analysis rather than a universal replacement for chemical processing."))
story.append(P("<b>Biophotovoltaics.</b> The field's own reviews identify extracellular electron transfer and terminal-oxidase limitation as the bottlenecks, and report power densities many orders of magnitude below solar flux [7]. Chemical production from photosynthetic or artificial-leaf systems is the more plausible application, because the figure of merit is product per unit area and energy, not electrical power."))
story.append(P("<b>Living and self-repairing materials.</b> Engineered living materials are an active area in which the matrix and the living component co-evolve. The reliability question is when biological repair keeps pace with damage, which is a rate comparison, and it is exactly the comparison the viability analysis of Section 10 formalises."))
story.append(P("<b>Radiative and thermal control.</b> Biological surfaces inspire spectral control, but space radiators are governed by the Stefan–Boltzmann law and by view factors (Section 4). Biological evaporative or convective cooling has no direct analogue in vacuum, so biology informs the surface design, not the heat-rejection physics."))
story.append(P("<b>Multi-agent and networked robustness.</b> Distributed control and graph connectivity are mature fields [16, 17]. Their application to biological or biohybrid infrastructure adds only the constraint that each agent may itself be a living module with its own failure dynamics, which the architecture model of Section 11 captures in its failure term."))
story.append(P("The positioning matters for novelty as well. The ingredients (capture geometry, radiative equilibrium, erasure-style redundancy, viability theory, Pareto analysis) are standard. What we add is their composition around a single allocation question, and specific results obtained from that composition. We have not found this composition in the literature we consulted, but the search was not exhaustive and novelty is claimed only as far as our search extends."))

# ================================================================ 3 MODEL
story.append(H1("3&nbsp;&nbsp;A conserved, viable, multi-class infrastructure model"))
story.append(H2("3.1 Resource network and process classes"))
story.append(P("Let <i>x(t)</i> &isin; &Ropf;<super>m</super><sub>&ge;0</sub> be the inventory of <i>m</i> resources, for example water, carbon, nitrogen, phosphorus, oxygen, minerals and biomass. Process-rate vectors are split into biological, biohybrid and abiotic blocks, <i>u(t) = (u<sub>B</sub>, u<sub>H</sub>, u<sub>A</sub>)</i>. Stoichiometric matrices <i>S</i><sub>B</sub>, <i>S</i><sub>H</sub>, <i>S</i><sub>A</sub> map process rates to inventory change, external acquisition enters through <i>E f</i><sub>ext</sub>, and consumption, losses and leakage under disturbance <i>w</i> enter through <i><i>l</i>(x,w)</i>."))
story.append(EQ(r"\dot{x}(t)=S_B u_B+S_H u_H+S_A u_A+E\,f_{\mathrm{ext}}-\ell(x,w)"))
story.append(P("The class-independence principle is a bookkeeping rule rather than a theorem. For any two process classes that produce the same product, the balance must include identical boundary terms: inputs, waste streams, purification energy, and the mass and energy of the reactor or machine that performs the process. A biological process that appears cheap because its waste is excluded is a modelling error, and we treat it as such in Section 11."))

story.append(H2("3.2 Material circularity"))
story.append(P("For resource <i>i</i> with gross demand <i>D<sub>i</sub></i>, recovery fraction <i>&rho;<sub>i</sub></i>, external replacement <i>M<sub>i</sub></i> and irreversible leakage <i>&lambda;<sub>i</sub>X<sub>i</sub></i>, the replacement rate obeys the identity below. Recovery improvements are not local: a loop that recovers 99% of a resource still requires a replacement pathway for the remaining 1%, together with the energy to purify, store and deliver it."))
story.append(EQ(r"\dot M_i=(1-\rho_i)D_i+\lambda_i X_i"))

story.append(H2("3.3 Energy and heat rejection"))
story.append(P("The energy budget requires that the sum of biological, biohybrid, abiotic and auxiliary power be bounded by available power, and that unavoidable waste heat be rejected by radiation. The radiative limit uses effective emissivity &epsilon;, Stefan–Boltzmann constant &sigma;, radiator area and background temperature."))
story.append(EQ(r"P_{\mathrm{bio}}+P_{\mathrm{hyb}}+P_{\mathrm{abio}}+P_{\mathrm{aux}}\leq P_{\mathrm{avail}}"))
story.append(EQ(r"Q_{\mathrm{rej}}\leq\epsilon\sigma A_{\mathrm{rad}}\left(T_{\mathrm{rad}}^4-T_{\mathrm{bg}}^4\right)"))

story.append(H2("3.4 Damage, repair and viability"))
story.append(P("Module damage <i>d<sub>j</sub></i> grows with environmental load <i>&lambda;<sub>j</sub>(w)</i> and is reduced by effective repair <i>r<sub>j</sub>(x,u)</i>. Let <i>s = (x, d)</i> denote the full state and let <i>&kappa;</i> be a closed admissible set. The viability kernel of &kappa; is the set of initial states from which some control keeps the trajectory in &kappa; under every disturbance. Viability theory [13, 14, 22] characterises this set as the largest fixed point of a backward operator, so that the kernel can be computed by iteration on a grid."))
story.append(EQ(r"\dot d_j=\lambda_j(w)-r_j(x,u)"))
story.append(EQ(r"\mathcal{V}(\kappa)=\left\{s_0:\exists\,u(\cdot)\ \forall\,w(\cdot)\ \ s(t)\in\kappa\ \ \forall\,t\geq 0\right\}"))
story.append(EQ(r"\mathcal{K}_{n+1}=\mathcal{K}_n\cap\left\{s:\exists\,u\ \forall\,w\ \ f(s,u,w)\in\mathcal{K}_n\right\}"))
story += BOX("Conjecture 1 (composite viability, not tested end to end)", [
    "Let an infrastructure be viable when its state remains in the admissible set &kappa; under all disturbances in a compact set. Then a biohybrid architecture is viable only if its robust viability kernel contains the initial state. We state this as a conjecture because the composite model in this paper is not a single end-to-end simulation of the full network. Its components are tested separately in Sections 4 to 11.",
], bg=VIO_L, edge=VIOLET)

story.append(H2("3.5 Architecture decision"))
story.append(P("An architecture <i>&iota;</i> assigns each function to a class. Three architectures are compared throughout: <b>A</b> abiotic (conventional chemical processing, physical purification, mechanical distribution); <b>B</b> biological (microbial processing, biological recycling, photobiological production); and <b>C</b> hybrid (biological regeneration plus abiotic extraction, synthetic materials and autonomous control). Each architecture is scored on three objectives to be minimised: import mass <i>M</i>, energy per unit product <i>E</i>, and mission failure probability <i>p</i>. An architecture is Pareto-dominated if another architecture is no worse on all objectives and strictly better on at least one. Section 11 gives the explicit objective functions."))

story.append(H2("3.6 Notation"))
notation = [["Symbol", "Meaning", "Units / range"],
    ["x(t), x<sub>i</sub>", "resource inventory vector and component", "kg or normalised"],
    ["u<sub>B</sub>, u<sub>H</sub>, u<sub>A</sub>", "process-rate vectors by class (biological, biohybrid, abiotic)", "s<super>-1</super> (normalised)"],
    ["S<sub>B</sub>, S<sub>H</sub>, S<sub>A</sub>, E", "stoichiometric and external-acquisition matrices", "dimensionless"],
    ["<i>l</i>(x,w)", "losses and leakage under disturbance w", "as x per unit time"],
    ["D<sub>i</sub>, &rho;<sub>i</sub>, M<sub>i</sub>, &lambda;<sub>i</sub>", "gross demand, recovery fraction, external replacement, leakage coefficient", "kg yr<super>-1</super>; [0,1]; kg; yr<super>-1</super>"],
    ["P, L<sub>&odot;</sub>, f<sub>cov</sub>, &eta;", "captured power, solar luminosity, covered fraction, collector efficiency", "W; 3.828&times;10<super>26</super> W; [0,1]; [0,1]"],
    ["S(r), r", "irradiance and orbital radius", "W m<super>-2</super>; m or AU"],
    ["&alpha;, &epsilon;, &sigma;", "absorptance, emissivity, Stefan–Boltzmann constant", "[0,1]; [0,1]; 5.670&times;10<super>-8</super> W m<super>-2</super> K<super>-4</super>"],
    ["T<sub>sh</sub>, T<sub>rad</sub>, T<sub>bg</sub>", "shell, radiator and background temperatures", "K"],
    ["A<sub>rad</sub>, Q<sub>rej</sub>", "radiator area and rejected heat", "m<super>2</super>; W"],
    ["K", "continuous Kardashev index", "dimensionless"],
    ["d<sub>j</sub>, r<sub>j</sub>", "module damage and effective repair", "normalised"],
    ["&kappa;, K<sub>n</sub>, V(&kappa;)", "admissible set, viability iterates, viability kernel", "subsets of state space"],
    ["Q, r, &Delta;p, &mu;", "volumetric flow, branch radius, pressure drop, viscosity", "m<super>3</super> s<super>-1</super>; m; Pa; Pa s"],
    ["L<sub>G</sub>, &lambda;<sub>2</sub>, &kappa;(G)", "graph Laplacian, algebraic connectivity, vertex connectivity", "dimensionless"],
    ["&zeta;(g), g, z<sub>ug</sub>", "abiotic gravity factor, gravity in units of Earth gravity, microgravity yield factor", "[0,1]; log-scaled; [0.05,0.50]"],
    ["W, R, F", "water closure, radiation index, feedstock fraction", "[0,1] each"],
    ["M, E, p", "import mass, energy per product, failure probability (objectives)", "normalised; normalised; [0,1]"],
    ["J<sub>&lambda;</sub>", "scalarised cost M + E + &lambda;p", "normalised"],
    ["c<sub>A</sub>, c<sub>B</sub>, e<sub>rec</sub>", "extraction-energy scales and recovery energies", "normalised"],
    ["&delta;, &Phi;<sub>B</sub>", "hybrid switching overhead and biological feedstock penalty", "normalised"],
    ["&tau;<sub>rt</sub>, PM, T<sub>min</sub>", "round-trip light time, phase margin, minimum control period", "s; rad; s"]]
story.append(TABLE(notation, [0.25, 0.47, 0.28], caption="<b>Table 1b.</b> Notation used throughout. Normalised quantities are defined relative to the abiotic reference architecture (Section 11)."))

# ================================================================ 4 CAPTURE GEOMETRY
story.append(H1("4&nbsp;&nbsp;Capture geometry and radiative equilibrium of collector fields"))
story.append(P("Stellar-scale proposals are usually discussed in terms of total power, but the physically binding quantities are geometric and thermodynamic. We start with the capture law, which is exact, and then the radiative equilibrium of a collector shell, which fixes its temperature and therefore its material constraints."))
story.append(H2("4.1 The capture-geometry law"))
story.append(P("Let <i>L</i><sub>&odot;</sub> be solar luminosity and let a collector field cover fraction <i>f</i><sub>cov</sub> of a spherical shell at radius <i>r</i>. The irradiance at that radius is <i>S(r) = L</i><sub>&odot;</sub>/(4&pi;r<super>2</super>), and the field intercepts the sunlight that falls on its projected coverage. The electrical or chemical power captured is <i>P = &eta; f</i><sub>cov</sub> <i>L</i><sub>&odot;</sub>, where the radius cancels because the coverage area scales as <i>r<super>2</super></i> and the irradiance scales as <i>r<super>-2</super></i>. This gives a statement that is independent of geometry."))
story.append(EQ(r"\eta\,f_{\mathrm{cov}}\,L_\odot\geq P\quad\Rightarrow\quad\eta\,f_{\mathrm{cov}}\geq\frac{P}{L_\odot}"))
story.append(P(f"<b>Proposition 1 (capture-geometry law).</b> No full-coverage or partial-coverage shell at any radius can capture more than &eta; f<sub>cov</sub> L<sub>&odot;</sub>. For a Type&nbsp;II flux of 10<super>26</super>&nbsp;W, the required product is <i>&eta; f</i><sub>cov</sub> &ge; {TYPE2_RATIO:.4f}, that is {pct(TYPE2_RATIO,1)}. The statement holds for any radius, so no choice of orbit relaxes it. <i>Proof.</i> The captured power is the integral of incident flux over the covered projected area multiplied by &eta;. Incident flux integrates over the sphere to <i>L</i><sub>&odot;</sub>, and the covered fraction of that sphere is at most <i>f</i><sub>cov</sub>. The bound follows immediately, and equality holds when all interceptable sunlight is converted at efficiency &eta; over the covered fraction. ■", "body"))
story.append(P(f"The result has two consequences that the earlier draft did not state. First, a Type&nbsp;II collector requires either an efficiency-coverage product above roughly one quarter or a source of power other than the Sun. Second, a Type&nbsp;III flux of 10<super>36</super>&nbsp;W corresponds to {TYPE3_RATIO:.2e} solar luminosities. That is a galactic-scale requirement, and it is not satisfied by any collector around one star. The Sagan continuous index [4] used in Figure 2 makes this explicit: humanity's present power of about 1.9&times;10<super>13</super>&nbsp;W gives K&nbsp;&asymp;&nbsp;{R['K_index']['Humanity (approx., 1.9e13 W)']:.2f}."))
story.append(EQ(r"K=\frac{\log_{10}P-6}{10}"))
story.append(FIGURE("fig02_kardashev.png", "The continuous Kardashev index, Eq. (9), with the scenario bands used in this paper. Bands above K&nbsp;=&nbsp;3 are our extrapolations and are not standard Kardashev categories. Humanity's power, of order 10<super>13</super>&nbsp;W, sits near K&nbsp;=&nbsp;0.73.", 0.9))
story.append(H2("4.2 Area, mass and the one-AU shell"))
story.append(P(f"At 1&nbsp;AU the solar constant is {R['S0_W_m2']:.1f}&nbsp;W&nbsp;m<super>-2</super>. A Type&nbsp;II field with efficiency 0.20 needs area <i>A = P/(&eta; S</i><sub>0</sub>) = {fe(R['A_needed_TypeII_eta020_m2'])}&nbsp;m<super>2</super>, which is {R['A_ratio_needed_over_sphere_eta020']:.2f} times the area of a full 1&nbsp;AU sphere. Efficiency 0.20 therefore cannot close the Type&nbsp;II requirement with a single shell at that radius, consistent with Proposition 1. The mass of a full shell follows from its areal density; Table 2 gives the mass under three scenarios."))
mass_rows = [["Areal density [kg m<super>-2</super>]", "Shell mass [kg]", "Fraction of Mercury", "Fraction of Earth"]]
for k_, v in R["shell_mass_1AU"].items():
    mass_rows.append([k_.replace("kg/m2", ""), fe(v["kg"]), f"{v['fraction_of_mercury']:.3f}", f"{v['fraction_of_earth']:.4f}"])
story.append(TABLE(mass_rows, [0.28, 0.26, 0.23, 0.23], caption="<b>Table 2.</b> Mass of one full 1&nbsp;AU spherical shell (area 4&pi;r<super>2</super> = %s m<super>2</super>) as a function of areal density. Reference masses: Mercury %s kg, Earth %s kg." % (fe(AREA_SHELL), fe(M_MERCURY), fe(M_EARTH))))
story.append(P("Table 2 shows that the material cost of a single shell is an exact multiple of the areal density, which makes it the dominant design variable. Shells built from thin films at 0.1 kg&nbsp;m<super>-2</super> remain a sizeable fraction of a planetary mass. The earlier draft's concern about the physical feasibility of a single rigid shell is therefore well founded, and the distributed-swarm interpretation is more defensible for the same reason."))
story.append(FIGURE("fig03_capture_mass.png", "Left: area required for 10<super>16</super> and 10<super>26</super>&nbsp;W against collector efficiency at 1&nbsp;AU, with the full 1&nbsp;AU sphere as reference; the Type&nbsp;II curve crosses the sphere only at &eta; above about 0.26 under full coverage, consistent with Proposition 1. Right: mass of a full 1&nbsp;AU shell against areal density, with reference masses of Mercury and the Moon.", 1.0))
story.append(H2("4.3 Radiative equilibrium of a collector shell"))
story.append(P("A collector shell absorbs sunlight over its projected disk and emits thermal radiation over its full surface. Its steady-state temperature follows from the balance between absorbed power after electrical extraction and emitted power. Writing absorptance <i>&alpha;</i>, emissivity <i>&epsilon;</i>, and irradiance <i>S(r) = L</i><sub>&odot;</sub>/(4&pi;r<super>2</super>), the equilibrium temperature is independent of coverage for a uniform isothermal shell."))
story.append(EQ(r"T_{\mathrm{sh}}(r,\eta)=\left[\frac{\alpha(1-\eta)L_\odot}{16\pi\,\epsilon\,\sigma\,r^2}\right]^{1/4}"))
story.append(P(f"<b>Proposition 2 (radiative equilibrium).</b> For a uniform isothermal collector shell, <i>T</i><sub>sh</sub> scales as <i>r</i><super>-1/2</super> at fixed &eta;, and extracting electrical power lowers the equilibrium temperature by the factor (1&minus;&eta;)<super>1/4</super>. For a black body at 1&nbsp;AU with &eta;&nbsp;=&nbsp;0, Eq. (10) gives {R['T_bare_blackbody_1AU_K']:.1f}&nbsp;K. With &eta;&nbsp;=&nbsp;0.26, &alpha;&nbsp;=&nbsp;0.95 and &epsilon;&nbsp;=&nbsp;0.90 it gives {R['T_shell_eta026_eps090_alpha095_K']:.1f}&nbsp;K. <i>Proof.</i> The absorbed power per unit area of the shell surface, averaged over the sphere, is <i>&alpha; S(r)(1&minus;&eta;)/4</i>, because the projected disk is one quarter of the sphere. Setting this equal to <i>&epsilon;&sigma;T<super>4</super></i> and solving gives Eq. (10). ■", "body"))
story.append(P("The temperature result has a direct engineering consequence. Converting more of the incident energy into electricity lowers the operating temperature of the collector, which improves photovoltaic output but does not remove the need for radiators. Heat rejection is therefore a binding constraint on biological manufacturing in orbit, not only on the collectors themselves. For a one-sided ideal radiator, the required area follows from Eq. (11)."))
story.append(EQ(r"A_{\mathrm{rad}}=\frac{Q_{\mathrm{rej}}}{\epsilon\,\sigma\,T^4}"))
story.append(P(f"A 1&nbsp;GW waste-heat load at 300&nbsp;K and &epsilon;&nbsp;=&nbsp;0.9 requires {fe(R['radiator_1GW_300K_m2'])}&nbsp;m<super>2</super> of radiator. Biological processes operate at temperatures in a narrow range, so a biological reactor at 300&nbsp;K requires radiators of the same order as an abiotic reactor of equal thermal load. Biology does not reduce this burden, because its thermal output is set by the same energy balance."))
story.append(FIGURE("fig04_radiative.png", "Left: equilibrium temperature of a collector shell against collector efficiency, for three orbital radii, from Eq. (10). Right: ideal one-sided radiator area against temperature for two heat loads, from Eq. (11). Both are exact identities; the figure shows their parametric dependence.", 1.0))

story.append(H2("4.4 Control latency of distributed collector fields"))
story.append(P("A distributed collector field, or any biological manufacturing plant at large distance from its operators, cannot be controlled from a single point in real time once its communication path is long. Light-time is an exact physical bound: the round trip between a controller and a unit at distance <i>d</i> takes at least <i>2d/c</i>."))
story.append(EQ(r"\tau_{\mathrm{rt}}=\frac{2d}{c}", label="4a"))
story.append(P("The consequence for feedback control is a classical result. A loop with crossover frequency &omega;<sub>c</sub> and phase margin PM tolerates a delay up to PM/&omega;<sub>c</sub> (the delay margin). Requiring the delay to be within the margin gives a minimum control period. This is a standard linear-systems condition, applied here to a delayed centralised loop, and it is the reason the swarm analysis of Section 9 assumes local feedback."))
story.append(EQ(r"\omega_c\,\tau_{\mathrm{rt}}<\mathrm{PM}\,;\qquad T_{\min}=\frac{2\pi\,\tau_{\mathrm{rt}}}{\mathrm{PM}}", label="4b"))
story.append(P(f"With PM = &pi;/3, which is a conventional design target, the minimum control period is <i>T</i><sub>min</sub> = 6&tau;<sub>rt</sub>. Table 4a gives the values. At 1&nbsp;AU, a centralised controller can update no faster than about every {6*R['latency']['1 AU']['round_trip_s']/3600:.1f}&nbsp;h, and a controller at a stellar distance can update only on timescales of years. Autonomy at the unit or cluster level is therefore a requirement, not an option, for distributed collector fields and remote biological plants."))
def _fmt_t(sec):
    if sec < 3600: return f"{sec/60:.1f} min"
    if sec < 86400: return f"{sec/3600:.2f} h"
    if sec < 3.156e7: return f"{sec/86400:.1f} d"
    return f"{sec/3.156e7:.1f} yr"
lat_rows = [["Distance", "One-way light time", "Round trip &tau;<sub>rt</sub>", "Minimum control period 6&tau;<sub>rt</sub>"]]
for k_, v in R["latency"].items():
    lat_rows.append([k_, _fmt_t(v["one_way_s"]), _fmt_t(v["round_trip_s"]), _fmt_t(6 * v["round_trip_s"])])
story.append(TABLE(lat_rows, [0.34, 0.2, 0.2, 0.26], caption="<b>Table 4a.</b> Light-time bounds and the minimum control period implied by the delay margin with PM = &pi;/3 (Eq. 4b). Values are exact from c and the stated distances."))
story.append(P("<b>Proposition 6 (latency bound).</b> Under the delay-margin condition, any centralised feedback loop with round-trip delay &tau;<sub>rt</sub> that is designed for phase margin PM has minimum sampling period 2&pi;&tau;<sub>rt</sub>/PM. <i>Proof.</i> The delay margin of a loop with crossover &omega;<sub>c</sub> is PM/&omega;<sub>c</sub>. Stability with delay &tau;<sub>rt</sub> requires &tau;<sub>rt</sub> &lt; PM/&omega;<sub>c</sub>, equivalently &omega;<sub>c</sub> &lt; PM/&tau;<sub>rt</sub>. The shortest period compatible with that crossover is 2&pi;/&omega;<sub>c</sub>, which gives the stated bound. ■", "body"))

story.append(H2("4.5 Arithmetic of growth toward higher scales"))
story.append(P("The Sagan index makes it easy to ask how long a fixed growth rate would take to reach each scale. For constant exponential growth of power at rate <i>g</i> per year from <i>P</i><sub>0</sub>, the time to reach <i>P</i> is <i>t</i> = ln(<i>P</i>/<i>P</i><sub>0</sub>)/ln(1+<i>g</i>). This is pure arithmetic, and it is included to show the time scale implied by the scenario bands, not as a forecast. Constant growth cannot persist indefinitely, and the table should be read as a bound on how the scenarios could be spaced in time."))
_P0 = 1.9e13
gr_rows = [["Growth rate per year", "to K = 1 (10<super>16</super> W)", "to K = 2 (10<super>26</super> W)", "to K = 3 (10<super>36</super> W)"]]
for gg in [0.005, 0.01, 0.02, 0.03]:
    row = [f"{100*gg:.1f}%"]
    for PT in [1e16, 1e26, 1e36]:
        yrs = math.log(PT / _P0) / math.log(1 + gg)
        row.append(f"{yrs:,.0f} yr")
    gr_rows.append(row)
story.append(TABLE(gr_rows, [0.2, 0.27, 0.27, 0.26], caption="<b>Table 4c.</b> Arithmetic time to reach each scenario power from humanity's present power of about 1.9&times;10<super>13</super>&nbsp;W at constant growth (exact arithmetic on the stated power; the growth rates are illustrative)."))

story.append(FIGURE("fig18_growth.png", "Years to reach each scenario power from 1.9&times;10<super>13</super> W as a function of constant growth rate, from the arithmetic in Eq. (4) of Section 4.5. Illustrative only: the curves show time scales, not predictions.", 0.85, label="4d"))
# ================================================================ 5 BIOLOGY'S CEILING
story.append(H1("5&nbsp;&nbsp;Thermodynamic ceilings on biological energy conversion"))
story.append(P("The question of whether biology can serve as a collector is answered by two ceilings. The first is the exergy of solar radiation. Petela's expression [19] gives the maximum fraction of incident radiation energy that can be converted to work, for a black-body sun at temperature <i>T</i><sub>s</sub> and environment <i>T</i><sub>0</sub>."))
story.append(EQ(r"\eta_{\mathrm{Petela}}=1-\frac{4}{3}\frac{T_0}{T_s}+\frac{1}{3}\left(\frac{T_0}{T_s}\right)^4"))
story.append(P(f"With <i>T</i><sub>s</sub>&nbsp;=&nbsp;5772&nbsp;K and <i>T</i><sub>0</sub>&nbsp;=&nbsp;300&nbsp;K, this gives {R['petela_exergy_limit']:.4f}. This is the ceiling for any solar converter, biological or abiotic. The second ceiling is specific to photosynthesis. The theoretical maximum solar-to-biomass efficiency under full sunlight, computed from the stoichiometry and quantum requirements of carbon fixation, is about 4.6&nbsp;% for C<sub>3</sub> plants [6]. Real photosynthetic systems are substantially below that value, and cyanobacterial or algal photobioreactors inherit the same order of limitation."))
story.append(P("For single-junction photovoltaics the Shockley–Queisser detailed-balance limit is 33.7% [5], and practical modules are well below it. Figure 5 places the biophotovoltaic range reported by Qi et al. [7] against an ideal PV converter at 20% efficiency and the incident solar flux."))
story.append(EQ(r"\frac{P_{\mathrm{PV}}}{P_{\mathrm{BPV}}}=\frac{\eta_{\mathrm{PV}}\,S_0}{\left(P/A\right)_{\mathrm{BPV}}}"))
story.append(P(f"At 20% efficiency the ideal PV output is {R['pv_eta020_mW_m2']:.2e}&nbsp;mW&nbsp;m<super>-2</super>. The best reported biophotovoltaic device is about {R['bpv_best_gap_factor']:.0f} times lower, and the lowest is about {R['bpv_worst_gap_factor']:.1e} times lower. The biohybrid photovoltaic gap is therefore not a matter of optimisation at the margin. The most plausible role for biohybrid photosynthesis is chemical production, where the target is a molecule of value rather than electrons per square metre, which is the view taken in the earlier draft. We adopt it."))
story.append(FIGURE("fig05_bpv_pv.png", "Power density of whole-cell biophotovoltaic devices (range from Qi et al. 2024 [7], shown at its low and high ends) against ideal 20% photovoltaics and the incident solar flux at 1&nbsp;AU. Logarithmic scale; values are in mW&nbsp;m<super>-2</super>.", 0.85))

story.append(H2("5.1 Thermodynamic floors of biological and abiotic products"))
story.append(P("Before comparing processes it is useful to know the minimum work each product requires. The reversible work of a reaction at standard conditions is the change in standard Gibbs energy. It sets a floor for any process that produces the product from the same reactants, biological or abiotic, and it is independent of the route. We use tabulated standard formation free energies at 298&nbsp;K [19] and express the floor per kilogram of product."))
DG = {"H2O(l)": -237.1, "CO2(g)": -394.4, "CH4(g)": -50.5, "C6H12O6": -910.0}
dG_h2 = -DG["H2O(l)"] / 2.016                     # MJ per kg H2 (per mol H2 = 237.1 kJ)
dG_ch4 = (DG["CH4(g)"] - (DG["CO2(g)"] + 2 * DG["H2O(l)"])) / 16.04   # kJ per g
dG_glu = (DG["C6H12O6"] - (6 * DG["CO2(g)"] + 6 * DG["H2O(l)"])) * -1 / 180.16
dG_o2 = (2 * -DG["H2O(l)"]) / 32.00
ch4_dG_kJ = -(DG["CH4(g)"] - (DG["CO2(g)"] + 2 * DG["H2O(l)"]))
glu_dG_kJ = -(DG["C6H12O6"] - (6 * DG["CO2(g)"] + 6 * DG["H2O(l)"]))
dG_ch4_MJ_kg = ch4_dG_kJ / 16.04
thermo = [["Product", "Reaction (reversible)", "dG0 per mol", "Minimum work per kg product", "in kWh per kg"],
  ["H2", "H2O to H2 + 1/2 O2", "237.1 kJ", f"{dG_h2:.1f} MJ", f"{dG_h2/3.6:.1f}"],
  ["O2", "2 H2O to 2 H2 + O2", "474.2 kJ", f"{dG_o2:.1f} MJ", f"{dG_o2/3.6:.1f}"],
  ["CH4", "CO2 + 2 H2O to CH4 + 2 O2", f"{ch4_dG_kJ:.1f} kJ", f"{dG_ch4_MJ_kg:.1f} MJ", f"{dG_ch4_MJ_kg/3.6:.1f}"],
  ["Glucose", "6 CO2 + 6 H2O to C6H12O6 + 6 O2", f"{glu_dG_kJ:.1f} kJ", f"{dG_glu:.2f} MJ", f"{dG_glu/3.6:.2f}"]]
story.append(TABLE(thermo, [0.14, 0.38, 0.14, 0.17, 0.17], caption="<b>Table 5a.</b> Reversible work floors for four products (E for the standard values; the computed per-kilogram figures are exact arithmetic on them). Per-kilogram values assume complete conversion and no losses. Standard values to be checked against a primary table before any quantitative use."))
story.append(FIGURE("fig17_thermo.png", "Reversible work floors per kilogram of product, in kWh, on a logarithmic axis. The values are the arithmetic on the tabulated standard free energies in Table 5a; they bound any process for the same product regardless of route (S/E).", 0.8, label="5b"))
story.append(P(f"The table has two consequences. First, the floor for a product does not depend on whether a bacterium, a fungus, a photocatalyst or an electrolyser performs the transformation. Biology changes the form of the input energy (photons rather than electricity), the kinetic path and the selectivity, but not the thermodynamic minimum. Second, the floor for photosynthetic glucose, about {dG_glu:.1f}&nbsp;MJ per kilogram, is a useful reference for the chemical-production role argued in Section 5. The same arithmetic sets the energy floor for oxygen at about {dG_o2:.1f}&nbsp;MJ per kilogram, against which any living oxygen source in a habitat must be compared on energy, not on mass alone."))


story.append(H1("6&nbsp;&nbsp;Material circularity and the replacement burden"))
story.append(P("Circularity is often presented as a binary property: a loop is either closed or not. Equation (2) shows why that framing hides the economics. For constant demand <i>D</i> and recovery <i>&rho;</i>, with no separate leakage term, the external replacement grows linearly in time, and the burden is set by the unrecovered fraction."))
story.append(P("<b>Proposition 3 (linear replacement burden).</b> For constant <i>D</i>, <i>&rho;</i> and leakage <i>&lambda;X</i>, the cumulative replacement is <i>M(t) = [(1&minus;&rho;)D + &lambda;X] t</i>. Its sensitivity to recovery is <i>&part;M/&part;&rho; = &minus;Dt</i>, independent of the level of &rho;. <i>Proof.</i> Integrate Eq. (2) with constant right-hand side. The sensitivity follows by differentiation. ■"))
story.append(EQ(r"M(t)=\int_0^t\left[(1-\rho)D+\lambda X\right]\mathrm{d}s=\left[(1-\rho)D+\lambda X\right]t"))
story.append(P("The sensitivity result is the important one. Each additional nine in recovery reduces the replacement burden by the same absolute amount per unit time, but the economic value of that reduction depends on the cost of the marginal nine, which rises steeply as &rho; approaches one. A recovery system is therefore worth improving only while the marginal cost of recovery is below the replacement cost of the unrecovered material, which is a control-theoretic optimum rather than a closure target."))
mat_rows = [["Recovery &rho;", "Replacement per year (units)", "Replacement over 50 years", "Relative to &rho; = 0.999"]]
base = R["material_losses"]["0.999"]["loss_over_50y"]
for k_, v in R["material_losses"].items():
    mat_rows.append([k_, f"{v['loss_per_year']:.1f}", f"{v['loss_over_50y']:.1f}", f"{v['loss_over_50y']/base if base>0 else float('nan'):.2f}"])
story.append(TABLE(mat_rows, [0.2, 0.26, 0.27, 0.27], caption="<b>Table 3.</b> Replacement burden under Eq. (2) with D = 10 units per day and no leakage. The numerical integration over 50 years reproduces the closed form at &rho; = 0.99 (numeric %.1f, closed form %.1f). Units are normalised." % (R["material_numeric_check_rho099"]["numeric"], R["material_numeric_check_rho099"]["closed_form"])))
story.append(FIGURE("fig08_material.png", "Cumulative external replacement M(t) under Proposition 3 for four recovery fractions at constant demand. The curves are straight lines because the integrand is constant; the slope, not the curvature, carries the design information.", 0.82))

story.append(H2("6.1 A reference crew water budget"))
story.append(P(f"To connect Proposition 3 to a concrete system we use a four-person crew with a water throughput of 2.50&nbsp;kg per person per day, the figure reported for a crew's water requirement in the bioregenerative life-support review of Verbeelen and colleagues [12]. The annual gross demand is therefore {R['water_budget']['demand_per_year_kg']:,.0f}&nbsp;kg. Table 3b applies Eq. (2) with no leakage term, so that the replacement rate is the unrecovered fraction of demand."))
wb = [["Water recovery &rho;", "Replacement per year [kg]", "Replacement over 20 years [kg]", "Fraction of annual demand"]]
for k_, v in R["water_budget"]["rows"].items():
    wb.append([k_, f"{v['loss_per_year_kg']:,.1f}", f"{v['loss_over_20y_kg']:,.0f}", pct(1 - float(k_), 1)])
story.append(TABLE(wb, [0.22, 0.26, 0.30, 0.22], caption="<b>Table 3b.</b> Annual external water replacement for a four-person crew under recovery fractions &rho; (S), from Eq. (2) with the 2.50&nbsp;kg/day figure. The gain from each additional nine of recovery is linear in the unrecovered fraction, as Proposition 3 states."))
story.append(P("The table makes the economics concrete. Moving from 98% to 99.9% recovery reduces the annual replacement from 73&nbsp;kg to under 4&nbsp;kg for this crew. Whether that reduction justifies the additional purification, energy and hardware is a marginal-cost question, and it is answered by the architecture analysis of Section 11 rather than by closure targets."))

# ================================================================ 7 GRAVITY
story.append(H1("7&nbsp;&nbsp;Gravity-dependent extraction: what the evidence supports"))
story.append(P("The BioAsteroid experiment [8] is the most direct empirical anchor for biomining in space. It tested three conditions on L-chondrite material: a bacterium (<i>Sphingomonas desiccabilis</i>), a fungus (<i>Penicillium simplicissimum</i>) and a mixed consortium, each under microgravity on the International Space Station and under matched terrestrial gravity. The palladium results, as reported in press coverage of the paper, are summarised in Figure 7. We use the reported values and flag that they should be checked against the full text."))
story.append(P(f"Three numbers carry the argument. Abiotic palladium release is about 29.5% of the metal present at 1&nbsp;g and about 2.2% in microgravity. The reported ratio of about 13.6 is therefore the abiotic gravity penalty, and rounding of the reported means gives {R['Pd_abiotic_ratio_1g_over_ug']:.1f} from the rounded values. The fungal arm in microgravity releases about 11.9% of palladium, which is about {R['Pd_fungus_over_abiotic_ug']:.1f} times the abiotic microgravity value, reported as 5.5 times. The fungal yield therefore does not fall with gravity in the same way as the abiotic yield. That is the qualitative basis for a gravity-dependent comparative advantage of biology."))
story.append(FIGURE("fig06_bioasteroid_pd.png", "Palladium released from L-chondrite under three conditions, as reported for the BioAsteroid experiment in press coverage of npj Microgravity [8]. The abiotic control falls about 13-fold in microgravity; the fungal arm retains a yield about five times its abiotic microgravity value. Values to be verified against the primary paper.", 0.78))
story.append(P("Two limits constrain the inference. The experiment compares microgravity with 1&nbsp;g only. No partial-gravity arm, such as lunar (0.16&nbsp;g) or Martian (0.38&nbsp;g), is reported in the sources we retrieved, so the shape of the gravity dependence between those points is unknown. The second limit is statistical. Variability is large, and the consortium result differs from the fungal result, so one organism and one substrate cannot establish a general rule."))
story.append(H2("7.1 A gravity model with an explicit interval"))
story.append(P("To carry the qualitative result into the decision model, we define an abiotic gravity factor &zeta;(g) that equals the reported microgravity yield at in-orbit gravity and rises to 1 at Martian gravity. Between these anchors we interpolate log-linearly in <i>g</i>. The microgravity yield is treated as an uncertain parameter <i>z</i><sub>ug</sub> over [0.05, 0.50], which brackets the reported value of about 0.075. The interpolation shape is an assumption, not a fit."))
story.append(EQ(r"\zeta(g)=z_{\mathrm{ug}}+(1-z_{\mathrm{ug}})\,\mathrm{clip}\!\left(\frac{\log_{10}g-\log_{10}g_\mu}{\log_{10}g_M-\log_{10}g_\mu},\,0,\,1\right)"))
story.append(P("Here <i>g</i><sub>&mu;</sub> = 10<super>-6</super> in units of Earth gravity, and <i>g</i><sub>M</sub> = 0.38. Under this model, the energy cost of abiotic extraction scales as <i>c</i><sub>A</sub>/&zeta;(g), while the biological cost <i>c</i><sub>B</sub> is treated as gravity-independent. The gravity-independence of biology is an assumption supported only by the observation that the fungal arm was not penalised in this experiment; it is the single most important assumption to test."))
bio_rows = [["Gravity bin (log10 g)", "Share of draws with biological extraction cheaper in energy", "Interpretation"]]
labels_map = {"g<1e-5.5": ("g < 10<super>-5.5</super>", "orbital microgravity, 1e-6 region"),
              "1e-5.5..1e-4": ("10<super>-5.5</super> to 10<super>-4</super>", "microgravity, weaker"),
              "1e-4..3e-3": ("10<super>-4</super> to 3&times;10<super>-3</super>", "low gravity"),
              "3e-3..0.1": ("3&times;10<super>-3</super> to 0.1", "partial gravity, lower end"),
              "0.1..0.32": ("0.1 to 0.32", "partial gravity, lunar range"),
              "g>0.32": ("&gt; 0.32", "Mars and Earth gravity")}
for k_, (lab_, interp) in labels_map.items():
    bio_rows.append([lab_, f"{100*bioc[k_]:.1f}%", interp])
story.append(TABLE(bio_rows, [0.27, 0.36, 0.37], caption=f"<b>Table 4.</b> Test of the gravity hypothesis under the model above. Overall share across all draws: {100*R['bio_extraction_cheaper_overall']:.1f}%. Shares are conditional on the parameter ranges in Appendix D and on the interpolation in Eq. (15)."))
story.append(P("The result is a threshold phenomenon. Biological extraction is cheaper in energy for most draws in microgravity, for a substantial minority at intermediate low gravity, and for no draws at 0.32&nbsp;g or above, a result that follows from the parameter ranges, since the biological cost then exceeds the abiotic cost. That pattern is what the BioAsteroid comparison implies, but the location of the threshold between 10<super>-4</super> and 0.1&nbsp;g is set by the interpolation and by the prior ranges, not by data. A partial-gravity experiment is the single most informative test that could move this threshold."))

story.append(H2("7.2 Sensitivity of the threshold to the interpolation shape"))
story.append(P("Table 4 uses a log-linear interpolation of the abiotic gravity factor. The interpolation shape is an assumption, so we repeat the test with two alternatives: a linear interpolation in <i>g</i> rather than in log <i>g</i>, and a step at 10<super>-3</super>&nbsp;g. Table 4b reports the share of draws in which biological extraction is cheaper for each shape."))
ivr = [["Gravity bin", "log-linear (main)", "linear in g", "step at 10<super>-3</super> g"]]
for lab_ in ["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32", "overall"]:
    nice = {"g<1e-5.5": "g &lt; 10<super>-5.5</super>", "1e-5.5..1e-4": "10<super>-5.5</super> to 10<super>-4</super>", "1e-4..3e-3": "10<super>-4</super> to 3&times;10<super>-3</super>",
            "3e-3..0.1": "3&times;10<super>-3</super> to 0.1", "0.1..0.32": "0.1 to 0.32", "g>0.32": "&gt; 0.32", "overall": "all draws"}[lab_]
    ivr.append([nice] + [pct(R["interp_variants"][k_][lab_]) for k_ in ["loglinear", "linear_g", "step_1e-3"]])
story.append(TABLE(ivr, [0.31, 0.23, 0.23, 0.23], caption="<b>Table 4b.</b> Share of draws in which biological extraction is cheaper in energy, under three interpolation shapes for the abiotic gravity factor (S). Each column uses the same sampled parameters."))
story.append(P(f"The result separates into a robust part and a fragile part. The robust part is the endpoints: biological extraction is cheaper in microgravity under all three shapes ({pct(R['interp_variants']['loglinear']['g<1e-5.5'],0)} to {pct(R['interp_variants']['linear_g']['g<1e-5.5'],0)}), and it is never cheaper at 0.32&nbsp;g or above, because the parameter ranges place biological extraction costs above abiotic costs at unit gravity factor. The fragile part is the transition. The overall biological share ranges from {pct(R['interp_variants']['loglinear']['overall'],0)} to {pct(R['interp_variants']['linear_g']['overall'],0)} across the shapes, and the share in the 0.1 to 0.32&nbsp;g bin ranges from nearly zero to about {pct(R['interp_variants']['linear_g']['0.1..0.32'],0)}. Where the threshold lies is therefore not identified by the present evidence, and this is the strongest reason to prioritise the partial-gravity experiment of Section 13.1."))

# ================================================================ 8 STRUCTURE
story.append(H1("8&nbsp;&nbsp;Transport networks, branching and structural materials"))
story.append(H2("8.1 Murray's law as an optimum"))
story.append(P("Vascular networks, whether animal, plant or engineered, must deliver flow with low pumping work and low maintenance cost. Consider a single channel of radius <i>r</i> carrying flow <i>Q</i>, with pumping cost proportional to <i>Q</i><super>2</super>/<i>r</i><super>4</super> by Poiseuille's law [20], and maintenance cost proportional to the volume <i>r</i><super>2</super>. The cost per unit length is minimised at a radius that scales as the cube root of the flow. This is Murray's law [15]."))
story.append(EQ(r"f(r)=\frac{a\,Q^2}{r^4}+b\,r^2,\qquad r^\ast=\left(\frac{2a}{b}\right)^{1/6}Q^{1/3}"))
story.append(P(f"<b>Proposition 4 (Murray exponent).</b> Cost-minimising laminar branching gives <i>r</i><super>*</super> &prop; <i>Q</i><super>1/3</super>, so that for a symmetric bifurcation <i>r</i><sub>0</sub><super>3</super> = 2<i>r</i><sub>1</sub><super>3</super>. Numerically, minimising the cost over a log-spaced grid of flows gives a fitted exponent of {R['murray_fitted_exponent']:.4f} against the theoretical 1/3. <i>Proof.</i> Differentiate Eq. (16) and set the derivative to zero. This gives <i>r</i><super>6</super> &prop; <i>Q</i><super>2</super>. The symmetric relation follows from flow conservation <i>Q</i><sub>0</sub> = 2<i>Q</i><sub>1</sub>. ■", "body"))
story.append(P("The relation has a sharp consequence for design: halving a branch radius at fixed flow increases pressure drop by a factor of 16, since &Delta;<i>p</i> &prop; 1/<i>r</i><super>4</super>. A manifold designed for low flow resistance therefore has a fixed radius hierarchy that cannot be altered without a large pumping penalty. The vascular-inspired designs in the atlas (concepts 7, 42, 61, 76 and 108) inherit this constraint. Figure 8 confirms the scaling numerically."))
story.append(EQ(r"\Delta p=\frac{8\,\mu\,L\,Q}{\pi\,r^4}"))

story.append(H2("8.2 Mycelium and biomineral materials"))
story.append(P("For mycelium composites, a first homogenised model writes effective modulus as a power law in the load-bearing solid fraction, with constants calibrated experimentally. For biomineralised regolith, bond strength is controlled by the precipitated mass per unit feedstock. Neither relation has been calibrated for planetary simulants in the sources we consulted, so we record their structure and not their values."))
story.append(EQ(r"E_{\mathrm{eff}}=C\,E_s\,\phi^n,\qquad\frac{\mathrm{d}M_c}{\mathrm{d}t}=k_p A_s\,f(\mathrm{Ca}^{2+},\mathrm{CO}_3^{2-},\mathrm{pH},T,X)"))
story.append(P("The engineering boundary is set by the mechanics. Mycelium composites are candidates for insulation, acoustic panels and interior partitions. Biomineralised regolith is a candidate for sealing and binding dust in non-primary structure. Neither should be treated as a substitute for a primary pressure hull or dense radiation shielding, for which the relevant limits are set by stress, fatigue and particle transport rather than by biology. We therefore retain these concepts as secondary-structure candidates and exclude them from primary load paths."))

story.append(H2("8.3 Diffusion-limited biocementation depth"))
story.append(P("Biocementation requires a substrate to reach the treated volume. Where transport is by diffusion alone, the treated depth is limited by transport, not by biology. We model a stylised substrate <i>c</i>, held at a boundary, consumed by a biomass <i>X</i> that grows logistically and precipitates mineral in proportion to consumption."))
story.append(EQ(r"\frac{\partial c}{\partial t}=D\,\frac{\partial^2 c}{\partial x^2}-k\,c\,X,\qquad\frac{\partial X}{\partial t}=Y k\,c\,X\left(1-X\right)-m X", label="8a"))
story.append(P("For the diffusion-only case with a fixed boundary concentration, the depth at which <i>c</i> reaches a threshold <i>c</i><super>*</super> follows the similarity solution, which gives the prefactor in the front law. This is the verification target for the simulation."))
story.append(EQ(r"x_f(t)=2\,\mathrm{erfc}^{-1}\!\left(c^\ast\right)\sqrt{D t}", label="8b"))
story.append(P(f"<b>Proposition 7 (diffusion-limited depth).</b> Without consumption, the depth of the <i>c</i><super>*</super>-contour grows as the square root of time, with prefactor 2 erfc<super>-1</super>(<i>c</i><super>*</super>). For <i>c</i><super>*</super> = 0.05 the prefactor is {R['micp']['1e-09']['prefactor_theory']:.3f}. Consequently the time to reach a depth <i>L</i> scales as <i>L</i><super>2</super>/(4[erfc<super>-1</super>(<i>c</i><super>*</super>)]<super>2</super> <i>D</i>). <i>Proof.</i> The Dirichlet problem on a half-line has the similarity solution <i>c</i> = erfc(<i>x</i>/2&radic;(<i>Dt</i>)); setting it equal to <i>c</i><super>*</super> and solving for <i>x</i> gives the result. ■", "body"))
mic = R["micp"]
mrows = [["Diffusivity D [m<super>2</super> s<super>-1</super>]", "Measured log–log slope", "Measured prefactor a", "Theory prefactor", "Time to 10&nbsp;cm, theory [d]", "Time to 10&nbsp;cm, measured a [d]"]]
for key_, lab_ in [("1e-09", "1e-9"), ("4e-09", "4e-9")]:
    m_ = mic[key_]
    tm = (0.10 / m_["prefactor_a"]) ** 2 / float(key_) / 86400
    mrows.append([lab_, f"{m_['loglog_slope']:.3f}", f"{m_['prefactor_a']:.3f}", f"{m_['prefactor_theory']:.3f}", f"{m_['t_to_10cm_days']:.1f}", f"{tm:.1f}"])
story.append(TABLE(mrows, [0.2, 0.15, 0.15, 0.15, 0.17, 0.18], caption="<b>Table 8a.</b> Diffusion-limited front in the stylised biocementation model (S), with the pure-diffusion theory of Proposition 7. The measured slope is below 0.5 and the measured prefactor below the theory because consumption retards the front. Time to 10&nbsp;cm is therefore a lower bound from theory."))
story.append(P("The reaction retards the front, as expected, but the scaling is the important result. Depth grows as the square root of time, so doubling the treated depth quadruples the required time. A block of 10&nbsp;cm treated by diffusion alone needs weeks at a diffusivity of 10<super>-9</super>&nbsp;m<super>2</super>&nbsp;s<super>-1</super>. Engineered biocement components must therefore rely on forced transport (flow, pressure or multi-point injection) or on thin-section fabrication, and the production rate of any biocement plant is set by this diffusion time, not by microbial growth rate."))
story.append(FIGURE("fig15_micp.png", "Left: depth of the 5% substrate contour against time for two diffusivities, with the fitted a&radic;(Dt) law (dotted). Right: final precipitate profile normalised to its maximum. Stylised parameters (Appendix D).", 1.0, label="8c"))

# ================================================================ 9 NETWORK ROBUSTNESS
story.append(H1("9&nbsp;&nbsp;Network robustness of distributed infrastructure"))
story.append(P("Distributed infrastructure such as swarms of collectors, robotic maintainers or modular habitats depends on the connectivity of its communication or resource graph. Algebraic connectivity <i>&lambda;</i><sub>2</sub> of the graph Laplacian is the standard measure. It is zero if and only if the graph is disconnected, and Fiedler's inequality bounds it above by the vertex connectivity [16]."))
story.append(EQ(r"\lambda_2(L)=\min_{x\perp\mathbf{1},\;|x|=1}x^{\mathrm{T}}Lx,\qquad\lambda_2(L)\leq\kappa(G)\leq\delta(G)"))
story.append(P("Consensus dynamics on the graph, <i>&dot;y = &minus;L</i><sub>G</sub><i>y + B u</i>, converge at a rate governed by <i>&lambda;</i><sub>2</sub> under standard assumptions [17]. The practical question is how fast connectivity is lost when units fail. We answer it for a random-geometric swarm of <i>N</i> = 300 units, each connected to its <i>k</i> nearest neighbours, with units removed uniformly at random."))
st_rows = [["Units lost", "P(connected), k=4", "P(connected), k=6", "P(connected), k=8"]]
for i_, f_ in enumerate(sw["fail_fracs"]):
    if i_ % 2 == 0:
        st_rows.append([f"{f_:.2f}", f"{sw['4']['p_connected'][i_]:.2f}", f"{sw['6']['p_connected'][i_]:.2f}", f"{sw['8']['p_connected'][i_]:.2f}"])
story.append(TABLE(st_rows, [0.25, 0.25, 0.25, 0.25], caption=f"<b>Table 5.</b> Probability that the surviving graph is connected, from 25 trials per cell (N = 300). Median threshold where P(connected) first falls below 0.5: k=4 at {swarm_threshold(4)}, k=6 at {swarm_threshold(6)}, k=8 at {swarm_threshold(8)}."))
story.append(P("The threshold rises with local degree, so denser local wiring buys robustness, but the cost is communication bandwidth and collision risk. The threshold is a property of the random-loss model. Targeted loss of hub units is more damaging, and the swarm must be designed against the worse case. Concepts 74, 84, 94 and 102 in the atlas describe swarm maintenance and logistics, and each must specify its loss model before its robustness is claimed."))
story.append(FIGURE("fig07_murray_swarm.png", "Left: optimal radius against flow for the cost f(r) in Eq. (16), on log–log axes, with the slope-1/3 Murray line. Right: probability that a random-geometric swarm of 300 units stays connected as units are lost at random, for three local degrees.", 1.0))

story.append(H2("9.1 Targeted loss of hub units"))
story.append(P("Random loss is the benign case for a distributed network. A targeted failure mode removes the most connected units first, for example a shared communication relay or a high-load maintenance hub. We compare the two loss models on the same graphs at k = 6, and report the connectivity probability and the mean algebraic connectivity."))
tgt = R["swarm_targeted"]
trows = [["Units lost", "P(conn), random", "P(conn), hub-first", "&lambda;<sub>2</sub>, random", "&lambda;<sub>2</sub>, hub-first"]]
for i_, f_ in enumerate(tgt["fail_fracs"]):
    if i_ % 2 == 0 or 0.25 <= f_ <= 0.35:
        trows.append([f"{f_:.2f}", f"{tgt['random'][i_]:.2f}", f"{tgt['hub_first'][i_]:.2f}", f"{tgt['lam2_random'][i_]:.3f}", f"{tgt['lam2_hub'][i_]:.3f}"])
story.append(TABLE(trows, [0.16, 0.21, 0.21, 0.21, 0.21], caption=f"<b>Table 9b.</b> Connectivity and algebraic connectivity under random and hub-first loss, N = 300, k = 6, 25 trials per cell (S). Connectivity thresholds, where the probability first falls below 0.5: random at {tgt and R['swarm_targeted_thresholds']['random']:.2f}, hub-first at {R['swarm_targeted_thresholds']['hub_first']:.2f}."))
story.append(P(f"Hub-first loss is more damaging than random loss. The threshold falls from {R['swarm_targeted_thresholds']['random']:.2f} to {R['swarm_targeted_thresholds']['hub_first']:.2f}, and the algebraic connectivity collapses to zero at a lower loss fraction. This matters for the atlas: any swarm concept that relies on a central relay, a shared power bus or a single maintenance hub must have its robustness stated under targeted loss, not only under random loss. The random-loss threshold also moves between independent runs by a few hundredths because of sampling noise, which is why the table reports the trial count."))

# ================================================================ 10 VIABILITY
story.append(H1("10&nbsp;&nbsp;Robust viability of a two-channel repair system"))
story.append(P("Repair can be carried out by a biological channel, which is slow but resource-cheap, or by an abiotic channel, which is fast but consumes resource. The question is whether one of these channels, used alone, can keep the system admissible when disturbances act adversarially. We consider a stylised state <i>s = (x, d)</i>, where <i>x</i> is an available resource stock and <i>d</i> is accumulated damage, both normalised to [0, 1]. The admissible set is <i>&kappa;</i> = {x &ge; 0.25, d &le; 0.60}."))
story.append(EQ(r"x_{t+1}=\mathrm{clip}\!\left(x_t+p(1-d_t)-c_u-\omega_w,\,0,\,1\right),\quad d_{t+1}=\mathrm{clip}\!\left(d_t+\delta_w-r_u(0.4+0.6x_t),\,0,\,1\right)"))
story.append(P("The control <i>u</i> &isin; {bio, abiotic} sets resource cost <i>c</i><sub>u</sub> and repair rate <i>r</i><sub>u</sub>. The disturbance <i>w</i> &isin; {nominal, adversarial} sets additional damage &delta;<sub>w</sub> and additional resource loss &omega;<sub>w</sub>. Parameter values are chosen to make the channels differ in cost and speed, and are not calibrated to any system. The robust kernel is computed by iterating Eq. (21) on a 161 &times; 161 grid, with the adversary choosing the worst disturbance at each step."))
story.append(EQ(r"\mathcal{K}_{n+1}=\mathcal{K}_n\cap\left\{s:\ \exists\,u\ \ \forall\,w\ \ f(s,u,w)\in\mathcal{K}_n\right\}"))
ka = [["Strategy", "Kernel fraction of admissible set", "Interpretation"],
      ["Nominal disturbance, both channels", pct(viab["kernel_nominal_fraction"]), "Admissible set is viable under nominal disturbance, so nominal viability is trivial here."],
      ["Adversarial disturbance, both channels (switching)", pct(viab["kernel_robust_fraction"]), "Viability requires state-dependent switching between channels."],
      ["Adversarial disturbance, biological channel only", pct(viab["robust_bio_only_fraction"]), "Damage accumulates faster than biological repair can remove it."],
      ["Adversarial disturbance, abiotic channel only", pct(viab["robust_abiotic_only_fraction"]), "Resource is consumed faster than production replenishes it."]]
story.append(TABLE(ka, [0.38, 0.2, 0.42], caption="<b>Table 6.</b> Viability kernels of the two-channel repair system (S). Iteration converged in %d steps for the robust switching kernel. The switching kernel is a subset of the nominal kernel (verified: %s)." % (viab["iterations_robust"], str(viab["robust_subset_of_nominal"]))))
story.append(P("<b>Proposition 5 (monotonicity of robust viability).</b> The robust kernel is contained in the nominal kernel, and both are the largest subsets of &kappa; that are invariant under the backward operator (21). <i>Proof.</i> Taking the intersection over a larger disturbance set can only remove states, so the robust operator is dominated by the nominal operator at every iteration. Invariance follows because the iteration stops at a fixed point that satisfies the viability condition, and the largest such set is the kernel. ■"))
story.append(P(f"The result in the toy system is qualitative but informative. At the default disturbance, neither channel suffices alone under adversarial disturbance (Section 10.1 shows how this depends on the adversary). The biological channel fails by damage accumulation; the abiotic channel fails by resource exhaustion. A switching controller retains {pct(viab['kernel_robust_fraction'])} of admissible states, and {pct(viab['robust_states_high_damage_frac'])} of those states lie at damage above 0.40, where the controller must rely on the faster abiotic channel. The magnitude of the switching gain depends on the chosen dynamics and is not a prediction. The structural statement, that a robust biohybrid controller can be strictly better than either pure strategy, is the part that transfers to any system with the same channel structure."))
story.append(FIGURE("fig09_viability.png", "Admissible set (grey) and viability kernels (coloured) of the two-channel repair system on the resource–damage state plane. Left: nominal disturbance, where the kernel equals the admissible set. Right: adversarial disturbance, where the kernel shrinks to a switching region. Stylised parameters; see Appendix D.", 1.0))

story.append(H2("10.1 Dependence on adversary strength and production"))
story.append(P("The single-channel result in Table 6 holds at one disturbance level and one production rate. To test how it depends on those choices, we sweep the adversarial damage per step from 0.04 to 0.20, and the production rate from 0.06 to 0.14, recomputing the robust kernel for the switching controller and for each single channel. Figure 9b shows the sweeps and Table 6a gives the values."))
sw_rows_v = [["Setting", "Switching", "Biological only", "Abiotic only", "Switching gain"]]
for dv, a_, b_, c_ in zip(R["viab_sweep_delta"]["x"], R["viab_sweep_delta"]["switching"], R["viab_sweep_delta"]["bio_only"], R["viab_sweep_delta"]["abiotic_only"]):
    sw_rows_v.append([f"&delta;<sub>adv</sub> = {dv:.2f}, p = 0.10", pct(a_), pct(b_), pct(c_), f"{100*(a_-max(b_,c_)):+.1f} pp"])
for pv, a_, b_, c_ in zip(R["viab_sweep_prod"]["x"], R["viab_sweep_prod"]["switching"], R["viab_sweep_prod"]["bio_only"], R["viab_sweep_prod"]["abiotic_only"]):
    sw_rows_v.append([f"p = {pv:.2f}, &delta;<sub>adv</sub> = 0.12", pct(a_), pct(b_), pct(c_), f"{100*(a_-max(b_,c_)):+.1f} pp"])
story.append(TABLE(sw_rows_v, [0.36, 0.14, 0.17, 0.16, 0.17], caption="<b>Table 6a.</b> Robust kernel fraction under adversary-strength and production sweeps (S). Switching gain is the switching kernel minus the better single channel, in percentage points."))
_gains = [a_ - max(b_, c_) for a_, b_, c_ in zip(R["viab_sweep_delta"]["switching"], R["viab_sweep_delta"]["bio_only"], R["viab_sweep_delta"]["abiotic_only"])]
story.append(P(f"Three regimes appear. For weak adversaries (&delta;<sub>adv</sub> = 0.04) the biological channel alone already attains the switching kernel, so switching adds nothing. For intermediate adversaries the switching controller is strictly better than either channel, with a gain of up to {100*max(_gains):.1f} percentage points at &delta;<sub>adv</sub> = 0.12. For strong adversaries (&delta;<sub>adv</sub> = 0.20) no strategy among these is robustly viable. The production sweep shows a related effect: at production 0.12 the abiotic channel alone matches the switching controller, so the switching gain is sensitive to the resource economy. The qualitative lesson is that the value of a second channel depends on which constraint binds, damage or resource, and this depends on the environment. The magnitudes are not predictions of any real system."))
story.append(FIGURE("fig13_viab_sweep.png", "Robust kernel fraction against adversary strength (left) and production rate (right) for the switching controller and each single channel. Stylised parameters (Appendix D).", 0.95, label="9b"))

# ================================================================ 11 ARCHITECTURE
story.append(H1("11&nbsp;&nbsp;Architecture comparison and the hybrid region"))
story.append(P("The architecture question is answered here with a stylised, normalised decision model. We emphasise that its purpose is to make the structure of the trade-off explicit and to test where conclusions depend on assumptions, not to predict the absolute cost of any infrastructure. Each architecture produces one unit of product per year. Costs are normalised so that the abiotic extraction energy at 1&nbsp;g equals <i>c</i><sub>A</sub>."))
story.append(H2("11.1 Objectives"))
story.append(EQ(r"M_A=(1-\rho_A)+m_A,\qquad M_B=(1-\rho_B)+m_B+\Phi_B(1-F),\qquad M_C=(1-\rho_C)+m_A+m_B+\Phi_B(1-F)"))
story.append(EQ(r"E_A=\frac{c_A}{\zeta(g)}+e^{\mathrm{rec}}_A+e_0,\quad E_B=c_B+e^{\mathrm{rec}}_B+e_0,\quad E_C=\min\!\left(\frac{c_A}{\zeta(g)},c_B\right)+\delta+e^{\mathrm{rec}}_B+0.1\,e^{\mathrm{rec}}_A+e_0"))
story.append(EQ(r"p_A=p^0_A(1+k_A R),\qquad p_B=p^0_B(1+k_B R),\qquad p_C=p_A\,p_B"))
story.append(EQ(r"\rho_B=\rho^0_B\,(0.5+0.5\,W),\qquad\rho_C=1-(1-\rho_A)(1-\rho_B)"))
story.append(P("The hybrid's import mass includes both sets of hardware, <i>m</i><sub>A</sub> + <i>m</i><sub>B</sub>, because two production lines must be carried. Its energy takes the cheaper extraction route at each draw, plus a switching overhead &delta;, and it runs the biological recovery loop actively while keeping the abiotic recovery on standby at 10% energy. Its failure probability is the product of the two channel failure probabilities, which is the redundancy assumption, under which the system fails only when both channels fail. Environmental variables enter through &zeta;(g), water closure <i>W</i>, radiation <i>R</i> and feedstock <i>F</i>. Table D1 in Appendix D gives the sampled ranges."))
story.append(P("The redundancy assumption is the reason the hybrid is never dominated on failure. Because <i>p</i><sub>C</sub> = <i>p</i><sub>A</sub><i>p</i><sub>B</sub> is at most the smaller of the two single-channel failure probabilities, the three-objective Pareto set always contains the hybrid. We report this as a structural fact, not as a result. The informative questions are how much the hybrid costs in mass and energy for that reliability, and under which conditions it is worth paying for."))
story.append(H2("11.2 Dominance and the failure-weight sweep"))
story.append(EQ(r"J_\lambda(\iota)=M_\iota+E_\iota+\lambda\,p_\iota,\qquad\iota^\ast_\lambda=\mathrm{arg\,min}_{\iota\in\{A,B,C\}}J_\lambda(\iota)"))
story.append(P("The weight &lambda; expresses how strongly reliability is valued relative to mass and energy, both normalised to the abiotic reference. We sweep &lambda; over four values. At &lambda;&nbsp;=&nbsp;0 the comparison is purely about mass and energy. The sweep is the most important diagnostic in this section, because it separates the portion of the hybrid's advantage that comes from reliability from the portion that comes from cost."))
sw_rows = [["&lambda;", "Winner: abiotic (A)", "Winner: biological (B)", "Winner: hybrid (C)"]]
for l_ in ["0.0", "1.0", "3.0", "10.0"]:
    o = lam[l_]["overall"]
    sw_rows.append([l_, pct(o["A"]), pct(o["B"]), pct(o["C"])])
story.append(TABLE(sw_rows, [0.16, 0.28, 0.28, 0.28], caption=f"<b>Table 7.</b> Share of {pareto['n_draws']:,} Monte Carlo draws won by each architecture under J<sub>&lambda;</sub>, over the uniform environment sweep. The hybrid's win share is driven by &lambda;; at &lambda;&nbsp;=&nbsp;0 the abiotic architecture wins most draws."))
story.append(P(f"At &lambda;&nbsp;=&nbsp;0 the hybrid wins {pct(lam['0.0']['overall']['C'])} of draws and the abiotic architecture wins {pct(lam['0.0']['overall']['A'])}. The biological architecture wins only {pct(lam['0.0']['overall']['B'])}, because biological extraction is energetically expensive in this parameterisation (c<sub>B</sub> at least 1.5) and carries feedstock and hardware penalties, so it wins only where abiotic extraction is costly and those penalties are small. At &lambda;&nbsp;=&nbsp;10 the hybrid wins {pct(lam['10.0']['overall']['C'])} of draws. The hybrid's position is therefore a reliability position, purchased at a mass cost, and it is sensitive to the weight given to failure."))
story.append(P(f"The mass cost is measured directly. Averaged across draws, the hybrid's import mass exceeds the better single architecture by {pareto['mean_redundancy_mass_penalty_C_vs_best_single']:.3f} normalised units, and its median failure probability is lower by a factor of {pareto['median_failure_reduction_factor_C_vs_best_single']:.1f}. Whether that exchange is acceptable depends on the value of reliability relative to mass in a specific mission, which is a decision the model makes visible but does not make."))

story.append(H2("11.3 Where the hybrid region lies"))
story.append(P("Figure 10 gives the two spatial results. The left panel shows the probability, over the sampled parameter ranges, that biological extraction is cheaper in energy, as a function of log gravity and water closure. The right panel shows the winner by gravity regime at &lambda;&nbsp;=&nbsp;0, which is the setting in which the gravity-dependent extraction result alone should determine the choice between A, B and C. We read the pattern as follows: the hybrid wins most often in microgravity because it takes the cheaper extraction route at a mass cost smaller than the energy saving. It loses to the abiotic architecture under partial gravity, where the abiotic energy advantage is decisive."))
story.append(FIGURE("fig10_pareto_env.png", "Left: probability that biological extraction energy is below abiotic extraction energy, across log gravity and water closure, from the Monte Carlo sweep. Right: winner share by gravity regime at &lambda;&nbsp;=&nbsp;0 (J = M + E), showing the abiotic, biological and hybrid architectures. Parameter ranges in Appendix D.", 1.0))

story.append(H2("11.4 Sensitivity"))
story.append(P("Figure 11 reports how far the hybrid's win share moves across the quintiles of each uncertain parameter, at &lambda;&nbsp;=&nbsp;10. The parameters with the largest effects are the abiotic failure base rate and the biological feedstock penalty. The largest single influence is therefore a reliability parameter, and the second is a resource-availability parameter, which is consistent with the reliability argument above. The effect of the biological extraction energy <i>c</i><sub>B</sub> is small under this weighting, because the hybrid's reliability advantage dominates at &lambda;&nbsp;=&nbsp;10. At lower failure weights the ranking changes: at &lambda;&nbsp;=&nbsp;0 and &lambda;&nbsp;=&nbsp;1 the biological hardware mass and the feedstock penalty are the largest influences on the hybrid's share (Appendix H), so the cost structure, not the failure rate, governs the hybrid when reliability is not heavily valued."))
sens_rows = [["Parameter", "Min share across quintiles", "Max share across quintiles", "Range"]]
for k_, v in sens_sorted:
    sens_rows.append([sens_label.get(k_, k_), pct(v["min"]), pct(v["max"]), pct(v["range"])])
story.append(TABLE(sens_rows, [0.46, 0.18, 0.18, 0.18], caption="<b>Table 8.</b> Sensitivity of the hybrid's win share at &lambda;&nbsp;=&nbsp;10 to each uncertain parameter, computed as the spread of the win share across quintiles of that parameter's sampled values."))
story.append(FIGURE("fig11_tornado.png", "Sensitivity of the hybrid's win share at &lambda;&nbsp;=&nbsp;10 to each uncertain parameter. Bars show the range of the win share across quintiles of that parameter. The dashed line marks the overall win share.", 0.85))

story.append(H2("11.5 Two-dimensional environment map"))
story.append(P(f"Figure 11b fixes gravity at two levels and maps the hybrid's share at &lambda;&nbsp;=&nbsp;1 over radiation and water closure, averaging over the other sampled parameters. Under microgravity the hybrid's mean share is {100*np.mean(np.array(R['map2d']['g1e-5']['hybrid'])):.0f}%, and under 0.1&nbsp;g it is {100*np.mean(np.array(R['map2d']['g0.1']['hybrid'])):.0f}%. Radiation and water closure move the share within each panel, but the gravity effect is the larger of the two. This supports the reading that the hybrid's region is set primarily by gravity, with radiation and water closure as secondary modulators."))
story.append(FIGURE("fig14_map2d.png", "Share of draws in which the hybrid architecture has the lowest J<sub>1</sub> = M + E + p, as a function of radiation index R and water closure W, at gravity 10<super>-5</super> g (left) and 0.1 g (right). Each cell averages 400 draws of the other parameters (S).", 1.0, label="11b"))

# ================================================================ 12 ATLAS
story.append(H1("12&nbsp;&nbsp;The 110-concept atlas: maturity audit"))
story.append(P("The earlier draft organised 110 engineering concepts into six phases, ordered by the Sagan scale of the power they would serve. The atlas is a design space, not a set of validated proposals. We audited it for internal consistency with the constraints of Sections 3 to 11. Each concept carries a maturity tag: <b>B</b> uses living biological systems, <b>H</b> combines biological and engineered components, <b>M</b> mimics biology with nonliving materials or machines, <b>E</b> is demonstrated in terrestrial engineering, <b>L</b> has laboratory or spaceflight proof of concept, <b>P</b> is a plausible research proposal, and <b>S</b> is speculative. Tags are assigned by the draft and retained here, except where the audit below records a correction."))
ph_rows = [["Phase (scale)", "B", "H", "M", "E", "L", "P", "S"]]
phase_name = {"I": "I (K ≈ 0.7–1)", "II": "II (K ≈ 1–1.5)", "III": "III (K ≈ 1.5–2)", "IV": "IV (K ≈ 2)", "V": "V (K ≈ 2–3)", "VI": "VI (K &gt; 3)"}
for ph in ["I", "II", "III", "IV", "V", "VI"]:
    row = [phase_name[ph]] + [str(phase_tags[ph][t]) for t in "BHMELPS"]
    ph_rows.append(row)
ph_rows.append(["All phases"] + [str(atl.get(t, 0)) for t in "BHMELPS"])
story.append(TABLE(ph_rows, [0.3] + [0.1] * 7, caption="<b>Table 9.</b> Count of maturity tags per phase. Concepts with multiple tags count once per tag. Total %d concepts." % R["atlas_n"]))
story.append(FIGURE("fig12_atlas.png", "Maturity tags across the six atlas phases. Experimental and terrestrial-engineering tags (E, L) are rare in the later phases, which is the expected pattern. Phases IV to VI are dominated by proposals and speculation.", 0.9))
story.append(H3("Audit findings"))
story.append(P("<b>F1. Biological tags on collectors.</b> No concept describing a collector, radiator or solar surface carries a B tag. This is consistent with the draft's statement that living organisms do not belong on exposed collectors. Concept 2, a terrestrial biohybrid leaf, carries an H tag and sits in phase I, where biology is appropriate. Concept 83, a distributed sensing layer for collector health, carries an H tag that implies a living component. Its description, inspired by biological nociception, refers to nonliving sensors, so the tag should be M. We correct it in the atlas summary and flag it here."))
story.append(P("<b>F2. Biological tags in the stellar phase.</b> Concepts 77, 80, 82 and 85 carry B tags and describe protected manufacturing, closed biospheres or asteroid-based refining. These are consistent with the draft's boundary that biology sits upstream of the collectors, and they remain in the atlas. Concept 82, an asteroid-to-collector refinery, uses a biological extraction step followed by conventional refining, which matches the draft's description."))
story.append(P("<b>F3. Speculative tags in the galactic phase.</b> Phase VI concepts carry B tags only where the biology is preserved or manufactured locally (101, 104, 105, 106, 109). The draft says that no biological activity is assumed in interstellar vacuum, and the tags agree. Concept 110, a viability limit analysis, is retained as a research question rather than an engineering proposal."))
story.append(P("<b>F4. Phases with little evidence.</b> The atlas contains 6 concepts tagged L and 18 tagged E; all of these lie in phases I to III. Phases IV to VI contain no L-tagged concept. This asymmetry is the main reason we describe the later phases as design space rather than engineering plan."))

# ================================================================ 13 FALSIFICATION
story.append(H1("13&nbsp;&nbsp;Predictions, status and a falsification programme"))
story.append(P("Table 10 lists the framework's predictions with their current status. Several predictions from the earlier draft are kept, updated with the results of this paper. Predictions H1 to H9 combine the earlier draft's list with the results of this paper. The status column distinguishes what has been proved, what has been checked numerically, and what remains untested."))
pred = [["#", "Prediction", "Status"],
        ["P1", "Exact capture-geometry law: &eta; f<sub>cov</sub> &ge; P/L<sub>&odot;</sub>, radius-independent", "Proved (Prop. 1)"],
        ["P2", "Shell temperature T &prop; r<super>-1/2</super>; extraction lowers T by (1&minus;&eta;)<super>1/4</super>", "Proved (Prop. 2)"],
        ["P3", "Replacement burden grows linearly; marginal value of recovery is constant in absolute terms", "Proved (Prop. 3)"],
        ["P4", "Murray exponent 1/3 for cost-minimising branching", "Proved; numerically confirmed (Prop. 4)"],
        ["P5", "Robust viability kernel is contained in nominal kernel", "Proved (Prop. 5)"],
        ["H1", "Biological extraction energy is below abiotic in microgravity, for most parameter draws", "Conditional on the gravity interval and on one reported experiment: %s of draws" % pct(bioc["g<1e-5.5"], 0)],
        ["H2", "Biological extraction energy is below abiotic at 0.32 g or above", "Zero under the model by construction of the parameter ranges; not an empirical test"],
        ["H3", "Hybrid architecture wins on combined mass and energy", "Conditional: wins at &lambda;=0 in %s of draws, mainly in microgravity" % pct(lam["0.0"]["overall"]["C"], 0)],
        ["H4", "Hybrid architecture is strictly more reliable than either single architecture", "Holds by construction under independence; median factor %.1f" % pareto["median_failure_reduction_factor_C_vs_best_single"]],
        ["H5", "Robust viability requires switching between biological and abiotic repair", "Holds in the stylised system; magnitude not a prediction"],
        ["H6", "Biofilm/fungal extraction in microgravity is more reliable than abiotic", "Supported in one experiment with large variability; not established"],
        ["H7", "Partial-gravity (0.16 g and 0.38 g) extraction shows the threshold location predicted in Section 7", "Untested. Decisive experiment; see Section 13.1"],
        ["H8", "Type III capture is energetically possible from one star", "Refuted by Eq. (8): needs %.2e solar luminosities" % TYPE3_RATIO],
        ["H9", "Biohybrid photovoltaics rival industrial PV in electrical output", "Refuted by the reported range: at best a factor of %.0f below ideal PV" % R["bpv_best_gap_factor"]]]
story.append(TABLE(pred, [0.07, 0.6, 0.33], caption="<b>Table 10.</b> Predictions, with current status. P = proved, H = hypothesis. A refuted hypothesis is retained because it constrains the design space."))

story.append(H2("13.1 A decisive experiment"))
story.append(P("The most useful next measurement is not another microgravity run. It is a set of partial-gravity arms. A centrifuge-based or sounding-rocket experiment could compare abiotic and fungal leaching of the same substrate at four gravity levels, for example 10<super>-6</super>, 0.16, 0.38 and 1&nbsp;g, with matched controls and a fixed reactor geometry. The primary outcome is extracted fraction per element. The secondary outcomes are energy per extracted kilogram and failure rate of the biological arm. The prediction, under our model, is that the cost crossover between abiotic and biological extraction lies between 10<super>-4</super> and 0.1&nbsp;g. A result that places the crossover at lunar gravity or above would falsify the threshold interval assumed in Section 7, and would be informative in its own right."))
story.append(P("Two design requirements follow. The arms must be replicated across organisms and substrates, because the BioAsteroid consortium result shows that organism choice changes the outcome. And every arm must report extraction energy, not only extraction fraction, because the decision model is sensitive to energy and the literature usually reports fractions alone."))

# ================================================================ 14 SAFETY
story.append(H1("14&nbsp;&nbsp;Planetary protection, containment and ecological escape"))
story.append(P("Any biological component of infrastructure raises issues that are not present in abiotic systems. These include forward contamination of planetary surfaces, genetic drift in long-running cultures, escape of engineered organisms into an ecosystem, and the spread of a fault from a biological module to its neighbours. The COSPAR policy on planetary protection sets the framework for missions that carry living material beyond Earth [18], and it is the reference against which any biological infrastructure must be assessed."))
story.append(P("We treat containment as an engineering requirement with explicit parameters. Each biological module must specify a containment level, a maximum credible escape rate, a genetic-stability interval after which the strain is replaced, and a fault-isolation rule that keeps a failed module from propagating through shared resource lines. These parameters are not fitted in this paper. Their absence is one reason the atlas tags remain conditional."))
story.append(P("Two specific risks deserve mention. Engineered microbial production is sensitive to evolutionary drift, and a production strain that performs well at launch may not do so after many generations. Biological repair can also fail silently, so that a damaged module appears functional until it is replaced. Both risks argue for monitoring and redundancy as design primitives, which is the hybrid's rationale in Section 11."))

story.append(H1("15&nbsp;&nbsp;Design rules derived from the analysis"))
story.append(P("The analysis yields a short set of design rules. Each rule states what the evidence supports, its basis in this paper, and its status. Rules are conditional on the stated assumptions and should be revisited when the partial-gravity experiment is performed."))
dr = [["#", "Design rule", "Basis", "Status"],
      ["D1", "Keep collectors, radiators and primary load-bearing structure abiotic", "Props. 1 and 2; Table 2", "Proved (exact identities)"],
      ["D2", "Size radiators from Eq. (11) before choosing a biological reactor temperature; biology gives no thermal relief", "Fig. 4; Section 4.3", "Proved"],
      ["D3", "Place biological extraction only where the gravity threshold is validated; do not commit on the present interval", "Table 4; Table 4b; Section 7.2", "Conditional; threshold unidentified"],
      ["D4", "Value recovery by its marginal effect on replacement, since replacement is linear in (1&minus;&rho;)", "Prop. 3", "Proved"],
      ["D5", "Use at least two repair channels, selected by the binding constraint (damage or resource)", "Table 6; Table 6a; Fig. 9b", "Holds in the stylised system"],
      ["D6", "Use local autonomy at distances beyond about 0.1&nbsp;AU; centralised control is limited to periods of 6&tau;<sub>rt</sub>", "Prop. 6; Table 4a", "Proved under the delay-margin condition"],
      ["D7", f"Choose local wiring degree from the target loss fraction; degree 6 crosses 50% connectivity near {swarm_threshold(6):.2f} random loss, and lower under hub-first loss (Table 9b)", "Table 5; Table 9b; Table E1", "Numerical (random and targeted models)"],
      ["D8", "Price hybrid redundancy explicitly as import mass; reliability, not cost, drives the hybrid's win", "Table 7; Section 11.2", "Numerical and conditional"],
      ["D9", "Report extraction energy per kilogram alongside extraction fraction in every biomining study", "Section 13.1", "Recommendation"]]
story.append(TABLE(dr, [0.06, 0.52, 0.22, 0.20], caption="<b>Table 15.</b> Design rules, their basis and status."))

story.append(H1("16&nbsp;&nbsp;Verification, convergence and reproducibility checks"))
story.append(P("Every numerical result is checked against an independent computation where one is available. Table 16a lists the checks, with the measured discrepancy. Table 16b reports convergence of the two stochastic or discretised quantities that carry the main conclusions: the Monte Carlo shares of Section 11, and the robust kernel fraction of Section 10 as a function of grid resolution."))
vv = R["verify"]
vrows = [["Check", "Independent method", "Measured discrepancy", "Tolerance / result"],
         ["Algebraic connectivity, one 300-unit graph", "dense eigvalsh vs sparse eigsh", f"{vv['lambda2_dense_minus_sparse']:.1e}", "< 1e-10: pass"],
         ["Shell temperature (eta = 0.26)", "bisection on the energy residual vs closed form", f"{vv['T_eq_bisection_minus_closed']:.1e} K", "< 1e-6 K: pass"],
         ["Murray optimum, Q = 1", "grid minimisation vs closed form (2a/b)<super>1/6</super>", f"{vv['murray_closed_minus_numeric_Q1']:.1e}", "< 1e-4: pass"],
         ["Replacement integral, rho = 0.99", "Euler integration vs closed form", f"{vv['material_closed_minus_numeric']:.1e}", "< 1e-6: pass"],
         ["Pareto dominance code", "brute-force pairwise check on 2000 random triples", f"{vv['dominance_mismatches']} mismatches", "0 mismatches: pass"],
         ["Robust kernel nested in nominal", "set inclusion on the grid", "verified", "True: pass"]]
story.append(TABLE(vrows, [0.28, 0.34, 0.2, 0.18], caption="<b>Table 16a.</b> Verification checks against independent computations."))
story.append(FIGURE("fig16_conv.png", "Left: Monte Carlo convergence of the hybrid share at &lambda; = 1 and of the biological-cheaper share, against draw count. Right: robust kernel fraction against grid resolution. Both settle within the tolerances stated in Tables 16b and 16c (S/V).", 0.92, label="16a"))
cmc = [["Draws n", "Hybrid share, &lambda; = 1", "Biological cheaper in energy"]]
for r_ in R["conv_mc"]:
    cmc.append([f"{r_['n']:,}", pct(r_["hybrid_share_lam1"], 2), pct(r_["bio_cheaper"], 2)])
story.append(TABLE(cmc, [0.2, 0.4, 0.4], caption="<b>Table 16b.</b> Monte Carlo convergence of the two architecture shares with the number of draws (S). The shares settle within about one percentage point by 2000 draws."))
cgr = [["Grid N", "Robust kernel fraction", "Change from previous grid"]]
prev = None
for r_ in R["conv_grid"]:
    chg = "" if prev is None else f"{100*(r_['robust_fraction']-prev):+.2f} pp"
    cgr.append([str(r_["Ng"]), pct(r_["robust_fraction"], 2), chg])
    prev = r_["robust_fraction"]
story.append(TABLE(cgr, [0.2, 0.4, 0.4], caption="<b>Table 16c.</b> Robust kernel fraction against grid resolution (S). The fraction changes by less than half a percentage point beyond N = 121."))

# ================================================================ 17 LIMITATIONS
story.append(H1("17&nbsp;&nbsp;Anticipated objections and responses"))
story.append(P("We set out the objections a careful reader is most likely to raise, with the response this paper supports and the limit of that response. The aim is to make the claims testable, not to win the argument."))
objs = [
 ("Biology is more efficient, so it should be used everywhere.", "The thermodynamic floors in Table 5a are route-independent, and the photosynthetic conversion ceiling in Section 5 is far below electrical PV. Biology is efficient at specific chemistry and selectivity, not as a general energy converter. The response depends on the assumed efficiencies, which are cited, not fitted."),
 ("The atlas is speculation.", "Yes, in part. That is why each concept carries a maturity tag, why the audit in Section 12 corrects two tags, and why phases IV to VI are described as design space. The atlas is not used to support any quantitative result."),
 ("The hybrid is just redundancy relabelled.", "In the model the hybrid's reliability gain is redundancy by construction, and we say so (Section 11.1). The substantive content is the cost: the hybrid pays in import mass, and the failure-weight sweep shows that its win depends on how heavily reliability is valued. We claim no more than that trade-off."),
 ("The gravity result is an artefact of the interpolation.", "Partly. Table 4b shows that the overall biological share changes a great deal with interpolation shape. The endpoint results survive all three shapes tested; the threshold location does not. The paper therefore claims the endpoints and marks the threshold as unidentified."),
 ("A two-state viability toy says nothing about real infrastructure.", "The toy is stylised, and its numbers should not be transferred. The structural claim is narrower: in a system with two channels of different cost and speed, the best controller can be strictly better than either channel, and the regime in which this holds depends on the adversary and production (Table 6a). A higher-dimensional study is the next step."),
 ("Stellar-scale constraints are irrelevant to near-term work.", "The scale results bind irrespective of timing, and they constrain near-term choices: they tell us which functions must stay abiotic whatever the biology achieves. Design rules D1 and D2 are the near-term consequences."),
 ("Light-time arguments assume a centralised controller.", "Yes. That is the case they address. The alternative, local control with delayed supervision, is what Section 9 and Table 4a imply, and the latency numbers quantify when it becomes mandatory."),
 ("The BioAsteroid numbers are press-reported.", "Yes, and they are flagged as such throughout. The ratio of about thirteen is reproduced from rounded means, and the paper's conclusions need only that abiotic yield falls substantially in microgravity. This must be re-checked against the primary paper before any quantitative reuse."),
 ("The diffusion model is too simple to matter.", "It is a transport diagnostic, not a design model. Its robust content is the square-root law of Proposition 7 and the observed sub-diffusive correction (Table 8a). Its prefactor depends on the reaction and on the boundary condition, which a design study would have to calibrate."),
 ("Why not model the biology in detail?", "Because no detailed biological model here is calibrated to the relevant environment. A detailed model with uncalibrated parameters would be less honest than a stylised one with explicit ranges. The path to a detailed model is the experiment in Section 13.1."),
]
for q_, a_ in objs:
    story.append(P(f"<b>Objection.</b> {q_} <b>Response.</b> {a_}"))

story.append(H1("18&nbsp;&nbsp;Limitations"))
story.append(P("<b>Stylised models.</b> The decision model and viability system are normalised and dimensionless. Their parameter ranges are chosen, not fitted. The conclusions in Sections 10 and 11 are structural and conditional on those ranges, and they must not be read as predictions of cost or reliability for any real infrastructure."))
story.append(P("<b>Single experiment.</b> The gravity dependence of biological and abiotic extraction rests on one reported ISS experiment with large variability, one substrate and one microbial pair, and on press-reported values that we have not checked against the full paper. The threshold location in Section 7 is therefore an assumption constrained by that experiment, not a finding."))
story.append(P("<b>Interpolation.</b> The gravity factor interpolates log-linearly between microgravity and Martian gravity. Table 4b shows that other shapes change the overall biological share from about one quarter to two thirds. Only the endpoint results are robust to the shape, and Table 4 should be read with that dependence in mind."))
story.append(P("<b>Independence.</b> The redundancy result assumes that the two channels fail independently. Common-cause failures, such as a shared radiation event or a shared feedstock shortage, would reduce the reliability advantage, and the feedstock dependence in the model is a first step toward modelling that correlation rather than a full treatment."))
story.append(P("<b>Viability dependence.</b> The single-channel non-viability result holds at default disturbance and production (Table 6). Table 6a shows that it reverses at weaker disturbance and higher production, so no general claim about single channels should be made.")); story.append(P("<b>Scale.</b> The network analysis uses 300 units and the viability analysis uses two states. Neither reproduces the dimension of a real infrastructure, and the robustness conclusions should be checked at larger scale before they are used."))
story.append(P("<b>Atlas.</b> The atlas tags are the draft's judgements, audited for internal consistency and not for technical feasibility. Concepts tagged P or S have not been assessed against any specific design requirement."))
story.append(P("<b>Literature.</b> The search for this paper was not exhaustive. Several items in the earlier draft could not be verified and were removed (Table 1). The novelty claim applies only to the composition described in Section 2, and only as far as our search extends."))

# ================================================================ 18 DISCUSSION & CONCLUSION
story.append(H1("19&nbsp;&nbsp;Discussion and conclusion"))
story.append(P("Table 19a assigns functions to classes scale by scale. Each row states the binding constraint, the quantitative anchor from this paper, and the evidence status. It is the most direct answer to the question of Section 1."))
scale_rows = [["Scale", "Allocated to biology (B/H)", "Kept abiotic (A)", "Binding constraint and anchor", "Evidence status"],
  ["Planetary surface", "Chemical production; biomineralised sealing and dust binding", "High-throughput extraction; pressure hulls", "Water closure and radiation (Fig. 10b, 11b)", "Components demonstrated; integration open"],
  ["Lunar and Martian habitat", "Regenerative loops; gas exchange; food", "Structure; power conversion; pressure systems", "Closure fraction; replacement burden (Eq. 2; Table 3b)", "Ground life-support integration; not flight-proven"],
  ["Solar-system industry", "Low-gravity biomining; biosynthesis", "High-temperature refining; machining", "Gravity threshold (Table 4; Table 4b)", "One microgravity experiment; threshold unidentified"],
  ["Stellar collectors", "Upstream manufacturing in protected facilities", "Collectors, radiators, primary structure", "Capture geometry and radiator area (Eqs. 8, 11)", "Exact physical constraints"],
  ["Distributed swarm", "None on exposed surfaces; bio-inspired control only", "All hardware and power", "Light-time and minimum control period (Table 4a); connectivity (Table 5)", "Exact and numerical; model-dependent"],
  ["Interstellar", "Contained cartridges; dormant libraries", "All active systems", "Round-trip light time; decades of latency (Table 4a)", "Speculative; design space only"],
  ["Beyond K = 3", "None asserted", "Not applicable", "Type III capture needs about 2.6&times;10<super>9</super> solar luminosities (Eq. 8)", "Limit analysis only"]]
story.append(TABLE(scale_rows, [0.15, 0.22, 0.2, 0.25, 0.18], caption="<b>Table 19a.</b> Recommended allocation of functions by scale, with binding constraint and evidence status."))
story.append(P("The question of this paper was where infrastructure functions should be assigned to living, biomimetic or abiotic systems. The answer that emerges is conditional but specific. Capture geometry and radiative physics fix the infrastructure at the stellar scale, and they place the collectors, radiators and most of the load-bearing structure outside biology. Thermodynamic ceilings set the biological role in energy conversion to chemistry rather than electricity. Circularity is a control problem with linear replacement economics, so recovery improvements must be valued at the margin. Gravity dependence favours biology in microgravity for extraction energy, but only under an interval that one experiment cannot pin down."))
story.append(P("The hybrid architecture is the most reliable option in the stylised comparison, and it wins on combined mass and energy when the value of reliability is high or when the environment is microgravity. Its reliability advantage is large and is paid for in mass. The switching result in the viability analysis points in the same direction: in a system with two repair channels of different speed and cost, a state-dependent switching controller can be strictly better than either channel alone. That conclusion is structural, and it is the part we consider most likely to transfer to real systems, subject to the independence and scale limitations above."))
story.append(P("The earlier draft asked whether a civilisation's infrastructure should become more biological as it becomes more advanced. Our analysis suggests a more specific answer. At the planetary and orbital scales, biology has a role in extraction, recycling and chemical production, where its gravity-dependent and chemical advantages are real. At stellar and galactic scales, the constraints of capture geometry and heat rejection make collectors and radiators nonliving, and the biological role shrinks to manufacturing upstream and design principles. This is a hypothesis about where the costs fall, not a claim about how civilisations will develop."))
story.append(P("The most useful next step is the partial-gravity experiment in Section 13.1, which tests the threshold that the decision model depends on most. The most useful theoretical step is to replace the stylised decision model with one calibrated to a specific mission architecture, so that the hybrid region can be stated for a named system rather than for a normalised one."))

story.append(H2("Acknowledgments and disclosures"))
story.append(P("<b>AI assistance.</b> The simulations, figures and manuscript text were produced with the assistance of Claude (Anthropic) under the direction of the authors, who define the research question and are responsible for the content. Xylia is the authors' AI research scientist. <b>Competing interests:</b> none declared. <b>Funding:</b> none. <b>Code and data:</b> all numerical results are generated by the analysis script and parameter table in Appendix D; results are stored in a machine-readable file. The authors will release code and data with the manuscript. <b>Literature:</b> not exhaustive; novelty is claimed only as far as the search extends.", "small"))

# ================================================================ REFERENCES
story.append(PageBreak())
story.append(H1("References"))
refs = [
 "[1] Kardashev NS (1964) Transmission of information by extraterrestrial civilizations. Soviet Astronomy 8:217–221.",
 "[2] Dyson FJ (1960) Search for artificial stellar sources of infrared radiation. Science 131:1667–1668.",
 "[3] O'Neill GK (1974) The colonization of space. Physics Today 27(9):32–40.",
 "[4] Sagan C (1973) Communication with extraterrestrial intelligence (CETI). MIT Press. Continuous power index as commonly cited; the formula used here is (log10 P − 6)/10.",
 "[5] Shockley W, Queisser HJ (1961) Detailed balance limit of efficiency of p–n junction solar cells. Journal of Applied Physics 32:510–519.",
 "[6] Zhu XG, Long SP, Ort DR (2008) What is the maximum efficiency with which photosynthesis can convert solar energy into biomass? Current Opinion in Biotechnology 19:153–159.",
 "[7] Qi X, Liu X, Gu Y, Liang P (2024) Whole-cell biophotovoltaic systems for renewable energy generation: a systematic analysis of existing knowledge. Bioelectrochemistry 108695. doi:10.1016/j.bioelechem.2024.108695.",
 "[8] Santomartino R, Stirpe A, et al. (2026) Microbial biomining from asteroidal material onboard the International Space Station. npj Microgravity (BioAsteroid). Full author list and volume to be confirmed against the published version.",
 "[9] Esposito M, Tonietti L, Santomartino R, Chianese E, Rotundi A, Poli A, Finore I, Di Donato P (2026) Integrating resource utilization and bioregenerative life support systems for sustainable space exploration. Journal details to be confirmed.",
 "[10] Koehle AP, Brumwell SL, Seto EP, Lynch AM, Urbaniak C (2023) Microbial applications for sustainable space exploration beyond low Earth orbit. npj Microgravity 9. doi:10.1038/s41526-023-00285-0.",
 "[11] Keller RJ, Porter W, Goli K, Rosenthal R, Butler N, Jones JA (2021) Life 11(8):844. doi:10.3390/life11080844.",
 "[12] Verbeelen T, Leys N, Ganigué R, Mastroleo F (2021) Development of nitrogen recycling strategies for bioregenerative life support systems in space. Frontiers in Microbiology. doi:10.3389/fmicb.2021.700810.",
 "[13] Aubin JP (1991) Viability Theory. Birkhäuser.",
 "[14] Blanchini F (1999) Set invariance in control. Automatica 35:1747–1767.",
 "[15] Murray CD (1926) The physiological principle of minimum work. I. The vascular system and the cost of blood volume. PNAS 12:207–214.",
 "[16] Fiedler M (1973) Algebraic connectivity of graphs. Czechoslovak Mathematical Journal 23:298–305.",
 "[17] Olfati-Saber R, Fax JA, Murray RM (2007) Consensus and cooperation in networked multi-agent systems. Proceedings of the IEEE 95:215–233.",
 "[18] COSPAR (2021) Policy on planetary protection. Committee on Space Research.",
 "[19] Petela R (1964) Exergy of heat radiation. Journal of Heat Transfer 86:187–192.",
 "[20] Poiseuille JLM (1841) Recherches expérimentales sur le mouvement des liquides dans les tubes de très petits diamètres. Comptes Rendus 12:112–115.",
 "[21] Pontryagin LS, Boltyanskii VG, Gamkrelidze RV, Mishchenko EF (1962) The Mathematical Theory of Optimal Processes. Interscience.",
 "[22] Nagumo M (1942) Über die Lage der Integralkurven gewöhnlicher Differentialgleichungen. Proc. Physico-Mathematical Society of Japan 24:551–559.",
]
for r_ in refs:
    story.append(Paragraph(mk(r_), S["ref"]))
story.append(Paragraph("Citations in the text are numeric and refer to this list. Where a reference was not retrieved in full during this work, the entry notes what remains to be confirmed.", S["small"]))

# ================================================================ APPENDIX A: PROOFS
story.append(PageBreak())
story.append(H1("Appendix A&nbsp;&nbsp;Proofs and derivations"))
story.append(H2("A.1 Proposition 1 (capture-geometry law)"))
story.append(P("Let the collector field be a set of area element <i>dA</i> on a sphere of radius <i>r</i> with covered fraction <i>f</i><sub>cov</sub>. The incident flux on each element, for a point source at the centre, is <i>S(r)</i> times the cosine of the incidence angle, and integrating over the sunlit hemisphere gives the projected area <i>&pi;r<super>2</super></i>. The power captured over the field is <i>&eta;</i> times the integral of incident flux over the covered elements. Since the incident flux over the whole sphere integrates to <i>L</i><sub>&odot;</sub> and the covered fraction of the sphere is <i>f</i><sub>cov</sub>, the captured power is at most <i>&eta; f</i><sub>cov</sub> <i>L</i><sub>&odot;</sub>, with equality when the covered elements are uniformly distributed over the sunlit hemisphere. The radius does not appear in the bound. ■"))
story.append(H2("A.2 Proposition 2 (radiative equilibrium)"))
story.append(P("For an isothermal shell of uniform emissivity &epsilon; and absorptance &alpha;, the absorbed power per unit surface area, averaged over the sphere, is <i>&alpha;S(r)(1&minus;&eta;)/4</i>. The shell emits <i>&epsilon;&sigma;T<super>4</super></i> per unit area in steady state. Equating the two and substituting <i>S(r) = L</i><sub>&odot;</sub>/(4&pi;r<super>2</super>) gives Eq. (10). The scaling <i>T</i> &prop; <i>r</i><super>-1/2</super> follows directly, and the factor (1&minus;&eta;)<super>1/4</super> follows from the linear dependence of absorbed power on (1&minus;&eta;). ■"))
story.append(H2("A.3 Proposition 3 (linear replacement burden)"))
story.append(P("Eq. (2) is a constant-coefficient ordinary differential equation in <i>M</i> when <i>D</i>, <i>&rho;</i>, <i>&lambda;</i> and <i>X</i> are constant. Its solution with <i>M</i>(0) = 0 is <i>M(t) = [(1&minus;&rho;)D + &lambda;X] t</i>. The sensitivity to &rho; is <i>&part;M/&part;&rho; = &minus;Dt</i>, which does not depend on &rho;. This gives the linearity of the cumulative replacement and the constancy of the absolute marginal value of recovery. ■"))
story.append(H2("A.4 Proposition 4 (Murray exponent)"))
story.append(P("With <i>f(r) = aQ<super>2</super>/r<super>4</super> + br<super>2</super></i>, the first-order condition is <i>&part;f/&part;r = &minus;4aQ<super>2</super>/r<super>5</super> + 2br = 0</i>. Solving gives <i>r</i><super>6</super> = 2aQ<super>2</super>/b, hence <i>r</i><super>*</super> = (2a/b)<super>1/6</super> Q<super>1/3</super>. The second-order condition holds because <i>f</i> &rarr; &infin; as <i>r</i> &rarr; 0 and as <i>r</i> &rarr; &infin;. For a symmetric bifurcation with flow conservation <i>Q</i><sub>0</sub> = 2<i>Q</i><sub>1</sub>, substituting into the cube-root law gives <i>r</i><sub>0</sub><super>3</super> = 2<i>r</i><sub>1</sub><super>3</super>. ■"))
story.append(H2("A.5 Proposition 5 (monotonicity of robust viability)"))
story.append(P("Let <i>F</i><sub>nom</sub> and <i>F</i><sub>rob</sub> be the backward operators in Eq. (21) with disturbance sets <i>W</i><sub>nom</sub> &sub; <i>W</i><sub>rob</sub>. For any set <i>S</i>, <i>F</i><sub>rob</sub>(<i>S</i>) = {s: &exist;u &forall;w &isin; W<sub>rob</sub> f(s,u,w) &isin; S} is contained in <i>F</i><sub>nom</sub>(<i>S</i>), since the universal quantifier ranges over a larger set. The iterates <i>&kappa;</i><sub>n+1</sub> = <i>&kappa;</i><sub>n</sub> &cap; <i>F</i>(<i>&kappa;</i><sub>n</sub>) are therefore nested, and by induction the robust sequence lies inside the nominal sequence. Both sequences are decreasing in a finite grid, so they stabilise, and the limits are the largest invariant subsets with respect to the respective operators. ■"))

story.append(H2("A.6 Asymmetric Murray law"))
story.append(P("Let each segment <i>i</i> carry flow <i>Q</i><sub>i</sub> with its own optimal radius. Proposition 4 gives <i>r</i><sub>i</sub> = &kappa; <i>Q</i><sub>i</sub><super>1/3</super> with &kappa; = (2a/b)<super>1/6</super> the same for every segment, since a and b are shared. Flow conservation at a bifurcation gives <i>Q</i><sub>0</sub> = <i>Q</i><sub>1</sub> + <i>Q</i><sub>2</sub> (for any split, not only the symmetric one). Cubing the radius law gives <i>r</i><sub>i</sub><super>3</super> = &kappa;<super>3</super> <i>Q</i><sub>i</sub>, and summing over the two daughters yields <i>r</i><sub>0</sub><super>3</super> = <i>r</i><sub>1</sub><super>3</super> + <i>r</i><sub>2</sub><super>3</super>. This is the asymmetric Murray relation, and it holds for any flow split, which is why the cube law appears in biological and engineered manifolds alike. ■"))
story.append(H2("A.7 Monotonicity of the robust kernel in adversary strength"))
story.append(P("Consider the robust backward operator of Eq. (21) with adversarial damage increment &delta; in the damage update. The resource update does not depend on &delta;, and the damage update is nondecreasing in &delta;. Since the admissible set imposes an upper bound on damage, it is a down-set in the damage coordinate, so a larger &delta; can only shrink the set of states from which the next state lies in the admissible set. By induction on the iterates, the kernel for a larger adversary is contained in the kernel for a smaller one. The sweep in Table 6a is consistent with this: the switching kernel is nonincreasing in &delta;. ■"))

# ================================================================ APPENDIX B: ATLAS
story.append(PageBreak())
story.append(H1("Appendix B&nbsp;&nbsp;Full 110-concept atlas"))
story.append(P("The atlas is reproduced with the maturity tags assigned in the draft, with concept 83 corrected from H to M (Section 12). Numbering follows the draft. Phase boundaries: I (1–30), II (31–40), III (41–70), IV (71–85), V (86–100), VI (101–110)."))
atlas_rows = [["No.", "Concept", "Tag"]]
_src = open(os.path.join(OUT, "analysis.py")).read()
_ns = {}
exec(_src[_src.index("ATLAS = ["):_src.index("assert len(ATLAS)")], _ns)
for num, name, tags in _ns["ATLAS"]:
    atlas_rows.append([str(num), name, tags])
story.append(TABLE(atlas_rows, [0.07, 0.8, 0.13], caption="<b>Table B1.</b> Atlas of 110 concepts with corrected maturity tags. Tag key in Section 12."))

# ================================================================ APPENDIX C: DATA / EQUATIONS RECAP
story.append(H1("Appendix C&nbsp;&nbsp;Numerical outputs"))
story.append(P("The tables below reproduce the numerical outputs of the analysis script. Values are copied from the results file and rounded for presentation."))
out_rows = [["Quantity", "Value", "Source / equation"],
            ["Solar constant at 1 AU", f"{R['S0_W_m2']:.2f} W m<super>-2</super>", "L<sub>&odot;</sub> / 4&pi;AU<super>2</super>"],
            ["Type II capture requirement &eta; f<sub>cov</sub>", f"{R['eta_fcov_required_TypeII_pct']:.2f}%", "Eq. (8), Prop. 1"],
            ["Type III capture in solar luminosities", f"{TYPE3_RATIO:.3e}", "10<super>36</super> / L<sub>&odot;</sub>"],
            ["Collector area at &eta;=0.20 (Type II)", fe(R['A_needed_TypeII_eta020_m2']) + " m<super>2</super>", "P / (&eta; S<sub>0</sub>)"],
            ["Full 1 AU sphere area", fe(R['A_sphere_1AU_m2']) + " m<super>2</super>", "4&pi;AU<super>2</super>"],
            ["Petela exergy limit (solar)", f"{R['petela_exergy_limit']:.4f}", "Eq. (12)"],
            ["Bare blackbody shell T at 1 AU", f"{R['T_bare_blackbody_1AU_K']:.2f} K", "Eq. (10), &eta;=0"],
            ["Shell T, &eta;=0.26, &epsilon;=0.90, &alpha;=0.95", f"{R['T_shell_eta026_eps090_alpha095_K']:.2f} K", "Eq. (10)"],
            ["Radiator area, 1 GW at 300 K", fe(R['radiator_1GW_300K_m2']) + " m<super>2</super>", "Eq. (11), &epsilon;=0.9"],
            ["Ideal PV at &eta;=0.20", f"{R['pv_eta020_mW_m2']:.3e} mW m<super>-2</super>", "&eta; S<sub>0</sub>"],
            ["BPV gap factor (best / worst reported)", f"{R['bpv_best_gap_factor']:.0f} / {R['bpv_worst_gap_factor']:.2e}", "Eq. (13)"],
            ["Murray exponent (fitted)", f"{R['murray_fitted_exponent']:.5f}", "Eq. (16), theory 1/3"],
            ["Robust kernel fraction (switching)", pct(viab["kernel_robust_fraction"]), "Eq. (21), 161 &times; 161 grid"],
            ["Nominal kernel fraction", pct(viab["kernel_nominal_fraction"]), "Eq. (21), nominal"],
            ["Swarm threshold, k = 6", f"{swarm_threshold(6)}", "Table 5, 25 trials"],
            ["Pd abiotic ratio, 1 g / µg (rounded means)", f"{R['Pd_abiotic_ratio_1g_over_ug']:.2f}", "Table/Fig. 6, reported values"],
            ["Pd fungus / abiotic in µg (rounded)", f"{R['Pd_fungus_over_abiotic_ug']:.2f}", "Fig. 6, reported 5.5"],
            ["Biological extraction cheaper, overall", pct(R["bio_extraction_cheaper_overall"]), "Eq. (15), Table 4"],
            ["Mean hybrid mass penalty (normalised)", f"{pareto['mean_redundancy_mass_penalty_C_vs_best_single']:.3f}", "M<sub>C</sub> &minus; min(M<sub>A</sub>, M<sub>B</sub>)"],
            ["Median failure reduction, hybrid", f"{pareto['median_failure_reduction_factor_C_vs_best_single']:.2f}&times;", "min(p<sub>A</sub>,p<sub>B</sub>) / p<sub>C</sub>"]]
story.append(TABLE(out_rows, [0.42, 0.26, 0.32], caption="<b>Table C1.</b> Key numerical outputs of the analysis."))
lam_rows = [["&lambda;", "A", "B", "C", "Gravity <10<super>-5.5</super>: C", "Gravity &gt; 0.32: C"]]
for l_ in ["0.0", "1.0", "3.0", "10.0"]:
    o = lam[l_]
    lam_rows.append([l_, pct(o["overall"]["A"]), pct(o["overall"]["B"]), pct(o["overall"]["C"]),
                     pct(o["by_gravity"]["g<1e-5.5"]["C"]), pct(o["by_gravity"]["g>0.32"]["C"])])
story.append(TABLE(lam_rows, [0.12, 0.14, 0.14, 0.14, 0.23, 0.23], caption="<b>Table C2.</b> Winner shares by failure weight &lambda;, overall and in two gravity regimes."))

# ================================================================ APPENDIX D: PARAMETERS & REPRO
story.append(PageBreak())
story.append(H1("Appendix D&nbsp;&nbsp;Parameters, sampling and reproducibility"))
story.append(P("The analysis script (<font name='Mono'>analysis.py</font>) is deterministic given its seed (20261121, NumPy default generator). It writes <font name='Mono'>results.json</font> and the figures. Each Monte Carlo draw samples the parameters below independently and uniformly over the declared range, and the environment vector is drawn uniformly over log gravity in [&minus;6, 0], water closure <i>W</i> in [0, 1], radiation <i>R</i> in [0, 1] and feedstock <i>F</i> in [0, 1]. The number of draws is 20,000 for the architecture analysis and 25 trials per cell for the swarm analysis."))
param_rows = [["Symbol", "Meaning", "Range (uniform)", "Basis"],
  ["z<sub>ug</sub>", "abiotic yield factor in microgravity", "[0.05, 0.50]", "brackets reported 0.075"],
  ["c<sub>A</sub>", "abiotic extraction energy scale", "[0.5, 1.5]", "normalised"],
  ["c<sub>B</sub>", "biological extraction energy scale", "[1.5, 3.0]", "assumed slower"],
  ["&rho;<sub>A</sub>", "abiotic recovery fraction", "[0.85, 0.95]", "assumed"],
  ["&rho;<sub>B,0</sub>", "biological recovery at W=1 (scaled by 0.5+0.5W)", "[0.60, 0.98]", "assumed"],
  ["e<sub>rec,A</sub>", "abiotic recovery energy", "[0.3, 0.6]", "normalised"],
  ["e<sub>rec,B</sub>", "biological recovery energy", "[0.1, 0.3]", "normalised"],
  ["m<sub>A</sub>", "abiotic hardware mass (per unit product)", "[0.05, 0.20]", "normalised"],
  ["m<sub>B</sub>", "biological hardware mass (reactor, growth)", "[0.10, 0.30]", "normalised"],
  ["p<super>0</super><sub>A</sub>", "abiotic base failure probability", "[0.01, 0.05]", "assumed"],
  ["k<sub>A</sub>", "abiotic radiation coefficient", "[0.5, 2.0]", "assumed"],
  ["p<super>0</super><sub>B</sub>", "biological base failure probability", "[0.03, 0.10]", "assumed"],
  ["k<sub>B</sub>", "biological radiation coefficient", "[0.1, 0.8]", "assumed; biology not assumed radiation-hard"],
  ["&Phi;<sub>B</sub>", "biological feedstock penalty", "[0.0, 0.5]", "assumed"],
  ["&delta;", "hybrid switching overhead", "[0.02, 0.08]", "assumed"],
  ["g<sub>&mu;</sub>, g<sub>M</sub>", "interpolation anchors (microgravity, 0.38 g)", "10<super>-6</super>, 0.38", "physical anchors"]]
story.append(TABLE(param_rows, [0.14, 0.38, 0.22, 0.26], caption="<b>Table D1.</b> Parameter ranges for the architecture Monte Carlo (referenced in Section 11). All ranges are declared assumptions, not fitted values."))
story.append(P("<b>Viability system (Section 10).</b> Grid 161 &times; 161 on [0,1]<super>2</super>. Admissible set <i>x</i> &ge; 0.25 and <i>d</i> &le; 0.60. Production rate p = 0.10. Biological channel: cost 0.020, repair rate 0.10. Abiotic channel: cost 0.080, repair rate 0.22. Nominal disturbance: damage +0.04, resource loss 0. Adversarial disturbance: damage +0.12, resource loss 0.03. Repair is scaled by (0.4 + 0.6x). Iteration to a fixed point of the backward operator. All of these values are stylised.", "small"))
story.append(P("<b>Swarm analysis (Section 9).</b> N = 300 units placed uniformly in the unit square, joined to their k nearest neighbours and symmetrised, for k in {4, 6, 8}. Failure fractions 0 to 0.60 in steps of 0.05. Units lost uniformly at random; algebraic connectivity computed from the Laplacian eigenvalues; connectivity from connected components. 25 independent trials per cell.", "small"))
story.append(P("<b>Murray and cost analysis (Section 8).</b> Cost f(r) = Q<super>2</super>/r<super>4</super> + r<super>2</super>, minimised over 4000 log-spaced radii for 60 log-spaced flows between 10<super>-2</super> and 10<super>2</super>. Exponent fitted by least squares on the log–log relation.", "small"))
story.append(P("<b>Capture and radiative identities (Sections 4 and 5).</b> Constants: &sigma; = 5.670374&times;10<super>-8</super>&nbsp;W&nbsp;m<super>-2</super>&nbsp;K<super>-4</super>; L<sub>&odot;</sub> = 3.828&times;10<super>26</super>&nbsp;W; AU = 1.495978707&times;10<super>11</super>&nbsp;m; T<sub>s</sub> = 5772&nbsp;K; T<sub>0</sub> = 300&nbsp;K. Earth mass 5.972&times;10<super>24</super>&nbsp;kg; Mercury 3.301&times;10<super>23</super>&nbsp;kg.", "small"))
story.append(P("<b>Interpretation of reported values.</b> Palladium values for the BioAsteroid experiment are taken from press coverage that quotes the paper, and are marked as evidence. They should be re-read from the primary publication before use, because press rounding (for example 13.4 from the rounded means against 13.6 reported) and the choice of mean may differ.", "small"))
story.append(P("<b>Software.</b> Python 3 with NumPy, SciPy, Matplotlib and ReportLab. Equations are rendered with the Computer Modern mathtext font set. No external data were fitted.", "small"))

# ================================================================ APPENDIX E: DATA TABLES
story.append(H1("Appendix E&nbsp;&nbsp;Extended data"))
story.append(P("Swarm connectivity at every failure fraction, with algebraic connectivity means and standard deviations for k = 6, reproduced from the stored results."))
ext_rows = [["Units lost", "P(conn) k=4", "P(conn) k=6", "P(conn) k=8", "lambda2 mean, k=6", "lambda2 sd, k=6"]]
for i_, f_ in enumerate(sw["fail_fracs"]):
    ext_rows.append([f"{f_:.2f}", f"{sw['4']['p_connected'][i_]:.2f}", f"{sw['6']['p_connected'][i_]:.2f}",
                     f"{sw['8']['p_connected'][i_]:.2f}", f"{sw['6']['lam2_mean'][i_]:.3f}", f"{sw['6']['lam2_sd'][i_]:.3f}"])
story.append(TABLE(ext_rows, [0.14, 0.17, 0.17, 0.17, 0.17, 0.18], caption="<b>Table E1.</b> Swarm connectivity and algebraic connectivity, N = 300, 25 trials per cell."))
story.append(P("Gravity-binned winner shares at &lambda;&nbsp;=&nbsp;1 and &lambda;&nbsp;=&nbsp;3, for completeness. The hybrid's share rises with &lambda; in every regime, which is the reliability effect discussed in Section 11.2.", "small"))
gl = ["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32"]
ge_rows = [["Gravity regime", "&lambda;=1: A", "&lambda;=1: B", "&lambda;=1: C", "&lambda;=3: A", "&lambda;=3: B", "&lambda;=3: C"]]
for g_ in gl:
    ge_rows.append([g_, pct(lam["1.0"]["by_gravity"][g_]["A"]), pct(lam["1.0"]["by_gravity"][g_]["B"]), pct(lam["1.0"]["by_gravity"][g_]["C"]),
                    pct(lam["3.0"]["by_gravity"][g_]["A"]), pct(lam["3.0"]["by_gravity"][g_]["B"]), pct(lam["3.0"]["by_gravity"][g_]["C"])])
story.append(TABLE(ge_rows, [0.2, 0.13, 0.13, 0.13, 0.13, 0.13, 0.15], caption="<b>Table E2.</b> Winner shares by gravity regime at intermediate failure weights."))
story.append(P("The reader should note that the gravity regime boundaries are those of the analysis script. They are log-spaced at &minus;5.5, &minus;4, &minus;2.5, &minus;1 and &minus;0.5, and do not correspond to physical gravity classes except at the lunar and Martian values, which lie within the top two bins."))

story.append(H1("Appendix F&nbsp;&nbsp;Glossary"))
gl_rows = [["Term", "Meaning in this paper"],
  ["Abiotic (A)", "Process class using conventional chemical, electrochemical or mechanical means with no living component."],
  ["Biohybrid (H)", "Process class combining living components with synthetic materials, electronics or machines."],
  ["Biological (B)", "Process class in which living organisms perform the transformation."],
  ["BioAsteroid", "ISS experiment testing microbial and fungal leaching of an L-chondrite meteorite under microgravity [8]."],
  ["BLSS / ISRU", "Bioregenerative life-support system / in-situ resource utilisation [9, 10]."],
  ["BPV", "Biophotovoltaic device: a photosynthetic organism coupled to an electrode [7]."],
  ["Capture-geometry law", "The bound eta times f<sub>cov</sub> times L<sub>&odot;</sub> on captured power (Proposition 1)."],
  ["Delay margin", "PM over crossover frequency: the largest loop delay a linear feedback loop tolerates."],
  ["Kernel (viability)", "Set of states from which admissible behaviour can be maintained under all disturbances."],
  ["Light-time", "One-way signal travel time between a controller and a unit."],
  ["MICP", "Microbially induced calcium carbonate precipitation, a biomineralisation route."],
  ["Murray's law", "Cost-minimising branching radius scaling with the cube root of flow."],
  ["Petela limit", "Maximum fraction of solar radiation exergy convertible to work, about 0.93 here."],
  ["Robust viability", "Viability under the worst disturbance in an admissible set, rather than a nominal one."],
  ["Sagan index K", "Continuous Kardashev index (log10 P &minus; 6) / 10."],
  ["Switching controller", "Repair policy that selects between channels as a function of the current state."],
  ["Type I/II/III", "Kardashev scales at 10<super>16</super>, 10<super>26</super> and 10<super>36</super> W respectively."]]
story.append(TABLE(gl_rows, [0.24, 0.76], caption="<b>Table F1.</b> Glossary of terms and abbreviations."))

story.append(H1("Appendix G&nbsp;&nbsp;Algorithm listings"))
story.append(P("The listings below give the core of each computation in the order it appears in the analysis script. They are pseudocode that matches the implementation; the full script is the reference."))
from reportlab.platypus import Preformatted
PRE = ParagraphStyle("pre", fontName="Mono", fontSize=6.7, leading=8.2, textColor=NAVY, backColor=LIGHT, borderPadding=4, leftIndent=2, rightIndent=2, spaceAfter=6)
alg1 = """Algorithm G1  Robust viability kernel (Section 10)
input : admissible set K0 on grid N x N; step(s,u,w) (clip-dynamics); controls U; disturbances W
K <- K0
repeat
    new <- empty
    for u in U:
        ok <- true everywhere
        for w in W:
            (x', d') <- step(X, D, u, w)            # vectorised over grid
            ok <- ok AND K[index(x'), index(d')]
        new <- new OR (ok AND K)
    new <- new AND K0
    if new == K: break
    K <- new
return K            # robust kernel; mean(K) is the reported fraction
"""
alg2 = """Algorithm G2  Architecture Monte Carlo and winners (Section 11)
draw n environments: log10 g ~ U[-6,0], W,R,F ~ U[0,1]
draw n parameter sets from Table D1 (independent uniform)
z   <- zeta(g; z_ug)                              # Eq. (15)
M,E,p <- evaluate(params, env)                     # Eqs. (22)-(25)
for lambda in {0, 1, 3, 10}:
    J   <- M + E + lambda * p                      # Eq. (26)
    win <- argmin over {A, B, C} of J
    share[lambda] <- frequency of each win value
hybrid_map[g,W] <- mean over draws in bin of (win == C)
"""
alg3 = """Algorithm G3  Biocementation solver (Section 8.3)
grid x_i = i dx, i = 0..n;  c_0 = 1 (Dirichlet);  c_n = c_{n-1} (Neumann)
X_i = 0.1;  M_i = 0
for step k = 1..K:                                  # explicit Euler, dt < dx^2/(2D)
    lap_i = (c_{i+1} - 2 c_i + c_{i-1}) / dx^2
    r_i   = k_u c_i X_i
    c_i  <- c_i + dt (D lap_i - r_i);   clip to [0,1]
    X_i  <- X_i + dt (Y r_i (1 - X_i) - m X_i)
    M_i  <- M_i + dt 0.3 r_i
    record front = max{x_i : c_i > 0.05} every T_rec steps
fit log front vs log t; prefactor a from last record
"""
alg4 = """Algorithm G4  Murray optimum and dominance check
f(r) = a Q^2 / r^4 + b r^2 ;  r*(Q) = argmin over log-spaced grid
slope = polyfit(log Q, log r*, 1)                  # expect 1/3
dominance: option i is dominated if some j has obj_j <= obj_i (all) and < (some)
check: fast nondominated() equals brute-force pairwise test on 2000 random triples
"""
for blk in [alg1, alg2, alg3, alg4]:
    story.append(Preformatted(blk, PRE))

story.append(H1("Appendix H&nbsp;&nbsp;Sensitivity at low failure weights"))
story.append(P("The main sensitivity analysis (Table 8) uses &lambda; = 10. The two tables below repeat it at &lambda; = 0 and &lambda; = 1. The ranking of parameters changes with the failure weight: at high weight, the abiotic failure rate dominates; at low weight, the biological hardware mass and feedstock penalty dominate. The change is the quantitative form of the reliability-versus-cost reading in Section 11.2."))
for lam_key, tlab in [("0.0", "H1"), ("1.0", "H2")]:
    rows_h = [["Parameter", "Hybrid share, min across quintiles", "Hybrid share, max across quintiles", "Hybrid range", "Abiotic range"]]
    for k_, v in R["sensitivity_lambda"][lam_key].items():
        rows_h.append([sens_label.get(k_, k_), pct(v["hyb_min"]), pct(v["hyb_max"]), pct(v["hyb_range"]), pct(v["abi_range"])])
    story.append(TABLE(rows_h, [0.36, 0.16, 0.16, 0.16, 0.16], caption=f"<b>Table {tlab}.</b> Sensitivity of the hybrid share at &lambda; = {float(lam_key):g} (S). Abiotic range is the spread of the abiotic architecture's win share across the same quintiles."))

story.append(H1("Appendix I&nbsp;&nbsp;Full two-dimensional environment maps"))
story.append(P("The tables give the hybrid's share at &lambda; = 1 across the 12 &times; 12 grid of radiation index R (columns) and water closure W (rows), at two gravity levels. Values are percentages of 400 draws per cell over the other parameters. Figure 11b shows the same data graphically."))
for key_, glab, tlab in [("g1e-5", "10<super>-5</super> g", "I1"), ("g0.1", "0.1 g", "I2")]:
    H_ = np.array(R["map2d"][key_]["hybrid"])
    hdr = ["W \\ R"] + [f"{r_:.2f}" for r_ in R["map2d"][key_]["R"]]
    rows_m = [hdr]
    for j_, w_ in enumerate(R["map2d"][key_]["W"]):
        rows_m.append([f"{w_:.2f}"] + [f"{100*H_[i_, j_]:.0f}" for i_ in range(H_.shape[0])])
    story.append(TABLE(rows_m, [0.08] + [0.0767] * 12, caption=f"<b>Table {tlab}.</b> Hybrid share (%) at &lambda; = 1, gravity {glab} (S). Rows: water closure W; columns: radiation index R."))

story.append(H1("Appendix J&nbsp;&nbsp;Claim register"))
story.append(P("Every quantitative claim in the body is listed below with its epistemic status, its section, and where it comes from. Status codes: P proved; N numerical; S stylised (conditional on declared ranges); E evidence from a published or press-reported measurement; V verification; A arithmetic on stated constants. Values are read from the stored results file at build time."))
creg = [["Claim", "Value", "Sec.", "Status", "Source"],
  ["Type II capture requirement &eta; f<sub>cov</sub>", pct(R['eta_fcov_required_TypeII_pct']/100, 2), "4.1", "P", "Eq. (8)"],
  ["Type III capture in solar luminosities", f"{TYPE3_RATIO:.2e}", "4.1", "A", "10<super>36</super>/L<sub>&odot;</sub>"],
  ["Humanity Sagan index K", f"{R['K_index']['Humanity (approx., 1.9e13 W)']:.3f}", "4.1", "A", "Eq. (9), P &asymp; 1.9&times;10<super>13</super> W"],
  ["Type II collector area / full sphere, &eta;=0.20", f"{R['A_ratio_needed_over_sphere_eta020']:.3f}", "4.2", "A", "Prop. 1 arithmetic"],
  ["Bare blackbody shell T at 1 AU", f"{R['T_bare_blackbody_1AU_K']:.2f} K", "4.3", "P", "Eq. (10)"],
  ["Shell T, &eta;=0.26, &epsilon;=0.90, &alpha;=0.95", f"{R['T_shell_eta026_eps090_alpha095_K']:.2f} K", "4.3", "P", "Eq. (10)"],
  ["Radiator area, 1 GW at 300 K", fe(R['radiator_1GW_300K_m2'], 3) + " m<super>2</super>", "4.3", "P", "Eq. (11)"],
  ["Round-trip light time, 1 AU", _fmt_t(R['latency']['1 AU']['round_trip_s']), "4.4", "P", "Eq. (4a)"],
  ["Minimum control period, 1 AU (PM = &pi;/3)", _fmt_t(6*R['latency']['1 AU']['round_trip_s']), "4.4", "P", "Eq. (4b), Prop. 6"],
  ["Petela solar exergy limit", f"{R['petela_exergy_limit']:.4f}", "5", "P", "Eq. (12)"],
  ["BPV gap to ideal PV, best and worst", f"{R['bpv_best_gap_factor']:.0f}&times; / {R['bpv_worst_gap_factor']:.1e}&times;", "5", "E, A", "Qi et al. 2024 [7]; Eq. (13)"],
  ["Glucose minimum work per kg", f"{dG_glu:.2f} MJ", "5.1", "E, A", "Tabulated &Delta;G&deg;f [19]; to be checked"],
  ["Abiotic Pd yield ratio, 1 g / microgravity", f"{R['Pd_abiotic_ratio_1g_over_ug']:.1f} (13.6 reported)", "7", "E", "BioAsteroid, press-reported [8]"],
  ["Fungal / abiotic Pd in microgravity", f"{R['Pd_fungus_over_abiotic_ug']:.1f} (5.5 reported)", "7", "E", "BioAsteroid, press-reported [8]"],
  ["Biological extraction cheaper, microgravity bin", pct(R['bio_extraction_cheaper_by_gravity']['g<1e-5.5']), "7", "S", "Table 4; prior ranges, Table D1"],
  ["Biological extraction cheaper, overall (log-linear)", pct(R['bio_extraction_cheaper_overall']), "7", "S", "Table 4"],
  ["Overall share, linear-in-g / step interpolation", f"{pct(R['interp_variants']['linear_g']['overall'])} / {pct(R['interp_variants']['step_1e-3']['overall'])}", "7.2", "S", "Table 4b"],
  ["Murray exponent (fitted)", f"{R['murray_fitted_exponent']:.4f}", "8.1", "N", "Prop. 4; theory 1/3"],
  ["MICP front log-log slope (D = 10<super>-9</super>)", f"{R['micp']['1e-09']['loglog_slope']:.3f}", "8.3", "N", "Table 8a; theory 0.5"],
  ["MICP prefactor, measured / theory", f"{R['micp']['1e-09']['prefactor_a']:.2f} / {R['micp']['1e-09']['prefactor_theory']:.2f}", "8.3", "N", "Prop. 7"],
  ["Swarm connectivity threshold, k = 6, random", f"{swarm_threshold(6):.2f}", "9", "N", "Table 5"],
  ["Swarm threshold, hub-first vs random", f"{R['swarm_targeted_thresholds']['hub_first']:.2f} vs {R['swarm_targeted_thresholds']['random']:.2f}", "9.1", "N", "Table 9b"],
  ["Robust kernel, switching", pct(viab['kernel_robust_fraction']), "10", "S", "Table 6; Eq. (21)"],
  ["Robust kernel, nominal", pct(viab['kernel_nominal_fraction']), "10", "S", "Table 6"],
  ["Robust kernel, biological only / abiotic only", f"{pct(viab['robust_bio_only_fraction'])} / {pct(viab['robust_abiotic_only_fraction'])}", "10", "S", "Table 6"],
  ["Hybrid win share at &lambda; = 0", pct(lam['0.0']['overall']['C']), "11.2", "S", "Table 7"],
  ["Hybrid win share at &lambda; = 10", pct(lam['10.0']['overall']['C']), "11.2", "S", "Table 7"],
  ["Median hybrid failure reduction factor", f"{pareto['median_failure_reduction_factor_C_vs_best_single']:.1f}&times;", "11.2", "S", "p<sub>min</sub>/p<sub>C</sub>"],
  ["Mean hybrid mass penalty (normalised)", f"{pareto['mean_redundancy_mass_penalty_C_vs_best_single']:.3f}", "11.2", "S", "M<sub>C</sub> minus min(M<sub>A</sub>,M<sub>B</sub>)"],
  ["Hybrid share, microgravity / 0.1 g (2D map mean)", f"{100*np.mean(np.array(R['map2d']['g1e-5']['hybrid'])):.0f}% / {100*np.mean(np.array(R['map2d']['g0.1']['hybrid'])):.0f}%", "11.5", "S", "Fig. 11b; Appendix I"],
  ["Monte Carlo convergence (2000 draws)", "within about 1 pp", "16", "N", "Table 16b"],
  ["Grid convergence of robust kernel", "within 0.5 pp beyond N = 121", "16", "N", "Table 16c"],
  ["Pareto dominance code vs brute force", f"{vv['dominance_mismatches']} mismatches", "16", "V", "Table 16a"],
  ["Algebraic connectivity, dense vs sparse", f"{vv['lambda2_dense_minus_sparse']:.1e}", "16", "V", "Table 16a"],
  ["Crew water replacement, 98% recovery", f"{R['water_budget']['rows']['0.98']['loss_per_year_kg']:.0f} kg/yr", "6.1", "A, E", "Eq. (2); 2.50 kg/day [12]"]]
story.append(TABLE(creg, [0.36, 0.2, 0.06, 0.1, 0.28], caption="<b>Table J1.</b> Claim register. Each quantitative claim, its status, the section where it appears, and its source."))

story.append(H1("Appendix K&nbsp;&nbsp;Reproduction manifest"))
story.append(P("This appendix lists the files of the computational release and the mapping from each figure to its generating code. It is written so that the release can be checked by a reader without access to the authors' working environment. Running the two scripts in order regenerates every number and figure in this document."))
fig_map = [["Figure", "File (figs/)", "Section", "Generating code"],
  ["1", "fig01_framework.png", "1", "analysis.py, framework block"],
  ["2", "fig02_kardashev.png", "4.1", "analysis.py, Fig. 1 block"],
  ["3", "fig03_capture_mass.png", "4.2", "analysis.py, Fig. 2 block"],
  ["4", "fig04_radiative.png", "4.3", "analysis.py, Fig. 3 block"],
  ["4d", "fig18_growth.png", "4.5", "build_pdf.py, make_extra_figs()"],
  ["5", "fig05_bpv_pv.png", "5", "analysis.py, Fig. 4 block"],
  ["5b", "fig17_thermo.png", "5.1", "build_pdf.py, make_extra_figs()"],
  ["6", "fig08_material.png", "6", "analysis.py, Fig. 8 block"],
  ["7", "fig06_bioasteroid_pd.png", "7", "analysis.py, Fig. 5 block"],
  ["8", "fig07_murray_swarm.png", "8, 9", "analysis.py, Fig. 6 block"],
  ["8c", "fig15_micp.png", "8.3", "analysis.py, section 18 (MICP)"],
  ["9", "fig09_viability.png", "10", "analysis.py, Fig. 9 block"],
  ["9b", "fig13_viab_sweep.png", "10.1", "analysis.py, section 13 (sweeps)"],
  ["10", "fig10_pareto_env.png", "11.3", "analysis.py, Fig. 10 block"],
  ["11", "fig11_tornado.png", "11.4", "analysis.py, Fig. 11 block"],
  ["11b", "fig14_map2d.png", "11.5", "analysis.py, section 15 (2D map)"],
  ["12", "fig12_atlas.png", "12", "analysis.py, Fig. 12 block"],
  ["16a", "fig16_conv.png", "16", "build_pdf.py, make_extra_figs()"]]
story.append(TABLE(fig_map, [0.1, 0.36, 0.1, 0.44], caption="<b>Table K1.</b> Figure-to-file map. Figure labels are those printed in the paper."))
rel = [["File", "Role", "Notes"],
  ["analysis.py", "All numerical analyses and figures", "Deterministic; seed 20261121"],
  ["results.json", "Machine-readable results read by the builder", "Written by analysis.py"],
  ["build_pdf.py", "Typesets this document from results.json", "Requires ReportLab and Matplotlib"],
  ["figs/, eqs/", "Figure and rendered-equation images", "Regenerated by the scripts"],
  ["Paper PDF", "This document, version 1.0", "Preprint; not peer reviewed"],
  ["CITATION.cff, .zenodo.json", "Citation metadata for the release", "Prepared at release time"],
  ["README.md", "Run order, environment, expected runtime", "Prepared at release time"]]
story.append(TABLE(rel, [0.26, 0.42, 0.32], caption="<b>Table K2.</b> Release manifest. Run analysis.py, then build_pdf.py. The full analysis takes several minutes on a single CPU core, dominated by the diffusion simulation (Section 8.3)."))
story.append(P("Software: Python 3.12, NumPy 2.x, SciPy 1.x, Matplotlib 3.x, ReportLab 4.x and 5.x. The fonts used are DejaVu Serif, DejaVu Sans and DejaVu Sans Mono. No external data files are read; the palladium values and thermodynamic constants are entered in the scripts with their sources cited in the text.", "small"))

# ================================================================ BUILD
doc = Doc(PDF_PATH, pagesize=A4, leftMargin=1.45 * cm, rightMargin=1.45 * cm,
          topMargin=1.55 * cm, bottomMargin=1.55 * cm,
          title="Biohybrid Infrastructure Viability Across Civilizational Scales",
          author="Devanik Debnath; Xylia", subject="Preprint v1.0, theoretical and computational",
          keywords="infrastructure viability, biohybrid, capture geometry, viability kernel, Pareto")
frame_first = Frame(1.45 * cm, 1.4 * cm, A4[0] - 2.9 * cm, A4[1] - 3.6 * cm, id="f1", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
frame_body = Frame(1.45 * cm, 1.4 * cm, A4[0] - 2.9 * cm, A4[1] - 2.95 * cm, id="f2", leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
doc.addPageTemplates([PageTemplate(id="first", frames=[frame_first], onPage=on_first),
                      PageTemplate(id="body", frames=[frame_body], onPage=on_page)])

def build_once(flow):
    d = Doc(PDF_PATH, pagesize=A4, leftMargin=1.45 * cm, rightMargin=1.45 * cm,
            topMargin=1.55 * cm, bottomMargin=1.55 * cm,
            title="Biohybrid Infrastructure Viability Across Civilizational Scales",
            author="Devanik Debnath; Xylia", subject="Preprint v1.0, theoretical and computational",
            keywords="infrastructure viability, biohybrid, capture geometry, viability kernel, Pareto")
    d.addPageTemplates([PageTemplate(id="first", frames=[frame_first], onPage=on_first),
                        PageTemplate(id="body", frames=[frame_body], onPage=on_page)])
    d.multiBuild(flow)
    return d

story_copy = list(story)
doc = build_once(story_copy)
print("built:", PDF_PATH)
