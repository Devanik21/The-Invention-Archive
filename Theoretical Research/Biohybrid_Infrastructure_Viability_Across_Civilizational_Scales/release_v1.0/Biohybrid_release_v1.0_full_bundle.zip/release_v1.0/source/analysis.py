"""
Numerical analysis for: Biohybrid Infrastructure Viability Across Civilizational Scales.
All quantities are reproduced from the formulas in the paper. Stylised parameters are
labelled as such. Seeds fixed. Outputs: results.json and figures/*.png
"""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from scipy.sparse import csgraph
from scipy.spatial import cKDTree

OUT = "/home/claude/build"
FIG = os.path.join(OUT, "figs")
os.makedirs(FIG, exist_ok=True)
R = {}  # results container
rng = np.random.default_rng(20261121)

NAVY = "#1B2A4A"; TEAL = "#0F7C86"; CORAL = "#E0643E"; GOLD = "#E8A33D"
VIOLET = "#6B4C9A"; GREEN = "#4C9A5B"; GREY = "#8A8F98"; SKY = "#5BA7D6"
CMAP = LinearSegmentedColormap.from_list("bh", ["#FFF6E5", GOLD, CORAL, VIOLET, NAVY])
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9.5,
    "axes.labelsize": 8.5, "axes.edgecolor": NAVY, "axes.linewidth": 0.7,
    "xtick.color": NAVY, "ytick.color": NAVY, "axes.labelcolor": NAVY,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "figure.dpi": 200,
})

# ----------------------------------------------------------------------------
# Physical constants (SI)
# ----------------------------------------------------------------------------
SIGMA = 5.670374419e-8      # W m^-2 K^-4
L_SUN = 3.828e26            # W
AU = 1.495978707e11         # m
T_SUN = 5772.0              # K effective temperature
R_SUN = 6.957e8             # m
M_EARTH = 5.972e24          # kg
M_MERCURY = 3.301e23        # kg
M_MOON = 7.342e22           # kg
S0 = L_SUN / (4 * np.pi * AU**2)     # solar constant at 1 AU
R["S0_W_m2"] = S0

# ----------------------------------------------------------------------------
# 1. Sagan continuous Kardashev index and scale table (exact identity)
# ----------------------------------------------------------------------------
P_levels = {"Humanity (approx., 1.9e13 W)": 1.9e13, "Type I ref. 1e16 W": 1e16,
            "Type II ref. 1e26 W": 1e26, "Type III ref. 1e36 W": 1e36}
R["K_index"] = {k: float((np.log10(v) - 6) / 10) for k, v in P_levels.items()}

# ----------------------------------------------------------------------------
# 2. Proposition 1: capture-geometry law (exact)
#    A_cov(r) = f_cov * 4 pi r^2 ;  captured power P = eta * f_cov * L_sun
#    => eta * f_cov >= P / L_sun, independent of r.
# ----------------------------------------------------------------------------
req = {}
for name, P in [("I", 1e16), ("II", 1e26), ("III", 1e36)]:
    req[name] = float(P / L_SUN)   # required eta*f_cov
R["eta_fcov_required"] = req
R["eta_fcov_required_TypeII_pct"] = 100 * req["II"]

# Area of a 1 AU collector field if eta = 0.20 (single-junction-class PV assumption)
A_needed_1AU = 1e26 / (0.20 * S0)
A_sphere_1AU = 4 * np.pi * AU**2
R["A_needed_TypeII_eta020_m2"] = float(A_needed_1AU)
R["A_sphere_1AU_m2"] = float(A_sphere_1AU)
R["A_ratio_needed_over_sphere_eta020"] = float(A_needed_1AU / A_sphere_1AU)

# Mass of the required collector field under areal-density scenarios
mass = {}
for ad in [0.1, 1.0, 10.0]:
    m = A_sphere_1AU * ad
    mass[f"{ad} kg/m2"] = {"kg": float(m), "fraction_of_mercury": float(m / M_MERCURY),
                           "fraction_of_earth": float(m / M_EARTH)}
R["shell_mass_1AU"] = mass

# Petela (1964) solar exergy efficiency upper bound for blackbody sun
T0 = 300.0
psi_petela = 1 - 4 / 3 * (T0 / T_SUN) + 1 / 3 * (T0 / T_SUN) ** 4
R["petela_exergy_limit"] = float(psi_petela)

# ----------------------------------------------------------------------------
# 3. Radiative equilibrium of a collector shell (exact steady-state identity)
#    shell absorbs S(r) alpha (1-eta) over projected disk, emits eps*sigma*T^4 over 4 pi
#    => T = [ S(r) alpha (1-eta) / (4 eps sigma) ]^{1/4}
# ----------------------------------------------------------------------------
def T_shell(eta, alpha=1.0, eps=1.0, r_au=1.0):
    S = S0 / r_au**2
    return (S * alpha * (1 - eta) / (4 * eps * SIGMA)) ** 0.25

R["T_bare_blackbody_1AU_K"] = float(T_shell(0.0))
R["T_shell_eta020_eps090_alpha095_K"] = float(T_shell(0.20, alpha=0.95, eps=0.90))
R["T_shell_eta026_eps090_alpha095_K"] = float(T_shell(0.26, alpha=0.95, eps=0.90))
R["T_shell_eta026_1AU_K"] = float(T_shell(0.26))
R["T_shell_scaling_exponent_r"] = -0.5   # T ∝ r^{-1/2}

# Radiator area for a given waste power and temperature (one-sided, ideal)
def radiator_area(Q, T, eps=0.9):
    return Q / (eps * SIGMA * T**4)
R["radiator_1GW_300K_m2"] = float(radiator_area(1e9, 300.0))
R["radiator_1TW_400K_m2"] = float(radiator_area(1e12, 400.0))

# ----------------------------------------------------------------------------
# 4. BPV versus PV power density (Qi et al. 2024 reported range)
# ----------------------------------------------------------------------------
S0_mW_m2 = S0 * 1000.0
pv_mW_m2 = 0.20 * S0_mW_m2
bpv_lo, bpv_hi = 1e-4, 1e3
R["solar_mW_m2"] = float(S0_mW_m2)
R["pv_eta020_mW_m2"] = float(pv_mW_m2)
R["bpv_best_gap_factor"] = float(pv_mW_m2 / bpv_hi)
R["bpv_worst_gap_factor"] = float(pv_mW_m2 / bpv_lo)
R["bpv_best_eff_pct"] = float(100 * bpv_hi / S0_mW_m2)

# ----------------------------------------------------------------------------
# 5. BioAsteroid reported Pd values (press coverage of npj Microgravity 2026)
# ----------------------------------------------------------------------------
pd_abiotic_1g = 29.5
pd_abiotic_ug = 2.2
pd_fungus_ug = 11.91
R["Pd_abiotic_ratio_1g_over_ug"] = pd_abiotic_1g / pd_abiotic_ug
R["Pd_fungus_over_abiotic_ug"] = pd_fungus_ug / pd_abiotic_ug

# ----------------------------------------------------------------------------
# 6. Proposition 2: material circularity (eq. 2), closed-form and numeric check
# ----------------------------------------------------------------------------
D_daily = 10.0          # gross demand per day (normalised units)
lam_X = 0.0
years = np.linspace(0, 50, 501)
recov = {"0.90": 0.90, "0.99": 0.99, "0.999": 0.999, "1.000": 1.0}
mat = {}
for k, rho in recov.items():
    dM = (1 - rho) * D_daily * 365.0     # per year
    mat[k] = {"loss_per_year": float(dM), "loss_over_50y": float(dM * 50)}
R["material_losses"] = mat
# numeric integration of dM/dt = (1-rho)D + lam X via Euler, check closed form
dt = 0.1
M = 0.0
for _ in range(int(50 / dt)):
    M += ((1 - 0.99) * D_daily * 365.0 + lam_X) * dt
R["material_numeric_check_rho099"] = {"numeric": float(M), "closed_form": float(0.01 * D_daily * 365 * 50)}

# ----------------------------------------------------------------------------
# 7. Murray (1926) branching: minimising pumping + maintenance cost per length
#    f(r) = a Q^2 / r^4 + b r^2  =>  r* = (2a/b)^{1/6} Q^{1/3} ; exponent 1/3
# ----------------------------------------------------------------------------
a_, b_ = 1.0, 1.0
Qs = np.logspace(-2, 2, 60)
r_opt = []
for Q in Qs:
    rs = np.logspace(-3, 1.5, 4000)
    f = a_ * Q**2 / rs**4 + b_ * rs**2
    r_opt.append(rs[np.argmin(f)])
r_opt = np.array(r_opt)
slope = np.polyfit(np.log(Qs), np.log(r_opt), 1)[0]
R["murray_fitted_exponent"] = float(slope)
R["murray_theory_exponent"] = 1 / 3
R["murray_bifurcation_ratio_r1_over_r0"] = float(2 ** (-1 / 3))

# Hagen–Poiseuille check: pressure drop per unit length at fixed flow
Rr = 1.0
R["poiseuille_halving_radius_penalty"] = float(2 ** 4)  # Δp ∝ 1/r^4

# ----------------------------------------------------------------------------
# 8. Swarm connectivity: algebraic connectivity under random node loss
# ----------------------------------------------------------------------------
def knn_graph(pts, k):
    tree = cKDTree(pts)
    _, idx = tree.query(pts, k + 1)
    n = len(pts)
    rows, cols = [], []
    for i in range(n):
        for j in idx[i, 1:]:
            rows.append(i); cols.append(j)
    A = np.zeros((n, n))
    A[rows, cols] = 1.0
    A = np.maximum(A, A.T)
    return A

def lambda2(A):
    L = csgraph.laplacian(A)
    w = np.linalg.eigvalsh(L)
    return w[1]

def connected_fraction(A):
    n_comp, _ = csgraph.connected_components(A, directed=False)
    return n_comp == 1

N_SW = 300
fail_fracs = np.linspace(0, 0.6, 13)
swarm = {}
for k in [4, 6, 8]:
    lam2_mean, lam2_sd, conn = [], [], []
    for f in fail_fracs:
        vals, cs = [], []
        for trial in range(25):
            pts = rng.uniform(0, 1, size=(N_SW, 2))
            A = knn_graph(pts, k)
            alive = rng.uniform(size=N_SW) >= f
            Asub = A[np.ix_(alive, alive)]
            if Asub.shape[0] < 3:
                continue
            vals.append(lambda2(Asub))
            cs.append(connected_fraction(Asub))
        lam2_mean.append(np.mean(vals)); lam2_sd.append(np.std(vals))
        conn.append(np.mean(cs))
    swarm[str(k)] = {"lam2_mean": lam2_mean, "lam2_sd": lam2_sd, "p_connected": conn}
R["swarm"] = {"fail_fracs": fail_fracs.tolist(), **swarm}
# threshold: smallest failure fraction where P(connected) < 0.5 for k=6
p6 = np.array(swarm["6"]["p_connected"])
idx = np.where(p6 < 0.5)[0]
R["swarm_k6_threshold_fail"] = float(fail_fracs[idx[0]]) if len(idx) else None

# ----------------------------------------------------------------------------
# 9. Robust viability kernel of a two-state repair system (Aubin / Nagumo style)
#    state s=(x,d) in [0,1]^2 ; admissible set K: x >= 0.25 and d <= 0.60
#    controls u in {bio, abiotic}; disturbance w in {nominal, adversarial}
#    x' = clip( x + p(1-d) - c_u - w*0.03 )
#    d' = clip( d + delta_w - r_u*(1-0.5*x)... ) (simple rules, see paper)
# ----------------------------------------------------------------------------
Ng = 161
xs = np.linspace(0, 1, Ng); ds = np.linspace(0, 1, Ng)
X, D = np.meshgrid(xs, ds, indexing="ij")
K0 = (X >= 0.25) & (D <= 0.60)
p_prod = 0.10
ctrl = {"bio": {"c": 0.020, "r": 0.10}, "abiotic": {"c": 0.080, "r": 0.22}}
dist_delta = {"nominal": 0.04, "adversarial": 0.12}
wdraw = {"nominal": 0.00, "adversarial": 0.03}

def step(x, d, u, w):
    xn = np.clip(x + p_prod * (1 - d) - ctrl[u]["c"] - wdraw[w], 0, 1)
    rep = ctrl[u]["r"] * (0.4 + 0.6 * x)   # repair needs some resource x
    dn = np.clip(d + dist_delta[w] - rep, 0, 1)
    return xn, dn

def kernel(robust=True, max_iter=400, controls=("bio", "abiotic")):
    Kk = K0.copy()
    for it in range(max_iter):
        new = np.zeros_like(Kk)
        for u in controls:
            ok_u = np.ones_like(Kk)
            wset = ["nominal", "adversarial"] if robust else ["nominal"]
            for w in wset:
                xn, dn = step(X, D, u, w)
                ix = np.clip(np.round(xn * (Ng - 1)).astype(int), 0, Ng - 1)
                iy = np.clip(np.round(dn * (Ng - 1)).astype(int), 0, Ng - 1)
                ok_u &= Kk[ix, iy]
            new |= ok_u & Kk
        new &= K0
        if np.array_equal(new, Kk):
            break
        Kk = new
    return Kk, it

Kr, it_r = kernel(robust=True)
Kn, it_n = kernel(robust=False)
Kr_bio, _ = kernel(robust=True, controls=("bio",))
Kr_abi, _ = kernel(robust=True, controls=("abiotic",))
R["viability"] = {"K0_fraction": float(K0.mean()),
                  "kernel_nominal_fraction": float(Kn.mean()),
                  "kernel_robust_fraction": float(Kr.mean()),
                  "iterations_robust": int(it_r), "iterations_nominal": int(it_n),
                  "robust_subset_of_nominal": bool(np.all(~Kr | Kn))}
# where must abiotic repair be used? states in robust kernel with d > 0.40
R["viability"]["robust_bio_only_fraction"] = float(Kr_bio.mean())
R["viability"]["robust_abiotic_only_fraction"] = float(Kr_abi.mean())
R["viability"]["switching_gain_over_best_single"] = float(Kr.mean() - max(Kr_bio.mean(), Kr_abi.mean()))
hi = Kr & (D > 0.40)
R["viability"]["robust_states_high_damage_frac"] = float(hi.sum() / max(Kr.sum(), 1))

# ----------------------------------------------------------------------------
# 10. Architecture comparison: stylised normalised decision model + Monte Carlo
#     Environment theta = (log10 g, W, R, F). Parameters sampled from declared ranges.
# ----------------------------------------------------------------------------
G_UG = 1e-6          # in-orbit microgravity, units of g_Earth
G_MARS = 0.38

def zeta(logg, z_ug):
    """Abiotic gravity factor. z_ug = relative abiotic yield in microgravity.
    Log-linear interpolation between microgravity (z_ug) and 0.38 g (1.0)."""
    lg_ug, lg_m = np.log10(G_UG), np.log10(G_MARS)
    frac = np.clip((logg - lg_ug) / (lg_m - lg_ug), 0, 1)
    return z_ug + (1 - z_ug) * frac

def sample_params(n, rng):
    P = {}
    P["z_ug"] = rng.uniform(0.05, 0.50, n)     # bracket measured 0.075
    P["c_A"] = rng.uniform(0.5, 1.5, n)        # abiotic extraction energy scale
    P["c_B"] = rng.uniform(1.5, 3.0, n)        # biological extraction energy scale
    P["rho_A0"] = rng.uniform(0.85, 0.95, n)   # abiotic recovery
    P["rho_B0"] = rng.uniform(0.60, 0.98, n)   # bio recovery at W=1 scaled below
    P["e_recA"] = rng.uniform(0.3, 0.6, n)
    P["e_recB"] = rng.uniform(0.1, 0.3, n)
    P["mhw_A"] = rng.uniform(0.05, 0.20, n)
    P["mhw_B"] = rng.uniform(0.10, 0.30, n)
    P["p0_A"] = rng.uniform(0.01, 0.05, n)
    P["kA"] = rng.uniform(0.5, 2.0, n)
    P["p0_B"] = rng.uniform(0.03, 0.10, n)
    P["kB"] = rng.uniform(0.1, 0.8, n)
    P["Phi_B"] = rng.uniform(0.0, 0.5, n)      # feedstock penalty for bio loop
    P["delta_sw"] = rng.uniform(0.02, 0.08, n) # switching overhead of hybrid
    return P

def evaluate(P, logg, W, Rad, F):
    z = zeta(logg, P["z_ug"])
    # Abiotic
    e_ext_A = P["c_A"] / z
    rhoA = P["rho_A0"]
    M_A = (1 - rhoA) + P["mhw_A"]
    E_A = e_ext_A + P["e_recA"] + 0.5
    p_A = np.clip(P["p0_A"] * (1 + P["kA"] * Rad), 0, 1)
    # Biological
    e_ext_B = P["c_B"] + 0 * z
    rhoB = np.clip(P["rho_B0"] * (0.5 + 0.5 * W), 0, 1)
    M_B = (1 - rhoB) + P["mhw_B"] + P["Phi_B"] * (1 - F)
    E_B = e_ext_B + P["e_recB"] + 0.5
    p_B = np.clip(P["p0_B"] * (1 + P["kB"] * Rad), 0, 1)
    # Hybrid: cheaper extraction + switching, bio recovery active, abiotic standby
    e_ext_C = np.minimum(e_ext_A, e_ext_B) + P["delta_sw"]
    rhoC = 1 - (1 - rhoA) * (1 - rhoB)
    M_C = (1 - rhoC) + P["mhw_A"] + P["mhw_B"] + P["Phi_B"] * (1 - F)
    E_C = e_ext_C + P["e_recB"] + 0.1 * P["e_recA"] + 0.5
    p_C = p_A * p_B
    return np.stack([M_A, M_B, M_C]), np.stack([E_A, E_B, E_C]), np.stack([p_A, p_B, p_C])

def nondominated(obj):
    """obj: (3 options, n draws, 3 objectives) minimised. Returns bool (3, n)."""
    k, n, _ = obj.shape
    nd = np.ones((k, n), dtype=bool)
    for i in range(k):
        for j in range(k):
            if i == j:
                continue
            dom = np.all(obj[j] <= obj[i], axis=-1) & np.any(obj[j] < obj[i], axis=-1)
            nd[i] &= ~dom
    return nd

def run_mc(n, logg, W, Rad, F, rng):
    P = sample_params(n, rng)
    M, E, p = evaluate(P, logg, W, Rad, F)
    obj = np.stack([M, E, p], axis=-1)   # (3, n, 3)
    nd = nondominated(obj)
    return P, M, E, p, nd

# Baseline: broad environment sweep
n_mc = 20000
envs = dict(logg=rng.uniform(-6, 0, n_mc), W=rng.uniform(0, 1, n_mc),
            Rad=rng.uniform(0, 1, n_mc), F=rng.uniform(0, 1, n_mc))
P_all = sample_params(n_mc, rng)
M, E, p = evaluate(P_all, envs["logg"], envs["W"], envs["Rad"], envs["F"])
obj3 = np.stack([M, E, p], axis=-1)
nd3 = nondominated(obj3)
obj2 = np.stack([M, E], axis=-1)
nd2 = nondominated(obj2)                       # trade-off on (import mass, energy)
# Scalarised preference: J = M + E + lam * p  (lam = 10; failure weighted heavily)
J = M + E + 10.0 * p
winner = np.argmin(J, axis=0)                  # 0 A, 1 B, 2 C
frac = lambda m: float(m.mean())
R["pareto"] = {
    "n_draws": int(n_mc),
    "3obj_nondominated_frac": {"A": frac(nd3[0]), "B": frac(nd3[1]), "C": frac(nd3[2])},
    "note_C_failure_by_construction": "p_C = p_A * p_B <= min(p_A, p_B) always, so C is never 3-objective-dominated",
    "2obj_MxE_nondominated_frac": {"A": frac(nd2[0]), "B": frac(nd2[1]), "C": frac(nd2[2])},
    "2obj_MxE_C_only": frac(nd2[2] & ~nd2[0] & ~nd2[1]),
    "2obj_MxE_A_only": frac(nd2[0] & ~nd2[1] & ~nd2[2]),
    "2obj_MxE_B_only": frac(nd2[1] & ~nd2[0] & ~nd2[2]),
    "scalarised_winner_share": {"A": float((winner == 0).mean()), "B": float((winner == 1).mean()), "C": float((winner == 2).mean())},
    "mean_redundancy_mass_penalty_C_vs_best_single": float(np.mean(M[2] - np.minimum(M[0], M[1]))),
    "median_failure_reduction_factor_C_vs_best_single": float(np.median(np.minimum(p[0], p[1]) / np.maximum(p[2], 1e-12))),
}
only_C = winner == 2

# Failure-weight sweep: how much of the hybrid win is reliability vs cost
gbin = np.digitize(envs["logg"], [-5.5, -4, -2.5, -1, -0.5])
lam_sweep = {}
for lam in [0.0, 1.0, 3.0, 10.0]:
    Jl = M + E + lam * p
    wl = np.argmin(Jl, axis=0)
    gb = {}
    for gi, lab in enumerate(["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32"]):
        m = gbin == gi
        gb[lab] = {"A": float((wl[m] == 0).mean()), "B": float((wl[m] == 1).mean()), "C": float((wl[m] == 2).mean())}
    lam_sweep[str(lam)] = {"overall": {"A": float((wl == 0).mean()), "B": float((wl == 1).mean()), "C": float((wl == 2).mean())},
                           "by_gravity": gb}
R["lambda_sweep"] = lam_sweep

# Direct test of the gravity hypothesis: is biological extraction energy below abiotic?
bio_cheaper_ext = (P_all["c_B"] < e_ext_A_all) if False else None
zA = zeta(envs["logg"], P_all["z_ug"])
eA_ext = P_all["c_A"] / zA
eB_ext = P_all["c_B"]
bio_cheaper = (eB_ext < eA_ext)
R["bio_extraction_cheaper_overall"] = float(bio_cheaper.mean())
gb_cheap = {}
for gi, lab in enumerate(["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32"]):
    m = gbin == gi
    gb_cheap[lab] = float(bio_cheaper[m].mean())
R["bio_extraction_cheaper_by_gravity"] = gb_cheap

# Gravity-resolved and water-resolved maps of the scalarised winner
nbins = 24
lg_edges = np.linspace(-6, 0, nbins + 1)
W_edges = np.linspace(0, 1, nbins + 1)
Hmap = np.full((nbins, nbins), np.nan)
ilg = np.clip(np.digitize(envs["logg"], lg_edges) - 1, 0, nbins - 1)
iW = np.clip(np.digitize(envs["W"], W_edges) - 1, 0, nbins - 1)
for a in range(nbins):
    for b in range(nbins):
        m = (ilg == a) & (iW == b)
        if m.sum() > 20:
            Hmap[a, b] = bio_cheaper[m].mean()

gbin = np.digitize(envs["logg"], [-5.5, -4, -2.5, -1, -0.5])
winners = {}
labels = ["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32"]
for gi in range(len(labels)):
    m = gbin == gi
    if m.sum() == 0:
        continue
    winners[labels[gi]] = {"n": int(m.sum()),
                           "C_unique": float((winner[m] == 2).mean()),
                           "A_unique": float((winner[m] == 0).mean()),
                           "B_unique": float((winner[m] == 1).mean())}
R["pareto_by_gravity"] = winners

# Tornado-style sensitivity: range of P(C unique) across quantile bins of each parameter
sens = {}
for key in ["z_ug", "c_B", "rho_B0", "mhw_B", "p0_B", "kB", "Phi_B", "delta_sw", "p0_A", "kA"]:
    v = P_all[key]
    qs = np.quantile(v, np.linspace(0, 1, 6))
    bins = np.clip(np.digitize(v, qs[1:-1]), 0, 4)
    rates = [only_C[bins == b].mean() for b in range(5)]  # share of draws where hybrid wins
    sens[key] = {"min": float(min(rates)), "max": float(max(rates)),
                 "range": float(max(rates) - min(rates))}
R["sensitivity"] = dict(sorted(sens.items(), key=lambda kv: -kv[1]["range"]))

# ----------------------------------------------------------------------------
# 11. Atlas tags (110 concepts) -> counts
# ----------------------------------------------------------------------------
ATLAS = [
 (1,"Planetary-to-orbital regenerative biosphere engines","B/H/E"),
 (2,"Photosynthesis-derived solar energy and artificial biohybrid leaves","H/P"),
 (3,"Microbial asteroid mining and biological resource refineries","B/L"),
 (4,"Regolith-to-structure biomineralization","B/P"),
 (5,"Mycelium-derived structural and thermal materials","B/E"),
 (6,"Engineered living materials with autonomous repair","B/H/P"),
 (7,"Artificial vascular networks for planetary and orbital infrastructure","M/P"),
 (8,"On-demand biological manufacturing in space","B/L"),
 (9,"Bio-inspired adaptive thermal and radiative infrastructure","M/P"),
 (10,"Bio-inspired autonomous construction of O'Neill and Dyson infrastructure","M/P"),
 (11,"Mycorrhizal Urban Water Networks","B/P"),(12,"Algal Wastewater Nutrient Refineries","B/E"),
 (13,"Bacterial Cellulose Filtration Membranes","B/H/E"),(14,"Aquaporin-Inspired Desalination","M/H"),
 (15,"Microbial Electrosynthesis Refineries","H/E"),(16,"Microbial Fuel-Cell Sensor Networks","H/E"),
 (17,"Biological Nitrogen-Recycling Infrastructure","B/E"),(18,"Microbial Carbon-to-Mineral Systems","B/E"),
 (19,"Phytomining of Critical Metals","B/E"),(20,"Root-Inspired Landscape Stabilization","M/H/E"),
 (21,"Insect-Based Organic Waste Refineries","B/E"),(22,"Precision-Fermented Protein Infrastructure","B/E"),
 (23,"Biological Contamination Sentinel Networks","H/P"),(24,"Microbiome-Optimized Vertical Farms","B/E"),
 (25,"Mangrove-Inspired Water Separation","M/H/P"),(26,"Termite-Mound-Inspired Thermal Architecture","M/E"),
 (27,"Self-Healing Urban Bioconcrete","H/E"),(28,"Lotus-Inspired Self-Cleaning Industrial Surfaces","M/E"),
 (29,"Shark-Skin-Inspired Fluid Transport Coatings","M/E"),(30,"Fungal Mycoremediation Infrastructure","B/E"),
 (31,"Perchlorate-Reducing Bioreactors","B/P"),(32,"Extraterrestrial Oxygen-Producing Photobioreactors","B/L"),
 (33,"Biological Methane-Feedstock Plants","B/H/P"),(34,"Regolith Phosphorus Recovery","B/H/P"),
 (35,"Lunar Mineral-Bioleaching Modules","B/L"),(36,"Space Organic-Waste Mineralization Factories","H/P"),
 (37,"Dormant Microbial Emergency Libraries","B/P"),(38,"Engineered Root-Zone Ecosystems","B/P"),
 (39,"Robotic Pollination Infrastructure","M/P"),(40,"Living Selective Membrane Systems","H/P"),
 (41,"Gravity-Independent Gas Exchange Networks","M/P"),(42,"Leaf-Vein Photobioreactor Manifolds","M/H/P"),
 (43,"Bacterial Cellulose Crop Supports","B/H/P"),(44,"Bio-Manufactured Industrial Sealants","B/H/P"),
 (45,"Gecko-Inspired Regolith Anchoring","M/P"),(46,"Lunar Dust-Resistant Surface Architecture","M/P"),
 (47,"Locally Manufactured Hydrogen-Rich Shielding Feedstocks","H/P"),(48,"Root-Inspired Regolith Retention Systems","M/P"),
 (49,"Biological Atmospheric Quality Sensors","H/P"),(50,"Algal Emergency Food Production Modules","B/L"),
 (51,"Selective Bioadsorption of Asteroid Metals","B/H/P"),(52,"Fungal Network Mineral Extraction","B/L"),
 (53,"Asteroid Ore Bio-Beneficiation","B/H/P"),(54,"Microbial Biopolymer Additive Manufacturing","B/P"),
 (55,"Bacterial Nanocellulose Filter Factories","B/H/P"),(56,"Bio-Derived Assembly Adhesives","B/H/P"),
 (57,"Enzymatic Polymer-Recycling Plants","B/H/P"),(58,"Microbial Lubricant Production","B/P"),
 (59,"Algae-to-Industrial-Bioplastic Systems","B/H/P"),(60,"Waste-Gas-to-Industrial-Feedstock Networks","B/H/P"),
 (61,"Vascular-Inspired Thermal Distribution","M/P"),(62,"Mycelium-Inspired Industrial Resource Routing","M/P"),
 (63,"Self-Cleaning Orbital Collector Surfaces","M/P"),(64,"Compound-Eye-Inspired Solar Concentrators","M/P"),
 (65,"Sunflower-Inspired Solar Tracking Networks","M/P"),(66,"Biomimetic Redox Energy Storage","H/P"),
 (67,"Enzyme-Assisted Asteroid Refining","B/H/P"),(68,"Bio-Inspired Selective Mineral Interfaces","M/H/P"),
 (69,"Bio-Composite Electrical Insulation","H/P"),(70,"Regolith-Biomineralization Repair Networks","H/P"),
 (71,"Leaf-Venation Dyson Collector Architecture","M/S"),(72,"Chloroplast-Inspired Photonic Collector Surfaces","M/P"),
 (73,"Self-Repairing Solar Collector Skin","M/P"),(74,"Ant-Colony-Inspired Dyson Swarm Maintenance","M/P"),
 (75,"Insect-Cuticle-Inspired Radiator Surfaces","M/P"),(76,"Vascular Electrical Distribution Networks","M/P"),
 (77,"Protected Orbital Biomanufacturing Stations","B/H/P"),(78,"Modular O'Neill Biosphere Architecture","H/P"),
 (79,"Fungal-Inspired Internal Habitat Architecture","H/P"),(80,"Closed-Loop O'Neill Agriculture and Atmosphere Systems","B/H/P"),
 (81,"Sun-Tracking Stellar Collector Meshes","M/S"),(82,"Asteroid-to-Collector Bio-Refineries","B/H/P"),
 (83,"Biological-Inspired Collector Health Monitoring","M/P"),(84,"Distributed Ant-Inspired Megastructure Logistics","M/P"),
 (85,"Multi-Biosphere O'Neill Settlement Networks","B/H/P"),(86,"Generation-Ship Closed Ecological Engines","B/H/P"),
 (87,"Interstellar Microbial Manufacturing Libraries","B/P"),(88,"Dormant Biomanufacturing Payloads","B/P"),
 (89,"Cell-Free Interstellar Manufacturing Cartridges","H/P"),(90,"Distributed Space Protein Factories","B/P"),
 (91,"Bio-Inspired Interstellar Logistics Networks","M/P"),(92,"DNA-Based Long-Term Scientific Archives","B/H/P"),
 (93,"Mycelial-Topology Communication Algorithms","M/P"),(94,"Interstellar Self-Assembling Robotic Construction Swarms","M/P"),
 (95,"Photosynthetic Habitat Energy-Biomass Coupling","B/H/P"),(96,"Multi-Century Microbial and Seed Preservation Archives","B/P"),
 (97,"Extremophile-Enzyme Industrial Catalysts","B/H/P"),(98,"Interstellar Biogeochemical Recycling Modules","B/H/P"),
 (99,"Distributed Asteroid Bio-Refineries Across Star Systems","B/H/S"),(100,"Interstellar Vascular Energy Networks","M/S"),
 (101,"Galactic Distributed Bio-Refineries","B/S"),(102,"Stellar-Cluster Autonomous Maintenance Swarms","M/S"),
 (103,"Galactic Metabolic Network Digital Twins","M/S"),(104,"Multi-System Biosphere Resilience Architecture","B/M/S"),
 (105,"Planetary Biomanufacturing Establishment Kits","B/H/S"),(106,"Distributed DNA Knowledge Archives","B/H/S"),
 (107,"Post-Biological Cellular-Automata Infrastructure","M/S"),(108,"Fractal Vascular Networks for Galactic Energy Distribution","M/S"),
 (109,"Deep-Time Biological Preservation Networks","B/S"),(110,"Cosmological-Scale Infrastructure Viability Limits","M/S"),
]
assert len(ATLAS) == 110, len(ATLAS)
phase_edges = [(1, 30, "I"), (31, 40, "II"), (41, 70, "III"), (71, 85, "IV"), (86, 100, "V"), (101, 110, "VI")]
tag_counts = {}
phase_tag = {}
for (lo, hi, ph) in phase_edges:
    phase_tag[ph] = {t: 0 for t in "BHMELPS"}
for num, name, tags in ATLAS:
    ph = [p for (lo, hi, p) in phase_edges if lo <= num <= hi][0]
    for t in tags.split("/"):
        phase_tag[ph][t] += 1
        tag_counts[t] = tag_counts.get(t, 0) + 1
R["atlas_tag_counts"] = tag_counts
R["atlas_phase_tags"] = phase_tag
R["atlas_n"] = len(ATLAS)
R["atlas_no_B_or_H_in_phase_IV_VI_count"] = sum(
    1 for num, _, tags in ATLAS if num >= 71 and any(t in tags for t in ["B"]) and num <= 110
)
R["atlas_B_tagged_in_IV_to_VI"] = [num for num, _, tags in ATLAS if num >= 71 and "B" in tags.split("/")]


# ----------------------------------------------------------------------------
# 12. Control latency of distributed collectors (light-time, exact physics)
# ----------------------------------------------------------------------------
C_LIGHT = 299792458.0
LY = 9.4607e15
lat = {}
for label, dist_m in [("0.1 AU", 0.1 * AU), ("1 AU", AU), ("5 AU", 5 * AU), ("30 AU (Neptune scale)", 30 * AU),
                      ("Proxima Centauri (4.245 ly)", 4.2465 * LY)]:
    one_way = dist_m / C_LIGHT
    lat[label] = {"one_way_s": float(one_way), "round_trip_s": float(2 * one_way),
                  "one_way_h": float(one_way / 3600), "round_trip_days": float(2 * one_way / 86400)}
R["latency"] = lat

# ----------------------------------------------------------------------------
# 13. Viability vs adversary strength and production rate (robust kernel sweeps)
# ----------------------------------------------------------------------------
def kernel_param(delta_adv, p_val, controls):
    global dist_delta, wdraw, p_prod
    old = (dist_delta, wdraw, p_prod)
    dist_delta = {"nominal": 0.04, "adversarial": delta_adv}
    wdraw = {"nominal": 0.00, "adversarial": 0.03}
    p_prod = p_val
    try:
        Kk, _ = kernel(robust=True, controls=controls)
    finally:
        dist_delta, wdraw, p_prod = old
    return float(Kk.mean())

deltas = [0.04, 0.08, 0.12, 0.16, 0.20]
vs = {"switching": [], "bio_only": [], "abiotic_only": []}
for dv in deltas:
    vs["switching"].append(kernel_param(dv, 0.10, ("bio", "abiotic")))
    vs["bio_only"].append(kernel_param(dv, 0.10, ("bio",)))
    vs["abiotic_only"].append(kernel_param(dv, 0.10, ("abiotic",)))
prods = [0.06, 0.08, 0.10, 0.12, 0.14]
vp = {"switching": [], "bio_only": [], "abiotic_only": []}
for pv in prods:
    vp["switching"].append(kernel_param(0.12, pv, ("bio", "abiotic")))
    vp["bio_only"].append(kernel_param(0.12, pv, ("bio",)))
    vp["abiotic_only"].append(kernel_param(0.12, pv, ("abiotic",)))
R["viab_sweep_delta"] = {"x": deltas, **vs}
R["viab_sweep_prod"] = {"x": prods, **vp}

# ----------------------------------------------------------------------------
# 14. Interpolation-shape sensitivity of the gravity threshold
# ----------------------------------------------------------------------------
def zeta_kind(logg, z_ug, kind):
    lg_ug, lg_m = np.log10(G_UG), np.log10(G_MARS)
    if kind == "loglinear":
        return zeta(logg, z_ug)
    if kind == "linear_g":
        g = 10 ** logg
        frac = np.clip((g - G_UG) / (G_MARS - G_UG), 0, 1)
        return z_ug + (1 - z_ug) * frac
    if kind == "step_1e-3":
        return np.where(logg < -3.0, z_ug, 1.0)
    raise ValueError(kind)

interp = {}
for kind in ["loglinear", "linear_g", "step_1e-3"]:
    zk = zeta_kind(envs["logg"], P_all["z_ug"], kind)
    bc = (P_all["c_B"] < P_all["c_A"] / zk)
    row = {}
    for gi, lab in enumerate(["g<1e-5.5", "1e-5.5..1e-4", "1e-4..3e-3", "3e-3..0.1", "0.1..0.32", "g>0.32"]):
        m = gbin == gi
        row[lab] = float(bc[m].mean())
    row["overall"] = float(bc.mean())
    interp[kind] = row
R["interp_variants"] = interp

# ----------------------------------------------------------------------------
# 15. Two-dimensional environment map: hybrid share at lambda = 1 over (R, W)
# ----------------------------------------------------------------------------
map2d = {}
Rg = np.linspace(0, 1, 12)
Wg = np.linspace(0, 1, 12)
for lg_fixed, key in [(-5.0, "g1e-5"), (-1.0, "g0.1")]:
    H_c = np.zeros((12, 12)); H_b = np.zeros((12, 12)); H_a = np.zeros((12, 12))
    for i, rv in enumerate(Rg):
        for j, wv in enumerate(Wg):
            n = 400
            Pm = sample_params(n, rng)
            Fm = rng.uniform(0, 1, n)
            Mm, Em, pm = evaluate(Pm, np.full(n, lg_fixed), np.full(n, wv), np.full(n, rv), Fm)
            Jm = Mm + Em + 1.0 * pm
            wn = np.argmin(Jm, axis=0)
            H_a[i, j] = (wn == 0).mean(); H_b[i, j] = (wn == 1).mean(); H_c[i, j] = (wn == 2).mean()
    map2d[key] = {"hybrid": H_c.tolist(), "bio": H_b.tolist(), "abiotic": H_a.tolist(), "R": Rg.tolist(), "W": Wg.tolist()}
R["map2d"] = map2d

# ----------------------------------------------------------------------------
# 16. Figures for new analyses
# ----------------------------------------------------------------------------
fig, (f1, f2) = plt.subplots(1, 2, figsize=(6.9, 2.8))
f1.plot(deltas, vs["switching"], "o-", color=CORAL, lw=1.6, ms=3.5, label="both channels (switching)")
f1.plot(deltas, vs["bio_only"], "s--", color=GREEN, lw=1.2, ms=3, label="biological only")
f1.plot(deltas, vs["abiotic_only"], "^--", color=GOLD, lw=1.2, ms=3, label="abiotic only")
f1.set_xlabel("adversarial damage per step δ_adv"); f1.set_ylabel("robust kernel fraction of K")
f1.set_title("Viability vs adversary strength"); f1.legend(fontsize=6.5)
f2.plot(prods, vp["switching"], "o-", color=CORAL, lw=1.6, ms=3.5, label="both channels (switching)")
f2.plot(prods, vp["bio_only"], "s--", color=GREEN, lw=1.2, ms=3, label="biological only")
f2.plot(prods, vp["abiotic_only"], "^--", color=GOLD, lw=1.2, ms=3, label="abiotic only")
f2.set_xlabel("resource production rate p"); f2.set_ylabel("robust kernel fraction of K")
f2.set_title("Viability vs production (δ_adv = 0.12)"); f2.legend(fontsize=6.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig13_viab_sweep.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(6.9, 2.9))
for ax, key, ttl in zip(axes, ["g1e-5", "g0.1"], ["g = 10^-5 g_Earth", "g = 0.1 g_Earth"]):
    d_ = map2d[key]
    im = ax.imshow(np.array(d_["hybrid"]).T, origin="lower", extent=[0, 1, 0, 1], aspect="auto", cmap=CMAP, vmin=0, vmax=1)
    ax.set_xlabel("radiation index R"); ax.set_ylabel("water closure W")
    ax.set_title(f"Hybrid share at λ=1, {ttl}")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=6.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig14_map2d.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)

print("new analyses done")


# ----------------------------------------------------------------------------
# 17. Convergence and verification checks
# ----------------------------------------------------------------------------
conv_n = []
for n_ in [500, 1000, 2000, 5000, 10000, 20000]:
    idx_ = slice(0, n_)
    Mi, Ei, pi_ = M[:, idx_], E[:, idx_], p[:, idx_]
    Ji = Mi + Ei + 1.0 * pi_
    wi = np.argmin(Ji, axis=0)
    conv_n.append({"n": n_, "hybrid_share_lam1": float((wi == 2).mean()),
                   "bio_cheaper": float((P_all["c_B"][idx_] < P_all["c_A"][idx_] / zeta(envs["logg"][idx_], P_all["z_ug"][idx_])).mean())})
R["conv_mc"] = conv_n

def kernel_grid(Ng_, robust=True):
    xs_ = np.linspace(0, 1, Ng_); ds_ = np.linspace(0, 1, Ng_)
    X_, D_ = np.meshgrid(xs_, ds_, indexing="ij")
    K0_ = (X_ >= 0.25) & (D_ <= 0.60)
    Kk = K0_.copy()
    for _ in range(600):
        new = np.zeros_like(Kk)
        for u in ("bio", "abiotic"):
            ok_u = np.ones_like(Kk)
            for w in (["nominal", "adversarial"] if robust else ["nominal"]):
                xn = np.clip(X_ + p_prod * (1 - D_) - ctrl[u]["c"] - wdraw[w], 0, 1)
                rep = ctrl[u]["r"] * (0.4 + 0.6 * X_)
                dn = np.clip(D_ + dist_delta[w] - rep, 0, 1)
                ix = np.clip(np.round(xn * (Ng_ - 1)).astype(int), 0, Ng_ - 1)
                iy = np.clip(np.round(dn * (Ng_ - 1)).astype(int), 0, Ng_ - 1)
                ok_u &= Kk[ix, iy]
            new |= ok_u & Kk
        new &= K0_
        if np.array_equal(new, Kk):
            break
        Kk = new
    return float(Kk.mean())

conv_grid = [{"Ng": g_, "robust_fraction": kernel_grid(g_, True)} for g_ in [41, 81, 121, 161, 241]]
R["conv_grid"] = conv_grid

# verification: dense vs sparse algebraic connectivity on one graph
pts_v = rng.uniform(0, 1, size=(300, 2))
Av = knn_graph(pts_v, 6)
lam_dense = np.linalg.eigvalsh(csgraph.laplacian(Av))[1]
from scipy.sparse.linalg import eigsh
Lsp = csgraph.laplacian(Av)
lam_sparse = eigsh(Lsp, k=2, sigma=-1e-6, which="LM")[0]
lam_sparse = sorted(lam_sparse)[1]
# Eq (2) numeric vs closed form error
R["verify"] = {}
R["verify"]["lambda2_dense_minus_sparse"] = float(abs(lam_dense - lam_sparse))
# Radiative equilibrium: residual of root-solve vs closed form (eta=0.26, alpha=0.95, eps=0.90)
from math import isclose
def resid(T, eta=0.26, alpha=0.95, eps=0.90):
    return alpha * S0 * (1 - eta) / 4 - eps * SIGMA * T**4
lo_, hi_ = 50.0, 2000.0
for _ in range(200):
    mid = 0.5 * (lo_ + hi_)
    if resid(mid) > 0:
        lo_ = mid
    else:
        hi_ = mid
R["verify"]["T_eq_bisection_minus_closed"] = float(abs(0.5 * (lo_ + hi_) - R["T_shell_eta026_eps090_alpha095_K"]))
# Dominance code vs brute force on random triples
tri = rng.uniform(0, 1, size=(3, 2000, 3))
nd_fast = nondominated(np.transpose(tri, (0, 1, 2)))
nd_brute = np.zeros((3, 2000), dtype=bool)
for j_ in range(2000):
    for i_ in range(3):
        dom_ = False
        for k_ in range(3):
            if k_ == i_:
                continue
            if np.all(tri[k_, j_] <= tri[i_, j_]) and np.any(tri[k_, j_] < tri[i_, j_]):
                dom_ = True
        nd_brute[i_, j_] = not dom_
R["verify"]["dominance_mismatches"] = int((nd_fast != nd_brute).sum())
# Murray: closed-form optimum vs numerical optimum at Q=1
rs_ = np.logspace(-3, 1.5, 200000)
f_ = a_ * 1.0 / rs_**4 + b_ * rs_**2
R["verify"]["murray_closed_minus_numeric_Q1"] = float(abs((2 * a_ / b_) ** (1 / 6) - rs_[np.argmin(f_)]))
R["verify"]["material_closed_minus_numeric"] = float(abs(R["material_numeric_check_rho099"]["numeric"] - R["material_numeric_check_rho099"]["closed_form"]))
print("convergence and verification done")



# ----------------------------------------------------------------------------
# 18. Diffusion-limited biocementation: explicit 1D reaction-diffusion simulation (stylised)
#     dc/dt = D c_xx - k c X ;  dX/dt = Y k c X - m X ;  M_c accumulates 0.3 k c X
# ----------------------------------------------------------------------------
def micp_sim(D_, ku_=5e-5, L_=0.10, dx_=2e-4, dt_=2.0, t_end_=2.0e5, rec_every=10000):
    n_ = int(round(L_ / dx_)) + 1
    c_ = np.zeros(n_); X_ = np.full(n_, 0.1); Mc_ = np.zeros(n_)
    c_[0] = 1.0
    Y_, m_ = 0.5, 1e-6
    steps_ = int(t_end_ / dt_)
    times, fronts = [], []
    for k_ in range(steps_ + 1):
        if k_ % rec_every == 0:
            act = np.where(c_ > 0.05)[0]
            front = (act.max() * dx_) if len(act) else 0.0
            times.append(k_ * dt_); fronts.append(front)
        lap_ = np.zeros(n_)
        lap_[1:-1] = (c_[2:] - 2 * c_[1:-1] + c_[:-2]) / dx_**2
        rate_ = ku_ * c_ * X_
        c_ = c_ + dt_ * (D_ * lap_ - rate_)
        c_[0] = 1.0
        c_[-1] = c_[-2]
        X_ = X_ + dt_ * (Y_ * rate_ * (1.0 - X_) - m_ * X_)   # logistic growth, capacity 1
        Mc_ = Mc_ + dt_ * 0.3 * rate_
        np.clip(c_, 0, 1, out=c_)
    return np.array(times), np.array(fronts), c_.copy(), Mc_.copy(), n_, dx_

micp = {}
prof = {}
for D_ in [1e-9, 4e-9]:
    t_, f_, cfin, Mfin, n_, dx_ = micp_sim(D_)
    sel = t_ > 0
    slope_ = np.polyfit(np.log(t_[sel]), np.log(np.maximum(f_[sel], 1e-9)), 1)[0]
    # prefactor a in x_f = a sqrt(D t) using last record
    a_ = f_[-1] / np.sqrt(D_ * t_[-1])
    from scipy.special import erfcinv
    a_theory = 2.0 * float(erfcinv(0.05))
    micp[str(D_)] = {"times": t_.tolist(), "fronts": f_.tolist(), "loglog_slope": float(slope_),
                     "prefactor_a": float(a_), "prefactor_theory": a_theory,
                     "t_to_10cm_days": float((0.10 / a_theory) ** 2 / D_ / 86400),
                     "front_final_m": float(f_[-1]), "precipitate_final_max": float(Mfin.max())}
    prof[str(D_)] = {"x": (np.arange(n_) * dx_).tolist(), "M": Mfin.tolist(), "c": cfin.tolist()}
R["micp"] = micp
R["micp_profiles"] = prof

# Pure-diffusion scaling: time to reach depth L is L^2 / D (order-of-magnitude), for L = 0.1 m
R["diffusion_time_10cm_days"] = {str(D_): float(((0.10 / (2.0 * float(__import__("scipy.special", fromlist=["erfcinv"]).erfcinv(0.05)))) ** 2 / D_) / 86400) for D_ in [1e-9, 4e-9]}

# ----------------------------------------------------------------------------
# 19. Crew water replacement budget (Eq. 2), using 2.50 kg/day water per person
#     (figure from Verbeelen et al. 2021, Front. Microbiol.)
# ----------------------------------------------------------------------------
crew = 4
water_pp = 2.50    # kg per person per day
D_water = crew * water_pp * 365.0
budget = {}
for rho_ in [0.90, 0.95, 0.98, 0.99, 0.999]:
    loss_ = (1 - rho_) * D_water
    budget[str(rho_)] = {"loss_per_year_kg": float(loss_), "loss_over_20y_kg": float(loss_ * 20)}
R["water_budget"] = {"demand_per_year_kg": float(D_water), "rows": budget}

with open(os.path.join(OUT, "results.json"), "w") as f:
    json.dump(R, f, indent=2, default=float)

# Figure 15 (labelled 8b in the paper): MICP front and profile
fig, (q1, q2) = plt.subplots(1, 2, figsize=(6.9, 2.7))
for key_, c_, lab_ in [("1e-09", TEAL, "D = 1e-9 m² s⁻¹"), ("4e-09", CORAL, "D = 4e-9 m² s⁻¹")]:
    t_ = np.array(micp[key_]["times"]); f_ = np.array(micp[key_]["fronts"])
    q1.plot(t_ / 86400, f_ * 1e3, "o-", ms=2.6, lw=1.2, color=c_, label=lab_)
    q1.plot(t_ / 86400, micp[key_]["prefactor_a"] * np.sqrt(float(key_) * t_) * 1e3, ":", color=c_, lw=1)
q1.set_xlabel("time [days]"); q1.set_ylabel("active-front depth [mm]")
q1.set_title("Front depth, dotted = a√(Dt) fit"); q1.legend(fontsize=6.6)
for key_, c_ in [("1e-09", TEAL), ("4e-09", CORAL)]:
    x_ = np.array(prof[key_]["x"]) * 1e3; M_ = np.array(prof[key_]["M"])
    q2.plot(x_, M_ / max(M_.max(), 1e-12), color=c_, lw=1.4, label=f"D = {key_}")
q2.set_xlabel("depth [mm]"); q2.set_ylabel("normalised precipitate")
q2.set_title("Final precipitate profile"); q2.legend(fontsize=6.6)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig15_micp.png"), bbox_inches="tight", facecolor="white"); plt.close(fig)
print("micp and budget done")



# ----------------------------------------------------------------------------
# 20. Targeted (hub-first) versus random loss in the swarm graph
# ----------------------------------------------------------------------------
tg = {"fail_fracs": fail_fracs.tolist(), "random": [], "hub_first": [], "lam2_random": [], "lam2_hub": []}
for f_ in fail_fracs:
    pr, ph, lr, lh = [], [], [], []
    for trial in range(25):
        pts = rng.uniform(0, 1, size=(N_SW, 2))
        A = knn_graph(pts, 6)
        deg = A.sum(axis=1)
        # random loss
        alive = rng.uniform(size=N_SW) >= f_
        keep = np.where(alive)[0]
        Ar = A[np.ix_(keep, keep)]
        pr.append(connected_fraction(Ar) if Ar.shape[0] > 2 else 0)
        lr.append(lambda2(Ar) if Ar.shape[0] > 2 else 0)
        # hub-first loss: remove the highest-degree units first
        n_rm = int(round(f_ * N_SW))
        order = np.argsort(-deg)
        keep_h = np.setdiff1d(np.arange(N_SW), order[:n_rm])
        Ah = A[np.ix_(keep_h, keep_h)]
        ph.append(connected_fraction(Ah) if Ah.shape[0] > 2 else 0)
        lh.append(lambda2(Ah) if Ah.shape[0] > 2 else 0)
    tg["random"].append(float(np.mean(pr))); tg["hub_first"].append(float(np.mean(ph)))
    tg["lam2_random"].append(float(np.mean(lr))); tg["lam2_hub"].append(float(np.mean(lh)))
R["swarm_targeted"] = tg
def _thr(arr, fr):
    for f_, p_ in zip(fr, arr):
        if p_ < 0.5:
            return float(f_)
    return None
R["swarm_targeted_thresholds"] = {"random": _thr(tg["random"], fail_fracs), "hub_first": _thr(tg["hub_first"], fail_fracs)}
print("targeted done")



# ----------------------------------------------------------------------------
# 21. Sensitivity at lambda = 0 and lambda = 1 (hybrid and abiotic shares)
# ----------------------------------------------------------------------------
sens_lam = {}
for lam_ in [0.0, 1.0]:
    Jl_ = M + E + lam_ * p
    wl_ = np.argmin(Jl_, axis=0)
    out_ = {}
    for key in ["z_ug", "c_B", "rho_B0", "mhw_B", "p0_B", "kB", "Phi_B", "delta_sw", "p0_A", "kA"]:
        v = P_all[key]
        qs = np.quantile(v, np.linspace(0, 1, 6))
        bins = np.clip(np.digitize(v, qs[1:-1]), 0, 4)
        rates = [(wl_[bins == b] == 2).mean() for b in range(5)]
        rates_a = [(wl_[bins == b] == 0).mean() for b in range(5)]
        out_[key] = {"hyb_min": float(min(rates)), "hyb_max": float(max(rates)), "hyb_range": float(max(rates) - min(rates)),
                     "abi_range": float(max(rates_a) - min(rates_a))}
    sens_lam[str(lam_)] = dict(sorted(out_.items(), key=lambda kv: -kv[1]["hyb_range"]))
R["sensitivity_lambda"] = sens_lam

# ----------------------------------------------------------------------------
# 22. Claim register data (values to cite in appendix J)
# ----------------------------------------------------------------------------
R["claim_register_note"] = "generated by analysis.py; see build_pdf.py Appendix J"


# ----------------------------------------------------------------------------
# Save results
# ----------------------------------------------------------------------------
with open(os.path.join(OUT, "results.json"), "w") as f:
    json.dump(R, f, indent=2, default=float)

# ----------------------------------------------------------------------------
# FIGURES
# ----------------------------------------------------------------------------
def save(fig, name):
    fig.savefig(os.path.join(FIG, name), bbox_inches="tight", facecolor="white")
    plt.close(fig)

# Fig 1: Kardashev index continuous and scale bands
fig, ax = plt.subplots(figsize=(6.6, 2.7))
Ks = np.linspace(0, 6, 300)
Ps = 10 ** (6 + 10 * Ks)
ax.plot(Ks, np.log10(Ps), color=NAVY, lw=1.8)
bands = [(0.7, 1.0, "Planetary", TEAL, 44.5), (1.0, 1.5, "Lunar/Martian\norbital", GREEN, 38.5),
         (1.5, 2.0, "Solar\nsystem", GOLD, 44.5), (2.0, 3.0, "Stellar /\ninterstellar", CORAL, 38.5),
         (3.0, 6.0, "Extrapolation", VIOLET, 28)]
for lo, hi, lab, c, ypos in bands:
    ax.axvspan(lo, hi, color=c, alpha=0.18, lw=0)
    ax.text((lo + hi) / 2, ypos, lab, ha="center", va="top", fontsize=7, color=c, rotation=0, linespacing=1.1)
ax.scatter([0.73], [np.log10(1.9e13)], s=34, color=CORAL, zorder=5)
ax.annotate("humanity, K ≈ 0.73", (0.73, np.log10(1.9e13)), xytext=(1.2, 17), fontsize=7.5,
            arrowprops=dict(arrowstyle="-", color=GREY, lw=0.6))
for K, lab in [(1, "I"), (2, "II"), (3, "III")]:
    ax.axvline(K, color=GREY, lw=0.6, ls="--")
ax.set_xlabel("Sagan index K = (log10 P − 6) / 10")
ax.set_ylabel("log10 P  [W]")
ax.set_xlim(0, 6); ax.set_ylim(10, 46)
ax.set_title("Continuous Kardashev index and the scenario bands used in this paper")
save(fig, "fig02_kardashev.png")

# Fig 2: capture geometry and collector mass
fig, (a1, a2) = plt.subplots(1, 2, figsize=(6.8, 2.8))
eta = np.linspace(0.05, 0.9, 200)
for P, lab, c in [(1e16, "Type I ref.", GREEN), (1e26, "Type II ref.", CORAL)]:
    A = P / (eta * S0)
    a1.plot(eta, np.log10(A), color=c, lw=1.7, label=lab)
a1.axhline(np.log10(A_sphere_1AU), color=NAVY, ls="--", lw=1)
a1.text(0.52, np.log10(A_sphere_1AU) + 0.15, "full 1 AU sphere, 4πr²", fontsize=7, color=NAVY)
a1.axvline(1 - 0.0, color=GREY, lw=0)  # spacer
a1.axvline(0.2612, color=GOLD, ls=":", lw=1.2)
a1.text(0.27, 17.8, "η·f_cov ≥ 0.261\n(Type II, any r)", fontsize=6.8, color=NAVY)
a1.set_xlabel("collector efficiency η"); a1.set_ylabel("log10 required area [m²]")
a1.set_title("Area law at 1 AU"); a1.legend(fontsize=7, loc="upper right")
a1.set_ylim(12, 25)
ad = np.logspace(-1, 1, 50)
for lab, f in [("Mercury mass", M_MERCURY), ("Moon mass", M_MOON)]:
    a2.axhline(np.log10(f), ls=":", lw=0.9, color=GREY)
    a2.text(-1.02, np.log10(f) + 0.2, lab, fontsize=6.5, color=GREY)
a2.plot(np.log10(ad), np.log10(A_sphere_1AU * ad), color=VIOLET, lw=1.8)
a2.set_xlabel("areal density [kg m⁻²] (log10)"); a2.set_ylabel("log10 mass [kg]")
a2.set_title("Mass of one full 1 AU shell")
a2.set_xlim(-1.05, 1.05)
fig.tight_layout()
save(fig, "fig03_capture_mass.png")

# Fig 3: radiative equilibrium and radiator area
fig, (b1, b2) = plt.subplots(1, 2, figsize=(6.8, 2.7))
etas = np.linspace(0, 0.5, 100)
for r_au, c in [(0.5, CORAL), (1.0, TEAL), (2.0, VIOLET)]:
    b1.plot(etas, T_shell(etas, alpha=0.95, eps=0.90, r_au=r_au), color=c, lw=1.7, label=f"r = {r_au} AU")
b1.set_xlabel("collector efficiency η"); b1.set_ylabel("equilibrium T [K]")
b1.set_title("Shell temperature, ε=0.9, α=0.95"); b1.legend(fontsize=7)
Ts = np.linspace(250, 600, 200)
for Q, c in [(1e9, GOLD), (1e12, CORAL)]:
    b2.semilogy(Ts, radiator_area(Q, Ts), color=c, lw=1.7, label=f"Q = {Q:.0e} W")
b2.set_xlabel("radiator temperature [K]"); b2.set_ylabel("radiator area [m²]")
b2.set_title("Ideal one-sided radiator: A = Q / εσT⁴"); b2.legend(fontsize=7)
fig.tight_layout(); save(fig, "fig04_radiative.png")

# Fig 4: Petela and PV vs BPV power density
fig, ax = plt.subplots(figsize=(6.6, 2.6))
labels = ["Whole-cell BPV\nlow (2024 review)", "Whole-cell BPV\nhigh (2024 review)", "Ideal PV\nη=0.20", "Solar\nincident"]
vals = [bpv_lo, bpv_hi, pv_mW_m2, S0_mW_m2]
cols = [GREY, TEAL, GOLD, NAVY]
bars = ax.bar(labels, np.log10(vals), color=cols, width=0.55)
for b_, v in zip(bars, vals):
    ax.text(b_.get_x() + b_.get_width() / 2, np.log10(v) + 0.15, f"{v:.1e} mW m⁻²", ha="center", fontsize=6.8)
ax.set_ylabel("log10 power density [mW m⁻²]")
ax.set_ylim(-5, 8)
ax.set_title("Biophotovoltaic power density against photovoltaic and incident solar flux")
save(fig, "fig05_bpv_pv.png")

# Fig 5: BioAsteroid palladium
fig, ax = plt.subplots(figsize=(5.8, 2.6))
labs = ["Abiotic\n1 g (Earth)", "Abiotic\nmicrogravity", "P. simplicissimum\nmicrogravity"]
vv = [pd_abiotic_1g, pd_abiotic_ug, pd_fungus_ug]
bb = ax.bar(labs, vv, color=[GREY, SKY, CORAL], width=0.5)
for b_, v in zip(bb, vv):
    ax.text(b_.get_x() + b_.get_width() / 2, v + 0.6, f"{v:.1f}%", ha="center", fontsize=7.5)
ax.set_ylabel("palladium extracted [% of metal present]")
ax.set_title("Palladium release from L-chondrite: gravity and biology (as reported)")
ax.set_ylim(0, 36)
save(fig, "fig06_bioasteroid_pd.png")

# Fig 6: Murray law and swarm connectivity (two-panel)
fig, (c1, c2) = plt.subplots(1, 2, figsize=(6.9, 2.8))
c1.loglog(Qs, r_opt, "o", ms=2.5, color=TEAL, label="numerical optimum")
c1.loglog(Qs, r_opt[0] * (Qs / Qs[0]) ** (1 / 3), color=CORAL, lw=1.2, label="slope 1/3 (Murray)")
c1.set_xlabel("flow Q"); c1.set_ylabel("optimal radius r*"); c1.legend(fontsize=7)
c1.set_title(f"Murray scaling: fitted slope {slope:.3f}")
fr = fail_fracs
for k, c in zip(["4", "6", "8"], [CORAL, TEAL, VIOLET]):
    c2.plot(fr, swarm[k]["p_connected"], "o-", ms=2.5, lw=1.2, color=c, label=f"kNN, k={k}")
c2.axhline(0.5, color=GREY, ls=":", lw=0.8)
c2.set_xlabel("fraction of units lost at random"); c2.set_ylabel("P(network connected)")
c2.set_title("Swarm connectivity under random loss, N=300"); c2.legend(fontsize=7)
fig.tight_layout(); save(fig, "fig07_murray_swarm.png")

# Fig 7: material circularity
fig, ax = plt.subplots(figsize=(6.4, 2.6))
for rho, c in [(0.90, CORAL), (0.99, GOLD), (0.999, TEAL), (1.0, VIOLET)]:
    cum = (1 - rho) * D_daily * 365.0 * years
    ax.plot(years, cum + 1e-9, color=c, lw=1.6, label=f"ρ = {rho}")
ax.set_xlabel("years"); ax.set_ylabel("cumulative external replacement M(t)  [units]")
ax.set_title("Eq. (2): replacement burden under recovery fraction ρ (constant D)")
ax.legend(fontsize=7)
save(fig, "fig08_material.png")

# Fig 8: robust viability kernel
fig, (d1, d2) = plt.subplots(1, 2, figsize=(6.9, 3.0))
ext = [0, 1, 0, 1]
d1.imshow(K0.T, origin="lower", extent=ext, cmap="Greys", alpha=0.25, aspect="auto")
d1.imshow(Kn.T, origin="lower", extent=ext, cmap=LinearSegmentedColormap.from_list("n", ["none", TEAL]), alpha=0.85, aspect="auto")
d1.set_title("Nominal kernel (teal) ⊂ K (grey)")
d1.set_xlabel("resource x"); d1.set_ylabel("damage d")
d2.imshow(K0.T, origin="lower", extent=ext, cmap="Greys", alpha=0.25, aspect="auto")
d2.imshow(Kr.T, origin="lower", extent=ext, cmap=LinearSegmentedColormap.from_list("r", ["none", CORAL]), alpha=0.9, aspect="auto")
d2.set_title("Robust kernel (coral), adversarial w")
d2.set_xlabel("resource x"); d2.set_ylabel("damage d")
fig.tight_layout(); save(fig, "fig09_viability.png")

# Fig 9: Pareto environment map and gravity winners
fig, (e1, e2) = plt.subplots(1, 2, figsize=(7.0, 3.0))
im = e1.imshow(np.ma.masked_invalid(Hmap.T), origin="lower", extent=[-6, 0, 0, 1], aspect="auto", cmap=CMAP, vmin=0, vmax=1)
e1.set_xlabel("log10 g  (units of g_Earth)"); e1.set_ylabel("water closure W")
e1.set_title("P(biological extraction cheaper in energy)")
cb = fig.colorbar(im, ax=e1, fraction=0.046, pad=0.03); cb.ax.tick_params(labelsize=6.5)
names = list(lam_sweep["0.0"]["by_gravity"].keys())
cu = [lam_sweep["0.0"]["by_gravity"][n]["C"] for n in names]
ca = [lam_sweep["0.0"]["by_gravity"][n]["A"] for n in names]
cbv = [lam_sweep["0.0"]["by_gravity"][n]["B"] for n in names]
xx = np.arange(len(names))
e2.bar(xx - 0.27, ca, 0.27, color=GOLD, label="abiotic")
e2.bar(xx, cbv, 0.27, color=GREEN, label="biological")
e2.bar(xx + 0.27, cu, 0.27, color=CORAL, label="hybrid")
e2.set_xticks(xx); e2.set_xticklabels(names, rotation=28, fontsize=6.3, ha="right")
e2.set_ylabel("share of draws won (J = M + E)"); e2.set_ylim(0, 1.0); e2.legend(fontsize=6.8, ncol=3, loc="upper center", frameon=False)
e2.set_title("Winner by gravity, no failure weight")
fig.tight_layout(); save(fig, "fig10_pareto_env.png")

# Fig 10: sensitivity tornado
fig, ax = plt.subplots(figsize=(6.4, 2.9))
items = list(R["sensitivity"].items())[::-1]
ylab = [k for k, _ in items]
for i, (k, v) in enumerate(items):
    ax.barh(i, v["max"] - v["min"], left=v["min"], color=TEAL if v["range"] > 0.03 else GREY, height=0.55)
ax.set_yticks(range(len(items))); ax.set_yticklabels(ylab, fontsize=7.5)
ax.axvline(R["pareto"]["scalarised_winner_share"]["C"], color=CORAL, ls="--", lw=1)
ax.set_xlabel("share of draws won by the hybrid, across quintiles of each parameter")
ax.set_title("Sensitivity of the hybrid region to each uncertain parameter")
save(fig, "fig11_tornado.png")

# Fig 11: atlas composition
fig, ax = plt.subplots(figsize=(6.6, 2.7))
phs = list(phase_tag.keys())
tags_order = ["B", "H", "M", "E", "L", "P", "S"]
pal = {"B": GREEN, "H": TEAL, "M": GOLD, "E": NAVY, "L": SKY, "P": VIOLET, "S": CORAL}
bottom = np.zeros(len(phs))
for t in tags_order:
    vals_t = np.array([phase_tag[p][t] for p in phs])
    ax.bar(phs, vals_t, bottom=bottom, color=pal[t], label=t, width=0.6)
    bottom += vals_t
ax.set_ylabel("tag occurrences")
ax.set_xlabel("Phase (I to VI)")
ax.set_title("Maturity and biology tags across the 110-concept atlas (multi-tag concepts count per tag)")
ax.legend(ncol=7, fontsize=7, loc="upper right")
save(fig, "fig12_atlas.png")

# Fig 12: swarm robustness and viability (already), plus framework schematic
fig, ax = plt.subplots(figsize=(6.8, 3.0))
ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")
def box(x, y, w, h, txt, c):
    from matplotlib.patches import FancyBboxPatch
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05,rounding_size=0.12", fc=c, ec=NAVY, lw=0.6, alpha=0.92))
    ax.text(x + w / 2, y + h / 2, txt, ha="center", va="center", fontsize=6.8, color="white" if c not in [GOLD, SKY] else NAVY)
box(0.2, 4.5, 2.9, 1.2, "Environment θ\n(T, p, g, R, W, F, τ)", NAVY)
box(3.55, 4.5, 2.9, 1.2, "Module set (B, H, A)\nprocess rates u(t)", TEAL)
box(6.9, 4.5, 2.9, 1.2, "Conservation (1)\nmaterial (2), energy (3)", VIOLET)
box(0.2, 2.3, 2.9, 1.2, "Heat rejection (4)\nradiative equilibrium", CORAL)
box(3.55, 2.3, 2.9, 1.2, "Damage & repair (5)\nrobust viability kernel", GREEN)
box(6.9, 2.3, 2.9, 1.2, "Network robustness\nλ2, swarm connectivity", GOLD)
box(3.55, 0.2, 2.9, 1.2, "Pareto set over (M, E, p)\nhybrid region Ω_BH", NAVY)
for (x1, y1, x2, y2) in [(3.1, 5.1, 3.55, 5.1), (6.45, 5.1, 6.9, 5.1), (1.65, 4.5, 1.65, 3.5),
                          (5.0, 4.5, 5.0, 3.5), (8.35, 4.5, 8.35, 3.5), (5.0, 2.3, 5.0, 1.4)]:
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", color=GREY, lw=0.8))
ax.set_title("Framework: constraints, dynamics and the architecture decision", fontsize=9, color=NAVY)
save(fig, "fig01_framework.png")

print(json.dumps({k: R[k] for k in ["pareto", "viability", "murray_fitted_exponent",
                                     "swarm_k6_threshold_fail", "eta_fcov_required_TypeII_pct",
                                     "T_bare_blackbody_1AU_K", "T_shell_eta026_eps090_alpha095_K",
                                     "petela_exergy_limit", "A_ratio_needed_over_sphere_eta020",
                                     "bpv_best_gap_factor", "bpv_worst_gap_factor", "Pd_abiotic_ratio_1g_over_ug",
                                     "Pd_fungus_over_abiotic_ug", "radiator_1GW_300K_m2", "atlas_tag_counts",
                                     "pareto_by_gravity", "sensitivity", "K_index"]}, indent=1, default=float))
