# Biohybrid Infrastructure Viability Across Civilizational Scales

**A thermodynamic–ecological network framework for where living, biomimetic and abiotic engineering belongs, from planetary life support to stellar collector fields**

**Authors.** Devanik Debnath (independent researcher) · Xylia (AI research scientist, multi-agent research system)

**Status.** Preprint v1.0, dated 21 November 2026. Not peer reviewed. Theoretical and computational only. Every number is produced by the formulas, parameter ranges and seeds stated in the companion PDF and its code. No result is a prediction for a living organism, a space mission or a human population.

**Companion artefacts.** `Biohybrid_Infrastructure_Viability_Preprint_v1.0.pdf` (40 pages), `analysis.py` (numerical analysis, deterministic seed `20261121`), `build_pdf.py` (typesets the PDF from `results.json`), `results.json` (machine-readable outputs).

---

## Contents

0. How to read this document
1. Executive summary
2. Notation master table
3. The decision problem, stated formally
4. Framework architecture (six layers and their coupling)
5. Conserved multi-class infrastructure model
6. Capture geometry of collector fields (Kardashev law)
7. Radiative equilibrium of collector shells (with a correction)
8. Control latency of distributed and remote systems
9. Thermodynamic ceilings and reversible work floors
10. Material circularity and the replacement burden
11. Gravity-dependent extraction and the evidence base
12. Transport networks: Murray's law and diffusion-limited biocementation
13. Network robustness of distributed infrastructure
14. Robust viability of a two-channel repair system
15. Architecture comparison: the Pareto analysis and the hybrid region
16. The 110-concept design-space atlas
17. Predictions, status and falsification programme
18. Experimental programme and sample-size theory
19. Planetary protection, containment and ecological escape
20. Design rules
21. Verification, convergence and reproducibility
22. Anticipated objections and responses
23. Limitations
24. Errata and known inconsistencies (read this section)
25. Roadmap
26. Reproduction instructions
27. Worked verification calculations
28. References
29. Glossary
30. Disclosures and citation

---

## 0. How to read this document

### 0.1 Epistemic labels

Every claim carries one of the labels used in the PDF. The label tells you what kind of support it has, not how important it is.

| Label | Meaning | What would falsify it |
|---|---|---|
| **P** | Proved analytically. Proof given in the PDF appendix or re-derived here. | A counterexample to the stated hypotheses. |
| **N** | Numerical result from code with stated seeds and sizes. | Failure to reproduce with the released code. |
| **S** | Stylised. Conditional on declared, chosen parameter ranges. | A parameter range change that flips the qualitative result. |
| **E** | Evidence: reproduced from a published or press-reported measurement. | A primary source that contradicts the reported value. |
| **V** | Verification check against an independent computation. | A discrepancy above the stated tolerance. |
| **A** | Arithmetic on stated constants. | An error in the constants. |
| **C** | Conjecture. Not proved and not tested end to end. | An end-to-end simulation that disagrees. |
| **H** | Hypothesis. Tested in a restricted setting, or untested. | Direct test (see Section 18). |

### 0.2 Equation format used in this README

Every display equation is written as a block that GitHub renders as mathematics. The format is: an opening fence line made of three backticks immediately followed by the word `math`, then the LaTeX lines, then a closing line of three backticks. The language tag must sit on the opening fence line for GitHub to render the block. Inline mathematics uses dollar-sign delimiters, for example $\eta \le 1$.

### 0.3 Reading paths

- **Engineer or planner:** Sections 1, 3, 15, 20, 24.
- **Mathematician or control theorist:** Sections 3, 5, 8, 13, 14, 27.
- **Experimentalist:** Sections 11, 17, 18, 24.
- **Reviewer:** Sections 22, 23, 24, 21.

---

## 1. Executive summary

The paper asks where the functions of future infrastructure should be carried out by living processes, by biomimetic or hybrid engineering, or by abiotic machinery. It treats infrastructure as a conserved resource network with three process classes, imposes material, energy and radiative-heat constraints, and treats damage and repair as a robust viability problem.

**Four results are exact (P).**

1. **Capture-geometry law.** A full- or partial-coverage collector shell at any radius captures at most $\eta f_{\mathrm{cov}} L_\odot$. A Type II flux of $10^{26}$ W therefore requires $\eta f_{\mathrm{cov}} \ge 26.1\%$. The bound does not depend on orbit.
2. **Radiative equilibrium scaling.** The shell temperature scales as $r^{-1/2}$ and falls with extracted power as $(1-\eta)^{1/4}$. *The numerical constant in the PDF's version of this result is affected by a geometry error. See Section 7 and Section 24.*
3. **Murray exponent.** Cost-minimising laminar branching has radius $\propto Q^{1/3}$. Numerically the fitted exponent is 0.3334.
4. **Type III requirement.** Capturing $10^{36}$ W needs about $2.61 \times 10^{9}$ solar luminosities.

**Key numerical results (N, S, E).**

- A robust viability kernel of a two-channel repair system shrinks from 44.8% of admissible states (nominal disturbance) to 24.8% (adversarial, switching controller). Neither single channel is robustly viable at default parameters (S).
- In the stylised architecture model, biological extraction is cheaper in energy than abiotic extraction in 75% of microgravity draws, in 0% of draws at 0.32 g or above, and in 24.8% of draws overall (S, conditional on Table D1 ranges and on the interpolation shape).
- The hybrid architecture wins 37.3% of draws when only mass and energy count, $\lambda = 0$, and 92.3% when failure probability is weighted by $\lambda = 10$ (S). Its median failure probability is lower by a factor of 12.2 (S), paid for in import mass.
- Abiotic palladium release from an L-chondrite falls by a factor of about 13.4 to 13.6 between 1 g and microgravity (E, press-reported). The fungal arm retains about 5.4 to 5.5 times the abiotic microgravity yield (E).

**Corrections identified in preparing this README.** Section 24 lists them in full. The most consequential is that Proposition 2 of the PDF applies a planet-geometry factor (the projected disk is one quarter of the sphere) to a shell that encloses the star. For such a shell the absorbed flux per unit area is not reduced by that factor. The temperature constants change, the scaling laws do not. Other corrections concern a sign convention in the reversible-work table, an inconsistent swarm connectivity threshold, and a formatting artefact in one table.

**What is not claimed.** No stellar-scale structure is shown to be buildable. No biological repair order is shown to extend life. No cost or reliability figure transfers to a real mission. The atlas of 110 concepts is a design space, not a catalogue of validated technologies.

---

## 2. Notation master table

Rates are in units of the single-slot repair rate $\mu = 1$ unless stated. Normalised quantities are relative to the abiotic reference architecture (Section 15).

| Symbol | Meaning | Units / range |
|---|---|---|
| $x(t) \in \mathbb{R}^m_{\ge 0}$ | resource inventory vector (water, carbon, nitrogen, phosphorus, oxygen, minerals, biomass) | kg or normalised |
| $u_B, u_H, u_A$ | process-rate vectors by class: biological, biohybrid, abiotic | s$^{-1}$ (normalised) |
| $S_B, S_H, S_A$ | stoichiometric matrices by class | dimensionless |
| $E$ | external acquisition matrix | dimensionless |
| $f_{\mathrm{ext}}$ | external acquisition rate | normalised |
| $\ell(x,w)$ | losses and leakage under disturbance $w$ | per unit time |
| $D_i, \rho_i, M_i, \lambda_i$ | gross demand, recovery fraction, external replacement, leakage coefficient | kg yr$^{-1}$; $[0,1]$; kg; yr$^{-1}$ |
| $P$ | captured power | W |
| $L_\odot$ | solar luminosity, $3.828 \times 10^{26}$ W | W |
| $f_{\mathrm{cov}}$ | covered fraction of a shell | $[0,1]$ |
| $\eta$ | collector efficiency | $[0,1]$ |
| $S(r)$ | irradiance at radius $r$ | W m$^{-2}$ |
| $r$ | orbital radius | m or AU |
| $\alpha, \varepsilon$ | absorptance, emissivity | $[0,1]$ |
| $\sigma$ | Stefan–Boltzmann constant, $5.670374 \times 10^{-8}$ W m$^{-2}$ K$^{-4}$ | W m$^{-2}$ K$^{-4}$ |
| $T_{\mathrm{sh}}, T_{\mathrm{rad}}, T_{\mathrm{bg}}$ | shell, radiator and background temperatures | K |
| $A_{\mathrm{rad}}, Q_{\mathrm{rej}}$ | radiator area and rejected heat | m$^2$; W |
| $K$ | continuous Kardashev index | dimensionless |
| $d_j, r_j$ | module damage and effective repair | normalised |
| $\kappa$ | admissible set | subset of state space |
| $\mathcal{V}(\kappa)$ | viability kernel | subset of state space |
| $Q, r, \Delta p, \mu$ | volumetric flow, branch radius, pressure drop, viscosity | m$^3$ s$^{-1}$; m; Pa; Pa s |
| $L_G$ | graph Laplacian | matrix |
| $\lambda_2$ | algebraic connectivity (Fiedler value) | dimensionless |
| $\kappa(G)$ | vertex connectivity | integer |
| $\zeta(g)$ | abiotic gravity factor | $[0,1]$ |
| $g$ | gravity in units of Earth gravity | log-scaled |
| $z_{\mathrm{ug}}$ | abiotic microgravity yield factor | $[0.05, 0.50]$ |
| $W, R, F$ | water closure, radiation index, feedstock fraction | $[0,1]$ each |
| $M, E, p$ | import mass, energy per product, failure probability (objectives) | normalised; normalised; $[0,1]$ |
| $J_\lambda$ | scalarised cost $M + E + \lambda p$ | normalised |
| $c_A, c_B, e_{\mathrm{rec}}$ | extraction-energy scales and recovery energies | normalised |
| $\delta$ | hybrid switching overhead | normalised |
| $\Phi_B$ | biological feedstock penalty | normalised |
| $\tau_{\mathrm{rt}}$ | round-trip light time | s |
| $\mathrm{PM}$ | phase margin | rad |
| $T_{\min}$ | minimum control period | s |
| $\omega_c$ | crossover frequency | rad s$^{-1}$ |

---

## 3. The decision problem, stated formally

### 3.1 Motivation

Proposals for large-scale engineering increasingly invoke living systems. Photosynthesis, microbial metabolism, fungal growth and vascular branching are presented as templates for orbital habitats, asteroid processing, solar collection and interstellar infrastructure. Biology does perform energy conversion, self-repair, distributed manufacturing and resource recycling at a scale and efficiency that engineers still struggle to match. The design question is not whether biology is impressive. It is which function should be performed by which kind of system, under which environmental conditions, and at what cost in mass, energy and reliability.

### 3.2 The decision problem

Infrastructure is modelled as a resource network whose process rates are split among three classes: biological (B), biomimetic or biohybrid (H) and abiotic (A). Every class is subject to the same conservation accounting, the same energy budget and the same heat-rejection limit, so that no class gains an advantage by having its waste streams or inputs left out of the balance. Damage accumulates in modules and is repaired by a finite repair machinery. An architecture is viable when damage and resource states can be kept admissible under every disturbance in a specified set.

The architecture question becomes: which allocation of functions to classes is Pareto-efficient in import mass $M$, energy $E$ and failure probability $p$, across the environmental vector $\theta$?

### 3.3 Architectures

Three architectures are compared throughout.

- **A (abiotic):** conventional chemical processing, physical purification, mechanical distribution.
- **B (biological):** microbial processing, biological recycling, photobiological production.
- **C (hybrid):** biological regeneration plus abiotic extraction, synthetic materials and autonomous control.

An architecture $\iota$ assigns each function to a class. An architecture is Pareto-dominated if another is no worse on every objective and strictly better on at least one.

### 3.4 Contributions by epistemic status

- **C1 (P).** Capture-geometry law for any full-coverage collector shell, and Kardashev consequences.
- **C2 (P, corrected).** Radiative equilibrium law for collector shells. See Section 7.
- **C3 (P).** Material circularity identity: recovery of 0.99 still leaves a linearly growing external replacement burden.
- **C4 (P/N).** Proof that cost-minimising branching gives Murray's exponent $1/3$, verified numerically.
- **C5 (N).** A robust viability kernel for a two-channel repair system, showing that adversarial disturbance can remove viability from every single-channel strategy in the stylised model.
- **C6 (S/E).** A three-architecture Pareto analysis conditioned on gravity-dependent extraction, with a failure-weight sweep.

---

## 4. Framework architecture

The framework is a stack of constraint, dynamics and decision layers.

```math
\underbrace{\text{Conservation (Sec. 5)}}_{\text{resource balance}} \;\longrightarrow\; \underbrace{\text{Capture and heat (Sec. 6–8)}}_{\text{physical limits}} \;\longrightarrow\; \underbrace{\text{Damage and repair (Sec. 12–14)}}_{\text{dynamics}} \;\longrightarrow\; \underbrace{\text{Architecture choice (Sec. 15)}}_{\text{decision}}
```

Arrows denote the direction of dependence used in the analysis. Conservation feeds into every class-level process rate. Capture and heat limits bound what any class can supply. Damage and repair determine whether a state remains admissible. The architecture decision combines all three into objectives $M$, $E$ and $p$.

The six technical layers are:

1. **Conservation layer.** Resource inventories, process classes, circularity (Sections 5, 10).
2. **Physical-limit layer.** Capture geometry, radiative equilibrium, latency, thermodynamic floors (Sections 6–9).
3. **Gravity layer.** Gravity dependence of extraction energy, with explicit uncertainty (Section 11).
4. **Transport layer.** Branching networks and diffusion-limited biocementation (Section 12).
5. **Network layer.** Algebraic connectivity under random and targeted loss (Section 13).
6. **Viability and decision layer.** Robust kernels and Pareto analysis (Sections 14, 15).

Conjecture 1 combines these into a single composite statement. It is not tested end to end (see Section 5.5).

---

## 5. Conserved multi-class infrastructure model

### 5.1 Resource network and process classes

Let $x(t) \in \mathbb{R}^m_{\ge 0}$ be the inventory of $m$ resources. Process-rate vectors split into biological, biohybrid and abiotic blocks, $u(t) = (u_B, u_H, u_A)$. The inventory dynamics are

```math
\dot{x}(t) = S_B\, u_B(t) + S_H\, u_H(t) + S_A\, u_A(t) + E\, f_{\mathrm{ext}}(t) - \ell(x, w(t))
```

Here $S_B, S_H, S_A$ map process rates to inventory change, $E f_{\mathrm{ext}}$ is external acquisition, and $\ell(x,w)$ collects losses and leakage under disturbance $w$.

### 5.2 Class-independence principle

This is a bookkeeping rule, not a theorem. For any two process classes producing the same product, the balance must include identical boundary terms: inputs, waste streams, purification energy, and the mass and energy of the reactor or machine that performs the process. A biological process that looks cheap because its waste is excluded is a modelling error. Section 11 applies this rule to the architecture comparison.

### 5.3 Material circularity

For resource $i$ with gross demand $D_i$, recovery fraction $\rho_i$, external replacement $M_i$ and irreversible leakage $\lambda_i X_i$, the replacement obeys

```math
\frac{\mathrm{d}M_i}{\mathrm{d}t} = (1 - \rho_i)\, D_i + \lambda_i X_i
```

A recovery loop that returns 99% of a resource still requires a replacement pathway for the remaining 1%, together with the energy to purify, store and deliver it.

### 5.4 Energy and heat rejection

The energy budget bounds the sum of biological, biohybrid, abiotic and auxiliary power by the available power. Unavoidable waste heat is rejected by radiation. The radiative rejection to a background at temperature $T_{\mathrm{bg}}$ is

```math
Q_{\mathrm{rej}} = \varepsilon \sigma A_{\mathrm{rad}} \left( T_{\mathrm{rad}}^4 - T_{\mathrm{bg}}^4 \right)
```

For a radiator to a cold background ($T_{\mathrm{bg}} \to 0$) this reduces to $Q_{\mathrm{rej}} = \varepsilon\sigma A_{\mathrm{rad}} T_{\mathrm{rad}}^4$. The PDF's radiator estimate uses this one-sided form.

### 5.5 Damage, repair and viability

Module damage $d_j$ grows with environmental load $\lambda_j(w)$ and is reduced by effective repair $r_j(x,u)$. Let $s = (x, d)$ denote the full state and $\kappa$ a closed admissible set. The control system is $\dot{s} = f(s, u, w)$, with control $u$ and disturbance $w$.

The **backward (robust) operator** is

```math
\mathcal{F}_{\mathrm{rob}}(K) = \left\{ s \in \kappa \;:\; \exists\, u \;\; \forall\, w \;\; f(s,u,w) \in K \right\}
```

The **robust viability kernel** is the largest set $\mathcal{V}(\kappa)$ obtained by iteration

```math
K_0 = \kappa, \qquad K_{n+1} = K_n \cap \mathcal{F}_{\mathrm{rob}}(K_n), \qquad \mathcal{V}(\kappa) = \lim_{n\to\infty} K_n
```

The iteration stops at a fixed point. On a finite grid the sequence is monotone decreasing and therefore terminates.

**Conjecture 1 (composite viability, C).** An infrastructure is viable when its state remains in $\kappa$ under all disturbances in a compact set. A biohybrid architecture is viable only if its robust kernel contains the initial state. This is not tested as one end-to-end simulation. Its components are tested in Sections 6–15.

---

## 6. Capture geometry of collector fields

### 6.1 The capture-geometry law

Let a collector field cover fraction $f_{\mathrm{cov}}$ of a spherical shell at radius $r$ around a central star of luminosity $L_\odot$. Irradiance at that radius is

```math
S(r) = \frac{L_\odot}{4\pi r^2}
```

The total luminosity crossing any closed surface that encloses the star is $L_\odot$, whatever its radius. A covered fraction $f_{\mathrm{cov}}$ of that surface therefore intercepts at most $f_{\mathrm{cov}} L_\odot$. With collector efficiency $\eta$, captured power is

```math
P = \eta\, f_{\mathrm{cov}}\, L_\odot
```

The radius cancels because the surface area scales as $r^2$ while irradiance scales as $r^{-2}$.

**Proposition 1 (capture-geometry law, P).** No full- or partial-coverage shell at any radius captures more than $\eta f_{\mathrm{cov}} L_\odot$. For a Type II flux $P = 10^{26}$ W,

```math
\eta f_{\mathrm{cov}} \ge \frac{P}{L_\odot} = \frac{10^{26}}{3.828 \times 10^{26}} \approx 0.2612
```

so the product must be at least 26.1%. No orbit relaxes this.

*Proof sketch.* Captured power is $\eta$ times the integral of incident flux over covered elements. Incident flux integrated over the full enclosing surface equals $L_\odot$. The covered fraction of that surface is at most $f_{\mathrm{cov}}$, so the captured power is at most $\eta f_{\mathrm{cov}} L_\odot$. Equality holds when all interceptable sunlight is converted over the covered fraction. $\blacksquare$

### 6.2 Consequences

Two consequences follow. A Type II collector requires either an efficiency–coverage product above roughly one quarter or a power source other than the Sun. A Type III flux of $10^{36}$ W corresponds to

```math
\frac{10^{36}}{3.828 \times 10^{26}} \approx 2.61 \times 10^{9}\ L_\odot
```

which is a galactic-scale requirement not satisfied by any collector around one star.

### 6.3 The continuous Kardashev index

The Sagan continuous index used in the paper is

```math
K = \frac{\log_{10} P - 6}{10}
```

Humanity's present power of about $1.9 \times 10^{13}$ W gives $K = (13.28 - 6)/10 \approx 0.73$. Type I, II and III correspond to $K = 1, 2, 3$ at $10^{16}$, $10^{26}$ and $10^{36}$ W. The bands above $K = 3$ are the paper's extrapolations and are not standard Kardashev categories. The Kardashev scale itself is defined by power, and it has no standard definition beyond Type III.

### 6.4 Area and mass of a one-AU shell

At 1 AU the solar constant is $S_0 = 1361.2$ W m$^{-2}$. A Type II field with $\eta = 0.20$ needs collector area

```math
A = \frac{P}{\eta S_0} = \frac{10^{26}}{0.20 \times 1361.2} \approx 3.67 \times 10^{23}\ \mathrm{m}^2
```

A full 1 AU sphere has area $4\pi (1.496\times 10^{11})^2 \approx 2.81 \times 10^{23}$ m$^2$. The required collector area is $1.31$ times the sphere. Efficiency 0.20 therefore cannot close the Type II requirement with one shell at that radius, consistent with Proposition 1.

The mass of a full shell is $m = \rho_A \cdot 4\pi r^2$, where $\rho_A$ is areal density.

| Areal density (kg m$^{-2}$) | Shell mass (kg) | Fraction of Mercury | Fraction of Earth |
|---|---|---|---|
| 0.1 | $2.81\times10^{22}$ | 0.085 | 0.0047 |
| 1.0 | $2.81\times10^{23}$ | 0.852 | 0.0471 |
| 10.0 | $2.81\times10^{24}$ | 8.520 | 0.4709 |

Reference masses: Mercury $3.30\times10^{23}$ kg, Earth $5.97\times10^{24}$ kg. Areal density is the dominant design variable, which supports a distributed-swarm interpretation over a single rigid shell.

### 6.5 Growth arithmetic

For constant exponential growth of power at rate $g$ per year from $P_0$, the time to reach $P$ is

```math
t = \frac{\ln(P/P_0)}{\ln(1+g)}
```

From $P_0 = 1.9\times10^{13}$ W, reaching $K = 2$ ($10^{26}$ W) at $g = 1\%$ per year takes about 2,944 years. This is arithmetic on a stated power, not a forecast. Constant growth cannot persist indefinitely, so the table is a bound on how the scenarios could be spaced in time.

| Growth rate | To $K=1$ | To $K=2$ | To $K=3$ |
|---|---|---|---|
| 0.5% | 1,256 yr | 5,873 yr | 10,490 yr |
| 1.0% | 630 yr | 2,944 yr | 5,258 yr |
| 2.0% | 316 yr | 1,479 yr | 2,642 yr |
| 3.0% | 212 yr | 991 yr | 1,770 yr |

---

## 7. Radiative equilibrium of collector shells (with a correction)

### 7.1 What the PDF states

The PDF states that for a uniform isothermal collector shell, absorbed power per unit area is $\alpha S(r)(1-\eta)/4$ and that emission is $\varepsilon\sigma T^4$ per unit area. Equating these gives

```math
\alpha\, \frac{L_\odot (1-\eta)}{16\pi r^2} = \varepsilon \sigma T_{\mathrm{sh}}^4
\quad\Longrightarrow\quad
T_{\mathrm{sh}} = \left[ \frac{\alpha (1-\eta) L_\odot}{16 \pi \varepsilon \sigma r^2} \right]^{1/4}
```

The PDF's justification for the factor $1/4$ is that "the projected disk is one quarter of the sphere."

### 7.2 Why this factor applies to a planet, not to an enclosing shell

The factor $1/4$ is correct for a **body** illuminated by a distant source, such as a planet. Such a body intercepts sunlight over its projected disk, $\pi R^2$, while emitting over its full surface, $4\pi R^2$. The ratio is $1/4$.

A collector **shell that encloses the star** is different. Every surface element of the inner face of the shell faces the star. The shell intercepts the full irradiance $S(r)$ over its entire area, not over one quarter of it. The absorbed power per unit area is therefore

```math
q_{\mathrm{abs}} = \alpha\, S(r)\,(1-\eta) = \alpha\, \frac{L_\odot (1-\eta)}{4\pi r^2}
```

with no factor $1/4$. The emitted power per unit area is $n\,\varepsilon\sigma T^4$, where $n = 1$ if only one face radiates and $n = 2$ if both faces radiate to space. Hence

```math
T_{\mathrm{sh}} = \left[ \frac{\alpha (1-\eta) L_\odot}{4\pi n\, \varepsilon \sigma r^2} \right]^{1/4}
```

### 7.3 Corrected numerical values

These are recomputed here from the stated constants. They are arithmetic (A) on the corrected formula, not a new simulation.

| Case | PDF value | Corrected, $n=1$ | Corrected, $n=2$ |
|---|---|---|---|
| Bare black body at 1 AU, $\eta=0$, $\alpha=\varepsilon=1$ | 278.3 K | 393.6 K | 331.1 K |
| $\eta=0.26$, $\alpha=0.95$, $\varepsilon=0.90$ | 261.7 K | ≈ 370 K | ≈ 311 K |

The PDF's 278.3 K value is the planet-like result: it is the equilibrium temperature of an Earth-like sphere at 1 AU. The scaling laws are unaffected. Both forms give $T \propto r^{-1/2}$ and $T \propto (1-\eta)^{1/4}$, because the correction changes only the numerical constant. Relative to the PDF's value, the temperature is multiplied by $(4/n)^{1/4}$: by $4^{1/4} \approx 1.414$ for one face and by $2^{1/4} \approx 1.189$ for two faces.

**Status.** Proposition 2 should be read as P for the scaling laws, and as a corrected A for the constants above. The claim "Four results are exact" in the abstract depends on this correction.

### 7.4 Radiator area

For a one-sided ideal radiator with heat load $Q$ and background at $T_{\mathrm{bg}}$,

```math
A_{\mathrm{rad}} = \frac{Q}{\varepsilon \sigma \left( T_{\mathrm{rad}}^4 - T_{\mathrm{bg}}^4 \right)}
```

For a 1 GW waste-heat load at $T = 300$ K and $\varepsilon = 0.9$, with $T_{\mathrm{bg}} \to 0$:

```math
A_{\mathrm{rad}} = \frac{10^9}{0.9 \times 5.670374\times10^{-8} \times 300^4} \approx 2.42 \times 10^{6}\ \mathrm{m}^2
```

Biological reactors at roughly 300 K therefore need radiators of the same order as abiotic reactors of equal thermal load. Biology does not reduce this burden, because its thermal output is set by the same energy balance. This conclusion (design rule D2) is unaffected by the correction in Section 7.2.

---

## 8. Control latency of distributed and remote systems

### 8.1 Light time

The round-trip light time between a controller and a unit at distance $d$ is

```math
\tau_{\mathrm{rt}} = \frac{2d}{c}
```

with $c = 2.998\times10^{8}$ m s$^{-1}$. At 1 AU the one-way time is 499 s, about 8.3 min, and the round trip is about 16.6 min.

### 8.2 Delay margin

For a linear loop with crossover frequency $\omega_c$ and phase margin $\mathrm{PM}$, the largest tolerable loop delay is the delay margin

```math
\tau_{\mathrm{m}} = \frac{\mathrm{PM}}{\omega_c}
```

Requiring the round-trip delay to lie within the margin, $\tau_{\mathrm{rt}} < \mathrm{PM}/\omega_c$, is equivalent to $\omega_c < \mathrm{PM}/\tau_{\mathrm{rt}}$.

**Proposition 6 (latency bound, P).** Under the delay-margin condition, any centralised feedback loop with round-trip delay $\tau_{\mathrm{rt}}$ designed for phase margin $\mathrm{PM}$ has minimum sampling period

```math
T_{\min} = \frac{2\pi\, \tau_{\mathrm{rt}}}{\mathrm{PM}}
```

*Proof.* The shortest sampling period compatible with crossover $\omega_c$ is $2\pi/\omega_c$. Stability with delay requires $\omega_c < \mathrm{PM}/\tau_{\mathrm{rt}}$. Substituting gives $T_{\min} > 2\pi\tau_{\mathrm{rt}}/\mathrm{PM}$. $\blacksquare$

With the conventional target $\mathrm{PM} = \pi/3$, the bound becomes $T_{\min} = 6\tau_{\mathrm{rt}}$.

| Distance | One-way light time | Round trip $\tau_{\mathrm{rt}}$ | Minimum control period $6\tau_{\mathrm{rt}}$ |
|---|---|---|---|
| 0.1 AU | 0.8 min | 1.7 min | 10.0 min |
| 1 AU | 8.3 min | 16.6 min | 1.66 h |
| 5 AU | 41.6 min | 1.39 h | 8.32 h |
| 30 AU | 4.16 h | 8.32 h | 2.1 d |
| Proxima Centauri (4.245 ly) | 4.2 yr | 8.5 yr | 51.0 yr |

**Design consequence (D6).** Beyond about 0.1 AU, autonomy at the unit or cluster level is a requirement, not an option. This is the reason the swarm analysis of Section 13 assumes local feedback.

---

## 9. Thermodynamic ceilings and reversible work floors

### 9.1 Solar exergy (Petela limit)

The maximum fraction of incident solar radiation energy convertible to work, for a black-body sun at $T_s$ and an environment at $T_0$, is

```math
\eta_{\mathrm{Petela}} = 1 - \frac{4}{3}\frac{T_0}{T_s} + \frac{1}{3}\left(\frac{T_0}{T_s}\right)^4
```

With $T_s = 5772$ K and $T_0 = 300$ K, $T_0/T_s = 0.05198$ and $\eta_{\mathrm{Petela}} = 0.9307$. This ceiling applies to any solar converter, biological or abiotic.

### 9.2 Photosynthetic ceiling

The theoretical maximum solar-to-biomass efficiency of C3 photosynthesis under full sunlight, from the stoichiometry and quantum requirements of carbon fixation, is about 4.6% (Zhu, Long and Ort, 2008). Real photosynthetic systems are substantially lower, and photobioreactors inherit the same order of limitation.

### 9.3 Photovoltaic ceiling and the biophotovoltaic gap

The Shockley–Queisser detailed-balance limit for a single-junction cell is 33.7%. At 20% efficiency and the incident flux at 1 AU, ideal photovoltaic output is

```math
P_{\mathrm{PV}} = 0.20 \times 1361.2\ \mathrm{W\,m^{-2}} = 2.72\times10^{2}\ \mathrm{W\,m^{-2}} = 2.72\times10^{5}\ \mathrm{mW\,m^{-2}}
```

The reported whole-cell biophotovoltaic range (Qi et al., 2024) is $10^{-4}$ to $10^{3}$ mW m$^{-2}$. The gap factors are

```math
\frac{2.72\times10^{5}}{10^{3}} \approx 272 \qquad\text{and}\qquad \frac{2.72\times10^{5}}{10^{-4}} \approx 2.7\times10^{9}
```

**Status (E, A).** The biohybrid photovoltaic gap is not a matter of marginal optimisation. The plausible role for biohybrid photosynthesis is chemical production, where the figure of merit is product per unit area and energy, not electrical power.

### 9.4 Reversible work floors

The reversible work of a reaction is the change in standard Gibbs energy. It sets a floor for any process producing the same product from the same reactants, independent of route. Per kilogram of product,

```math
W_{\min} = \frac{\Delta_r G^\circ}{M_{\mathrm{product}}}
```

where $M_{\mathrm{product}}$ is molar mass per mole of product as written in the stoichiometric reaction. For hydrogen, $\Delta G^\circ = 237.1$ kJ per mole of H$_2$ with molar mass 2.016 g mol$^{-1}$, giving

```math
W_{\min}(\mathrm{H_2}) = \frac{237.1\ \mathrm{kJ}}{2.016\ \mathrm{g}} \approx 117.6\ \mathrm{MJ\,kg^{-1}} \approx 32.7\ \mathrm{kWh\,kg^{-1}}
```

For glucose, $\Delta G^\circ = 2879.0$ kJ per mole with molar mass 180.16 g mol$^{-1}$, giving about 15.98 MJ kg$^{-1}$ (4.44 kWh kg$^{-1}$). For oxygen, 474.2 kJ per mole of O$_2$ with molar mass 32.00 g mol$^{-1}$ gives about 14.8 MJ kg$^{-1}$.

**Sign convention (corrected, see Section 24).** The reversible work *required* to produce these products from their reactants is positive. The PDF's Table 5a lists some values with negative signs. The magnitudes are correct. The signs should read: input work positive for CH$_4$ and glucose, since those reactions are endergonic.

**Consequence.** The floor is route-independent. Biology changes the form of the input energy (photons rather than electricity), the kinetic path and the selectivity, not the thermodynamic minimum. Any living oxygen source must be compared with 14.8 MJ kg$^{-1}$ on energy, not on mass alone.

---

## 10. Material circularity and the replacement burden

### 10.1 Constant-coefficient solution

Proposition 3 (linear replacement burden, P). For constant $D$, $\rho$ and leakage $\lambda X$, the cumulative replacement with $M(0) = 0$ is

```math
M(t) = \left[ (1-\rho) D + \lambda X \right] t
```

Its sensitivity to recovery is

```math
\frac{\partial M}{\partial \rho} = -D\, t
```

which does not depend on the level of $\rho$.

*Proof.* Integrate the replacement equation of Section 5.3 with constant right-hand side. Differentiate with respect to $\rho$. $\blacksquare$

### 10.2 Interpretation

Each additional nine of recovery reduces the replacement burden by the same absolute amount per unit time. The economic value of that reduction, however, depends on the cost of the marginal nine, which rises steeply as $\rho \to 1$. A recovery system is worth improving only while the marginal cost of recovery is below the replacement cost of the unrecovered material. This is a control-theoretic optimum, not a closure target. Design rule D4 follows.

### 10.3 Crew water budget

For a four-person crew at 2.50 kg per person per day, the annual gross demand is $D = 4 \times 2.50 \times 365 = 3{,}650$ kg. Replacement under recovery $\rho$ with no leakage is $(1-\rho) D$.

| Recovery $\rho$ | Replacement per year (kg) | Replacement over 20 years (kg) | Fraction of annual demand |
|---|---|---|---|
| 0.90 | 365.0 | 7,300 | 10.0% |
| 0.95 | 182.5 | 3,650 | 5.0% |
| 0.98 | 73.0 | 1,460 | 2.0% |
| 0.99 | 36.5 | 730 | 1.0% |
| 0.999 | 3.7 | 73 | 0.1% |

Moving from 98% to 99.9% recovery reduces annual replacement from 73 kg to under 4 kg for this crew. Whether that justifies the extra purification, energy and hardware is a marginal-cost question, answered in Section 15.

---

## 11. Gravity-dependent extraction and the evidence base

### 11.1 The BioAsteroid anchor (E)

The BioAsteroid experiment on the International Space Station (Santomartino et al., 2026) tested bacterial (*Sphingomonas desiccabilis*), fungal (*Penicillium simplicissimum*) and mixed-consortium leaching of an L-chondrite meteorite, under microgravity and under matched 1 g controls. The palladium values used here are taken from press coverage that quotes the paper, and must be re-checked against the primary publication.

| Quantity | Reported value | Derived ratio | Note |
|---|---|---|---|
| Abiotic Pd release at 1 g | 29.5% of metal present | | |
| Abiotic Pd release in microgravity | 2.2% | | |
| Abiotic gravity penalty | 13.6 (reported) | $29.5/2.2 = 13.4$ | Rounding of reported means gives 13.4 |
| Fungal Pd release in microgravity | 11.9% | | |
| Fungal / abiotic ratio in microgravity | 5.5 (reported) | $11.9/2.2 = 5.4$ | Fungal yield does not fall as abiotic yield does |

Two limits constrain inference. The experiment compares microgravity with 1 g only. No partial-gravity arm (lunar 0.16 g, Martian 0.38 g) is reported in the sources retrieved, so the gravity dependence between those points is unknown. Variability is large, and the consortium result differs from the fungal result, so one organism and one substrate cannot establish a general rule.

### 11.2 Gravity model with an explicit interval (S)

Define the abiotic gravity factor $\zeta(g)$ to equal the microgravity yield $z_{\mathrm{ug}}$ at in-orbit gravity and to rise to 1 at Martian gravity, interpolating log-linearly in $g$ between the anchors $g_\mu = 10^{-6}$ and $g_M = 0.38$. The paper's exact typeset form is Eq. (17) and the code is authoritative. The structure is

```math
\zeta(g) =
\begin{cases}
z_{\mathrm{ug}}, & g \le g_\mu \\[4pt]
z_{\mathrm{ug}} + (1 - z_{\mathrm{ug}})\, \dfrac{\log_{10} g - \log_{10} g_\mu}{\log_{10} g_M - \log_{10} g_\mu}, & g_\mu < g < g_M \\[4pt]
1, & g \ge g_M
\end{cases}
```

The microgravity yield $z_{\mathrm{ug}}$ is an uncertain parameter drawn uniformly over $[0.05, 0.50]$. This interval brackets the reported value of about 0.075. The interpolation shape is an assumption, not a fit.

Under this model the energy cost of abiotic extraction is $c_A / \zeta(g)$, while the biological cost $c_B$ is treated as gravity-independent. The gravity-independence of biology is supported only by the observation that the fungal arm was not penalised in this experiment. It is the single most important assumption to test.

### 11.3 Test of the gravity hypothesis

Biological extraction is cheaper in energy than abiotic extraction for the following shares of draws (Table 4, S, conditional on Table D1 and on the log-linear interpolation).

| Gravity bin ($\log_{10} g$) | Share of draws, biological cheaper | Interpretation |
|---|---|---|
| $< -5.5$ | 74.6% | orbital microgravity |
| $-5.5$ to $-4$ | 52.1% | microgravity, weaker |
| $-4$ to $-2.5$ | 18.9% | low gravity |
| $-2.5$ to $-1$ | 3.3% | partial gravity, lower end |
| $-1$ to $-0.5$ | 0.1% | partial gravity, lunar range |
| $> -0.5$ | 0.0% | Mars and Earth gravity |

The overall share across all draws is 24.8%. The pattern is a threshold phenomenon. Biological extraction is cheaper for most microgravity draws, for a substantial minority at intermediate low gravity, and for no draws at 0.32 g or above. The last result follows from the parameter ranges, since biological cost then exceeds abiotic cost. The location of the threshold between $10^{-4}$ and 0.1 g is set by the interpolation and prior ranges, not by data.

### 11.4 Sensitivity to interpolation shape (S)

| Gravity bin | Log-linear (main) | Linear in $g$ | Step at $10^{-3}$ g |
|---|---|---|---|
| $< -5.5$ | 74.6% | 79.3% | 79.3% |
| $-5.5$ to $-4$ | 52.1% | 80.5% | 80.5% |
| $-4$ to $-2.5$ | 18.9% | 80.5% | 55.1% |
| $-2.5$ to $-1$ | 3.3% | 72.6% | 0.0% |
| $-1$ to $-0.5$ | 0.1% | 20.3% | 0.0% |
| $> -0.5$ | 0.0% | 0.0% | 0.0% |
| All draws | 24.8% | 66.7% | 40.6% |

The result separates into a robust part and a fragile part. The endpoints are robust: biological extraction is cheaper in microgravity under all three shapes (75% to 79%), and never at 0.32 g or above. The transition is fragile. The overall share ranges from 25% to 67% across shapes, and the share in the 0.1 to 0.32 g bin ranges from near zero to about 20%. The present evidence does not identify where the threshold lies. This is the strongest reason to prioritise the partial-gravity experiment (Section 18).

### 11.5 Thermodynamic and cost interpretation

Biological extraction is energetically expensive in this parameterisation ($c_B \ge 1.5$ in normalised units) and carries feedstock and hardware penalties. It can therefore only win where abiotic extraction is costly and those penalties are small. The gravity dependence of abiotic yield is the mechanism that creates that window.

---

## 12. Transport networks, branching and structural materials

### 12.1 Murray's law as a cost optimum

Consider a single channel of radius $r$ carrying flow $Q$. Pumping cost scales as $Q^2/r^4$ by Poiseuille's law, and maintenance cost scales as the volume $r^2$. The cost per unit length is

```math
f(r) = a\, \frac{Q^2}{r^4} + b\, r^2
```

with constants $a, b > 0$. Setting the derivative to zero,

```math
\frac{\partial f}{\partial r} = -\frac{4aQ^2}{r^5} + 2br = 0 \quad\Longrightarrow\quad r^6 = \frac{2aQ^2}{b}
```

**Proposition 4 (Murray exponent, P).** The optimal radius is

```math
r^* = \left(\frac{2a}{b}\right)^{1/6} Q^{1/3}
```

so $r^* \propto Q^{1/3}$. For a symmetric bifurcation with flow conservation $Q_0 = 2Q_1$, this gives $r_0^3 = 2 r_1^3$. Numerically, minimising the cost over a log-spaced grid of flows gives a fitted exponent of 0.3334 against the theoretical $1/3$ (N).

**Asymmetric form (P).** For any split $Q_0 = Q_1 + Q_2$, with each segment at its own optimum and the shared constant $\kappa = (2a/b)^{1/6}$,

```math
r_0^3 = r_1^3 + r_2^3
```

This holds for any flow split, which is why the cube law appears in biological and engineered manifolds alike.

**Design consequence.** Poiseuille's law gives $\Delta p \propto 1/r^4$ at fixed flow. Halving a branch radius therefore multiplies pressure drop by $2^4 = 16$. Vascular-inspired designs in the atlas (concepts 7, 42, 61, 76, 108) inherit this constraint.

### 12.2 Mycelium and biomineral materials (structure, not calibration)

For mycelium composites, a homogenised model writes effective modulus as a power law in the load-bearing solid fraction $\phi$,

```math
E_{\mathrm{eff}} = E_0\, \phi^{n}
```

with constants $E_0, n$ calibrated experimentally. For biomineralised regolith, bond strength is controlled by the precipitated mass per unit feedstock. Neither relation has been calibrated for planetary simulants in the sources consulted, so the structure is recorded and not the values. Mycelium composites are candidates for insulation, acoustic panels and interior partitions. Biomineralised regolith is a candidate for dust binding in non-primary structure. Neither should be used for primary pressure hulls or dense radiation shielding, whose limits are set by stress, fatigue and particle transport.

### 12.3 Diffusion-limited biocementation depth (P, N)

A stylised substrate $c$, held at a boundary, is consumed by biomass $X$ that grows logistically and precipitates mineral in proportion to consumption. For diffusion alone, with a fixed boundary concentration of 1 and no consumption, the solution of $\partial_t c = D\,\partial_{xx} c$ is the similarity solution

```math
c(x,t) = \operatorname{erfc}\!\left(\frac{x}{2\sqrt{Dt}}\right)
```

**Proposition 7 (diffusion-limited depth, P).** The depth at which $c$ reaches a threshold $c^*$ is

```math
x^*(t) = 2\, \operatorname{erfc}^{-1}(c^*)\, \sqrt{Dt}
```

so the time to reach a depth $L$ is

```math
t_L = \frac{L^2}{4\,[\operatorname{erfc}^{-1}(c^*)]^2\, D}
```

*Proof.* Set $\operatorname{erfc}(x/(2\sqrt{Dt})) = c^*$ and solve for $x$. $\blacksquare$

For $c^* = 0.05$, $\operatorname{erfc}^{-1}(0.05) = 1.3859$, so the prefactor is $2.772$.

**Measured front (N).** The simulated front has log–log slope 0.422 and prefactor 2.234, below the pure-diffusion values (0.5 and 2.772). Consumption retards the front. The time to 10 cm from theory at $D = 10^{-9}$ m$^2$ s$^{-1}$ is

```math
t_{10\,\mathrm{cm}} = \frac{(0.10)^2}{4 \times 1.9207 \times 10^{-9}} \approx 1.30\times10^{6}\ \mathrm{s} \approx 15.1\ \mathrm{d}
```

which is a lower bound because consumption slows the front. Depth grows as the square root of time, so doubling depth quadruples time. Engineered biocement must therefore rely on forced transport or thin sections, and a plant's production rate is set by diffusion time, not by microbial growth rate.

---

## 13. Network robustness of distributed infrastructure

### 13.1 Algebraic connectivity

For a graph $G$ with Laplacian $L_G = D - A$, the algebraic connectivity $\lambda_2$ is the second-smallest eigenvalue. It is zero if and only if $G$ is disconnected, and Fiedler's inequality bounds it by the vertex connectivity:

```math
0 \le \lambda_2(L_G) \le \kappa(G)
```

for non-complete graphs. Consensus dynamics on the graph,

```math
\dot{y} = -L_G\, y + B\, u,
```

converge at a rate governed by $\lambda_2$ under standard assumptions (Olfati-Saber, Fax and Murray, 2007).

### 13.2 Random-loss experiment (N)

A random-geometric swarm of $N = 300$ units is placed uniformly in the unit square, each connected to its $k$ nearest neighbours and symmetrised, for $k \in \{4, 6, 8\}$. Units are removed uniformly at random. Each cell uses 25 trials.

| Units lost | $P(\text{connected})$, $k=4$ | $k=6$ | $k=8$ |
|---|---|---|---|
| 0.00 | 0.92 | 1.00 | 1.00 |
| 0.10 | 0.64 | 0.96 | 1.00 |
| 0.20 | 0.12 | 0.92 | 1.00 |
| 0.30 | 0.00 | 0.60 | 1.00 |
| 0.40 | 0.00 | 0.16 | 0.64 |
| 0.50 | 0.00 | 0.00 | 0.36 |
| 0.60 | 0.00 | 0.00 | 0.00 |

The probability falls below 0.5 near a loss fraction of 0.15 for $k = 4$, 0.30 to 0.35 for $k = 6$, and about 0.50 for $k = 8$. The threshold rises with local degree. Denser local wiring buys robustness at the cost of communication bandwidth and collision risk. (For $k=6$ the threshold is reported as 0.35 in Table 5 and as 0.30 in Table 9b. See Section 24.)

### 13.3 Targeted hub-first loss (N)

Hub-first loss removes the most connected units first. At $k = 6$, with the same 25 trials:

| Units lost | $P(\text{conn})$ random | $P(\text{conn})$ hub-first | $\lambda_2$ random | $\lambda_2$ hub-first |
|---|---|---|---|---|
| 0.00 | 1.00 | 1.00 | 0.049 | 0.049 |
| 0.10 | 0.92 | 0.92 | 0.033 | 0.036 |
| 0.20 | 1.00 | 0.88 | 0.025 | 0.021 |
| 0.30 | 0.48 | 0.04 | 0.008 | 0.000 |
| 0.35 | 0.32 | 0.00 | 0.005 | $-0.000$ |
| 0.40 | 0.12 | 0.00 | 0.001 | $-0.000$ |

Hub-first loss is more damaging. The connectivity threshold falls from about 0.30 to about 0.25, and $\lambda_2$ collapses to zero at a lower loss fraction. Any swarm concept relying on a central relay, a shared power bus or a single maintenance hub must state robustness under targeted loss, not only random loss.

**Design consequence (D7).** Choose the local wiring degree from the target loss fraction. Under random loss, degree 6 crosses 50% connectivity near a loss fraction of 0.30 to 0.35. Under hub-first loss the crossing is lower.

---

## 14. Robust viability of a two-channel repair system

### 14.1 Setting

Repair is carried out by a biological channel, which is slow but resource-cheap, or by an abiotic channel, which is fast but consumes resource. The question is whether one channel, used alone, can keep the system admissible under adversarial disturbance.

The stylised state is $s = (x, d)$, where $x \in [0,1]$ is an available resource stock and $d \in [0,1]$ is accumulated damage. The admissible set is

```math
\kappa = \{ (x,d) \;:\; x \ge 0.25,\; d \le 0.60 \}
```

The control $u \in \{\mathrm{bio}, \mathrm{abiotic}\}$ sets resource cost $c_u$ and repair rate $r_u$. The disturbance $w \in \{\mathrm{nominal}, \mathrm{adversarial}\}$ sets additional damage $\delta_w$ and resource loss $\omega_w$. The robust kernel is computed by iterating the backward operator of Section 5.5 on a $161 \times 161$ grid.

### 14.2 Parameters (S)

| Parameter | Value |
|---|---|
| Grid | $161 \times 161$ on $[0,1]^2$ |
| Production rate $p$ | 0.10 |
| Biological channel: cost, repair rate | 0.020, 0.10 |
| Abiotic channel: cost, repair rate | 0.080, 0.22 |
| Nominal disturbance: damage, resource loss | $+0.04$, 0 |
| Adversarial disturbance: damage, resource loss | $+0.12$, 0.03 |
| Repair scaling | $(0.4 + 0.6x)$ |

The exact one-step update is in `analysis.py` (Algorithm G1) and is the reference. Qualitatively, the abiotic channel is resource-hungry and fast, the biological channel is slow and cheap, and damage accumulates unless repaired. The admissible set and the parameters above fully specify the computation.

### 14.3 Results (S, N)

| Strategy | Kernel fraction of admissible set | Interpretation |
|---|---|---|
| Nominal disturbance, both channels | 44.8% | Nominal viability is trivial here. |
| Adversarial, both channels (switching) | 24.8% | Viability requires state-dependent switching. |
| Adversarial, biological only | 0.0% | Damage accumulates faster than biological repair removes it. |
| Adversarial, abiotic only | 0.0% | Resource is consumed faster than production replenishes it. |

**Proposition 5 (monotonicity, P).** The robust kernel is contained in the nominal kernel. Taking the intersection over a larger disturbance set can only remove states. The robust operator is dominated by the nominal operator at every iteration, so the nested iterates satisfy $K^{\mathrm{rob}}_n \subseteq K^{\mathrm{nom}}_n$.

The switching kernel is a subset of the nominal kernel (verified, V). Iteration converged in 56 steps.

Of the switching kernel, 18.5% lies at damage above 0.40, where the controller must rely on the faster abiotic channel. The magnitude of the switching gain depends on the chosen dynamics and is not a prediction. The structural statement, that a robust biohybrid controller can be strictly better than either pure strategy, is the part that transfers to any system with the same channel structure.

### 14.4 Dependence on adversary strength and production (S)

| Setting | Switching | Biological only | Abiotic only | Switching gain |
|---|---|---|---|---|
| $\delta_{\mathrm{adv}} = 0.04$, $p=0.10$ | 44.7% | 44.7% | 0.0% | 0.0 pp |
| $\delta_{\mathrm{adv}} = 0.08$, $p=0.10$ | 40.1% | 33.9% | 0.0% | +6.2 pp |
| $\delta_{\mathrm{adv}} = 0.12$, $p=0.10$ | 24.8% | 0.0% | 0.0% | +24.8 pp |
| $\delta_{\mathrm{adv}} = 0.16$, $p=0.10$ | 7.0% | 0.0% | 0.0% | +7.0 pp |
| $\delta_{\mathrm{adv}} = 0.20$, $p=0.10$ | 0.0% | 0.0% | 0.0% | 0.0 pp |
| $p = 0.06$, $\delta_{\mathrm{adv}}=0.12$ | 0.0% | 0.0% | 0.0% | 0.0 pp |
| $p = 0.08$, $\delta_{\mathrm{adv}}=0.12$ | 13.2% | 0.0% | 0.0% | +13.2 pp |
| $p = 0.10$, $\delta_{\mathrm{adv}}=0.12$ | 24.8% | 0.0% | 0.0% | +24.8 pp |
| $p = 0.12$, $\delta_{\mathrm{adv}}=0.12$ | 32.7% | 0.0% | 32.7% | 0.0 pp |
| $p = 0.14$, $\delta_{\mathrm{adv}}=0.12$ | 37.6% | 0.0% | 37.6% | 0.0 pp |

Three regimes appear. For weak adversaries the biological channel alone attains the switching kernel, so switching adds nothing. For intermediate adversaries switching is strictly better than either channel. For strong adversaries no strategy among these is robustly viable. The production sweep shows that at $p = 0.12$ the abiotic channel alone matches the switching controller. The value of a second channel depends on which constraint binds, damage or resource.

**Design consequence (D5).** Use at least two repair channels, selected by the binding constraint.

---

## 15. Architecture comparison and the hybrid region

### 15.1 Objectives (S)

The architecture analysis is a stylised, normalised decision model. Its purpose is to make the structure of the trade-off explicit and to test where conclusions depend on assumptions, not to predict absolute cost.

Each architecture produces one unit of product per year. Costs are normalised so that the abiotic extraction energy at 1 g equals $c_A$. The three objectives are minimised.

- **Import mass.** Abiotic architecture carries its own hardware $m_A$. Biological architecture carries $m_B$ and feedstock penalty. The hybrid carries both sets of hardware, because two production lines must be carried:

```math
M_C = m_A + m_B
```

- **Energy.** The hybrid takes the cheaper extraction route at each draw, pays a switching overhead $\delta$, and runs biological recovery actively while keeping abiotic recovery on standby at 10% energy. Energy per product is therefore of the form

```math
E_C = \min\!\left( \frac{c_A}{\zeta(g)},\, c_B \right) + \delta + \text{recovery terms}
```

where the recovery terms are as set out in the PDF's Section 11.1 (Eqs. 22–25).

- **Failure probability.** The hybrid fails only when both channels fail, which is the redundancy assumption under independence:

```math
p_C = p_A\, p_B
```

Environmental variables enter through $\zeta(g)$, water closure $W$, radiation $R$ and feedstock $F$. Table D1 in the PDF gives the sampled ranges.

### 15.2 Structural fact: the hybrid is never dominated on failure

Because $p_C = p_A p_B$ is at most the smaller of the two single-channel failure probabilities, the three-objective Pareto set always contains the hybrid. This is a structural consequence of the independence assumption, not a result. The informative questions are how much the hybrid costs in mass and energy for its reliability, and under which conditions that is worth paying.

### 15.3 Scalarised cost and the failure-weight sweep

The scalarised cost is

```math
J_\lambda = M + E + \lambda\, p
```

The weight $\lambda$ expresses how strongly reliability is valued. The sweep is the most important diagnostic in this section, because it separates the portion of the hybrid's advantage that comes from reliability from the portion that comes from cost.

**Table 7 (S, 20,000 Monte Carlo draws, uniform environment sweep).**

| $\lambda$ | Winner: abiotic (A) | Winner: biological (B) | Winner: hybrid (C) |
|---|---|---|---|
| 0.0 | 58.9% | 3.8% | 37.3% |
| 1.0 | 50.3% | 1.7% | 48.0% |
| 3.0 | 33.6% | 0.2% | 66.2% |
| 10.0 | 7.7% | 0.0% | 92.3% |

Each row sums to 100%. The hybrid's win share is driven by $\lambda$. At $\lambda = 0$ the abiotic architecture wins most draws. At $\lambda = 10$ the hybrid wins most draws. The hybrid's position is therefore a reliability position, purchased at a mass cost.

Averaged across draws, the hybrid's import mass exceeds the better single architecture by 0.267 normalised units. Its median failure probability is lower by a factor of 12.2 (min$(p_A,p_B)/p_C$).

### 15.4 Gravity regimes (S)

| Gravity regime | $\lambda=0$: C wins | $\lambda=10$: C wins |
|---|---|---|
| $g < 10^{-5.5}$ | 65.8% | 97.4% |
| $g > 0.32$ | 26.7% | 91.3% |

The hybrid wins most often in microgravity, because it takes the cheaper extraction route at a mass cost smaller than the energy saving. It loses to the abiotic architecture under partial gravity, where the abiotic energy advantage is decisive.

### 15.5 Sensitivity (S)

At $\lambda = 10$, the hybrid's win share varies across quintiles of each uncertain parameter as follows.

| Parameter | Range of win share across quintiles |
|---|---|
| abiotic failure base rate $p_{0,A}$ | 22.4 pp |
| biological feedstock penalty $\Phi_B$ | 15.1 pp |
| biological hardware mass $m_B$ | 9.6 pp |
| abiotic radiation coefficient $k_A$ | 4.1 pp |
| biological extraction energy $c_B$ | 3.3 pp |
| abiotic microgravity yield $z_{\mathrm{ug}}$ | 2.7 pp |
| switching overhead $\delta$ | 2.5 pp |
| biological failure base rate $p_{0,B}$ | 1.2 pp |
| biological recovery $\rho_{B,0}$ | 1.1 pp |
| biological radiation coefficient $k_B$ | 0.7 pp |

At $\lambda = 10$ the largest influence is a reliability parameter. At $\lambda = 0$ and $\lambda = 1$ the ranking changes: biological hardware mass and feedstock penalty dominate (Appendix H of the PDF). The cost structure, not the failure rate, governs the hybrid when reliability is not heavily valued.

### 15.6 Two-dimensional environment map (S)

At $\lambda = 1$, averaged over the other sampled parameters, the hybrid's mean share is 66% in microgravity ($10^{-5}$ g) and 36% at 0.1 g. Radiation and water closure move the share within each panel, but the gravity effect is larger. The hybrid's region is set primarily by gravity, with radiation and water closure as secondary modulators.

### 15.7 Biological recovery and water closure

The biological recovery fraction is scaled by water closure, $\rho_{B,0}(0.5 + 0.5W)$ in the PDF's parameterisation, with $\rho_{B,0} \in [0.60, 0.98]$. Water closure therefore enters the biological arm directly and the abiotic arm not at all in this parameterisation. This asymmetry is an assumption and should be tested.

---

## 16. The 110-concept design-space atlas

### 16.1 What the atlas is

The earlier research draft organised **110 engineering concepts** into six phases, ordered by the Sagan scale of the power they would serve. The atlas is a **design space, not a set of validated proposals**. It was audited for internal consistency with the constraints of Sections 5 to 15, not for technical feasibility.

Each concept carries one or more maturity tags:

| Tag | Meaning |
|---|---|
| **B** | uses living biological systems |
| **H** | combines biological and engineered components |
| **M** | mimics biology with nonliving materials or machines |
| **E** | demonstrated in terrestrial engineering |
| **L** | laboratory or spaceflight proof of concept |
| **P** | plausible research proposal |
| **S** | speculative |

### 16.2 Counts, stated carefully

The tags are multi-label, so tag totals exceed the number of concepts. The phase table counts a concept once per tag it carries (Table 9 of the PDF).

| Phase (scale) | B | H | M | E | L | P | S |
|---|---|---|---|---|---|---|---|
| I (K ≈ 0.7–1), concepts 1–30 | 16 | 11 | 9 | 18 | 2 | 9 | 0 |
| II (K ≈ 1–1.5), concepts 31–40 | 7 | 4 | 1 | 0 | 2 | 8 | 0 |
| III (K ≈ 1.5–2), concepts 41–70 | 14 | 17 | 11 | 0 | 2 | 28 | 0 |
| IV (K ≈ 2), concepts 71–85 | 4 | 6 | 9 | 0 | 0 | 13 | 2 |
| V (K ≈ 2–3), concepts 86–100 | 10 | 7 | 4 | 0 | 0 | 13 | 2 |
| VI (K > 3), concepts 101–110 | 5 | 2 | 6 | 0 | 0 | 0 | 10 |
| **All phases** | **56** | **47** | **40** | **18** | **6** | **71** | **14** |

**Evidence-tagged concepts.** Counting concepts rather than tags, **24 of 110** carry an E or L tag: 18 with E and 6 with L, with no overlap. These are concepts 1, 3, 5, 8, 12, 13, 15 to 22, 24, 26 to 30, 32, 35, 50 and 52. The remaining **86** carry no evidence tag and are design space only. Phase VI (galactic) has no E or L concept, and each of its 10 concepts carries an S (speculative) tag.

*Note on the framing of this README.* An earlier brief described the atlas as "90-plus biological and galactic methods plus 10 existing real ones." The PDF's own tags give 110 concepts, 24 with E or L evidence, and 86 without. This README uses the PDF's counts.

### 16.3 Full atlas with corrected tags

Tags are as in the PDF's Appendix B, with concept 83 corrected from H to M (Section 16.4, F1).

| No. | Concept | Tag |
|---|---|---|
| 1 | Planetary-to-orbital regenerative biosphere engines | B/H/E |
| 2 | Photosynthesis-derived solar energy and artificial biohybrid leaves | H/P |
| 3 | Microbial asteroid mining and biological resource refineries | B/L |
| 4 | Regolith-to-structure biomineralization | B/P |
| 5 | Mycelium-derived structural and thermal materials | B/E |
| 6 | Engineered living materials with autonomous repair | B/H/P |
| 7 | Artificial vascular networks for planetary and orbital infrastructure | M/P |
| 8 | On-demand biological manufacturing in space | B/L |
| 9 | Bio-inspired adaptive thermal and radiative infrastructure | M/P |
| 10 | Bio-inspired autonomous construction of O'Neill and Dyson infrastructure | M/P |
| 11 | Mycorrhizal Urban Water Networks | B/P |
| 12 | Algal Wastewater Nutrient Refineries | B/E |
| 13 | Bacterial Cellulose Filtration Membranes | B/H/E |
| 14 | Aquaporin-Inspired Desalination | M/H |
| 15 | Microbial Electrosynthesis Refineries | H/E |
| 16 | Microbial Fuel-Cell Sensor Networks | H/E |
| 17 | Biological Nitrogen-Recycling Infrastructure | B/E |
| 18 | Microbial Carbon-to-Mineral Systems | B/E |
| 19 | Phytomining of Critical Metals | B/E |
| 20 | Root-Inspired Landscape Stabilization | M/H/E |
| 21 | Insect-Based Organic Waste Refineries | B/E |
| 22 | Precision-Fermented Protein Infrastructure | B/E |
| 23 | Biological Contamination Sentinel Networks | H/P |
| 24 | Microbiome-Optimized Vertical Farms | B/E |
| 25 | Mangrove-Inspired Water Separation | M/H/P |
| 26 | Termite-Mound-Inspired Thermal Architecture | M/E |
| 27 | Self-Healing Urban Bioconcrete | H/E |
| 28 | Lotus-Inspired Self-Cleaning Industrial Surfaces | M/E |
| 29 | Shark-Skin-Inspired Fluid Transport Coatings | M/E |
| 30 | Fungal Mycoremediation Infrastructure | B/E |
| 31 | Perchlorate-Reducing Bioreactors | B/P |
| 32 | Extraterrestrial Oxygen-Producing Photobioreactors | B/L |
| 33 | Biological Methane-Feedstock Plants | B/H/P |
| 34 | Regolith Phosphorus Recovery | B/H/P |
| 35 | Lunar Mineral-Bioleaching Modules | B/L |
| 36 | Space Organic-Waste Mineralization Factories | H/P |
| 37 | Dormant Microbial Emergency Libraries | B/P |
| 38 | Engineered Root-Zone Ecosystems | B/P |
| 39 | Robotic Pollination Infrastructure | M/P |
| 40 | Living Selective Membrane Systems | H/P |
| 41 | Gravity-Independent Gas Exchange Networks | M/P |
| 42 | Leaf-Vein Photobioreactor Manifolds | M/H/P |
| 43 | Bacterial Cellulose Crop Supports | B/H/P |
| 44 | Bio-Manufactured Industrial Sealants | B/H/P |
| 45 | Gecko-Inspired Regolith Anchoring | M/P |
| 46 | Lunar Dust-Resistant Surface Architecture | M/P |
| 47 | Locally Manufactured Hydrogen-Rich Shielding Feedstocks | H/P |
| 48 | Root-Inspired Regolith Retention Systems | M/P |
| 49 | Biological Atmospheric Quality Sensors | H/P |
| 50 | Algal Emergency Food Production Modules | B/L |
| 51 | Selective Bioadsorption of Asteroid Metals | B/H/P |
| 52 | Fungal Network Mineral Extraction | B/L |
| 53 | Asteroid Ore Bio-Beneficiation | B/H/P |
| 54 | Microbial Biopolymer Additive Manufacturing | B/P |
| 55 | Bacterial Nanocellulose Filter Factories | B/H/P |
| 56 | Bio-Derived Assembly Adhesives | B/H/P |
| 57 | Enzymatic Polymer-Recycling Plants | B/H/P |
| 58 | Microbial Lubricant Production | B/P |
| 59 | Algae-to-Industrial-Bioplastic Systems | B/H/P |
| 60 | Waste-Gas-to-Industrial-Feedstock Networks | B/H/P |
| 61 | Vascular-Inspired Thermal Distribution | M/P |
| 62 | Mycelium-Inspired Industrial Resource Routing | M/P |
| 63 | Self-Cleaning Orbital Collector Surfaces | M/P |
| 64 | Compound-Eye-Inspired Solar Concentrators | M/P |
| 65 | Sunflower-Inspired Solar Tracking Networks | M/P |
| 66 | Biomimetic Redox Energy Storage | H/P |
| 67 | Enzyme-Assisted Asteroid Refining | B/H/P |
| 68 | Bio-Inspired Selective Mineral Interfaces | M/H/P |
| 69 | Bio-Composite Electrical Insulation | H/P |
| 70 | Regolith-Biomineralization Repair Networks | H/P |
| 71 | Leaf-Venation Dyson Collector Architecture | M/S |
| 72 | Chloroplast-Inspired Photonic Collector Surfaces | M/P |
| 73 | Self-Repairing Solar Collector Skin | M/P |
| 74 | Ant-Colony-Inspired Dyson Swarm Maintenance | M/P |
| 75 | Insect-Cuticle-Inspired Radiator Surfaces | M/P |
| 76 | Vascular Electrical Distribution Networks | M/P |
| 77 | Protected Orbital Biomanufacturing Stations | B/H/P |
| 78 | Modular O'Neill Biosphere Architecture | H/P |
| 79 | Fungal-Inspired Internal Habitat Architecture | H/P |
| 80 | Closed-Loop O'Neill Agriculture and Atmosphere Systems | B/H/P |
| 81 | Sun-Tracking Stellar Collector Meshes | M/S |
| 82 | Asteroid-to-Collector Bio-Refineries | B/H/P |
| 83 | Biological-Inspired Collector Health Monitoring | M/P |
| 84 | Distributed Ant-Inspired Megastructure Logistics | M/P |
| 85 | Multi-Biosphere O'Neill Settlement Networks | B/H/P |
| 86 | Generation-Ship Closed Ecological Engines | B/H/P |
| 87 | Interstellar Microbial Manufacturing Libraries | B/P |
| 88 | Dormant Biomanufacturing Payloads | B/P |
| 89 | Cell-Free Interstellar Manufacturing Cartridges | H/P |
| 90 | Distributed Space Protein Factories | B/P |
| 91 | Bio-Inspired Interstellar Logistics Networks | M/P |
| 92 | DNA-Based Long-Term Scientific Archives | B/H/P |
| 93 | Mycelial-Topology Communication Algorithms | M/P |
| 94 | Interstellar Self-Assembling Robotic Construction Swarms | M/P |
| 95 | Photosynthetic Habitat Energy-Biomass Coupling | B/H/P |
| 96 | Multi-Century Microbial and Seed Preservation Archives | B/P |
| 97 | Extremophile-Enzyme Industrial Catalysts | B/H/P |
| 98 | Interstellar Biogeochemical Recycling Modules | B/H/P |
| 99 | Distributed Asteroid Bio-Refineries Across Star Systems | B/H/S |
| 100 | Interstellar Vascular Energy Networks | M/S |
| 101 | Galactic Distributed Bio-Refineries | B/S |
| 102 | Stellar-Cluster Autonomous Maintenance Swarms | M/S |
| 103 | Galactic Metabolic Network Digital Twins | M/S |
| 104 | Multi-System Biosphere Resilience Architecture | B/M/S |
| 105 | Planetary Biomanufacturing Establishment Kits | B/H/S |
| 106 | Distributed DNA Knowledge Archives | B/H/S |
| 107 | Post-Biological Cellular-Automata Infrastructure | M/S |
| 108 | Fractal Vascular Networks for Galactic Energy Distribution | M/S |
| 109 | Deep-Time Biological Preservation Networks | B/S |
| 110 | Cosmological-Scale Infrastructure Viability Limits | M/S |

### 16.4 Audit findings

**F1. Biological tags on collectors.** No concept describing a collector, radiator or solar surface carries a B tag. Concept 2, a terrestrial biohybrid leaf, carries an H tag and sits in phase I, where biology is appropriate. Concept 83, a distributed sensing layer, carried an H tag implying a living component. Its description refers to nonliving sensors, so it is corrected to M.

**F2. Biological tags in the stellar phase.** Concepts 77, 80, 82 and 85 carry B tags and describe protected manufacturing, closed biospheres or asteroid-based refining. These are consistent with the boundary that biology sits upstream of collectors.

**F3. Speculative tags in the galactic phase.** Phase VI concepts carry B tags only where the biology is preserved or manufactured locally (101, 104, 105, 106, 109). No biological activity is assumed in interstellar vacuum. Concept 110 is retained as a research question.

**F4. Phases with little evidence.** The atlas contains 6 L-tagged and 18 E-tagged concepts, all in phases I to III. Phases IV to VI contain no L-tagged concept. This asymmetry is the main reason later phases are described as design space rather than engineering plan.

### 16.5 How to use the atlas

Treat the atlas as a set of hypotheses about where a function could be placed, filtered by the constraints of Sections 6 to 15. A concept violates a constraint when it places a living component on an exposed collector, when it ignores heat rejection (Section 7), when it assumes a centralised controller beyond the latency bound (Section 8), or when it claims a robustness it has not stated under targeted loss (Section 13). Each concept whose robustness is claimed must specify its loss model. Concepts 74, 84, 94 and 102 (swarm maintenance and logistics) are the clearest examples.

---

## 17. Predictions, status and falsification programme

Table 10 of the PDF lists the framework's predictions with their status. A refuted hypothesis is retained because it constrains the design space.

| # | Prediction | Status |
|---|---|---|
| P1 | Exact capture-geometry law: $\eta f_{\mathrm{cov}} \ge P/L_\odot$, radius-independent | Proved (Prop. 1) |
| P2 | Shell temperature scales as $r^{-1/2}$; extraction lowers $T$ by $(1-\eta)^{1/4}$ | Scaling proved; **constant corrected (Section 7)** |
| P3 | Replacement burden grows linearly; marginal value of recovery constant in absolute terms | Proved (Prop. 3) |
| P4 | Murray exponent $1/3$ for cost-minimising branching | Proved; numerically confirmed (Prop. 4) |
| P5 | Robust viability kernel contained in nominal kernel | Proved (Prop. 5) |
| H1 | Biological extraction energy is below abiotic in microgravity, for most parameter draws | Conditional on the gravity interval and one experiment: 75% of draws |
| H2 | Biological extraction energy below abiotic at 0.32 g or above | Zero under the model by construction; not an empirical test |
| H3 | Hybrid wins on combined mass and energy | Conditional: wins at $\lambda=0$ in 37% of draws, mainly in microgravity |
| H4 | Hybrid strictly more reliable than either single architecture | Holds by construction under independence; median factor 12.2 |
| H5 | Robust viability requires switching between biological and abiotic repair | Holds in the stylised system; magnitude not a prediction |
| H6 | Fungal extraction in microgravity is more reliable than abiotic | Supported in one experiment with large variability; not established |
| H7 | Partial-gravity (0.16 g and 0.38 g) extraction shows the threshold location predicted in Section 11 | **Untested. Decisive experiment (Section 18)** |
| H8 | Type III capture is energetically possible from one star | Refuted by Eq. (8): needs $2.61\times10^9$ solar luminosities |
| H9 | Biohybrid photovoltaics rival industrial PV in electrical output | Refuted: at best a factor of 272 below ideal PV |
| H10 | In a living system, reordering repair at matched flux changes lifespan | Not in this paper (see the aging preprint) |

### 17.1 Falsification criteria

H7 has a falsifier stated in the PDF. The other falsifiers below are proposed in this README to make each unrefuted hypothesis testable; they are not in the PDF.

- **H1 falsified** if a partial-gravity arm places the cost crossover at or above 0.1 g, or if microgravity fungal extraction energy exceeds abiotic energy at matched substrate.
- **H3 falsified** if the hybrid's import mass penalty, measured for a specific mission architecture, exceeds the energy and failure benefit at every plausible weight $\lambda$.
- **H7 falsified** if partial-gravity leaching shows the cost crossover at lunar gravity or above (Section 18).
- **H5 falsified** if a single-channel controller is robustly viable in a higher-dimensional model that matches the channel structure.

---

## 18. Experimental programme and sample-size theory

### 18.1 The decisive experiment

The most useful next measurement is not another microgravity run. It is a set of partial-gravity arms. A centrifuge-based or sounding-rocket experiment could compare abiotic and fungal leaching of the same substrate at four gravity levels, for example $10^{-6}$, 0.16, 0.38 and 1 g, with matched controls and a fixed reactor geometry.

- **Primary outcome.** Extracted fraction per element.
- **Secondary outcomes.** Energy per extracted kilogram, and failure rate of the biological arm.
- **Prediction under the model.** The cost crossover between abiotic and biological extraction lies between $10^{-4}$ and 0.1 g.
- **Falsifier.** A crossover at lunar gravity or above falsifies the threshold interval assumed in Section 11, and would be informative in its own right.

Two design requirements follow. Arms must be replicated across organisms and substrates, because the BioAsteroid consortium result shows that organism choice changes the outcome. Every arm must report extraction energy, not only extraction fraction, because the decision model is sensitive to energy and the literature usually reports fractions alone (design rule D9).

### 18.2 Sample size for a lifespan assay (for the related biology protocol)

The companion aging preprint proposes a lifespan assay. The sample-size theory used there is recorded here because it is general.

For two arms of equal size with full follow-up, the number of deaths $D$ needed for a log-rank test at two-sided level $\alpha$ and power $1-\beta$ follows Schoenfeld's formula:

```math
D = \frac{4\left(z_{1-\alpha/2} + z_{1-\beta}\right)^2}{\left(\ln \mathrm{HR}\right)^2}
```

If lifespans are Weibull with shape $k$ and the manipulation stretches lifespan by a factor $1+g$, the hazard ratio is

```math
\mathrm{HR} = (1+g)^{-k}
```

Power for a given number of deaths is

```math
\text{power} = \Phi\!\left( \frac{\sqrt{D}\,|\ln \mathrm{HR}|}{2} - z_{1-\alpha/2} \right)
```

**Worked check.** At $\alpha = 0.05$ and power 0.80, Schoenfeld's formula gives $D = 4(1.96 + 0.842)^2/(\ln \mathrm{HR})^2 \approx 31.4/(\ln\mathrm{HR})^2$. For $k=5$ and $g=6\%$, $\mathrm{HR} = 1.06^{-5} \approx 0.747$, so $\ln\mathrm{HR} = -0.291$ and $D \approx 370$ deaths. With 60 animals per arm (120 total, so at most 120 deaths), the power formula with $D = 120$ gives $\Phi(\sqrt{120}\cdot 0.1457 - 1.96) = \Phi(-0.364) \approx 0.36$. This matches the PDF's analytic power of 0.36 at that size, and the PDF's simulated value of 0.37 is consistent with it. The 80% power requirement needs about 370 deaths, which is why full follow-up and a larger cohort matter. The Weibull shape must be estimated from pilot survival curves.

---

## 19. Planetary protection, containment and ecological escape

### 19.1 Risks

Any biological component of infrastructure raises issues absent from abiotic systems. These include forward contamination of planetary surfaces, genetic drift in long-running cultures, escape of engineered organisms into an ecosystem, and the spread of a fault from a biological module to its neighbours. The COSPAR policy on planetary protection (2021) sets the framework for missions carrying living material beyond Earth, and is the reference against which any biological infrastructure must be assessed.

### 19.2 Required parameters (not fitted here)

Containment is treated as an engineering requirement with explicit parameters. Each biological module must specify:

- a **containment level**;
- a **maximum credible escape rate** $\varepsilon_{\mathrm{esc}}$ per unit time;
- a **genetic-stability interval** $T_{\mathrm{stab}}$ after which the strain is replaced;
- a **fault-isolation rule** that keeps a failed module from propagating through shared resource lines.

These parameters are not fitted in the paper. Their absence is one reason the atlas tags remain conditional.

### 19.3 Two specific risks

Engineered microbial production is sensitive to evolutionary drift, so a strain that performs well at launch may not do so after many generations. Biological repair can also fail silently, so a damaged module appears functional until it is replaced. Both risks argue for monitoring and redundancy as design primitives, which is the hybrid's rationale in Section 15.

---

## 20. Design rules

The analysis yields nine design rules. Each states what the evidence supports, its basis, and its status. All are conditional on stated assumptions and should be revisited when the partial-gravity experiment is performed.

| # | Design rule | Basis | Status |
|---|---|---|---|
| D1 | Keep collectors, radiators and primary load-bearing structure abiotic | Props. 1 and 2; Section 6 | P (exact identities) |
| D2 | Size radiators from the radiator equation before choosing a biological reactor temperature; biology gives no thermal relief | Section 7.4 | P |
| D3 | Place biological extraction only where the gravity threshold is validated; do not commit on the present interval | Section 11 | Conditional; threshold unidentified |
| D4 | Value recovery by its marginal effect on replacement, since replacement is linear in $(1-\rho)$ | Prop. 3 | P |
| D5 | Use at least two repair channels, selected by the binding constraint (damage or resource) | Section 14 | Holds in the stylised system |
| D6 | Use local autonomy beyond about 0.1 AU; centralised control is limited to periods of $6\tau_{\mathrm{rt}}$ | Prop. 6; Section 8 | P under the delay-margin condition |
| D7 | Choose local wiring degree from the target loss fraction | Section 13 | N (random and targeted models) |
| D8 | Price hybrid redundancy explicitly as import mass; reliability, not cost, drives the hybrid's win | Section 15 | N and conditional |
| D9 | Report extraction energy per kilogram alongside extraction fraction in every biomining study | Section 18 | Recommendation |

---

## 21. Verification, convergence and reproducibility

### 21.1 Independent checks

Every numerical result is checked against an independent computation where available.

| Check | Independent method | Measured discrepancy | Tolerance | Result |
|---|---|---|---|---|
| Algebraic connectivity, one 300-unit graph | dense `eigvalsh` vs sparse `eigsh` | $9.6\times10^{-15}$ | $< 10^{-10}$ | pass |
| Shell temperature ($\eta = 0.26$) | bisection on energy residual vs closed form | 0.0 K | $< 10^{-6}$ K | pass |
| Murray optimum, $Q=1$ | grid minimisation vs $(2a/b)^{1/6}$ | $2.9\times10^{-5}$ | $< 10^{-4}$ | pass |
| Replacement integral, $\rho=0.99$ | Euler integration vs closed form | $1.6\times10^{-11}$ | $< 10^{-6}$ | pass |
| Pareto dominance | brute-force pairwise on 2000 random triples | 0 mismatches | 0 | pass |
| Robust kernel nested in nominal | inclusion on grid | verified | | pass |

**Caveat.** These checks verify numerical code against closed forms. They do not verify the physical geometry of a closed form. The shell-temperature check passes for the PDF's formula, which contains the geometry error described in Section 7.2. A check of this kind can pass for a wrong model.

### 21.2 Convergence

**Monte Carlo (Table 16b, N).** The hybrid share at $\lambda=1$ and the biological-cheaper share settle within about one percentage point by 2,000 draws.

| Draws $n$ | Hybrid share, $\lambda=1$ | Biological cheaper in energy |
|---|---|---|
| 500 | 46.60% | 23.60% |
| 1,000 | 47.20% | 22.70% |
| 2,000 | 47.40% | 24.25% |
| 5,000 | 48.10% | 24.70% |
| 10,000 | 47.34% | 24.06% |
| 20,000 | 48.02% | 24.76% |

**Grid (Table 16c, N).** The robust kernel fraction changes by less than half a percentage point beyond $N = 121$.

| Grid $N$ | Robust kernel fraction | Change |
|---|---|---|
| 41 | 29.74% | |
| 81 | 25.41% | $-4.34$ pp |
| 121 | 24.97% | $-0.44$ pp |
| 161 | 24.81% | $-0.16$ pp |
| 241 | 24.67% | $-0.14$ pp |

### 21.3 Determinism

The analysis is deterministic given seed `20261121` (NumPy default generator). Training and evaluation seeds are disjoint where applicable. The tropical enumeration is deterministic.

---

## 22. Anticipated objections and responses

**Objection. Biology is more efficient, so it should be used everywhere.**
*Response.* The thermodynamic floors (Section 9.4) are route-independent, and the photosynthetic ceiling (Section 9.2) is far below electrical PV. Biology is efficient at specific chemistry and selectivity, not as a general energy converter. The response depends on assumed efficiencies, which are cited, not fitted.

**Objection. The atlas is speculation.**
*Response.* Yes, in part. Each concept carries a maturity tag, the audit in Section 16.4 corrects tags, and phases IV to VI are described as design space. The atlas is not used to support any quantitative result.

**Objection. The hybrid is redundancy relabelled.**
*Response.* In the model the hybrid's reliability gain is redundancy by construction, and this is stated (Section 15.2). The substantive content is cost. The hybrid pays in import mass, and the failure-weight sweep shows its win depends on how heavily reliability is valued.

**Objection. The gravity result is an artefact of the interpolation.**
*Response.* Partly. The overall biological share changes greatly with interpolation shape (Section 11.4). The endpoint results survive all three shapes tested. The threshold location does not. The paper therefore claims the endpoints and marks the threshold as unidentified.

**Objection. A two-state viability toy says nothing about real infrastructure.**
*Response.* The toy is stylised and its numbers should not be transferred. The structural claim is narrower: with two channels of different cost and speed, the best controller can be strictly better than either channel. The regime depends on the adversary and production (Section 14.4).

**Objection. Stellar-scale constraints are irrelevant to near-term work.**
*Response.* The scale results bind irrespective of timing, and they constrain near-term choices. They tell us which functions must stay abiotic whatever biology achieves (D1, D2).

**Objection. Light-time arguments assume a centralised controller.**
*Response.* Yes, and that is the case they address. The alternative, local control with delayed supervision, is what Section 13 and Section 8 imply, and the latency numbers quantify when it becomes mandatory.

**Objection. The BioAsteroid numbers are press-reported.**
*Response.* Yes, and they are flagged throughout. The ratio of about 13 is reproduced from rounded means. Conclusions need only that abiotic yield falls substantially in microgravity. This must be re-checked against the primary paper before quantitative reuse.

**Objection. The diffusion model is too simple to matter.**
*Response.* It is a transport diagnostic, not a design model. Its robust content is the square-root law (Proposition 7) and the observed sub-diffusive correction. Its prefactor depends on the reaction and boundary condition, which a design study would have to calibrate.

**Objection. Why not model the biology in detail?**
*Response.* No detailed biological model here is calibrated to the relevant environment. An uncalibrated detailed model would be less honest than a stylised one with explicit ranges. The path to a detailed model is the experiment in Section 18.

---

## 23. Limitations

**Stylised models.** The decision model and viability system are normalised and dimensionless. Parameter ranges are chosen, not fitted. The conclusions in Sections 14 and 15 are structural and conditional on those ranges. They must not be read as predictions of cost or reliability for any real infrastructure.

**Single experiment.** The gravity dependence rests on one reported ISS experiment with large variability, one substrate and one microbial pair, and on press-reported values not yet checked against the full paper. The threshold location is therefore an assumption constrained by that experiment, not a finding.

**Interpolation.** Other shapes change the overall biological share from about one quarter to two thirds. Only endpoint results are robust to shape.

**Independence.** The redundancy result assumes the two channels fail independently. Common-cause failures, such as a shared radiation event or a shared feedstock shortage, would reduce the reliability advantage. The feedstock dependence in the model is a first step toward modelling that correlation, not a full treatment.

**Viability dependence.** The single-channel non-viability result holds at default disturbance and production. It reverses at weaker disturbance and higher production (Table 6a), so no general claim about single channels should be made.

**Scale.** The network analysis uses 300 units and the viability analysis uses two states. Neither reproduces the dimension of real infrastructure. Robustness conclusions should be checked at larger scale before use.

**Atlas.** Tags are the draft's judgements, audited for internal consistency and not for technical feasibility. Concepts tagged P or S have not been assessed against any design requirement.

**Literature.** The search was not exhaustive. Several items in the earlier draft could not be verified and were removed (Table 1 of the PDF). The novelty claim applies only to the composition in Section 2 of the PDF, and only as far as the search extends.

**Reconstructed equations.** Some equations in the PDF are typeset as images. Where this README reconstructs them from the PDF's prose (the gravity interpolation in Section 11.2, the energy and failure structure in Section 15.1, the one-step map summarised in Section 14.2), the reconstruction is marked and the code is authoritative.

---

## 24. Errata and known inconsistencies

This section lists problems found while preparing this README, with their impact. Read it before citing any number from the PDF. Items are ordered by consequence.

### E1. Radiative equilibrium geometry (serious; affects Proposition 2 constants)

**What the PDF says.** Absorbed power per unit area for a collector shell is $\alpha S(r)(1-\eta)/4$, justified by "the projected disk is one quarter of the sphere" (Section 4.3, Appendix A.2, Table 1 correction row "Radiative balance written without area factors").

**The problem.** The one-quarter factor applies to a body illuminated from a distance, such as a planet. A shell enclosing the star has every inner surface element facing the star. The full irradiance $S(r)$ falls on it, so the factor is absent.

**Corrected form.**

```math
T_{\mathrm{sh}} = \left[ \frac{\alpha(1-\eta) L_\odot}{4\pi n \varepsilon \sigma r^2} \right]^{1/4}, \qquad n \in \{1, 2\}
```

**Impact.**

- Scaling laws $T \propto r^{-1/2}$ and $T \propto (1-\eta)^{1/4}$ are unchanged.
- Numerical constants change by $(4/n)^{1/4}$. Bare-black-body values at 1 AU become about 393.6 K ($n=1$) or 331.1 K ($n=2$), not 278.3 K. The $\eta=0.26$ values become about 370 K or 311 K.
- Affected: Abstract (result ii and "four results are exact"), Section 4.3 text, Appendix A.2, Table C1 rows for shell temperature, Table J1 rows, Figure 4 (left panel values).
- Not affected: the radiator equation (Section 7.4 here), design rules D1 and D2, and the qualitative conclusion that biology provides no thermal relief.
- Why the verification passed: Table 16a checks the closed form against bisection of the same formula. It cannot detect a wrong geometric factor.

**Status.** Requires a v1.1 correction. The PDF's headline "exact" classification for result (ii) should be downgraded to "exact scaling, constant corrected" until then.

### E2. Sign convention in the reversible-work table (Table 5a)

Reversible work required to produce CH$_4$ and glucose from their reactants is positive, since both reactions are endergonic. Table 5a lists $-51.0$ MJ and $-15.98$ MJ per kilogram. The magnitudes are correct. Section 5.1 of the PDF refers to "about $-16.0$ MJ per kilogram" for glucose. It should read $+16.0$ MJ kg$^{-1}$, the minimum energy input.

### E3. Swarm connectivity threshold, $k = 6$, random loss

Three sources give different values for the same nominal experiment.

- Table 5 and Section 9 state the threshold as 0.35. Table E1 gives $P(\text{conn}) = 0.60$ at 0.30 and $0.28$ at 0.35.
- Table 9b states the random threshold as 0.30, with $P(\text{conn}) = 0.48$ at 0.30.
- Table 9b and Table 5 disagree at 0.30 ($0.48$ vs $0.60$).

These come from separate trial sets of 25 trials each, so the discrepancy is sampling noise. The honest statement is a threshold range of about 0.30 to 0.35. The runs should be re-executed with a shared trial set and reported as one table.

### E4. Formatting artefact in Table 5

The header for $k=8$ reads "0.49999999999999994". It should read 0.50.

### E5. Equation-number collisions

Several cross-references point to the wrong equation number.

- "Eq. (4)" denotes the composite conjecture (Section 3.3) and the growth formula (Section 4.5).
- "Eq. (8)" denotes the capture law and also appears with sub-labels 8a and 8b for the biocementation model.
- The Murray cost is labelled (18) but the Proposition 4 proof cites "Eq. (16)". Table C1 cites "Eq. (16)" for the Murray exponent.

These do not affect results. They should be fixed in the v1.1 typesetting.

### E6. Palladium ratios (disclosed, retained)

The PDF reports the abiotic 1 g to microgravity ratio as 13.6 (press-reported) and as 13.4 (from rounded means). It reports fungal over abiotic in microgravity as 5.5 (reported) and 5.4 (from rounded means). Both sets are in the PDF. The primary paper must be checked before quantitative reuse.

### E7. Press-reported and unverified references

The BioAsteroid author list and volume (Ref. 8) and the journal details of Ref. 9 are marked "to be confirmed" in the PDF. Several items in the earlier draft could not be verified and were removed (Table 1). Nothing in the quantitative results depends on those removed items.

### E8. Figure-layout defects (fixed in this build)

Two figure-layout defects were corrected in the v1.0 build: overlapping band labels in Figure 2 (Section 6.3), and a legend overlapping the title of the right panel of Figure 10. A proof-end symbol and a notation-table glyph also rendered as empty boxes; they now render correctly. None of these changed any number.

### E9. Summary of what is and is not affected

| Result | Affected by | Status after correction |
|---|---|---|
| Capture-geometry law (Prop. 1) | none | unchanged |
| Radiative scaling laws | E1 | unchanged |
| Radiative constants | E1 | corrected (Section 7.3) |
| Radiator area | E1 (no) | unchanged |
| Murray exponent | none | unchanged |
| Latency bound | none | unchanged |
| Reversible work magnitudes | E2 (signs only) | unchanged in magnitude |
| Swarm threshold | E3 | reported as a range |
| Gravity threshold and shares | none (assumption-driven) | unchanged; flagged |
| Robust kernel values | none | unchanged |
| Pareto win shares | none | unchanged |
| Atlas tags | none | unchanged; counts as in Section 16.2 |

---

## 25. Roadmap

**Near term (documentation).**

1. Issue v1.1 of the PDF with the corrected Proposition 2 (E1), the sign convention (E2), a single swarm threshold table (E3), the table formatting fix (E4), and the equation-number fixes (E5).
2. Re-run the swarm analysis with a shared trial set and report the threshold with a confidence interval.
3. Re-check all BioAsteroid numbers against the primary publication and replace press-reported values.

**Medium term (experiment and modelling).**

4. Partial-gravity leaching experiment (Section 18.1). This is the single most informative next measurement. It tests H7 and the gravity threshold on which the decision model depends most.
5. Replace the stylised decision model with one calibrated to a named mission architecture, so the hybrid region can be stated for a specific system.
6. Model common-cause failures between the two channels (Section 23), since they reduce the reliability advantage.

**Longer term (scale and theory).**

7. Extend the swarm and viability analyses to larger $N$ and to higher-dimensional state spaces.
8. Test the composite conjecture (Conjecture 1) with a single end-to-end simulation that includes all layers. This is currently untested.
9. Revisit the atlas tags as evidence accumulates, promoting P or S concepts only when a specific design requirement has been assessed.

---

## 26. Reproduction instructions

### 26.1 Environment

Python 3.12 with NumPy 2.x, SciPy 1.x, Matplotlib 3.x, ReportLab 4.x or 5.x, and NetworkX and Numba as used in the scripts. Fonts used are DejaVu Serif, DejaVu Sans and DejaVu Sans Mono.

### 26.2 Run order

```bash
python3 analysis.py      # all numerical analyses and figures, seed 20261121
python3 build_pdf.py     # typesets the PDF from results.json
```

The full analysis takes several minutes on one CPU core, dominated by the diffusion simulation of Section 12.3. `build_pdf.py` reads `results.json` and writes the PDF to `/mnt/user-data/outputs/`.

### 26.3 Expected outputs

- `results.json`: machine-readable results used by the builder.
- `figs/`: figure images, including `fig02_kardashev.png` and `fig10_pareto_env.png`.
- `eqs/`: rendered equation images.
- `Biohybrid_Infrastructure_Viability_Preprint_v1.0.pdf`: 40 pages.

### 26.4 Known reproduction notes

- The v1.0 PDF incorporates the figure-layout fixes described in E8. Re-running `analysis.py` with the same seed reproduces the same numbers.
- Palladium inputs and thermodynamic constants are entered in the scripts with their sources cited in the text. No external data files are read.
- Training seeds and evaluation seeds are disjoint. Percolation uses five replicates per density in the aging preprint. The swarm analysis uses 25 trials per cell.

### 26.5 Parameter tables

The full parameter set is Table D1 (architecture Monte Carlo) and the viability parameters listed in Section 14.2. Every value is a declared assumption, not a fitted quantity.

---

## 27. Worked verification calculations

These calculations were recomputed for this README from the stated constants. They are arithmetic (A) or analytic (P) checks, not new simulations.

### 27.1 Lifespan exponent $\Phi$ (Proposition 3)

With $\lambda = 0.25$, $\mu = 1$, $\theta = 0.4$, $b = 0.3$, the fluid fixed point is the root of $\mu x / (\lambda(1-x)) = 1$ for $x < b$:

```math
x^* = \frac{\lambda}{\mu + \lambda} = 0.2
```

Since $x^* < b$, $\min(x,b) = x$ on $[0.2, 0.3]$ and $\min(x,b) = 0.3$ on $[0.3, 0.4]$. Therefore

```math
\Phi = \int_{0.2}^{0.3} \ln\frac{x}{0.25(1-x)}\,\mathrm{d}x \;+\; \int_{0.3}^{0.4} \ln\frac{0.3}{0.25(1-x)}\,\mathrm{d}x
```

The first integral evaluates to about $0.02817$ and the second to about $0.06140$. The sum is

```math
\Phi \approx 0.0896
```

which matches the PDF's large-deviation limit (Table 5).

### 27.2 Corrected shell temperature (Section 7)

For $\alpha = 0.95$, $\varepsilon = 0.90$, $\eta = 0.26$ and $S_0 = 1361.2$ W m$^{-2}$ at 1 AU, the balance with $n$ radiating faces is $\alpha S_0 (1-\eta) = n\,\varepsilon\sigma T^4$, so

```math
T^4 = \frac{\alpha S_0 (1-\eta)}{n\,\varepsilon\,\sigma} = \frac{0.95 \times 1361.2 \times 0.74}{n \times 0.90 \times 5.670374\times10^{-8}}
```

For $n=1$ the value is $T^4 \approx 1.875\times10^{10}$ K$^4$, giving $T \approx 370$ K. For $n=2$ it is $T^4 \approx 9.38\times10^{9}$ K$^4$, giving $T \approx 311$ K. These confirm the values in Section 7.3.

### 27.3 Radiator area (Section 7.4)

```math
A_{\mathrm{rad}} = \frac{10^{9}}{0.9 \times 5.670374\times10^{-8} \times (300)^4} = \frac{10^9}{413.4} \approx 2.42\times10^{6}\ \mathrm{m}^2
```

### 27.4 Petela limit (Section 9.1)

```math
\eta_{\mathrm{P}} = 1 - \frac{4}{3}(0.05198) + \frac{1}{3}(0.05198)^4 \approx 1 - 0.06931 + 0.0000024 = 0.9307
```

### 27.5 Murray factor (Section 12.1)

Halving the radius at fixed flow multiplies $\Delta p \propto r^{-4}$ by

```math
\frac{\Delta p(r/2)}{\Delta p(r)} = \left(\frac{r}{r/2}\right)^{4} = 2^4 = 16
```

### 27.6 Diffusion time to 10 cm (Section 12.3)

```math
t = \frac{(0.10)^2}{4\,(1.3859)^2\,(10^{-9})} = \frac{0.01}{7.68\times10^{-9}} \approx 1.30\times10^{6}\ \mathrm{s} \approx 15.1\ \mathrm{d}
```

### 27.7 Hydrogen reversible work (Section 9.4)

```math
\frac{237.1\ \mathrm{kJ}}{2.016\ \mathrm{g}} = 117.6\ \mathrm{MJ\,kg^{-1}}, \qquad \frac{117.6}{3.6} \approx 32.7\ \mathrm{kWh\,kg^{-1}}
```

### 27.8 Crew replacement (Section 10.3)

```math
(1 - 0.98) \times 3{,}650\ \mathrm{kg\,yr^{-1}} = 73\ \mathrm{kg\,yr^{-1}}, \qquad (1 - 0.999)\times 3{,}650 = 3.65\ \mathrm{kg\,yr^{-1}}
```

### 27.9 Gravity penalty from BioAsteroid values (Section 11.1)

```math
\frac{29.5\%}{2.2\%} \approx 13.4, \qquad \frac{11.9\%}{2.2\%} \approx 5.4
```

### 27.10 Light time and minimum control period (Section 8)

At 1 AU, $\tau_{\mathrm{rt}} = 2 \times 1.496\times10^{11} / (2.998\times10^{8}) \approx 998$ s $\approx 16.6$ min, and with $\mathrm{PM} = \pi/3$,

```math
T_{\min} = \frac{2\pi \times 998\ \mathrm{s}}{\pi/3} = 6 \times 998\ \mathrm{s} \approx 1.66\ \mathrm{h}
```

---

## 28. References

Numbering follows the PDF.

1. Kardashev NS (1964) Transmission of information by extraterrestrial civilizations. *Soviet Astronomy* 8:217–221.
2. Dyson FJ (1960) Search for artificial stellar sources of infrared radiation. *Science* 131:1667–1668.
3. O'Neill GK (1974) The colonization of space. *Physics Today* 27(9):32–40.
4. Sagan C (1973) *Communication with extraterrestrial intelligence (CETI)*. MIT Press. The continuous power index as commonly cited; the formula used here is $(\log_{10} P - 6)/10$.
5. Shockley W, Queisser HJ (1961) Detailed balance limit of efficiency of p–n junction solar cells. *Journal of Applied Physics* 32:510–519.
6. Zhu XG, Long SP, Ort DR (2008) What is the maximum efficiency with which photosynthesis can convert solar energy into biomass? *Current Opinion in Biotechnology* 19:153–159.
7. Qi X, Liu X, Gu Y, Liang P (2024) Whole-cell biophotovoltaic systems for renewable energy generation: a systematic analysis of existing knowledge. *Bioelectrochemistry* 108695. doi:10.1016/j.bioelechem.2024.108695.
8. Santomartino R, Stirpe A, et al. (2026) Microbial biomining from asteroidal material onboard the International Space Station. *npj Microgravity* (BioAsteroid). Full author list and volume to be confirmed against the published version.
9. Esposito M, Tonietti L, Santomartino R, Chianese E, Rotundi A, Poli A, Finore I, Di Donato P (2026) Integrating resource utilization and bioregenerative life support systems for sustainable space exploration. Journal details to be confirmed.
10. Koehle AP, Brumwell SL, Seto EP, Lynch AM, Urbaniak C (2023) Microbial applications for sustainable space exploration beyond low Earth orbit. *npj Microgravity* 9. doi:10.1038/s41526-023-00285-0.
11. Keller RJ, Porter W, Goli K, Rosenthal R, Butler N, Jones JA (2021) *Life* 11(8):844. doi:10.3390/life11080844.
12. Verbeelen T, Leys N, Ganigué R, Mastroleo F (2021) Development of nitrogen recycling strategies for bioregenerative life support systems in space. *Frontiers in Microbiology*. doi:10.3389/fmicb.2021.700810.
13. Aubin JP (1991) *Viability Theory*. Birkhäuser.
14. Blanchini F (1999) Set invariance in control. *Automatica* 35:1747–1767.
15. Murray CD (1926) The physiological principle of minimum work. I. The vascular system and the cost of blood volume. *PNAS* 12:207–214.
16. Fiedler M (1973) Algebraic connectivity of graphs. *Czechoslovak Mathematical Journal* 23:298–305.
17. Olfati-Saber R, Fax JA, Murray RM (2007) Consensus and cooperation in networked multi-agent systems. *Proceedings of the IEEE* 95:215–233.
18. COSPAR (2021) *Policy on planetary protection*. Committee on Space Research.
19. Petela R (1964) Exergy of heat radiation. *Journal of Heat Transfer* 86:187–192.
20. Poiseuille JLM (1841) Recherches expérimentales sur le mouvement des liquides dans les tubes de très petits diamètres. *Comptes Rendus* 12:112–115.
21. Pontryagin LS, Boltyanskii VG, Gamkrelidze RV, Mishchenko EF (1962) *The Mathematical Theory of Optimal Processes*. Interscience.
22. Nagumo M (1942) Über die Lage der Integralkurven gewöhnlicher Differentialgleichungen. *Proc. Physico-Mathematical Society of Japan* 24:551–559.

Citations in the text are numeric and refer to this list. Where a reference was not retrieved in full during this work, the entry notes what remains to be confirmed.

---

## 29. Glossary

| Term | Meaning in this work |
|---|---|
| Abiotic (A) | Process class using conventional chemical, electrochemical or mechanical means with no living component. |
| Biohybrid (H) | Process class combining living components with synthetic materials, electronics or machines. |
| Biological (B) | Process class in which living organisms perform the transformation. |
| BioAsteroid | ISS experiment testing microbial and fungal leaching of an L-chondrite under microgravity [8]. |
| BLSS / ISRU | Bioregenerative life-support system / in-situ resource utilisation [9, 10]. |
| BPV | Biophotovoltaic device: a photosynthetic organism coupled to an electrode [7]. |
| Capture-geometry law | The bound $\eta f_{\mathrm{cov}} L_\odot$ on captured power (Proposition 1). |
| Delay margin | $\mathrm{PM}/\omega_c$: the largest loop delay a linear feedback loop tolerates. |
| Viability kernel | Set of states from which admissible behaviour can be maintained under all disturbances. |
| Light time | One-way signal travel time between a controller and a unit. |
| MICP | Microbially induced calcium carbonate precipitation, a biomineralisation route. |
| Murray's law | Cost-minimising branching radius scaling with the cube root of flow. |
| Petela limit | Maximum fraction of solar radiation exergy convertible to work, about 0.93. |
| Robust viability | Viability under the worst disturbance in an admissible set, rather than a nominal one. |
| Sagan index $K$ | Continuous Kardashev index $(\log_{10} P - 6)/10$. |
| Switching controller | Repair policy selecting between channels as a function of the current state. |
| Type I / II / III | Kardashev scales at $10^{16}$, $10^{26}$ and $10^{36}$ W. |
| Algebraic connectivity $\lambda_2$ | Second-smallest eigenvalue of the graph Laplacian. |
| Schoenfeld formula | Event count for a log-rank test: $D = 4(z_{1-\alpha/2}+z_{1-\beta})^2/(\ln\mathrm{HR})^2$. |

---

## 30. Disclosures and citation

**AI assistance.** The simulations, figures and manuscript text were produced with the assistance of Claude (Anthropic) under the direction of the authors, who define the research question and are responsible for the content. Xylia is the authors' AI research scientist.

**Competing interests.** None declared. **Funding.** None.

**Literature.** The search was not exhaustive. Novelty is claimed only as far as the search extends, and only for the composition described in Section 2 of the PDF.

**Code and data.** All numerical results are generated by `analysis.py` and the parameter tables in Appendix D of the PDF, with outputs stored in `results.json`. The authors will release code and data with the manuscript.

**Scope.** This is a theoretical and computational preprint. It makes no claim about human lifespan, clinical use, or any prediction for a living organism, space mission or population.

**Suggested citation.**

```bibtex
@misc{debnath2026biohybrid,
  title        = {Biohybrid Infrastructure Viability Across Civilizational Scales},
  author       = {Debnath, Devanik and Xylia},
  year         = {2026},
  note         = {Preprint v1.0, not peer reviewed},
  howpublished = {Companion code and PDF, version 1.0}
}
```

---

*End of README. Companion PDF: `Biohybrid_Infrastructure_Viability_Preprint_v1.0.pdf`. Errata in Section 24 apply to that version.*
