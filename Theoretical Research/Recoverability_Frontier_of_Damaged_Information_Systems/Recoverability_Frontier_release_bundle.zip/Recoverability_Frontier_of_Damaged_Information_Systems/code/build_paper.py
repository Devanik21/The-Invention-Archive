#!/usr/bin/env python3
"""Builds the research PDF from the outputs of recoverability_experiments.py."""
import json
import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "paper", "Recoverability_Frontier_of_Damaged_Information_Systems.pdf")

FD = "/usr/share/fonts/truetype/dejavu/"
for name, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"),
                 ("Serif-I", "DejaVuSerif-Italic.ttf"), ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"),
                 ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
                 ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")

S = json.load(open(os.path.join(RES, "summary.json")))
E1 = json.load(open(os.path.join(RES, "E1_erasure_code.json")))
E2 = json.load(open(os.path.join(RES, "E2_topological_recoverability.json")))
E3 = json.load(open(os.path.join(RES, "E3_control_reachability.json")))
E4 = json.load(open(os.path.join(RES, "E4_information_lmmse.json")))
E6 = json.load(open(os.path.join(RES, "E6_composite_frontier.json")))

NAVY = colors.HexColor("#1f4e79")
GREY = colors.HexColor("#555555")
LIGHT = colors.HexColor("#eef3f8")

body = ParagraphStyle("body", fontName="Serif", fontSize=9.4, leading=13.6,
                      alignment=TA_JUSTIFY, spaceAfter=6)
small = ParagraphStyle("small", parent=body, fontSize=8.2, leading=11, spaceAfter=3)
cap = ParagraphStyle("cap", parent=body, fontSize=8.0, leading=10.6, textColor=GREY, spaceBefore=3,
                     spaceAfter=10)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=12.5, leading=16, textColor=NAVY,
                    spaceBefore=12, spaceAfter=6)
title = ParagraphStyle("title", fontName="Sans-B", fontSize=19, leading=24, alignment=TA_CENTER,
                       textColor=NAVY, spaceAfter=10)
subtitle = ParagraphStyle("subtitle", fontName="Serif-I", fontSize=10.5, leading=14,
                          alignment=TA_CENTER, textColor=GREY, spaceAfter=6)
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER)
eqs = ParagraphStyle("eqs", fontName="Serif-I", fontSize=9.4, leading=13.5, alignment=TA_CENTER,
                     spaceBefore=3, spaceAfter=7)
cell = ParagraphStyle("cell", fontName="Serif", fontSize=7.6, leading=9.6)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Serif-B")


def P(t, s=body):
    return Paragraph(t, s)


def H1(t):
    return Paragraph(t, h1)


def EQ(t):
    return Paragraph(t, eqs)


def FIGURE(name, caption, width_cm=16.0):
    path = os.path.join(FIG, name + ".png")
    iw, ih = ImageReader(path).getSize()
    w = width_cm * cm
    return KeepTogether([Image(path, width=w, height=w * ih / iw), Paragraph(caption, cap)])


def TABLE(rows, widths):
    data = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                           ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def BOX(text):
    t = Table([[Paragraph(text, small)]], colWidths=[16.0 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def fmt(x, nd=3):
    if x is None or (isinstance(x, float) and x != x):
        return "n/a"
    return f"{x:.{nd}f}"


def pct(x):
    return f"{100 * x:.0f}%"


def control_threshold(ctrl):
    """Largest actuator loss at which success fraction is still at least one half."""
    best = None
    for loss, s in zip(E3["actuator_loss"], E3["success_frac"]):
        if s >= 0.5 and (best is None or loss > best):
            best = loss
    return best


CTRL_TH = control_threshold(E3)
ROW_MEDIAN = dict(zip(E3["m"], E3["median_norm_cost"]))
TOPO_D90 = S["E2_d90_deletion_only"]
RHO = E4["rho"]
TOPO0 = E2["modes"]["0.0"]
TOPO3 = E2["modes"]["0.3"]
FR = E6["rates"]

story = []

# =============================================================== title
story += [Spacer(1, 0.8 * cm),
          P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 8 NOVEMBER 2026", center),
          Spacer(1, 0.5 * cm),
          P("The Recoverability Frontier of Damaged Information-Bearing Systems", title),
          P("Coding, topology, reachability, linear estimation and thermodynamic cost in one "
            "stylised framework", subtitle),
          Spacer(1, 0.2 * cm),
          P("Devanik Debnath<super>1</super> · Xylia<super>2</super>", center),
          P("<super>1</super> Independent researcher &nbsp;&nbsp; <super>2</super> Xylia, AI research "
            "scientist (multi-agent research system)", small),
          Spacer(1, 0.4 * cm)]

story.append(BOX(
    "<b>Scope.</b> This paper studies abstract, dimensionless models of damaged information-bearing systems. "
    "It asks when the information in a damaged system can still be identified, decoded, reached by a control "
    "action, estimated from partial observations, and restored at a finite physical cost. <b>It does not study "
    "the reversal of death, the revival of any organism or person, personal identity, or any medical "
    "intervention.</b> Every number is produced by <font face='Mono'>code/recoverability_experiments.py</font> "
    "with the fixed seed 20261108. No experiment on living material is reported, and no claim about biology "
    "follows from these results without a separate measurement programme."))
story.append(Spacer(1, 0.35 * cm))
story.append(P(
    "<b>Abstract.</b> When a system is damaged, three questions are often run together: is the information still "
    "present, can a controller drive the system back to a functional state, and what does that cost? We separate "
    "these questions and give each a precise meaning. Information recovery is modelled as decoding of a redundant "
    "erasure code. Identifiability of organisation is modelled through persistent clusters of a point cloud. "
    "Functional restoration is modelled as reachability and minimum-energy control of a linear system. Partial "
    "observation is modelled as Gaussian linear estimation, and the physical floor on restoration as a "
    "Landauer-type bound. We prove six propositions, including an exact closed form for full-rank recovery of random "
    "binary codes, a generic reachability rank of min(n, Tm), and monotonicity of recoverability under damage. "
    "The numerical results show four things. A coding threshold sits at 1 − R: the measured 50% points are "
    f"{E1['rates']['0.25']['e50']:.2f}, {E1['rates']['0.5']['e50']:.2f} and {E1['rates']['0.75']['e50']:.2f} against "
    f"{E1['rates']['0.25']['shannon_limit']:.2f}, {E1['rates']['0.5']['shannon_limit']:.2f} and "
    f"{E1['rates']['0.75']['shannon_limit']:.2f}. A topological signature survives deletion of {pct(TOPO_D90)} of "
    "points but is fragile to measurement jitter at a fixed scale. Reachability has a cliff at m = ⌈n/T⌉ actuators, "
    "and the energy cost just above the cliff is about three orders of magnitude above full actuation. The observed "
    "fraction needed for estimation depends strongly on correlation, falling from "
    f"{pct(RHO['0.2']['o_for_D0.2'])} at ρ = 0.2 to {pct(RHO['0.9']['o_for_D0.2'])} at ρ = 0.9. A composite frontier "
    "shows that the control layer acts as a cliff rather than a slope. We state a falsifiable hypothesis for each "
    "layer, report which survived and which failed, and specify what is needed to test the composite conjecture "
    "end to end. The contribution is a framework, a set of verified sub-results, and two negative findings that "
    "constrain how the framework should be used.", body))
story.append(P("<b>Keywords:</b> erasure codes · persistent homology · reachability · minimum-energy control · "
               "linear estimation · rate–distortion · Landauer bound · recoverability", small))
story.append(PageBreak())

# ============================================================== contents
story.append(H1("Contents"))
for t in ["1  Introduction and scope", "2  Motivation, and what existing evidence does and does not show",
          "3  Formal framework: five quantities of recoverability", "4  Propositions",
          "5  Layer A: coding recoverability", "6  Layer B: topological recoverability",
          "7  Layer C: control reachability and energy", "8  Layer D: information from partial observation",
          "9  Layer E: thermodynamic floor", "10  The composite recoverability frontier",
          "11  Predictions, status and falsification", "12  Reproducibility",
          "13  Limitations", "14  Discussion", "15  Conclusion", "Appendix A  Proof details",
          "Appendix B  Parameter table", "References"]:
    story.append(P(t, small))
story.append(PageBreak())

# ================================================================ 1
story.append(H1("1  Introduction and scope"))
story.append(P(
    "Damage to a biological or engineered system is usually described as a loss of material, a loss of function, "
    "or both. Those descriptions answer a different question from the one that governs recovery. A system can lose "
    "most of its physical parts and still hold the information needed to rebuild them, provided the surviving parts "
    "are arranged so that reconstruction is possible. The same system can keep most of its parts and still be "
    "unrecoverable, because the surviving information has become inaccessible, uncontrollable or too costly to use. "
    "Recovery therefore depends on at least four logically distinct properties: whether the information survives, "
    "whether it can be estimated from what remains, whether a controller can reach a functional state, and what "
    "physical resources that requires. A fifth quantity, the physical floor on restoration, bounds all four."))
story.append(P(
    "This paper formalises these five quantities as layers of one framework and tests the layers numerically on "
    "stylised systems. The central object is the set of conditions under which all layers hold together, which we "
    "call the recoverability frontier. We treat the frontier as a mathematical and computational question, not as a "
    "fact about any organism."))
story.append(P(
    "<b>Scope and exclusions.</b> We do not model the death of any organism, the restoration of any deceased animal "
    "or person, the preservation or revival of personal identity, or any clinical procedure. <i>Recoverability</i> "
    "here refers only to the recovery of an abstract information state in a simulated system. Connecting these "
    "results to biology needs a separate measurement programme, outlined in Section 13."))
story.append(P(
    "<b>How to read the evidence.</b> Statements are labelled Proposition (proved in Section 4 or Appendix A), "
    "Conjecture (not proved), Numerical result (produced by the code with the stated seed and sizes), or Hypothesis "
    "(a stated prediction with a status). Where an outcome contradicts what we expected, we say so."))

# ================================================================ 2
story.append(H1("2  Motivation, and what existing evidence does and does not show"))
story.append(P(
    "Four bodies of work motivate the layers. Information theory gives the limit of what a redundant code can "
    "recover (Shannon 1948; Cover and Thomas 2006), and the theory of sparse-graph codes shows how decoding succeeds "
    "or fails sharply as damage grows (Richardson and Urbanke 2008). Persistent homology describes which multiscale "
    "structures survive perturbation (Edelsbrunner, Letscher and Zomorodian 2002; Zomorodian and Carlsson 2005; "
    "Carlsson 2009). Control theory gives exact conditions under which a system can be steered (Kalman 1963; Sontag "
    "1998). Thermodynamics gives the cost of information processing (Landauer 1961; Bennett 1982; Seifert 2012). Each "
    "is standard. Our contribution is to place them in one framework with a common notion of damage, and to test "
    "their interaction."))
story.append(P(
    "Some experimental work bears on the question without answering it. Reports of partial restoration of "
    "circulation and cellular function in post-mortem large-animal tissue (Vrselja et al. 2019) show that certain "
    "processes can be restarted after an interval. Those reports do not show restoration of organised, conscious or "
    "whole-body function, and we do not treat them as evidence for organismal recovery. Memory research shows that "
    "engram representations are distributed and that the physical substrate of memory is still under study "
    "(Josselyn and Tonegawa 2020). These findings motivate the question of which information survives damage. They do "
    "not supply thresholds, and we do not use them to set parameters."))

# ================================================================ 3
story.append(H1("3  Formal framework: five quantities of recoverability"))
story.append(P(
    "Let X<sub>0</sub> denote the intact system, a random object whose state includes a redundant encoding of target "
    "information Z = Φ(X<sub>0</sub>). A damage process of severity x ∈ [0, 1] returns a damaged state X<sub>x</sub>. "
    "An observation channel returns Y = H(X<sub>x</sub>) + ε, where H is a linear or sampling map and ε is noise. "
    "The five quantities are:"))
story.append(P(
    "<b>Definition 1 (information recoverability).</b> D*(x) = inf over estimators Ẑ(Y) of E[d(Z, Ẑ)], the minimum "
    "achievable distortion. Information is recoverable at severity x when D*(x) ≤ D<sub>max</sub>."))
story.append(P(
    "<b>Definition 2 (code recoverability).</b> When redundancy is an erasure code of rate R and damage erases a "
    "fraction x of coded symbols, P<sub>code</sub>(x; R) is the probability that all information symbols are decoded "
    "from the survivors."))
story.append(P(
    "<b>Definition 3 (topological recoverability).</b> When organisation is encoded by single-linkage clustering of a "
    "point cloud, P<sub>topo</sub>(x) is the probability that the number of clusters at a fixed scale is unchanged by "
    "damage of severity x."))
story.append(P(
    "<b>Definition 4 (dynamical recoverability).</b> Let the damaged system evolve as x<sub>t+1</sub> = A x<sub>t</sub> + "
    "B<sub>a</sub> u<sub>t</sub>, where B<sub>a</sub> retains the surviving actuators after a fraction a is lost. The "
    "target is reachable in horizon T if the controllability matrix has rank n. P<sub>ctrl</sub>(a) is the fraction of "
    "actuator sets for which the target is reachable and the minimum input energy stays within κ times a reference."))
story.append(P(
    "<b>Definition 5 (thermodynamic floor).</b> Restoring b bits at temperature T costs at least W<sub>min</sub> = "
    "k<sub>B</sub> T ln 2 · b (Proposition 6)."))
story.append(P(
    "<b>The recoverability frontier.</b> Under an independence assumption, the composite success probability is "
    "P<sub>rec</sub>(x, a; R) = P<sub>code</sub>(x; R) · P<sub>topo</sub>(x) · P<sub>ctrl</sub>(a), and the frontier is the "
    "set of parameters where this is at least one half. Section 13 explains why the product is an approximation and "
    "not a derived result."))
story.append(EQ("𝔑 = { (x, a, R) : P<sub>rec</sub>(x, a; R) ≥ 1/2 }"))
story.append(P(
    "<b>Hypothesis H0 (composite threshold).</b> The layers jointly determine recoverability, and the frontier 𝔑 "
    "separates three regimes: information survives and function is restorable; information survives but no admissible "
    "control reaches the target; and observations no longer identify the target. We test the layers separately and "
    "test the composite only under the stated independence assumption."))

# ================================================================ 4
story.append(H1("4  Propositions"))
story.append(P(
    "Full proofs of Propositions 2 and 3 are in Appendix A. Propositions 1, 4, 5 and 6 are short and proved in place."))
story.append(P(
    "<b>Proposition 1 (monotonicity under damage).</b> If X<sub>x</sub> is obtained from X<sub>0</sub> by a damage "
    "channel that does not depend on Z, then I(Z; Y) ≤ I(Z; X<sub>x</sub>) ≤ I(Z; X<sub>0</sub>) for any observation "
    "Y = H(X<sub>x</sub>) + ε. Consequently D*(x) is non-decreasing in x."))
story.append(P(
    "<i>Proof.</i> The data-processing inequality states I(Z; g(W)) ≤ I(Z; W) for any measurable g when "
    "Z → W → g(W) is a Markov chain (Cover and Thomas 2006, Thm. 2.8.1). Because the damage does not depend on Z, the "
    "chain Z → X<sub>0</sub> → X<sub>x</sub> → Y is Markov, which gives both inequalities. A larger mutual information "
    "allows a smaller minimum distortion, so D* is non-decreasing in x. ∎"))
story.append(P(
    "<b>Proposition 2 (exact full-rank probability of random binary codes).</b> For a uniformly random k × n binary "
    "matrix G and a uniformly random set S of s columns, P(rank G<sub>S</sub> = k) equals"))
story.append(EQ("P<sub>full</sub>(k, s) = ∏<sub>i=0</sub><super>k−1</super> (1 − 2<super>i−s</super>)   for s ≥ k, and 0 otherwise."))
story.append(P(
    "Hence P<sub>full</sub> → 1 when s − k → +∞ and → 0 when s − k → −∞, so the erasure threshold of random linear codes "
    "of rate R is 1 − R in the large-n limit, the Shannon limit for the binary erasure channel (Shannon 1948)."))
story.append(P(
    "<b>Proposition 3 (generic reachability rank).</b> For x<sub>t+1</sub> = A x<sub>t</sub> + B u<sub>t</sub> with n states and "
    "m inputs, the horizon-T controllability matrix M = [A<super>T−1</super>B, …, B] has rank at most min(n, Tm). For generic "
    "(A, B) the rank equals min(n, Tm). The target is therefore generically reachable in horizon T if and only if Tm ≥ n, "
    "and the generic cliff is at m* = ⌈n/T⌉."))
story.append(P(
    "<b>Proposition 4 (minimum-energy steering).</b> If M has full row rank n, the minimum input energy Σ<sub>t</sub> ‖u<sub>t</sub>‖² "
    "that steers x<sub>0</sub> to z in horizon T is"))
story.append(EQ("E<sub>min</sub> = r<super>⊤</super> (M M<super>⊤</super>)<super>−1</super> r,   r = z − A<super>T</super> x<sub>0</sub>."))
story.append(P(
    "<i>Proof.</i> The terminal state is x<sub>T</sub> = A<super>T</super> x<sub>0</sub> + M u, with u the stacked inputs. The "
    "minimum-norm solution of M u = r is u* = M<super>⊤</super>(MM<super>⊤</super>)<super>−1</super> r, with ‖u*‖² = r<super>⊤</super>(MM<super>⊤</super>)<super>−1</super>r. "
    "Any other solution differs from u* by a component in the null space of M, which is orthogonal to u* and so only adds "
    "norm. ∎"))
story.append(P(
    "<b>Proposition 5 (more observations cannot hurt linear recovery).</b> For a Gaussian vector Z with covariance Σ and noisy "
    "observations on index sets S ⊆ S′, the LMMSE error tr(Σ − K<sub>S′</sub>) is no larger than tr(Σ − K<sub>S</sub>), where "
    "K<sub>S</sub> = Σ<sub>·S</sub>(Σ<sub>SS</sub> + σ²I)<super>−1</super>Σ<sub>S·</sub>."))
story.append(P(
    "<i>Proof.</i> K<sub>S</sub> is the covariance explained by observing S. Under Gaussian conditioning, explained covariance "
    "grows in the Loewner order as observations are added, so the residual trace shrinks. ∎"))
story.append(P(
    "<b>Proposition 6 (Landauer-type floor, stated as a bound).</b> Suppose a restoration process raises the information "
    "held about Z by b bits at isothermal temperature T, with the entropy reduction paid for by an environment. Then the "
    "work W satisfies W ≥ k<sub>B</sub> T ln 2 · b. This is the standard Landauer argument extended to information gain "
    "through the second law (Landauer 1961; Bennett 1982; Sagawa and Ueda 2008). It is a bound under explicit assumptions, "
    "and we do not claim that real processes operate near it."))

# ================================================================ 5
story.append(H1("5  Layer A: coding recoverability"))
story.append(P(
    "We take n = 48 coded symbols and rates R ∈ {0.25, 0.5, 0.75}, giving k = 12, 24 and 36 information symbols. For each "
    "erasure fraction ε from 0 to 0.9 in steps of 0.05 we draw 400 independent random binary codes, erase the stated "
    "fraction of symbols, and test whether the information is recovered by GF(2) elimination."))
story.append(FIGURE("fig02_erasure_recoverability",
                    "<b>Figure 2.</b> Full-recovery probability of random binary linear codes. (a) Monte Carlo estimates with "
                    "95% Wilson bands (points), exact closed form of Proposition 2 (dashed), and the Shannon limit 1 − R (dotted). "
                    "(b) Monte Carlo minus exact. Deviations are of the order of the sampling standard error at 400 trials, "
                    "at most 0.025."))
rows = [["Rate R", "Info. symbols k", "Measured 50% point", "Shannon limit 1 − R", "Max |MC − exact|"]]
for R in ["0.25", "0.5", "0.75"]:
    r = E1["rates"][R]
    rows.append([R, r["k"], fmt(r["e50"]), fmt(r["shannon_limit"], 2), fmt(r["max_abs_dev_theory"])])
story.append(TABLE(rows, [2.4, 3.0, 3.4, 3.6, 3.6]))
story.append(Spacer(1, 4))
story.append(P(
    "<b>Numerical result.</b> The measured 50% point lies within 0.03 of the Shannon limit at every rate. The Monte Carlo "
    "estimates agree with Proposition 2 across all 57 (rate, erasure) points, with the largest deviation 0.049, which is "
    "about two standard errors and within what sampling over 57 points produces. Redundancy is not free: the more of a "
    "unit's capacity goes to function, the smaller the damage it can survive. This is the trade-off the framework "
    "predicts, and here it is checked against an exact formula rather than an approximation."))

# ================================================================ 6
story.append(H1("6  Layer B: topological recoverability"))
story.append(P(
    "We sample N = 240 points from three Gaussian clusters, 80 points each, standard deviation 0.5, at the vertices of a "
    "triangle with sides about 4. Organisation is encoded by single-linkage clustering. At cut height 1.0 the intact data "
    "form three clusters of at least five points each. The largest within-cluster link is about 0.65 and the smallest "
    "between-cluster link about 1.23, so the cut sits in a clean gap. (A first attempt at cut 1.5 merged two clusters, "
    "which is why the cut was lowered; the choice was made from the intact data alone.) Damage removes a fraction d of "
    "points, optionally followed by Gaussian jitter of standard deviation 0.3 on the survivors. There are 300 trials per "
    "damage level."))
story.append(FIGURE("fig03_topological_recoverability",
                    "<b>Figure 3.</b> Topological recoverability of a three-cluster point cloud. (a) Probability that three "
                    "clusters of size at least five survive, with 95% bands. (b) Median largest merge height relative to the "
                    "intact value. (c) Snapshots at cut 1.0 after 0%, 50% and 85% deletion; colours are cluster labels."))
story.append(P(
    f"<b>Numerical result.</b> With deletion alone, the three-cluster signature survives with probability above 0.99 until "
    f"85% of points are removed, and falls to {TOPO0['p_preserved'][-1]:.2f} at 90% deletion. The 90%-preservation point is at "
    f"d = {TOPO_D90:.2f}. The largest persistence scale grows as points disappear, because clusters that lose members spread "
    f"out, so the largest merge height reaches {TOPO0['median_top_ratio'][-1]:.2f} times its intact value at 90% deletion."))
story.append(P(
    f"<b>Negative finding.</b> Jitter of 0.3 on the survivors breaks the signature even when nothing is deleted: the "
    f"preservation probability is {S['E2_P_zero_deletion_with_jitter']:.2f} at d = 0. The cut of 1.0 was chosen for clean "
    "data, and jitter fills the gap between clusters. As deletion increases, the jitter curve rises, because thinner clusters "
    "are better separated relative to the noise. The practical lesson is that a topological invariant is meaningful only "
    "relative to a scale calibrated to the measurement noise of the particular system. Any comparison of a damaged state "
    "with an intact one must recalibrate the cut from data first."))

# ================================================================ 7
story.append(H1("7  Layer C: control reachability and energy"))
story.append(P(
    "We build a random stable linear system with n = 20 states and spectral radius 0.9, with ten candidate actuators and "
    "horizon T = 8. For each number of active actuators m from 1 to 10 we sample 30 actuator sets and, for every reachable "
    "set, 10 random pairs of initial and target states. A set is reachable when the controllability matrix has rank n. We "
    "record the minimum input energy of Proposition 4, normalised by the median energy with all ten actuators. A set "
    "succeeds when it is reachable and its mean energy is at most twice that reference."))
story.append(FIGURE("fig04_control_reachability",
                    "<b>Figure 4.</b> Control reachability as actuators are lost. (a) Fraction of actuator sets that are "
                    "reachable (step) and fraction that succeed (points). The dotted line marks the generic cliff m* = ⌈n/T⌉ = 3. "
                    "(b) Median minimum energy relative to full actuation, log scale."))
rows = [["Active actuators m", "Actuator loss a", "Reachable fraction", "Success fraction", "Median energy / reference"]]
for m, a, rf, sf in zip(E3["m"], E3["actuator_loss"], E3["reach_frac"], E3["success_frac"]):
    c = ROW_MEDIAN[m]
    rows.append([m, fmt(a, 1), fmt(rf, 2), fmt(sf, 2), "undefined (unreachable)" if c is None else fmt(c, 2)])
story.append(TABLE(rows, [3.0, 3.0, 3.2, 3.2, 3.6]))
story.append(Spacer(1, 4))
story.append(P(
    f"<b>Numerical result.</b> The reachability rank matches Proposition 3. No set with m ≤ 2 is reachable and every set with "
    f"m ≥ 3 is, so the cliff sits at m* = ⌈20/8⌉ = 3. Reachability is therefore a discrete property in this system, while "
    f"energy is continuous and steep near the cliff: at m = 3 the median energy is {ROW_MEDIAN[3]:.0f} times the full-actuation "
    f"reference. Success is exceeded half the time only with at least eight actuators remaining. The consequence for "
    "practice is that a system can be controllable in principle and still be unrecoverable in practice, because the energy "
    "budget is exceeded well before the rank condition fails."))

# ================================================================ 8
story.append(H1("8  Layer D: information from partial observation"))
story.append(P(
    "The damaged state is modelled as a stationary Gaussian vector Z in ℝ<super>40</super> with unit variance and correlation "
    "Σ<sub>ij</sub> = ρ<super>|i−j|</super>. It is observed on a random subset of coordinates with noise variance 0.1. The "
    "normalised LMMSE error D(o, ρ) is averaged over 40 random subsets for each observed fraction o. Proposition 5 implies that "
    "adding observations cannot increase D. We report the observed fraction needed for D ≤ 0.2 across correlation strengths "
    "from 0 to 0.98."))
story.append(FIGURE("fig05_information_recoverability",
                    "<b>Figure 5.</b> Information recoverability from partial observation. (a) Normalised LMMSE error against "
                    "observed fraction for three correlation strengths; the dotted line marks D = 0.2. (b) Observed fraction "
                    "needed to reach D ≤ 0.2, as a function of correlation strength."))
rows = [["Correlation ρ", "Observed fraction for D ≤ 0.2", "Interpretation"],
        ["0.2", pct(RHO["0.2"]["o_for_D0.2"]), "weakly structured: most coordinates needed"],
        ["0.6", pct(RHO["0.6"]["o_for_D0.2"]), "moderately structured"],
        ["0.9", pct(RHO["0.9"]["o_for_D0.2"]), "strongly structured: under half needed"]]
story.append(TABLE(rows, [3.2, 4.8, 8.0]))
story.append(Spacer(1, 4))
story.append(P(
    f"<b>Numerical result.</b> Structure lowers the observation requirement. A strongly correlated system can be estimated "
    f"accurately from less than half its coordinates, whereas a weakly correlated one needs about "
    f"{pct(RHO['0.2']['o_for_D0.2'])}. At ρ = 0.98 the requirement falls to "
    f"{pct(E4['o_needed_for_D0.2'][-1])}, as Figure 5(b) shows. This supports the view that "
    "recoverability depends on joint structure, not on the amount of damage alone. The result holds for Gaussian linear "
    "estimation with known covariance, a strong assumption discussed in Section 13."))

# ================================================================ 9
story.append(H1("9  Layer E: thermodynamic floor"))
story.append(P(
    "For a unit-variance Gaussian coordinate, reducing the normalised error to D requires at least ½ log<sub>2</sub>(1/D) "
    "bits per coordinate (Gaussian rate–distortion; Berger 1971). Multiplying by k<sub>B</sub> T ln 2 at T = 310 K gives a "
    "Landauer-type energy floor (Proposition 6). This is a floor, not a prediction of cost, and it does not depend on the "
    "mechanism that supplies the bits."))
story.append(FIGURE("fig06_thermodynamic_floor",
                    "<b>Figure 6.</b> Thermodynamic floor for restoring information. (a) Bits per coordinate needed for a target "
                    "normalised error D. (b) Total floor for n = 40 coordinates at 310 K in joules, log scale. The floor is a "
                    "lower bound; no mechanism is assumed."))
story.append(P(
    f"<b>Numerical result.</b> For D = 0.2 the requirement is {S['E5_bits_at_D0.2']:.3f} bits per coordinate. At 310 K this "
    f"corresponds to k<sub>B</sub>T ln 2 = {S['E5_kTln2_J_310K']:.2e} J, so about {S['E5_bits_at_D0.2'] * S['E5_kTln2_J_310K'] * 40:.1e} J "
    "for 40 coordinates. For scale, the free energy of one ATP hydrolysis is roughly 8 × 10<super>−20</super> J, about thirty "
    "times this floor per bit. The floor therefore does not constrain restoration at these scales. The binding constraints in "
    "this framework are the reachability and energy conditions of Layer C. Real physical costs are set by dissipation far above "
    "the floor (Seifert 2012; Parrondo, Horowitz and Sagawa 2015)."))

# ================================================================ 10
story.append(H1("10  The composite recoverability frontier"))
story.append(P(
    "We combine Layers A, B and C under the independence assumption of Section 3: P<sub>rec</sub>(x, a; R) = "
    "P<sub>code</sub>(x; R) · P<sub>topo</sub>(x) · P<sub>ctrl</sub>(a). Damage x is shared by the code and the point cloud, and "
    "actuator loss a enters through the control layer. Figure 7 shows the composite surface at R = 0.5 and the critical damage "
    "x*(a) for three code rates, where x*(a) is the largest damage with composite probability at least one half."))
story.append(FIGURE("fig07_recoverability_frontier",
                    "<b>Figure 7.</b> The composite recoverability frontier under the independence assumption. (a) Composite "
                    "probability over damage x and actuator loss a at R = 0.5; the white contour is the one-half level. (b) "
                    "Critical damage x*(a) for R = 0.25, 0.5 and 0.75. A value of 0 means no damage level is safe at that "
                    "actuator loss."))
story.append(P(
    f"<b>Numerical result.</b> At full actuation the critical damage is {FR['0.25']['frontier_x_at_a'][0]:.2f}, "
    f"{FR['0.5']['frontier_x_at_a'][0]:.2f} and {FR['0.75']['frontier_x_at_a'][0]:.2f} for R = 0.25, 0.5 and 0.75, roughly "
    "tracking 1 − R. The composite is set by the weakest layer. Topology is not limiting at these damage levels; control is. "
    f"From an actuator loss of 0.3 onward no damage level is safe, because success falls below one half at all damage "
    "levels. The frontier position is therefore governed by a discrete event, and that is the main structural finding of the "
    "composite analysis."))
story.append(P(
    "This result must be read with the caveat of Section 13. The three layers were evaluated in separate simulations, and the "
    "product is correct only if the events are independent, which nothing guarantees. A joint simulation in which one damage "
    "process acts on the code, the point cloud and the actuators together is needed before the frontier can be treated as more "
    "than an illustrative composition."))
rows = [["Layer", "Quantity", "Critical value", "Source"],
        ["A  Coding", "erasure fraction at 50% recovery (R = 0.5)", fmt(E1["rates"]["0.5"]["e50"]), "E1"],
        ["B  Topology", "deletion fraction at 90% preservation", fmt(TOPO_D90), "E2"],
        ["C  Control", "largest actuator loss with success ≥ 0.5", fmt(CTRL_TH, 2), "E3"],
        ["D  Information", "observed fraction for D ≤ 0.2 (ρ = 0.9)", pct(RHO["0.9"]["o_for_D0.2"]), "E4"],
        ["E  Floor", "bits per coordinate at D = 0.2", fmt(S["E5_bits_at_D0.2"]), "E5"]]
story.append(TABLE(rows, [3.2, 7.0, 3.0, 2.2]))
story.append(P("<b>Table.</b> Critical value of each layer, each taken from its own experiment.", cap))

# ================================================================ 11
story.append(H1("11  Predictions, status and falsification"))
story.append(P(
    "The table below records each hypothesis with its status after the experiments. Hypotheses that failed stay in the table, and the "
    "status column says what the evidence supports. The status is deliberately conservative."))
rows = [["#", "Hypothesis", "Status"],
        ["H1", "Random binary code recovery matches the closed form of Proposition 2",
         "Supported. Max deviation 0.049 over 57 points, consistent with 400-trial sampling error"],
        ["H2", "Three-cluster topology survives moderate deletion", "Supported to about 87% deletion"],
        ["H3", "Fixed-scale topology is robust to measurement jitter",
         f"Falsified. Preservation {S['E2_P_zero_deletion_with_jitter']:.2f} at zero deletion with jitter 0.3"],
        ["H4", "Reachability requires m ≥ ⌈n/T⌉ actuators", "Supported. Cliff at m = 3 as predicted"],
        ["H5", "Energy cost rises steeply as actuators are lost",
         f"Supported. About {ROW_MEDIAN[3]:.0f}× reference at m = 3, 1.0× at m = 10"],
        ["H6", "Structure lowers the observed fraction needed for estimation",
         f"Supported. {pct(RHO['0.2']['o_for_D0.2'])} at ρ = 0.2 down to {pct(RHO['0.9']['o_for_D0.2'])} at ρ = 0.9"],
        ["H7", "The composite frontier governs joint recoverability", "Untested end to end. Illustrative only"],
        ["H8", "The Landauer-type floor constrains restoration cost",
         "Stated as a bound. Not constraining at these scales. Not tested in a physical system"]]
story.append(TABLE(rows, [1.0, 7.0, 8.0]))
story.append(Spacer(1, 4))
story.append(P(
    "H1 and H4 are proved and checked numerically. H2, H5 and H6 are numerical results within the stated models. H3 was "
    "expected to hold and did not. H7 and H8 remain open. Falsifiability is built in: each hypothesis names a measurement "
    "that would contradict it."))

# ================================================================ 12
story.append(H1("12  Reproducibility"))
story.append(P(
    "All results come from <font face='Mono'>code/recoverability_experiments.py</font>, which uses NumPy, SciPy and Matplotlib "
    "with one random generator seeded with 20261108. It writes JSON results to <font face='Mono'>results/</font> and figures to "
    "<font face='Mono'>figures/</font> in both PNG and SVG. <font face='Mono'>code/build_paper.py</font> reads those files and "
    "produces this PDF, so every number in the text is taken from the same run. Runtime on a single CPU core is a few minutes, "
    "dominated by the topology experiment. Appendix B lists every parameter."))

# ================================================================ 13
story.append(H1("13  Limitations"))
for t in [
    "<b>Stylised models.</b> All systems are abstract and dimensionless. Nothing here fits biological data, and no numerical value "
    "should be read as a prediction for any organism.",
    "<b>Independence.</b> The composite frontier multiplies three probabilities measured in separate simulations. A joint simulation "
    "is needed to know how far the true joint probability departs from the product.",
    "<b>Gaussian and linear assumptions.</b> Layer D assumes Gaussian statistics and linear observation with known covariance. Layer C "
    "assumes linear dynamics with known matrices. Real systems are nonlinear and their parameters must be estimated.",
    "<b>Sample sizes.</b> Monte Carlo estimates use 300 to 400 trials per point and 30 actuator sets, so differences smaller than a few "
    "percent are not resolved. Bands in the figures show sampling uncertainty only, not model uncertainty.",
    "<b>Topology.</b> Single-linkage clustering at a fixed scale is one invariant among many. Its dependence on the cut is shown in the "
    "jitter result, and other invariants may behave differently.",
    "<b>Literature.</b> The search was not exhaustive. Novelty is claimed only to our knowledge, and parts of the composition may exist elsewhere.",
    "<b>Connection to experiment.</b> A biological test would need to measure information content, reachability and energy in a living "
    "system, which none of the models provides. Section 14 outlines what such a test would require."]:
    story.append(P(t))

# ================================================================ 14
story.append(H1("14  Discussion"))
story.append(P(
    "The results support a three-part picture. Coding sets how much damage a representation tolerates, and it does so with a "
    "sharp threshold that follows the rate. Structure, measured as correlation or as the topological organisation of a cloud, "
    "sets how much information a partial observation carries. Control sets whether any admissible action can reach the target, "
    "and it does so with a discrete cliff followed by a steep cost. In the models studied, the discrete reachability event sets the frontier more strongly "
    "than information loss does over the range tested. The physical floor is far below the other costs."))
story.append(P(
    "Three things follow for research design. First, recoverability should be measured in the three currencies together: how "
    "much information survives, how much of the control space survives, and what the restoration costs. Measuring one of them "
    "alone can mislead. Second, topological and other structural summaries must be calibrated to measurement noise before "
    "comparison, as the jitter result shows. Third, the most informative failures here were the hypothesis that jitter would not "
    "matter and the expectation that the composite would be a smooth function. Both were overturned by the numbers."))
story.append(P(
    "We wish to be explicit about what these results do not say. They do not show that any damaged organism, tissue or person can "
    "be restored, that identity can be preserved or recovered, or that any intervention would achieve function. They describe "
    "conditions under which an abstract information state is recoverable in a stylised model. Any statement about living systems "
    "requires a separate experiment with its own measurements, controls and ethical review. A minimal first step, outside the scope of "
    "this paper, would be to measure information retention, reachability and energy in a model organism under controlled damage, "
    "with pre-registered criteria for success and failure."))

# ================================================================ 15
story.append(H1("15  Conclusion"))
story.append(P(
    "We formalised recoverability of damaged information-bearing systems as five layers, proved six propositions, and checked each "
    "layer numerically. The coding threshold, the topological signature under deletion, the reachability cliff, the dependence of "
    "estimation on structure and the thermodynamic floor are all reproducible from one script. Two findings are negative or "
    "cautionary: fixed-scale topology is fragile to noise, and the composite frontier is governed by a discrete control event. The "
    "composite conjecture remains untested end to end, and the next step is a joint simulation. The framework is a tool for asking "
    "where recoverability ends, and it is deliberately silent on whether any living system can be brought back."))

# ============================================================ Appendix A
story.append(H1("Appendix A  Proof details"))
story.append(P(
    "<b>Proof of Proposition 2.</b> Let the k rows of G<sub>S</sub> be r<sub>1</sub>, …, r<sub>k</sub>. Each is uniform on "
    "F<sub>2</sub><super>s</super> and independent of the others. The probability that r<sub>1</sub>, …, r<sub>k</sub> are linearly "
    "independent is found sequentially: given independence of the first i vectors, they span a subspace of size 2<super>i</super>, "
    "so r<sub>i+1</sub> must avoid that subspace, which has probability 1 − 2<super>i−s</super>. Multiplying over i = 0, …, k−1 gives "
    "the stated product. If s < k the rows cannot be independent. The limits follow because each factor tends to 1 when s − k grows, "
    "and the union bound gives P<sub>full</sub> ≥ 1 − 2<super>k−s</super>. The Monte Carlo check in Figure 2 uses "
    "independent draws of G and S, so the sampled and exact probabilities are directly comparable. ∎"))
story.append(P(
    "<b>Proof sketch of Proposition 3.</b> The bound rank M ≤ Tm holds because M has Tm columns, and rank M ≤ n because M has n "
    "rows. For genericity, rank M is at least r exactly when some r × r minor of M is nonzero. Each minor is a polynomial in the "
    "entries of (A, B). A polynomial that is nonzero at one point is nonzero on a dense open set, so it suffices to exhibit one "
    "pair (A, B) with rank min(n, Tm). Taking A a cyclic shift and B the first min(m, n) unit vectors gives that pair, which is the "
    "standard Kalman example. The numerical cliff in Figure 4 is consistent with this, since the rank changes exactly at m = 3 for "
    "n = 20 and T = 8. ∎"))

# ============================================================ Appendix B
story.append(H1("Appendix B  Parameter table"))
rows = [["Experiment", "Parameter", "Value"],
        ["E1 codes", "information symbols; coded symbols; rates; erasure grid", "k = 12, 24, 36; n = 48; R = 0.25, 0.5, 0.75; 0 to 0.9 step 0.05"],
        ["E1 sampling", "trials per point; code ensemble", "400; fresh uniform random binary matrix per trial"],
        ["E2 cloud", "clusters; points per cluster; centres; standard deviation", "3; 80; (0,0), (4,0), (2,3.5); 0.5"],
        ["E2 signature", "linkage; cut; minimum cluster size", "single linkage; 1.0; 5"],
        ["E2 damage", "deletion grid; jitter; trials", "0 to 0.9 step 0.05; 0 and 0.3; 300"],
        ["E3 system", "states n; actuators m_full; horizon T; spectral radius", "20; 10; 8; 0.9"],
        ["E3 sampling", "actuator sets per m; targets per set; success factor κ", "30; 10; 2"],
        ["E4 model", "states; noise variance; correlation ρ; observed fraction grid", "40; 0.1; 0.2, 0.6, 0.9 (and 0 to 0.98); 0.05 to 1.0"],
        ["E4 sampling", "random subsets per estimate", "40"],
        ["E5 floor", "temperature; coordinates in energy total", "310 K; n = 40"],
        ["Seed", "single generator", "20261108 (NumPy default_rng)"]]
story.append(TABLE(rows, [3.2, 6.6, 6.2]))

# ============================================================ References
story.append(H1("References"))
refs = [
    "Berger T (1971) Rate Distortion Theory. Prentice-Hall.",
    "Bennett CH (1982) The thermodynamics of computation: a review. Int J Theor Phys 21:905–940.",
    "Carlsson G (2009) Topology and data. Bull Am Math Soc 46:255–308.",
    "Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd edn. Wiley.",
    "Edelsbrunner H, Letscher D, Zomorodian A (2002) Topological persistence and simplification. Discrete Comput Geom 28:511–533.",
    "Josselyn SA, Tonegawa S (2020) Memory engrams: recalling the past and imagining the future. Science 367:eaaw4325.",
    "Kalman RE (1963) Mathematical description of linear dynamical systems. J SIAM Control 1:152–192.",
    "Landauer R (1961) Irreversibility and heat generation in the computing process. IBM J Res Dev 5:183–191.",
    "Parrondo JMR, Horowitz JM, Sagawa T (2015) Thermodynamics of information. Nat Phys 11:131–139.",
    "Richardson TJ, Urbanke RL (2008) Modern Coding Theory. Cambridge University Press.",
    "Sagawa T, Ueda M (2008) Second law of thermodynamics with discrete quantum feedback control. Phys Rev Lett 100:080403.",
    "Seifert U (2012) Stochastic thermodynamics, fluctuation theorems and molecular machines. Rep Prog Phys 75:126001.",
    "Shannon CE (1948) A mathematical theory of communication. Bell Syst Tech J 27:379–423, 623–656.",
    "Sontag ED (1998) Mathematical Control Theory, 2nd edn. Springer.",
    "Vrselja Z, Daniele SG, Silbereis J, et al. (2019) Restoration of brain circulation and cellular functions hours post-mortem. Nature 568:336–343.",
    "Zomorodian A, Carlsson G (2005) Computing persistent homology. Discrete Comput Geom 33:249–274.",
]
for r in refs:
    story.append(P(r, small))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Sans", 7)
    canvas.setFillColor(GREY)
    canvas.drawString(2.0 * cm, 1.2 * cm,
                      "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 8 Nov 2026")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"{doc.page}")
    canvas.restoreState()


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2.0 * cm, rightMargin=2.0 * cm,
                            topMargin=1.8 * cm, bottomMargin=1.9 * cm,
                            title="The Recoverability Frontier of Damaged Information-Bearing Systems",
                            author="Devanik Debnath; Xylia", subject="Preprint v1.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print("wrote", OUT)
