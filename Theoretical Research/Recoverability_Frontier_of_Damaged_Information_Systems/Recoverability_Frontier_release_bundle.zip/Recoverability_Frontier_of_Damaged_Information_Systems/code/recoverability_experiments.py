#!/usr/bin/env python3
"""
The Recoverability Frontier of Damaged Information-Bearing Systems
Reproducible numerical experiments (fixed seed, deterministic).

Run:  python recoverability_experiments.py
Writes results/*.json and figures/*.png + figures/*.svg in the parent folder.

Scope: abstract, stylised systems only. Nothing here models a living organism,
a human, or personal identity.
"""
import json
import math
import os

import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
os.makedirs(RES, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

SEED = 20261108
rng = np.random.default_rng(SEED)
TRIALS_CODE = 400
TRIALS_TOPO = 300
KB = 1.380649e-23   # Boltzmann constant, J/K
TEMP = 310.0        # reference temperature, K

plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "legend.fontsize": 7.5, "figure.dpi": 110})
C1, C2, C3, C4 = "#1f4e79", "#c0504d", "#4f8f3a", "#8064a2"


# ----------------------------------------------------------------- utilities
def wilson(k, n, z=1.96):
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, c - h), min(1.0, c + h)


def crossing(x, y, level):
    """x where y first crosses `level` (linear interpolation); NaN if never."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    for i in range(len(y) - 1):
        if (y[i] - level) * (y[i + 1] - level) <= 0 and y[i] != y[i + 1]:
            t = (level - y[i]) / (y[i + 1] - y[i])
            return float(x[i] + t * (x[i + 1] - x[i]))
    return float("nan")


def first_at_or_below(x, y, level):
    for xi, yi in zip(x, y):
        if yi <= level:
            return float(xi)
    return float("nan")


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=160, bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".svg"), bbox_inches="tight")
    plt.close(fig)


def dump(obj, name):
    with open(os.path.join(RES, name + ".json"), "w") as f:
        json.dump(obj, f, indent=2)


# --------------------------------------------- E1: erasure recoverability
def rank_bits(rows):
    """GF(2) rank of a list of integers read as bit-vectors."""
    basis, r = {}, 0
    for v in rows:
        while v:
            p = v.bit_length() - 1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                r += 1
                break
    return r


def erasure_success(k, n, s, gen):
    G = gen.integers(0, 2, size=(k, n), dtype=np.int64)  # fresh random code
    S = gen.choice(n, size=s, replace=False)             # surviving symbols
    w = np.left_shift(np.int64(1), np.arange(s, dtype=np.int64))
    return rank_bits((G[:, S] @ w).tolist()) == k


def theory_full_rank(k, s):
    """Exact P(uniform random k x s binary matrix has full row rank)."""
    if s < k:
        return 0.0
    p = 1.0
    for i in range(k):
        p *= 1 - 2.0 ** (i - s)
    return p


def run_erasure(n=48):
    e_grid = np.round(np.linspace(0, 0.9, 19), 2)
    out = {"n": n, "e": e_grid.tolist(), "rates": {}}
    for R in [0.25, 0.5, 0.75]:
        k = int(round(R * n))
        p, lo, hi, th = [], [], [], []
        for e in e_grid:
            s = n - int(round(e * n))
            ok = sum(erasure_success(k, n, s, rng) for _ in range(TRIALS_CODE))
            a, b = wilson(ok, TRIALS_CODE)
            p.append(ok / TRIALS_CODE)
            lo.append(a)
            hi.append(b)
            th.append(theory_full_rank(k, s))
        out["rates"][str(R)] = {
            "k": k, "p": p, "lo": lo, "hi": hi, "theory": th,
            "e50": crossing(e_grid, p, 0.5),
            "shannon_limit": round(1 - R, 4),
            "max_abs_dev_theory": float(np.max(np.abs(np.array(p) - np.array(th)))),
        }
    return out


# -------------------------------------------- E2: topological recoverability
def cluster_cloud(gen):
    centers = np.array([[0.0, 0.0], [4.0, 0.0], [2.0, 3.5]])
    return np.vstack([c + 0.5 * gen.standard_normal((80, 2)) for c in centers])


def topo_signature(X, cut=1.0, minsize=5):
    """Number of single-linkage clusters of size >= minsize at scale `cut`,
    and the largest merge height (the widest persistent H0 gap)."""
    Z = linkage(X, method="single")
    lab = fcluster(Z, t=cut, criterion="distance")
    sizes = np.bincount(lab)[1:]
    return int(np.sum(sizes >= minsize)), float(np.max(Z[:, 2]))


def run_topology(X0):
    N = len(X0)
    grid = np.round(np.linspace(0, 0.9, 19), 2)
    orig_sig, orig_top = topo_signature(X0)
    out = {"N": N, "original_clusters": orig_sig,
           "original_top_merge": orig_top, "d": grid.tolist(), "modes": {}}
    for sigma in [0.0, 0.3]:
        pres, lo, hi, ratio = [], [], [], []
        for d in grid:
            k = int(round((1 - d) * N))
            ok, tops = 0, []
            for _ in range(TRIALS_TOPO):
                idx = rng.choice(N, size=k, replace=False)
                Xd = X0[idx] + sigma * rng.standard_normal((k, 2))
                sig, top = topo_signature(Xd)
                ok += int(sig == orig_sig)
                tops.append(top)
            a, b = wilson(ok, TRIALS_TOPO)
            pres.append(ok / TRIALS_TOPO)
            lo.append(a)
            hi.append(b)
            ratio.append(float(np.median(tops) / orig_top))
        out["modes"][str(sigma)] = {
            "p_preserved": pres, "lo": lo, "hi": hi,
            "median_top_ratio": ratio,
            "d90": crossing(grid, pres, 0.9),
        }
    return out


# ------------------------------------------------ E3: control reachability
def run_control(n=20, m_full=10, T=8, n_sets=30, n_targets=10):
    A = rng.standard_normal((n, n))
    A *= 0.9 / np.max(np.abs(np.linalg.eigvals(A)))
    B = rng.standard_normal((n, m_full))
    B /= np.linalg.norm(B, axis=0)
    P = [np.linalg.matrix_power(A, p) for p in range(T + 1)]
    AT = P[T]
    records = {}
    for m in range(1, m_full + 1):
        reach, costs = [], []
        for _ in range(n_sets):
            idx = rng.choice(m_full, size=m, replace=False)
            Bm = B[:, idx]
            M = np.hstack([P[T - 1 - t] @ Bm for t in range(T)])
            if np.linalg.matrix_rank(M) < n:
                reach.append(0.0)
                costs.append(float("nan"))
                continue
            reach.append(1.0)
            G = M @ M.T
            cs = []
            for _ in range(n_targets):
                x0 = rng.standard_normal(n)
                z = rng.standard_normal(n)
                r = z - AT @ x0
                cs.append(float(r @ np.linalg.solve(G, r)))
            costs.append(float(np.mean(cs)))
        records[m] = {"reach": reach, "cost": costs}
    c_ref = float(np.nanmedian(records[m_full]["cost"]))
    kappa = 2.0
    out = {"n": n, "m_full": m_full, "T": T,
           "generic_cliff_m": math.ceil(n / T),
           "C_ref": c_ref, "kappa": kappa,
           "m": [], "reach_frac": [], "success_frac": [],
           "median_norm_cost": [], "actuator_loss": []}
    for m in range(1, m_full + 1):
        reach = records[m]["reach"]
        costs = np.array(records[m]["cost"])
        ok = [(not math.isnan(c)) and c <= kappa * c_ref for c in costs]
        finite = costs[~np.isnan(costs)]
        out["m"].append(m)
        out["reach_frac"].append(float(np.mean(reach)))
        out["success_frac"].append(float(np.mean(ok)))
        out["median_norm_cost"].append(
            float(np.median(finite) / c_ref) if len(finite) else float("nan"))
        out["actuator_loss"].append(round(1 - m / m_full, 2))
    return out


# ------------------------------------------ E4: linear information recovery
def lmmse_D(Sigma, S, noise):
    """Normalised LMMSE error of a Gaussian vector from noisy coordinates S."""
    n = Sigma.shape[0]
    if len(S) == 0:
        return float(np.trace(Sigma) / n)
    SS = Sigma[np.ix_(S, S)] + noise * np.eye(len(S))
    K = Sigma[:, S] @ np.linalg.solve(SS, Sigma[S, :])
    return float(np.trace(Sigma - K) / n)


def mean_D(Sigma, o, noise, draws, n):
    m = max(1, int(round(o * n)))
    return float(np.mean([lmmse_D(Sigma, rng.choice(n, size=m, replace=False), noise)
                          for _ in range(draws)]))


def run_information(n=40, noise=0.1, draws=40):
    idx = np.arange(n)
    o_grid = np.round(np.linspace(0.05, 1.0, 20), 3)
    out = {"n": n, "noise": noise, "o": o_grid.tolist(), "rho": {}}
    for rho in [0.2, 0.6, 0.9]:
        Sigma = rho ** np.abs(idx[:, None] - idx[None, :]).astype(float)
        D = [mean_D(Sigma, o, noise, draws, n) for o in o_grid]
        out["rho"][str(rho)] = {"D": D,
                                "o_for_D0.2": first_at_or_below(o_grid, D, 0.2)}
    rho_scan = np.round(np.linspace(0.0, 0.98, 13), 2)
    need = []
    for rho in rho_scan:
        Sigma = rho ** np.abs(idx[:, None] - idx[None, :]).astype(float)
        D = [mean_D(Sigma, o, noise, draws, n) for o in o_grid]
        need.append(first_at_or_below(o_grid, D, 0.2))
    out["rho_scan"] = rho_scan.tolist()
    out["o_needed_for_D0.2"] = need
    return out


# ----------------------------------------------- E5: thermodynamic floor
def run_thermo():
    D = np.round(np.linspace(0.05, 0.95, 19), 3)
    bits = 0.5 * np.log2(1.0 / D)          # Gaussian rate-distortion, per coordinate
    kTln2 = KB * TEMP * math.log(2)
    per_coord_J = bits * kTln2
    return {"D": D.tolist(), "bits_per_coordinate": bits.tolist(),
            "kTln2_J": kTln2, "per_coordinate_J": per_coord_J.tolist(),
            "total_J_n40": (40 * per_coord_J).tolist(), "temperature_K": TEMP}


# ------------------------------------------- E6: composite frontier
def frontier_x(x, col):
    """Largest damage x with P >= 0.5 (0 if never safe, max if never unsafe)."""
    col = np.asarray(col, float)
    if col[0] < 0.5:
        return 0.0
    if np.all(col >= 0.5):
        return float(x[-1])
    return crossing(x, col, 0.5)


def run_frontier(code, topo, ctrl):
    x_grid = np.array(code["e"])
    a_grid = np.array(ctrl["actuator_loss"])
    Pt = np.array(topo["modes"]["0.0"]["p_preserved"])
    order = np.argsort(a_grid)                 # ascending actuator loss
    a_grid = a_grid[order]
    Ps = np.array(ctrl["success_frac"])[order]
    out = {"x": x_grid.tolist(), "a": a_grid.tolist(), "rates": {}}
    for R, rec in code["rates"].items():
        Pc = np.array(rec["p"])
        M = np.outer(Pc * Pt, Ps)            # rows: damage x, cols: actuator loss a
        frontier = [frontier_x(x_grid, M[:, j]) for j in range(len(a_grid))]
        out["rates"][R] = {"frontier_x_at_a": frontier,
                           "composite_at_zero_damage": float(M[0, 0]),
                           "matrix": M.tolist()}
    out["composite_R0.5"] = out["rates"]["0.5"]["matrix"]
    return out


# ================================================================ figures
def box(ax, x, y, w, h, text, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05",
                                fc=color, ec="#333", lw=0.8, alpha=0.92))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=7.4)


def arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="->", lw=0.9, color="#333"))


def fig_architecture():
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    box(ax, 0.2, 4.8, 2.6, 0.9, "Intact system $X_0$\nunits, links, controls", "#dbe5f1")
    box(ax, 3.7, 4.8, 2.6, 0.9, "Damage $\\mathcal{D}$\nerasure / deletion / loss", "#f2dcdb")
    box(ax, 7.2, 4.8, 2.6, 0.9, "Partial observation $Y$\n+ measurement noise", "#ebf1de")
    arrow(ax, 2.8, 5.25, 3.7, 5.25)
    arrow(ax, 6.3, 5.25, 7.2, 5.25)
    box(ax, 0.2, 3.0, 2.6, 1.0, "A  Coding\nerasure decodability\n$P_{\\rm code}(x;R)$", "#fde9d9")
    box(ax, 3.7, 3.0, 2.6, 1.0, "B  Topology\npersistent clusters\n$P_{\\rm topo}(x)$", "#e4dfec")
    box(ax, 7.2, 3.0, 2.6, 1.0, "C  Control\nreachability, energy\n$P_{\\rm ctrl}(a)$", "#daeef3")
    arrow(ax, 1.5, 4.8, 1.5, 4.0)
    arrow(ax, 5.0, 4.8, 5.0, 4.0)
    arrow(ax, 8.5, 4.8, 8.5, 4.0)
    box(ax, 0.2, 1.4, 4.8, 1.0, "D  Information\nLMMSE error vs observed fraction $D(o,\\rho)$", "#fdeada")
    box(ax, 5.2, 1.4, 4.6, 1.0, "E  Thermodynamic floor\n$\\geq k_B T\\ln 2$ per bit restored", "#e6e0ec")
    arrow(ax, 2.6, 3.0, 2.6, 2.4)
    arrow(ax, 7.5, 3.0, 7.5, 2.4)
    box(ax, 1.2, 0.05, 7.6, 0.95,
        "Recoverability frontier: the region where A, B and C hold jointly;\n"
        "D and E bound what information and cost are required", "#ffffff")
    arrow(ax, 5.0, 1.4, 5.0, 1.0)
    save(fig, "fig01_architecture")


def fig_erasure(code):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    e = np.array(code["e"])
    cols = {"0.25": C1, "0.5": C2, "0.75": C3}
    for R, rec in code["rates"].items():
        col = cols[R]
        ax[0].plot(e, rec["p"], "o-", ms=3, color=col, label=f"R={R} (k={rec['k']})")
        ax[0].fill_between(e, rec["lo"], rec["hi"], color=col, alpha=0.15)
        ax[0].plot(e, rec["theory"], "--", color=col, lw=0.9)
        ax[0].axvline(rec["shannon_limit"], color=col, ls=":", lw=0.9)
        ax[1].plot(e, np.array(rec["p"]) - np.array(rec["theory"]), "o-", ms=2.5,
                   color=col, label=f"R={R}")
    ax[0].set_xlabel("erasure fraction $\\varepsilon$")
    ax[0].set_ylabel("P(full recovery)")
    ax[0].set_title("(a) Recovery vs damage (dashed: exact; dotted: $1-R$)")
    ax[0].legend(loc="lower left")
    ax[1].axhline(0, color="k", lw=0.6)
    ax[1].set_xlabel("erasure fraction $\\varepsilon$")
    ax[1].set_ylabel("Monte Carlo minus exact")
    ax[1].set_title("(b) Agreement with the closed form")
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig02_erasure_recoverability")


def fig_topology(X0, topo):
    fig, ax = plt.subplots(1, 3, figsize=(7.8, 2.8))
    d = np.array(topo["d"])
    for sigma, col, lab in [("0.0", C1, "deletion only"), ("0.3", C2, "deletion + jitter 0.3")]:
        m = topo["modes"][sigma]
        ax[0].plot(d, m["p_preserved"], "o-", ms=3, color=col, label=lab)
        ax[0].fill_between(d, m["lo"], m["hi"], color=col, alpha=0.15)
        ax[1].plot(d, m["median_top_ratio"], "s-", ms=3, color=col, label=lab)
    ax[0].axhline(0.5, color="grey", ls=":", lw=0.8)
    ax[0].set_xlabel("damage fraction (points removed)")
    ax[0].set_ylabel("P(3 clusters preserved)")
    ax[0].set_title("(a) Topological preservation")
    ax[0].legend(fontsize=6.5)
    ax[1].axhline(1, color="grey", ls=":", lw=0.8)
    ax[1].set_xlabel("damage fraction")
    ax[1].set_ylabel("median top merge / original")
    ax[1].set_title("(b) Widest persistence scale")
    ax[1].legend(fontsize=6.5)
    ax[2].axis("off")
    ax[2].set_title("(c) Snapshots (cut at 1.0)", fontsize=8.5)
    for j, dd in enumerate([0.0, 0.5, 0.85]):
        sub = ax[2].inset_axes([0.01 + j * 0.33, 0.08, 0.31, 0.78])
        k = int(round((1 - dd) * len(X0)))
        idx = np.random.default_rng(SEED + 1).choice(len(X0), size=k, replace=False)
        Xd = X0[idx]
        lab = fcluster(linkage(Xd, "single"), t=1.0, criterion="distance")
        sub.scatter(Xd[:, 0], Xd[:, 1], s=2.5, c=lab, cmap="tab10")
        sub.set_title(f"d={dd}", fontsize=7)
        sub.set_xticks([])
        sub.set_yticks([])
    fig.tight_layout()
    save(fig, "fig03_topological_recoverability")


def fig_control(ctrl):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    m = np.array(ctrl["m"])
    ax[0].step(m, ctrl["reach_frac"], where="mid", color=C1, lw=1.4,
               label="reachable (rank test)")
    ax[0].plot(m, ctrl["success_frac"], "o-", ms=3, color=C2,
               label=f"reachable and cost ≤ {ctrl['kappa']:.0f}× reference")
    ax[0].axvline(ctrl["generic_cliff_m"] - 0.5, color="grey", ls=":", lw=0.9)
    ax[0].set_xlabel("active actuators m")
    ax[0].set_ylabel("fraction of actuator sets")
    ax[0].set_title("(a) Reachability cliff at m = ⌈n/T⌉")
    ax[0].legend(fontsize=6.5)
    ax[1].semilogy(m, ctrl["median_norm_cost"], "o-", ms=3, color=C3)
    ax[1].set_xlabel("active actuators m")
    ax[1].set_ylabel("median min-energy / reference")
    ax[1].set_title("(b) Energy cost as actuators are lost")
    fig.tight_layout()
    save(fig, "fig04_control_reachability")


def fig_information(info):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    o = np.array(info["o"])
    for rho, col in zip(["0.2", "0.6", "0.9"], [C1, C2, C3]):
        ax[0].plot(o, info["rho"][rho]["D"], "o-", ms=3, color=col, label=f"ρ={rho}")
    ax[0].axhline(0.2, color="grey", ls=":", lw=0.8)
    ax[0].set_xlabel("observed fraction o")
    ax[0].set_ylabel("normalised LMMSE error D")
    ax[0].set_title("(a) Error vs observed fraction")
    ax[0].legend()
    ax[1].plot(info["rho_scan"], info["o_needed_for_D0.2"], "o-", ms=3, color=C4)
    ax[1].set_xlabel("correlation strength ρ")
    ax[1].set_ylabel("observed fraction needed for D ≤ 0.2")
    ax[1].set_title("(b) Structure lowers the observation need")
    fig.tight_layout()
    save(fig, "fig05_information_recoverability")


def fig_thermo(thermo):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.9))
    D = np.array(thermo["D"])
    ax[0].plot(D, thermo["bits_per_coordinate"], color=C1, lw=1.5)
    ax[0].set_xlabel("target normalised error D")
    ax[0].set_ylabel("bits per coordinate")
    ax[0].set_title("(a) Gaussian rate–distortion requirement")
    ax[0].grid(alpha=0.3)
    ax[1].semilogy(D, thermo["total_J_n40"], color=C2, lw=1.5)
    ax[1].set_xlabel("target normalised error D")
    ax[1].set_ylabel("joules (n = 40, 310 K)")
    ax[1].set_title("(b) Landauer-type floor $k_B T\\ln 2$ per bit")
    ax[1].grid(alpha=0.3, which="both")
    fig.tight_layout()
    save(fig, "fig06_thermodynamic_floor")


def fig_frontier(frontier):
    fig, ax = plt.subplots(1, 2, figsize=(7.6, 3.1))
    x = np.array(frontier["x"])
    a = np.array(frontier["a"])
    M = np.array(frontier["composite_R0.5"])
    im = ax[0].contourf(a, x, M, levels=np.linspace(0, 1, 11), cmap="viridis")
    ax[0].contour(a, x, M, levels=[0.5], colors="white", linewidths=1.4)
    ax[0].set_xlabel("actuator loss a")
    ax[0].set_ylabel("damage x (erasure = deletion)")
    ax[0].set_title("(a) Composite recoverability, R = 0.5")
    fig.colorbar(im, ax=ax[0], fraction=0.046, label="P(all layers pass)")
    for R, col in zip(["0.25", "0.5", "0.75"], [C1, C2, C3]):
        fr = np.array(frontier["rates"][R]["frontier_x_at_a"], float)
        ax[1].plot(a, fr, "o-", ms=3, color=col, label=f"R = {R}")
    ax[1].set_xlabel("actuator loss a")
    ax[1].set_ylabel("critical damage $x^*(a)$")
    ax[1].set_title("(b) Frontier shift with code rate")
    ax[1].set_ylim(0, 1)
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig07_recoverability_frontier")


def fig_dashboard(code, topo, ctrl, info):
    labels = [
        "A  Coding: erasure at P=0.5 (R=0.5)",
        "B  Topology: deletion at which P falls to 0.9",
        "C  Control: max actuator loss with success ≥ 0.5",
        "D  Information: observed fraction, D≤0.2 (ρ=0.9)",
        "D  Information: observed fraction, D≤0.2 (ρ=0.2)",
    ]
    vals = [code["rates"]["0.5"]["e50"], topo["modes"]["0.0"]["d90"],
            first_control_threshold(ctrl),
            info["rho"]["0.9"]["o_for_D0.2"], info["rho"]["0.2"]["o_for_D0.2"]]
    fig, ax = plt.subplots(figsize=(7.4, 2.9))
    y = np.arange(len(labels))[::-1]
    ax.barh(y, vals, color=[C1, C2, C3, C4, C4], alpha=0.85)
    for yi, v in zip(y, vals):
        ax.text(v + 0.01, yi, f"{v:.2f}", va="center", fontsize=7.5)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.2)
    ax.set_xlabel("critical value of each layer's control parameter")
    ax.set_xlim(0, 1.1)
    ax.set_title("Layer transition points, each from its own experiment")
    fig.tight_layout()
    save(fig, "fig08_layer_transitions_dashboard")


def first_control_threshold(ctrl):
    for li, si in zip(ctrl["actuator_loss"], ctrl["success_frac"]):
        if si >= 0.5:
            return float(li)
    return float("nan")


# ==================================================================== main
def main():
    X0 = cluster_cloud(rng)
    erasure = run_erasure()
    dump(erasure, "E1_erasure_code")
    topo = run_topology(X0)
    dump(topo, "E2_topological_recoverability")
    ctrl = run_control()
    dump(ctrl, "E3_control_reachability")
    info = run_information()
    dump(info, "E4_information_lmmse")
    thermo = run_thermo()
    dump(thermo, "E5_thermodynamic_floor")
    frontier = run_frontier(erasure, topo, ctrl)
    dump(frontier, "E6_composite_frontier")

    fig_architecture()
    fig_erasure(erasure)
    fig_topology(X0, topo)
    fig_control(ctrl)
    fig_information(info)
    fig_thermo(thermo)
    fig_frontier(frontier)
    fig_dashboard(erasure, topo, ctrl, info)

    summary = {
        "seed": SEED,
        "E1_max_abs_dev_from_exact": {R: round(v["max_abs_dev_theory"], 4)
                                      for R, v in erasure["rates"].items()},
        "E1_e50": {R: round(v["e50"], 3) for R, v in erasure["rates"].items()},
        "E1_shannon_limit": {R: v["shannon_limit"] for R, v in erasure["rates"].items()},
        "E2_original_clusters": topo["original_clusters"],
        "E2_d90_deletion_only": round(topo["modes"]["0.0"]["d90"], 3),
        "E2_P_zero_deletion_with_jitter": round(topo["modes"]["0.3"]["p_preserved"][0], 3),
        "E3_generic_cliff_m": ctrl["generic_cliff_m"],
        "E3_reach_frac": dict(zip(ctrl["m"], ctrl["reach_frac"])),
        "E3_success_frac": dict(zip(ctrl["m"], ctrl["success_frac"])),
        "E3_median_norm_cost": dict(zip(ctrl["m"], [round(c, 3) if not math.isnan(c) else None
                                                    for c in ctrl["median_norm_cost"]])),
        "E4_o_for_D0.2": {r: (round(v["o_for_D0.2"], 3) if not math.isnan(v["o_for_D0.2"]) else None)
                          for r, v in info["rho"].items()},
        "E4_o_needed_rho_scan": {str(r): (round(o, 3) if not math.isnan(o) else None)
                                 for r, o in zip(info["rho_scan"], info["o_needed_for_D0.2"])},
        "E5_bits_at_D0.2": round(0.5 * math.log2(1 / 0.2), 4),
        "E5_kTln2_J_310K": thermo["kTln2_J"],
        "E6_frontier_x_at_a": {R: [round(v, 3) if not math.isnan(v) else None for v in f["frontier_x_at_a"]]
                               for R, f in frontier["rates"].items()},
        "E6_composite_zero_damage": {R: round(f["composite_at_zero_damage"], 3)
                                     for R, f in frontier["rates"].items()},
    }
    dump(summary, "summary")
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
