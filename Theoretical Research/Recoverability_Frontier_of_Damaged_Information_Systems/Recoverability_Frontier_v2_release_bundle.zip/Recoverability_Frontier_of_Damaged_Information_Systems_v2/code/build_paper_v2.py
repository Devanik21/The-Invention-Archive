#!/usr/bin/env python3
"""Builds the v2 research PDF. Numbers are read from the results folders."""
import json
import math
import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate,
                                Spacer, Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
V1 = "/home/claude/recoverability"
R1 = os.path.join(V1, "results")
F1 = os.path.join(V1, "figures")
R2 = os.path.join(ROOT, "results_v2")
F2 = os.path.join(ROOT, "figures_v2")
OUT = os.path.join(ROOT, "paper", "Recoverability_Frontier_of_Damaged_Information_Systems_v2.pdf")

FD = "/usr/share/fonts/truetype/dejavu/"
for name, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"),
                 ("Serif-I", "DejaVuSerif-Italic.ttf"), ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"),
                 ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
                 ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")


def load(p):
    return json.load(open(p))


S1 = load(os.path.join(R1, "summary.json"))
E1 = load(os.path.join(R1, "E1_erasure_code.json"))
E2 = load(os.path.join(R1, "E2_topological_recoverability.json"))
E3 = load(os.path.join(R1, "E3_control_reachability.json"))
E4 = load(os.path.join(R1, "E4_information_lmmse.json"))
E6 = load(os.path.join(R1, "E6_composite_frontier.json"))
S2 = load(os.path.join(R2, "summary_v2.json"))
E7 = load(os.path.join(R2, "E7_finite_size.json"))
E8 = load(os.path.join(R2, "E8_topology_calibration.json"))
E9 = load(os.path.join(R2, "E9_control_grid.json"))
E10 = load(os.path.join(R2, "E10_time_energy.json"))
E11 = load(os.path.join(R2, "E11_information_estimation_gap.json"))
E12 = load(os.path.join(R2, "E12_shared_substrate.json"))

NAVY = colors.HexColor("#1f4e79")
GREY = colors.HexColor("#555555")
LIGHT = colors.HexColor("#eef3f8")

body = ParagraphStyle("body", fontName="Serif", fontSize=9.6, leading=14.2, alignment=TA_JUSTIFY, spaceAfter=6.5)
small = ParagraphStyle("small", parent=body, fontSize=8.3, leading=11.3, spaceAfter=3)
cap = ParagraphStyle("cap", parent=body, fontSize=8.0, leading=10.6, textColor=GREY, spaceBefore=3, spaceAfter=11)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=13, leading=17, textColor=NAVY, spaceBefore=14, spaceAfter=7)
h2 = ParagraphStyle("h2", fontName="Sans-B", fontSize=10.5, leading=14, textColor=NAVY, spaceBefore=9, spaceAfter=4)
title = ParagraphStyle("title", fontName="Sans-B", fontSize=20, leading=26, alignment=TA_CENTER, textColor=NAVY, spaceAfter=10)
subtitle = ParagraphStyle("subtitle", fontName="Serif-I", fontSize=10.5, leading=14.5, alignment=TA_CENTER, textColor=GREY, spaceAfter=6)
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER)
eqs = ParagraphStyle("eqs", fontName="Serif-I", fontSize=9.6, leading=14, alignment=TA_CENTER, spaceBefore=3, spaceAfter=8)
cell = ParagraphStyle("cell", fontName="Serif", fontSize=7.7, leading=9.8)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Serif-B")


def P(t, s=body):
    return Paragraph(t, s)


def H1(t):
    return Paragraph(t, h1)


def H2(t):
    return Paragraph(t, h2)


def EQ(t):
    return Paragraph(t, eqs)


def IMG(name, caption, width_cm=16.0):
    path = os.path.join(F1, name + ".png")
    if not os.path.exists(path):
        path = os.path.join(F2, name + ".png")
    iw, ih = ImageReader(path).getSize()
    w = width_cm * cm
    return KeepTogether([Image(path, width=w, height=w * ih / iw), Paragraph(caption, cap)])


def TABLE(rows, widths):
    data = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (-1, 0), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                           ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def BOX(text):
    t = Table([[Paragraph(text, small)]], colWidths=[16.0 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def f(x, nd=3):
    if x is None or (isinstance(x, float) and x != x):
        return "n/a"
    return f"{x:.{nd}f}"


def pct(x):
    return f"{100 * x:.0f}%"


def prod_limit(delta, terms=200):
    if delta < 0:
        return 0.0
    p = 1.0
    for j in range(delta + 1, terms):
        p *= 1 - 2.0 ** (-j)
    return p


CAL = E8["calibrated"]
FIX = E8["fixed"]
SIG = E8["sigma"]
D8 = E8["d"]
G7 = E7["gumbel"]
CTRL_TH = 0.2
RHO11 = E11["rho"]
E12x = E12["x"]
story = []

# =================================================================== title
story += [Spacer(1, 0.7 * cm),
          P("PREPRINT · NOT PEER REVIEWED · VERSION 2.0 · 8 NOVEMBER 2026", center),
          Spacer(1, 0.4 * cm),
          P("The Recoverability Frontier of Damaged Information-Bearing Systems", title),
          P("Finite-size limits, topological calibration, reachability cliffs, the estimation gap, "
            "and the independence question, in one stylised framework", subtitle),
          Spacer(1, 0.2 * cm),
          P("Devanik Debnath<super>1</super> · Xylia<super>2</super>", center),
          P("<super>1</super> Independent researcher &nbsp;&nbsp; <super>2</super> Xylia, AI research scientist "
            "(multi-agent research system)", small),
          Spacer(1, 0.4 * cm)]
story.append(BOX(
    "<b>Scope.</b> This paper studies abstract, dimensionless models of damaged information-bearing systems. It asks "
    "when information in a damaged system remains identifiable, decodable, reachable by a control action, estimable "
    "from partial observations, and restorable at finite physical cost. <b>It does not study the reversal of death, the "
    "revival of any organism or person, personal identity, or any medical intervention.</b> No experiment on living "
    "material is reported. Every number is produced by the code in <font face='Mono'>code/</font> with fixed seeds "
    "(20261108 and 20261109). Version 2 supersedes Version 1 and records its corrections in Appendix C."))
story.append(Spacer(1, 0.35 * cm))
story.append(P(
    "<b>Abstract.</b> Damage to an information-bearing system is commonly described by how much of it is lost. Recovery "
    "depends on something else: whether the surviving information can be decoded, whether the surviving organisation "
    "can be identified across scales, whether a controller can reach a functional state within an energy budget, "
    "whether partial observations carry enough information to estimate the target, and what physical work the "
    "restoration requires. We formalise these as five layers and prove nine propositions, including an exact finite-size "
    "law for random binary codes whose limit is the infinite product of (1 − 2<super>−j</super>) over j beyond the surplus, "
    "a generic reachability rank of min(n, Tm), a monotonicity result that makes reachability and energy thresholds "
    "increasing events, and a converse showing that rate–distortion sufficiency is necessary but not sufficient for "
    "estimation through a fixed observation channel. Numerically, we find that the coding threshold converges to 1/2 "
    f"at rate 1/2 with a transition width that falls roughly as n<super>−1</super> (fitted exponent "
    f"{S2['E7_width_loglog_slope']:.2f}); that a fixed-scale topological signature is fragile to noise, while a calibrated "
    "scale exists only when the between-cluster separation exceeds the within-cluster spread; that reachability has a "
    "discrete cliff at m = ⌈n/T⌉ that held in every cell of a 30-point (n, T) grid; that structure lowers the observed "
    "fraction needed for information sufficiency from 70% to 20% across correlation strengths, and for linear "
    f"estimation from {pct(E4['rho']['0.2']['o_for_D0.2'])} to {pct(E4['rho']['0.9']['o_for_D0.2'])}; and that under shared "
    "damage the composite product understates the joint success probability, as the Harris–FKG inequality predicts for "
    "these monotone layers, though the measured gaps are small, about 0.02 to 0.03 at the two highest damage levels, and of order two standard errors at 4000 trials. We state "
    "the remaining open problems precisely. The framework is a set of verified mathematical sub-results and a research "
    "programme; it is not a demonstration that any living system can be restored.", body))
story.append(P("<b>Keywords:</b> erasure codes · random matrices over GF(2) · persistent homology · reachability · "
               "minimum-energy control · linear estimation · rate–distortion · FKG inequality · Landauer bound", small))
story.append(PageBreak())

# =================================================================== contents
story.append(H1("Contents"))
for t in ["1  Introduction and what changed since Version 1",
          "2  Related work and positioning",
          "3  Formal framework and notation",
          "4  Theory: propositions, conjectures and proofs",
          "5  Layer A: coding recoverability and finite-size limits",
          "6  Layer B: topological recoverability and calibration",
          "7  Layer C: reachability, the cliff, and the time–energy trade-off",
          "8  Layer D: estimation and the information–estimation gap",
          "9  Layer E: the thermodynamic floor",
          "10  The independence question: shared-substrate damage",
          "11  The composite frontier, revisited",
          "12  Predictions, status and falsification",
          "13  Limitations",
          "14  A research programme: precise open problems",
          "15  Discussion and scope",
          "16  Conclusion",
          "Appendix A  Complete proofs",
          "Appendix B  Experimental protocol and parameters",
          "Appendix C  Corrections from Version 1",
          "References"]:
    story.append(P(t, small))
story.append(PageBreak())

# =================================================================== 1
story.append(H1("1  Introduction and what changed since Version 1"))
story.append(P(
    "A damaged system can be described in two ways that are easy to confuse. One asks how much of the original "
    "structure is missing. The other asks whether what remains is enough to recover a functional state. The two "
    "descriptions diverge sharply. A system may lose most of its components while the surviving components still "
    "determine the missing ones, and a system with modest visible damage may be unrecoverable because the surviving "
    "information is inaccessible to any admissible intervention. This paper takes the second question seriously and "
    "treats it as a mathematical problem with a precise answer in each stylised model we can write down."))
story.append(P(
    "Version 1 introduced five layers (coding, topology, reachability, estimation, thermodynamics), proved six "
    "propositions, and reported numerical checks. Its composite frontier multiplied three layer probabilities as if "
    "the layers were independent, and it did not test that assumption. Its topological negative finding rested on a "
    "single point cloud. Version 2 addresses these weaknesses directly. It adds finite-size analysis of the coding "
    "layer, a calibration study of the topological layer across noise levels, a grid test of the reachability rank "
    "law, a time–energy trade-off, a comparison of information sufficiency with linear estimation, and a shared-"
    "substrate experiment that tests the independence assumption under a common damage process."))
story.append(P(
    "Four results of Version 2 are new and, in our view, carry the most weight. First, the finite-size law of random "
    "binary codes has a clean infinite-product limit that we derive and verify; the Gumbel-type form we initially "
    "expected is incorrect for small surplus, and we retract it (Appendix C). Second, a fixed-scale topological "
    "invariant has a computable separability index that predicts whether any calibrated scale exists. Third, the "
    "reachability cliff is not an artefact of one system: it appears in every cell of the (n, T) grid we tested. "
    "Fourth, the information–estimation comparison exposes a gap between two necessary conditions for estimation, "
    "which we formalise as a converse that is not tight for a fixed channel."))
story.append(P(
    "We also report what Version 2 does not resolve. The independence question is answered only for one shared-"
    "substrate design, and the measured dependence gaps are not separated from sampling noise at the sample sizes "
    "used. The finite-size exponent is estimated at −0.82 against a conjectured −1, limited by grid resolution. Neither "
    "claim is pushed further than the data allow."))
story.append(P(
    "<b>Scope.</b> Everything here concerns abstract systems. The word recoverability denotes recovery of an information "
    "state in a model. We make no claim about organisms, persons, identity or clinical procedures, and Section 15 "
    "explains why a measurement programme on living systems would need its own design, controls and ethical review."))

# =================================================================== 2
story.append(H1("2  Related work and positioning"))
story.append(P(
    "Each layer has an established literature, and the value of this paper, if any, lies in the composition and in the "
    "sharpened sub-results. Table 1 summarises the anchors and what we borrow from each."))
rows = [["Area", "Established result we use", "Our use", "What we do not claim"],
        ["Erasure codes", "Random linear codes and the binary erasure channel (Shannon 1948; Richardson and Urbanke 2008)",
         "Exact finite-size law and its limit", "Any biological code"],
        ["Random matrices over GF(2)", "Probability of full rank of random binary matrices (classical counting)",
         "Limit law in the surplus, window size", "Novel counting result"],
        ["Persistent homology", "Single-linkage H0 persistence equals MST merge heights (Edelsbrunner et al. 2002; Carlsson 2009)",
         "Separability index and calibration", "Topology of real tissue"],
        ["Reachability", "Kalman rank condition and minimum-energy steering (Kalman 1963; Sontag 1998)",
         "Generic-rank grid test and time–energy curve", "Controllability of organisms"],
        ["Estimation", "LMMSE for Gaussian vectors; rate–distortion converse (Berger 1971; Cover and Thomas 2006)",
         "Fixed-channel information–estimation gap", "A general estimation theory"],
        ["Correlation inequalities", "Harris (1960) and FKG (1971) for increasing events on product spaces",
         "Sign of the shared-substrate gap", "Tightness beyond product measure"],
        ["Thermodynamics", "Landauer bound and information thermodynamics (Landauer 1961; Bennett 1982; Parrondo et al. 2015)",
         "Floor for bits restored", "Physical cost of any real process"]]
story.append(TABLE(rows, [2.8, 5.6, 4.2, 3.4]))
story.append(P("<b>Table 1.</b> Anchors, their use here, and the boundaries of each claim.", cap))
story.append(P(
    "Experimental context is handled with the same care. Reports of partial restoration of circulation and cellular "
    "function in post-mortem large-animal tissue (Vrselja et al. 2019) show that some processes can be restarted after "
    "an interval. Those results do not show restoration of organised, conscious or whole-body function, and we treat "
    "them only as motivation for asking which information survives. Work on memory engrams (Josselyn and Tonegawa 2020) "
    "motivates distributed representations of information, but it supplies no threshold we could use."))

# =================================================================== 3
story.append(H1("3  Formal framework and notation"))
story.append(P(
    "A system is an information-bearing random object X<sub>0</sub> with a target variable Z = Φ(X<sub>0</sub>). A damage "
    "process produces a damaged state X<sub>x</sub> at severity x ∈ [0, 1]. Observations take the form Y = H(X<sub>x</sub>) + ε. "
    "Table 2 fixes notation used throughout."))
rows = [["Symbol", "Meaning"],
        ["n, k, R", "coded symbols; information symbols; rate k/n"],
        ["ε, x, d, a", "erasure fraction; generic damage severity; point-deletion fraction; actuator loss fraction"],
        ["T, m, m*(n,T)", "horizon; active actuators; empirical reachability cliff"],
        ["ρ, o, D", "AR(1) correlation; observed fraction; normalised LMMSE error"],
        ["κ", "energy tolerance factor for success (κ = 2)"],
        ["θ, σ²", "water level in reverse water-filling; measurement noise variance"],
        ["P<sub>code</sub>, P<sub>topo</sub>, P<sub>ctrl</sub>", "layer success probabilities"],
        ["I(Z;Y)", "mutual information between target and observation, in bits"],
        ["R(D)", "Gaussian vector rate–distortion function, reverse water-filling, in bits"]]
story.append(TABLE(rows, [4.0, 12.0]))
story.append(P("<b>Table 2.</b> Notation.", cap))
story.append(P(
    "<b>Definition 1 (information recoverability).</b> D*(x) = inf<sub>Ẑ(Y)</sub> E[d(Z, Ẑ)] is the minimum achievable distortion "
    "at severity x. The information is recoverable when D*(x) ≤ D<sub>max</sub>."))
story.append(P(
    "<b>Definition 2 (code recoverability).</b> P<sub>code</sub>(x; R) is the probability that a random linear code of rate R "
    "over GF(2), with a fraction x of coded symbols erased, recovers all information symbols."))
story.append(P(
    "<b>Definition 3 (topological recoverability).</b> P<sub>topo</sub>(d; σ, τ) is the probability that the number of "
    "single-linkage clusters of size at least five at scale τ equals the intact count, after deletion of a fraction d "
    "of points and Gaussian jitter of standard deviation σ. The separability index is "
    "s = b<sub>05</sub> / w<sub>95</sub>, where w<sub>95</sub> is the 95th percentile of the widest within-cluster link and "
    "b<sub>05</sub> the 5th percentile of the smallest between-cluster distance, both taken over noise draws."))
story.append(P(
    "<b>Definition 4 (dynamical recoverability).</b> For x<sub>t+1</sub> = A x<sub>t</sub> + B<sub>a</sub> u<sub>t</sub> with n states, "
    "the target is reachable in horizon T if M = [A<super>T−1</super>B<sub>a</sub>, …, B<sub>a</sub>] has rank n. An actuator set succeeds "
    "when it is reachable and its mean minimum energy over targets is at most κ times the full-actuation reference."))
story.append(P(
    "<b>Definition 5 (estimation sufficiency).</b> A set of observations is information-sufficient for distortion D when "
    "I(Z;Y) ≥ R(D), and LMMSE-sufficient when the linear estimator attains normalised error at most D."))
story.append(P(
    "<b>Definition 6 (thermodynamic floor).</b> Restoring b bits at temperature T requires at least k<sub>B</sub> T ln 2 · b "
    "of work, under the assumptions of Proposition 9."))
story.append(P(
    "<b>Definition 7 (composite frontier).</b> Under the layer product, P<sub>rec</sub> = P<sub>code</sub> · P<sub>topo</sub> · P<sub>ctrl</sub>, "
    "and the frontier 𝔑 = {(x, a, R) : P<sub>rec</sub> ≥ 1/2}. Section 10 tests when this product is a bound."))

# =================================================================== 4
story.append(H1("4  Theory: propositions, conjectures and proofs"))
story.append(P(
    "We state nine propositions with proofs in place or in Appendix A, and three conjectures that remain open. The "
    "propositions are chosen to be used in the experiments: each one either predicts a measured quantity or constrains "
    "how the layers may be combined."))
story.append(H2("4.1  Monotonicity under damage"))
story.append(P(
    "<b>Proposition 1 (monotonicity).</b> If X<sub>x</sub> is produced from X<sub>0</sub> by a damage channel that does not depend "
    "on Z, then I(Z;Y) ≤ I(Z;X<sub>x</sub>) ≤ I(Z;X<sub>0</sub>) for any Y = H(X<sub>x</sub>) + ε, and D*(x) is non-decreasing in x."))
story.append(P(
    "<i>Proof.</i> The chain Z → X<sub>0</sub> → X<sub>x</sub> → Y is Markov, so the data-processing inequality gives both inequalities "
    "(Cover and Thomas 2006, Thm. 2.8.1). A larger mutual information cannot increase the minimum distortion. ∎"))
story.append(H2("4.2  Coding: exact finite-size law and its limit"))
story.append(P(
    "<b>Proposition 2 (exact full-rank probability).</b> For a uniformly random k × n binary matrix and a uniform set S of s "
    "columns, the probability that G<sub>S</sub> has full row rank k is"))
story.append(EQ("P<sub>full</sub>(k, s) = ∏<sub>i=0</sub><super>k−1</super> (1 − 2<super>i−s</super>)  for s ≥ k, and 0 for s < k."))
story.append(P(
    "<i>Proof.</i> The k rows of G<sub>S</sub> are independent and uniform on F<sub>2</sub><super>s</super>. Given that the first i "
    "are independent, they span 2<super>i</super> vectors, so row i+1 must avoid that span, which has probability 1 − 2<super>i−s</super>. "
    "Multiply over i. ∎"))
story.append(P(
    "<b>Proposition 3 (limit law and window).</b> Let s = k + δ. For each fixed δ ∈ ℤ,"))
story.append(EQ("lim<sub>k→∞</sub> P<sub>full</sub>(k, k+δ) = ∏<sub>j=δ+1</sub><super>∞</super> (1 − 2<super>−j</super>)  for δ ≥ 0, and 0 for δ < 0."))
story.append(P(
    "Consequently the transition in the surplus δ is of order one symbol, and the transition in the erasure fraction has "
    "width of order 1/n."))
story.append(P(
    "<i>Proof.</i> Substitute j = s − i in Proposition 2. The index i runs over 0,…,k−1, so j runs over s, s−1,…, s−k+1 = δ+1. "
    "Hence P<sub>full</sub>(k, k+δ) = ∏<sub>j=δ+1</sub><super>k+δ</super>(1 − 2<super>−j</super>). The factors with j > k+δ are absent, and the "
    "omitted tail ∏<sub>j>k+δ</sub>(1 − 2<super>−j</super>) tends to 1 as k grows. This gives the limit. For δ < 0 we have s < k, "
    "so the probability is zero by Proposition 2 directly. The window statement follows because the limit depends on δ "
    "alone, and an erasure step of 1/n changes s by one symbol. ∎"))
story.append(P(
    "Proposition 3 corrects an expression from our preliminary notes, which proposed exp(−2<super>−δ</super>) as the limit. That "
    "expression is wrong for small δ, because the largest factors are not small. Appendix C records the correction."))
story.append(H2("4.3  Reachability: generic rank and energy"))
story.append(P(
    "<b>Proposition 4 (generic rank).</b> For x<sub>t+1</sub> = Ax<sub>t</sub> + Bu<sub>t</sub> with n states and m inputs, rank M ≤ min(n, Tm), "
    "with equality for generic (A, B). The target is generically reachable in horizon T iff Tm ≥ n, so the generic cliff is "
    "m* = ⌈n/T⌉."))
story.append(P(
    "<i>Proof sketch.</i> The bound is immediate from the shape of M. Rank equality is a nonvanishing condition on minors, which are "
    "polynomials in the entries of (A, B). A polynomial that is nonzero at one point is nonzero on a dense open set, so it suffices "
    "to exhibit one pair attaining the bound: a cyclic shift A and B given by the first min(m, n) unit vectors. This is the "
    "standard Kalman construction (Kalman 1963; Sontag 1998). ∎"))
story.append(P(
    "<b>Proposition 5 (minimum energy).</b> If M has full row rank n, the minimum of Σ<sub>t</sub> ‖u<sub>t</sub>‖² subject to steering "
    "x<sub>0</sub> to z is r<super>⊤</super>(MM<super>⊤</super>)<super>−1</super>r, with r = z − A<super>T</super>x<sub>0</sub>."))
story.append(P(
    "<b>Proposition 6 (monotonicity of reachability and energy in actuators).</b> Adding an actuator never destroys reachability, "
    "and never increases the minimum energy. Consequently the events 'reachable' and 'energy at most κ times reference' are "
    "increasing in the set of active actuators."))
story.append(P(
    "<i>Proof.</i> Adding an input column enlarges the set of feasible input sequences, with the new input set to zero on the old "
    "solutions. The rank cannot fall. The minimum over a larger feasible set is no larger. ∎"))
story.append(H2("4.4  Estimation: monotonicity and the converse"))
story.append(P(
    "<b>Proposition 7 (monotonicity of linear recovery).</b> For Gaussian Z with covariance Σ and observations on S ⊆ S′, the "
    "LMMSE error satisfies tr(Σ − K<sub>S′</sub>) ≤ tr(Σ − K<sub>S</sub>), where K<sub>S</sub> is the explained covariance."))
story.append(P(
    "<i>Proof.</i> Gaussian conditioning increases the explained covariance in the Loewner order when observations are added, so the "
    "residual trace decreases. ∎"))
story.append(P(
    "<b>Proposition 8 (rate–distortion converse for a fixed channel).</b> If an estimator Ẑ(Y) satisfies E‖Z − Ẑ‖² ≤ nD, then "
    "I(Z;Y) ≥ R(D), where R(D) is the Gaussian vector rate–distortion function in bits. Hence information sufficiency is necessary "
    "for estimation at distortion D. Because the observation channel is fixed rather than an encoder we design, the converse need not "
    "be tight."))
story.append(P(
    "<i>Proof.</i> The chain Z → Y → Ẑ is Markov, so the rate–distortion converse for the Gaussian source applies to the pair (Z, Ẑ) "
    "with I(Z;Ẑ) ≤ I(Z;Y) by data processing. ∎"))
story.append(H2("4.5  Correlation inequalities and the independence question"))
story.append(P(
    "<b>Proposition 9 (Harris–FKG for product damage).</b> Let each unit survive independently. If A and B are increasing events "
    "(adding survivors cannot destroy them), then P(A ∩ B) ≥ P(A)P(B). Under independent survival the composite product is therefore "
    "a lower bound on the joint success probability whenever the layer events are increasing."))
story.append(P(
    "<i>Proof.</i> This is the Harris inequality for product measures (Harris 1960), proved by induction on the number of units "
    "with the FKG lattice condition on the product of two-point spaces. ∎"))
story.append(P(
    "<b>Proposition 10 (thermodynamic floor, stated as a bound).</b> If a restoration process raises the information about Z by b bits "
    "at temperature T and the entropy reduction is paid by an environment, the work satisfies W ≥ k<sub>B</sub> T ln 2 · b "
    "(Landauer 1961; Bennett 1982; Sagawa and Ueda 2008). This is a stated bound under explicit assumptions."))
story.append(P(
    "<b>Proposition 11 (calibration existence).</b> A scale that separates clusters at every noise draw exists exactly when "
    "w<sub>95</sub> < b<sub>05</sub>, that is, when the separability index exceeds one."))
story.append(P(
    "<i>Proof.</i> A scale τ with the required count is any value between the largest within-cluster link and the smallest "
    "between-cluster distance over the calibration draws. The interval is nonempty iff w<sub>95</sub> < b<sub>05</sub>. ∎"))
story.append(P(
    "<b>Conjecture 1 (composite lower bound).</b> For shared product damage with increasing layer events, P<sub>rec</sub> is a lower bound "
    "on the true joint success probability. Section 10 tests this for the code and control layers. Topology is not monotone in "
    "unit survival, so the conjecture does not cover it."))
story.append(P(
    "<b>Conjecture 2 (finite-size width).</b> For each code rate R ∈ (0, 1), the 25–75% transition width in the erasure fraction is "
    "of order n<super>−1</super>. Section 5 gives evidence at R = 1/2."))
story.append(P(
    "<b>Conjecture 3 (fixed-channel estimation).</b> The minimum number of observations for information sufficiency and for "
    "linear estimation sufficiency differ by a positive amount for correlated Gaussian targets. Section 8 provides numerical evidence."))

# =================================================================== 5
story.append(H1("5  Layer A: coding recoverability and finite-size limits"))
story.append(P(
    "Version 1 established the threshold at 1 − R for rate R = 0.25, 0.5 and 0.75 with n = 48. Version 2 asks how the transition "
    "sharpens with code length, and whether the exact limit of Proposition 3 is visible in finite samples."))
story.append(IMG("fig02_erasure_recoverability",
                 "<b>Figure 1.</b> Version 1 coding results: Monte Carlo against the exact formula and the Shannon limit (reproduced for reference)."))
rows = [["Code length n", "Measured 50% point", "25–75% width", "Interval half-width scale"]]
for n, e50, w in zip(E7["sizes"], E7["e50"], E7["width"]):
    rows.append([n, f(e50), f(w), f(w / 2 if w == w else None)])
story.append(TABLE(rows, [3.6, 4.2, 4.2, 4.0]))
story.append(P("<b>Table 3.</b> Finite-size behaviour at rate 1/2, 400 Monte Carlo trials per erasure point, grid step 0.01.", cap))
story.append(IMG("fig09_finite_size_scaling",
                 "<b>Figure 2.</b> Finite-size scaling at rate 1/2. (a) Recovery curves sharpen and centre on 1/2 as n grows. (b) "
                 "Transition width against n on log–log axes, with a slope −1 reference line."))
story.append(P(
    f"<b>Numerical result.</b> The 50% point moves from {f(E7['e50'][0])} at n = 24 to {f(E7['e50'][-1])} at n = 192, "
    f"approaching the limit 1/2 from below, as expected from the surplus expression with δ = 0. The 25–75% width falls from "
    f"{f(E7['width'][0])} to {f(E7['width'][-1])}, with fitted log–log exponent {S2['E7_width_loglog_slope']:.2f}. The "
    "conjectured exponent −1 is within the uncertainty of this estimate, but the grid step of 0.01 limits resolution at "
    "n = 192, where the width is only about one and a half grid steps. We therefore regard Conjecture 2 as supported but not "
    "established at this precision."))
story.append(IMG("fig10_gumbel_limit",
                 "<b>Figure 3.</b> Surplus law. Exact full-rank probability at k = 96 against the infinite-product limit of Proposition 3."))
gx = G7["delta"]
rows = [["Surplus δ", "Exact, k = 96", "Limit ∏<sub>j>δ</sub>(1 − 2<super>−j</super>)", "Previous expression exp(−2<super>−δ</super>)"]]
for d, ex, li in zip(gx, G7["exact_k96"], G7["limit"]):
    if d in (-1, 0, 1, 2, 3):
        rows.append([d, f(ex, 4), f(li, 4), f(math.exp(-2.0 ** (-d)), 4)])
story.append(TABLE(rows, [2.6, 3.4, 5.0, 5.0]))
story.append(P("<b>Table 4.</b> Surplus law at k = 96. The product limit matches the exact values to four decimals. The "
               "expression used in preliminary notes does not.", cap))
story.append(P(
    "<b>Discussion.</b> The coding layer has an unusually clean finite-size structure. Its transition is governed by the surplus "
    "δ = s − k, which takes integer values, so the sharpness is set by counting and not by a scaling function we had to fit. "
    "Every erasure experiment should therefore report the code length and the surplus, not just the rate. A design that "
    "targets a fixed erasure fraction with a few percent margin needs n large enough that the window of order 1/n lies inside "
    "the margin."))

# =================================================================== 6
story.append(H1("6  Layer B: topological recoverability and calibration"))
story.append(P(
    "Version 1 reported that a three-cluster signature survives deletion of up to 87% of points, and that jitter of 0.3 "
    "breaks it at a fixed cut even with nothing deleted, with preservation 0.513. Version 2 retests the second claim across "
    "noise levels and asks whether a calibrated scale can restore robustness."))
story.append(P(
    "We generated a three-cluster cloud of 240 points as in Version 1 and computed, for each noise level σ ∈ {0, 0.15, 0.3, 0.45, 0.6}, "
    "the separability index of Definition 3 over 60 noise draws. Where the index exceeds one, the calibrated cut is the geometric mean "
    "of w<sub>95</sub> and b<sub>05</sub>. We then measured preservation of the three-cluster count, using 200 trials per deletion level, "
    "for the fixed cut 1.0 and for the calibrated cut."))
story.append(IMG("fig11_topology_calibration",
                 "<b>Figure 4.</b> Topological calibration. (a) Separability index against jitter; the dotted line is the threshold of "
                 "Proposition 11. (b) Preservation against deletion for two noise levels, with the fixed cut (dashed) and the calibrated "
                 "cut (solid). Calibrated values are undefined where the index is below one, and are left blank."))
rows = [["Noise σ", "Separability index", "Calibrated cut", "Preservation at d = 0 (fixed)", "Preservation at d = 0.8 (fixed)"]]
for s in SIG:
    rows.append([s, f(E8["sep_index"][SIG.index(s)], 2),
                 f(E8["cut_cal"][SIG.index(s)], 3) if E8["cut_cal"][SIG.index(s)] == E8["cut_cal"][SIG.index(s)] else "none",
                 f(FIX[str(s)][0], 2), f(FIX[str(s)][-1], 2)])
story.append(TABLE(rows, [2.3, 3.2, 3.0, 4.3, 4.2]))
story.append(P("<b>Table 5.</b> Separability, calibration and preservation across noise levels (200 trials per entry).", cap))
story.append(P(
    f"<b>Numerical result.</b> The separability index falls monotonically with noise, from {f(E8['sep_index'][0], 2)} at σ = 0 to "
    f"{f(E8['sep_index'][-1], 2)} at σ = 0.6. A calibrated scale exists only for σ ≤ 0.15 in this sample. At σ = 0.15 the calibrated "
    "cut keeps preservation between 0.99 and 1.0 across all deletion levels. Above that noise the scale cannot be calibrated, and "
    "the fixed cut degrades. At σ = 0.3, preservation at zero deletion is "
    f"{f(FIX['0.3'][0], 2)}, rising to {f(FIX['0.3'][-1], 2)} at 80% deletion. At σ = 0.45 the same pattern holds more strongly."))
story.append(P(
    "<b>Sample dependence of the Version 1 result.</b> Version 1 reported preservation 0.513 at σ = 0.3 and zero deletion. In this "
    f"run, on a different intact sample drawn from the same distribution, the value is {f(FIX['0.3'][0], 2)}. The qualitative claim "
    "that a fixed scale is fragile to noise stands, and it strengthens with σ. The specific number does not. We therefore report the "
    "fragility as a function of separability, which is the quantity that governs it, and not as a single constant."))
story.append(P(
    "<b>An unexpected monotonicity.</b> Under jitter, preservation with the fixed cut increases with deletion. The likely mechanism is "
    "bridging: jitter creates short links between clusters, and removing points reduces the number of potential bridges. This is a "
    "hypothesis, not a tested mechanism, and it needs its own experiment that counts bridging links directly."))

# =================================================================== 7
story.append(H1("7  Layer C: reachability, the cliff, and the time–energy trade-off"))
story.append(P(
    "Version 1 established a reachability cliff at m = 3 for n = 20 and T = 8, with energy rising steeply above it. Version 2 "
    "tests whether the generic rule m* = ⌈n/T⌉ holds across a grid of state dimensions and horizons, and measures how energy "
    "trades against horizon for a fixed number of actuators."))
story.append(IMG("fig12_control_cliff_grid",
                 "<b>Figure 5.</b> Reachability cliff over (n, T). (a) Smallest active-actuator count reaching 95% reachability. (b) "
                 "Difference from the prediction ⌈n/T⌉; zero throughout."))
story.append(P(
    f"<b>Numerical result.</b> The empirical cliff equals ⌈n/T⌉ in every one of the {len(E9['n']) * len(E9['T'])} cells of the grid "
    f"(agreement {pct(S2['E9_agreement'])}). This is a test of Proposition 4 across a range of dimensions and horizons, not a single "
    "example. The resolution of the test is limited by 20 actuator sets per count, so a cell reports the smallest count at which the "
    "estimated reachability reaches 95%."))
story.append(IMG("fig13_time_energy_tradeoff",
                 "<b>Figure 6.</b> Time–energy trade-off for n = 20 and six active actuators. (a) Reachable fraction against horizon, with "
                 "the cliff at T = ⌈20/6⌉ = 4. (b) Median minimum energy and interquartile range, log scale."))
rows = [["Horizon T", "Reachable fraction", "Median energy", "Interquartile range"]]
for T, r, m, a, b in zip(E10["T"], E10["reach"], E10["median_energy"], E10["p25"], E10["p75"]):
    if T in (4, 5, 6, 8, 10, 12, 16, 18):
        rows.append([T, f(r, 2), f(m, 1), f"{f(a, 1)} to {f(b, 1)}"])
story.append(TABLE(rows, [3.0, 4.0, 4.0, 5.0]))
story.append(P("<b>Table 6.</b> Selected horizons for six active actuators. Energies are in units of the input norm squared.", cap))
story.append(P(
    "<b>Numerical result.</b> Reachability switches on at T = 4, as predicted. Median energy is highest just above the cliff and falls "
    "over the first few horizons. Beyond about T = 8 the median plateaus between roughly 420 and 560, with large sampling noise. "
    "The data do not establish a monotone decrease at larger horizons, and we make no such claim. Two practical conclusions follow. "
    "A horizon just above the cliff is expensive, so a design with few actuators should allow more time. And the cliff, not the "
    "energy, sets the feasibility boundary."))

# =================================================================== 8
story.append(H1("8  Layer D: estimation and the information–estimation gap"))
story.append(P(
    "Version 1 showed that correlation lowers the observed fraction needed to reach normalised LMMSE error 0.2. Version 2 compares "
    "that requirement with the information condition of Proposition 8. For a Gaussian target with covariance Σ and observations "
    "Y<sub>S</sub> = Z<sub>S</sub> + noise, the mutual information is I(Z;Y) = ½ log det(Σ<sub>SS</sub> + σ²I) − ½ m log σ² in nats, "
    "converted to bits. The rate–distortion requirement R(D) is computed by reverse water-filling over the eigenvalues of Σ."))
story.append(IMG("fig14_information_estimation_gap",
                 "<b>Figure 7.</b> Information and estimation. (a) Information held per coordinate against the required rate (dashed) for three "
                 "correlation strengths. (b) Observed fraction needed for information sufficiency (blue) and LMMSE sufficiency (red)."))
rows = [["Correlation ρ", "Required rate R(D) bits/coord", "Info-sufficient fraction", "LMMSE-sufficient fraction", "Gap"]]
for r in ["0.2", "0.6", "0.9"]:
    a = RHO11[r]["o_info_sufficient"]
    b = RHO11[r]["o_lmmse_sufficient"]
    rows.append([r, f(RHO11[r]["R_req"], 3), f(a, 2), f(b, 2), f(b - a, 2)])
story.append(TABLE(rows, [2.8, 4.2, 3.4, 3.6, 2.0]))
story.append(P("<b>Table 7.</b> Two necessary conditions for estimation and their observed-fraction thresholds (n = 40, D = 0.2).", cap))
story.append(P(
    "<b>Numerical result.</b> Information sufficiency is reached earlier than LMMSE sufficiency at every correlation strength, by 0.20 to 0.25 "
    "of the observed fraction. Because the target is Gaussian and the observation is linear, the minimum-mean-square estimator is linear, so "
    "the LMMSE column is the true minimum distortion for each observed set. The gap therefore lies between the rate–distortion converse "
    "and what a fixed channel delivers. The converse counts bits that could in principle be extracted. The channel fixes which bits are "
    "accessible. Conjecture 3 states that the gap is positive, and the data are consistent with it at all three correlation strengths."))

# =================================================================== 9
story.append(H1("9  Layer E: the thermodynamic floor"))
story.append(P(
    "For a unit-variance Gaussian coordinate, reducing normalised error to D requires at least ½ log<sub>2</sub>(1/D) bits. For D = 0.2 "
    f"this is {S1['E5_bits_at_D0.2']:.3f} bits per coordinate. At 310 K the Landauer-type energy per bit is "
    f"{S1['E5_kTln2_J_310K']:.2e} J, so the floor for 40 coordinates is about {S1['E5_bits_at_D0.2'] * S1['E5_kTln2_J_310K'] * 40:.1e} J. "
    "One hydrolysis of ATP releases roughly 8 × 10<super>−20</super> J under standard conditions, about thirty times the floor per bit."))
story.append(P(
    "The floor is far below the costs of reachability in Layer C, which are set by the energy of steering and not by the bits needed. "
    "We therefore do not treat thermodynamics as binding in these models. The floor becomes relevant only in systems whose dissipation is "
    "close to the minimum, which real processes are not (Seifert 2012; Parrondo et al. 2015). The layer is included for completeness, "
    "and its role is to exclude claims that would require energies below the bound."))

# =================================================================== 10
story.append(H1("10  The independence question: shared-substrate damage"))
story.append(P(
    "The composite frontier of Version 1 multiplies layer probabilities. That is correct only when the layers' events are independent, "
    "which holds when the three layers are built on disjoint substrates and damage is drawn independently. A shared substrate, in which "
    "one unit carries a code symbol, cloud points and possibly an actuator, creates dependence through the damage process. We test this "
    "design directly."))
story.append(P(
    "We take n = 48 units, each carrying one code symbol (k = 24, rate 1/2), five cloud points, and one actuator for the first ten units. "
    "Each unit is damaged independently with probability x, so the damage process is a product measure. The control layer uses a fixed "
    "stable system with n = 20 states and horizon T = 8, with success determined for every subset of active actuators. The topology layer "
    "removes the points of damaged units and tests the three-cluster count. Joint success is evaluated on the same damage draw. The product "
    "uses the marginal success probabilities from that draw. We used 4000 trials per damage level, which gives a standard error of about 0.007 to 0.013 on each joint probability near the middle of the range."))
story.append(IMG("fig15_shared_substrate_dependence",
                 "<b>Figure 8.</b> Shared-substrate dependence. (a) Joint success probability for all three layers against the product of "
                 "marginals, with the 95% band for the joint. (b) Joint minus product, for all three layers and for code and control only."))
rows = [["x", "P<sub>code</sub>", "P<sub>ctrl</sub>", "P<sub>topo</sub>", "Joint (all)", "Product (all)", "Joint − product", "Joint − product (code, control)"]]
for i, x in enumerate(E12x):
    rows.append([f(x, 1), f(E12["P_code"][i], 3), f(E12["P_ctrl"][i], 3), f(E12["P_topo"][i], 3),
                 f(E12["joint3"][i], 3), f(E12["product3"][i], 3), f(E12["dev3"][i], 4), f(E12["dev_cc"][i], 4)])
story.append(TABLE(rows, [1.3, 1.9, 1.9, 1.9, 2.0, 2.2, 2.4, 2.8]))
story.append(P("<b>Table 8.</b> Shared-substrate experiment, 4000 trials per row. The 95% half-width on a joint probability is at most about 0.02 in this range.", cap))
story.append(P(
    "<b>Numerical result.</b> Three findings. First, the topology layer never failed at these damage levels, because deletion up to half "
    "the points preserves the three-cluster count, as Version 1 showed. The joint probability for all three layers therefore equals the "
    "code-and-control joint, and the topology layer contributes nothing to the dependence in this regime. Second, the gap has the sign that "
    "Proposition 9 predicts. Code success and control success are increasing in the set of surviving units, so the joint probability is at "
    "least the product, and the measured gaps are nonnegative at all six damage levels. Third, the magnitudes are 0.0003, 0.0034, 0.0219 and 0.0266 at x = 0.2 to 0.5. The two largest are about two standard "
    "errors each, so the size is suggestive rather than established at any single damage level. The sign is established by the "
    "inequality, and the size is measured but modest."))
story.append(P(
    "<b>Consequence.</b> For the code and control layers under product damage, the composite of Version 1 is a conservative estimate: it "
    "underestimates joint recoverability. Frontier positions computed from the product are therefore safe in one direction. Measuring the size "
    "more precisely needs more trials, and a design with stronger shared dependence would produce a larger gap. The "
    "result does not extend to topology, which is not monotone in unit survival."))

# =================================================================== 11
story.append(H1("11  The composite frontier, revisited"))
story.append(P(
    "Version 1's composite frontier is unchanged by the new experiments. Its critical damage at full actuation is "
    f"{E6['rates']['0.25']['frontier_x_at_a'][0]:.2f}, {E6['rates']['0.5']['frontier_x_at_a'][0]:.2f} and "
    f"{E6['rates']['0.75']['frontier_x_at_a'][0]:.2f} for rates 1/4, 1/2 and 3/4. The layer that determines the frontier is still control: "
    "above an actuator loss of 0.3 the success probability is below one half at every damage level."))
story.append(IMG("fig07_recoverability_frontier",
                 "<b>Figure 9.</b> Composite frontier from Version 1, under the product formula. Section 10 shows that for code and control "
                 "under product damage this product is a conservative lower bound."))
story.append(IMG("fig08_layer_transitions_dashboard",
                 "<b>Figure 10.</b> Layer transition points, each taken from its own experiment, as in Version 1."))
story.append(P(
    "The Version 2 results sharpen this picture in three ways. The coding threshold has a finite-size window that shrinks as 1/n, so "
    "the frontier is a sharp line for large codes. The topology threshold depends on the separability index, and it does not limit the "
    "frontier at moderate damage. The control threshold is a discrete rank cliff with a cost cliff just above it. The frontier is therefore "
    "governed by the coding and control layers, with topology and estimation playing supporting roles in the regimes tested."))

# =================================================================== 12
story.append(H1("12  Predictions, status and falsification"))
story.append(P("Table 9 records each hypothesis of Version 2 with its status. Failed predictions are retained."))
rows = [["#", "Prediction", "Status"],
        ["H1", "Random code full-rank probability matches Proposition 2", "Supported (Version 1)"],
        ["H2", "Coding threshold converges to 1/2 at rate 1/2 as n grows", "Supported; n = 24 to 192"],
        ["H3", "Transition width scales as n<super>−1</super>", "Partly supported; fitted −0.82, grid-limited"],
        ["H4", "Surplus limit equals the infinite product", "Supported to four decimals at k = 96"],
        ["H5", "Calibrated topological scale exists iff separability exceeds one", "Supported by Proposition 11 and Table 5"],
        ["H6", "Fixed-scale topology degrades with noise", "Supported; magnitude sample-dependent"],
        ["H7", "Reachability cliff at ⌈n/T⌉ across (n, T)", "Supported in all 30 grid cells"],
        ["H8", "Information sufficiency precedes LMMSE sufficiency", "Supported at three correlation strengths"],
        ["H9", "Joint success is at least the product for code and control", "Sign supported at all six levels; size 0.02–0.03 at x = 0.4–0.5, about two standard errors"],
        ["H10", "Shared topology changes the joint result", "Not observed; topology never failed here"],
        ["H11", "Composite frontier is governed by control", "Supported in Version 1 and unchanged"],
        ["H12", "Landauer floor constrains restoration cost", "Bound only; not binding in these models"]]
story.append(TABLE(rows, [1.2, 9.2, 5.6]))
story.append(P("<b>Table 9.</b> Predictions and status. H3 and H9 are the two places where the evidence is weakest relative to the claim.", cap))

# =================================================================== 13
story.append(H1("13  Limitations"))
for t in [
    "<b>Stylised models.</b> Every system is abstract and dimensionless. Nothing here fits biological data, and no numerical value is a "
    "prediction for any organism.",
    "<b>Sample sizes.</b> Most Monte Carlo estimates use 200 to 600 trials. Differences below about 0.01 to 0.02 in probability are not resolved at "
    "a single point, and the most interesting comparison (Section 10) sits at about this level.",
    "<b>Single sample of the intact system.</b> Topological and reachability results were computed on one intact sample each, with the same "
    "random seed family. Version 1's experience shows that a specific number can move with the sample. Robustness across samples is "
    "a priority for the next version.",
    "<b>Gaussian and linear assumptions.</b> Layer D assumes Gaussian statistics and linear observations with known covariance. Layer C "
    "assumes linear dynamics with known matrices. Real systems are nonlinear, and their parameters are not known.",
    "<b>Monotone and non-monotone layers.</b> The Harris–FKG argument applies to increasing events. Topology is not increasing in unit survival, so "
    "the composite bound is not established for that layer.",
    "<b>Literature.</b> The literature search was not exhaustive. Novelty is claimed only to the authors' knowledge, and each sub-result may "
    "exist in the classical literature in a different form.",
    "<b>No link to experiment.</b> A biological test would need to measure information content, reachability and energy in a living system. "
    "The models here do not supply those measurements, and Section 15 describes what such a test would require."]:
    story.append(P(t))

# =================================================================== 14
story.append(H1("14  A research programme: precise open problems"))
story.append(P(
    "We state the problems that Version 2 leaves open, in the form in which a solution would settle them. Each is an invitation to "
    "a specific piece of mathematics or simulation, and none is claimed."))
story.append(P(
    "<b>Problem 1 (joint threshold).</b> Characterise the set of (x, a, R) for which all layers pass when damage is a common latent "
    "process and each layer's events are monotone in unit survival. Proposition 9 gives a lower bound. Determine when the bound is tight."))
story.append(P(
    "<b>Problem 2 (finite-size width).</b> Prove or refute that the 25–75% erasure width of random binary codes at rate R is of order "
    "1/n for all R in (0, 1). Version 2 supports this at R = 1/2 with the exponent −0.82 and a grid-limited estimate."))
story.append(P(
    "<b>Problem 3 (channel-constrained rate–distortion).</b> Find the minimum number of observed coordinates needed for distortion D "
    "when the observation channel is fixed and the target is Gaussian. Proposition 8 gives a necessary condition that Section 8 shows is "
    "not sufficient for the observed fraction."))
story.append(P(
    "<b>Problem 4 (topological stability).</b> Replace single-linkage clustering with persistence landscapes and bootstrap stability, "
    "and determine which noise levels preserve a given topological invariant. Proposition 11 gives the criterion for one scale. Extend it "
    "to a family of scales."))
story.append(P(
    "<b>Problem 5 (nonlinear reachability).</b> Determine the energy cliff for nonlinear dynamics with state-dependent damage. The linear "
    "cliff of Proposition 4 is a special case, and the question is whether a corresponding rank-type condition exists."))
story.append(P(
    "<b>Problem 6 (bridging mechanism).</b> Test whether the increase of topological preservation with deletion under jitter is caused by "
    "a reduction in inter-cluster bridging links, using direct counts of bridges as the measured quantity."))

# =================================================================== 15
story.append(H1("15  Discussion and scope"))
story.append(P(
    "The results support a layered picture in which each layer has its own threshold and its own mathematics. Coding sets the damage a "
    "representation tolerates, with a sharp finite-size window. Topology sets how much organisation can be identified, and it depends on "
    "a scale that exists only when clusters are separated relative to noise. Reachability sets whether any admissible control can reach "
    "the target, with a discrete rank cliff and a steep energy cost above it. Estimation sets how much of the target a partial "
    "observation can recover, and it is bounded by an information condition that is necessary but not sufficient. The thermodynamic floor "
    "is far below the other costs in these models."))
story.append(P(
    "Three conclusions for research design follow. Recoverability should be measured in each currency separately, because no single "
    "summary captures all of them. Topological summaries must be calibrated to measurement noise before comparison, and a calibration "
    "should be reported with its separability index. Frontier computations that multiply layer probabilities should state whether the "
    "layers share a substrate, since shared damage changes the answer in a predictable direction."))
story.append(P(
    "We wish to be explicit about what these results do not say. They do not show that any damaged organism, tissue or person can be "
    "restored, that identity can be preserved or recovered, or that any intervention would achieve function. They describe conditions under "
    "which an abstract information state is recoverable in a stylised model. A statement about living systems would need a separate "
    "experiment with its own measurements, controls, pre-registered criteria and ethical review. Such an experiment lies outside this paper."))

# =================================================================== 16
story.append(H1("16  Conclusion"))
story.append(P(
    "Version 2 turns a set of illustrative calculations into a sharper framework with exact limits, a calibration criterion, a verified "
    "reachability rank law across a grid, an information–estimation gap, and a test of the independence assumption. Two earlier expectations "
    "were corrected: the coding limit is an infinite product, not an exponential, and the topological fragility depends on the sample. The "
    "composite frontier remains governed by control, and the independence assumption makes the composite a conservative estimate for "
    "the code and control layers. Six problems are left open in precise form. The framework is a tool for asking where recoverability ends. "
    "It says nothing about whether any living system can be brought back."))

# =================================================================== App A
story.append(H1("Appendix A  Complete proofs"))
story.append(P(
    "<b>Proof of Proposition 3, limit step.</b> Fix δ ≥ 0. Write P<sub>full</sub>(k, k+δ) = ∏<sub>j=δ+1</sub><super>k+δ</super>(1 − 2<super>−j</super>). "
    "For fixed δ the upper limit k+δ → ∞. The partial products are monotone in the upper limit and bounded below by zero, so their limit "
    "exists and equals ∏<sub>j≥δ+1</sub>(1 − 2<super>−j</super>), which converges because Σ 2<super>−j</super> < ∞. For δ < 0 the probability is zero by "
    "Proposition 2, since s < k. ∎"))
story.append(P(
    "<b>Numerical check.</b> At k = 96 and δ = 0 the exact product is 0.288788 and the limit is 0.288788; at δ = 3 the exact value is "
    "0.880116 and the limit 0.880116. Agreement to six digits at these values is a test of the algebra, not of the Monte Carlo."))
story.append(P(
    "<b>Proof of Proposition 4, rank equality.</b> Let p = min(n, Tm). Consider the n × Tm matrix M. Its rank is the dimension of the span of "
    "the columns A<super>t</super>b<sub>j</sub>. For generic (A, B) with m ≥ 1, the Krylov vectors from each input are linearly independent up to "
    "the Krylov degree, and the union over inputs spans min(n, Tm) dimensions. The nonvanishing of a p × p minor is a polynomial condition in "
    "(A, B), nonzero at the cyclic-shift construction, so it holds on a dense open set. ∎"))
story.append(P(
    "<b>Proof of Proposition 6.</b> Let M<sub>1</sub> have column set C and M<sub>2</sub> = [M<sub>1</sub>, b<sub>new</sub>]. Any solution u<sub>1</sub> of "
    "M<sub>1</sub>u = r gives a solution [u<sub>1</sub>; 0] of M<sub>2</sub>u = r with the same norm. Hence the minimum energy for M<sub>2</sub> is at most "
    "that for M<sub>1</sub>. Rank is nondecreasing under column addition. ∎"))
story.append(P(
    "<b>Proof of Proposition 9.</b> The Harris inequality states that for independent random variables taking values in totally ordered "
    "spaces, increasing events are positively correlated. The product of Bernoulli survival variables satisfies the FKG lattice condition, "
    "so the inequality holds for increasing events. Code success is increasing in the survivor set, because adding a surviving symbol cannot "
    "reduce the rank of the surviving generator. Control success is increasing by Proposition 6. The topology event is not increasing, and the "
    "proposition does not apply to it. ∎"))
story.append(P(
    "<b>Proof of Proposition 11.</b> Over calibration draws, let W be the random variable of the widest within-cluster link and B the "
    "smallest between-cluster distance. A cut τ yields the correct count for all draws if and only if max W < τ < min B. This is possible "
    "exactly when the 95th percentile of W is below the 5th percentile of B, which is the separability condition. The geometric mean of the "
    "two percentiles lies in the interval when the condition holds. ∎"))

# =================================================================== App B
story.append(H1("Appendix B  Experimental protocol and parameters"))
story.append(P(
    "All experiments are in <font face='Mono'>code/v2_experiments.py</font>, which reuses primitives from the Version 1 script. Version 1 "
    "experiments are reproduced by <font face='Mono'>code/recoverability_experiments.py</font>. Seeds are 20261108 (Version 1) and "
    "20261109 (Version 2). The packing of binary vectors is linear, so GF(2) ranks are exact at every code length."))
rows = [["Experiment", "Parameters", "Trials"],
        ["E7 finite-size coding", "n = 24, 48, 96, 192; rate 1/2; grid 0.30 to 0.70 in 25 steps", "400 per point"],
        ["E8 topology calibration", "σ = 0 to 0.6; 240 points; deletion 0 to 0.8; cut 1.0 or calibrated", "60 draws; 200 per point"],
        ["E9 control grid", "n = 8, 12, 16, 20, 24; T = 1, 2, 3, 4, 6, 8; full actuators", "20 sets per count"],
        ["E10 time–energy", "n = 20; m = 6 of 10 actuators; T = 3 to 18", "30 sets; 10 targets"],
        ["E11 information gap", "n = 40; ρ = 0.2, 0.6, 0.9; noise 0.1; D = 0.2; o grid 0.05 to 1", "40 subsets per o"],
        ["E12 shared substrate", "48 units; k = 24; Bernoulli damage; 5 points per unit; 10 actuators; κ = 2", "4000 per x"]]
story.append(TABLE(rows, [4.0, 9.0, 3.0]))
story.append(P("<b>Table 10.</b> Experimental parameters. Version 1 parameters are listed in its Appendix B.", cap))

# =================================================================== App C
story.append(H1("Appendix C  Corrections from Version 1"))
for t in [
    "<b>Limit of the coding law.</b> Version 1's preliminary notes proposed an exponential limit for the surplus law. The exact limit is the "
    "infinite product in Proposition 3. The exponential is off by about 0.08 at δ = 0 and is retracted.",
    "<b>Topological jitter result.</b> Version 1 reported preservation 0.513 at jitter 0.3 and zero deletion. On a second intact sample, "
    "the value is 0.79. The claim that a fixed scale is fragile stands, but the specific number is sample-dependent.",
    "<b>Composite frontier.</b> Version 1 presented the product as the composite probability without testing independence. Version 2 shows "
    "that for code and control under product damage the product is a conservative bound.",
    "<b>Cut for the topology layer.</b> Version 1's cut of 1.0 was chosen from intact data; a first attempt at 1.5 merged two clusters. "
    "This choice is documented in Section 6 and is retained as the fixed-scale baseline.",
    "<b>Estimation gap.</b> Version 1 did not compare estimation with the information condition. Version 2 shows the two necessary conditions "
    "differ, and that the LMMSE column is the true minimum distortion for a Gaussian target."]:
    story.append(P(t))

# =================================================================== references
story.append(H1("References"))
refs = [
    "Berger T (1971) Rate Distortion Theory. Prentice-Hall.",
    "Bennett CH (1982) The thermodynamics of computation: a review. Int J Theor Phys 21:905–940.",
    "Carlsson G (2009) Topology and data. Bull Am Math Soc 46:255–308.",
    "Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd edn. Wiley.",
    "Edelsbrunner H, Letscher D, Zomorodian A (2002) Topological persistence and simplification. Discrete Comput Geom 28:511–533.",
    "Harris TE (1960) A lower bound for the critical probability in a certain percolation process. Proc Camb Philos Soc 56:13–20.",
    "Fortuin CM, Kasteleyn PW, Ginibre J (1971) Correlation inequalities on some partially ordered sets. Commun Math Phys 22:89–103.",
    "Josselyn SA, Tonegawa S (2020) Memory engrams: recalling the past and imagining the future. Science 367:eaaw4325.",
    "Kalman RE (1963) Mathematical description of linear dynamical systems. J SIAM Control 1:152–192.",
    "Landauer R (1961) Irreversibility and heat generation in the computing process. IBM J Res Dev 5:183–191.",
    "Parrondo JMR, Horowitz JM, Sagawa T (2015) Thermodynamics of information. Nat Phys 11:131–139.",
    "Richardson TJ, Urbanke RL (2008) Modern Coding Theory. Cambridge University Press.",
    "Sagawa T, Ueda M (2008) Second law of thermodynamics with discrete quantum feedback control. Phys Rev Lett 100:080403.",
    "Seifert U (2012) Stochastic thermodynamics, fluctuation theorems and molecular machines. Rep Prog Phys 75:126001.",
    "Shannon CE (1948) A mathematical theory of communication. Bell Syst Tech J 27:379–423, 623–656.",
    "Sontag ED (1998) Mathematical Control Theory, 2nd edn. Springer.",
    "Vrselja Z, Daniele SG, Silbereis J, et al. (2019) Restoration of brain circulation and cellular functions hours post-mortem. Nature 568:336–343.",
    "Zomorodian A, Carlsson G (2005) Computing persistent homology. Discrete Comput Geom 33:249–274.",
]
for r in refs:
    story.append(P(r, small))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Sans", 7)
    canvas.setFillColor(GREY)
    canvas.drawString(2.0 * cm, 1.2 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 2.0 · Debnath & Xylia · 8 Nov 2026")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"{doc.page}")
    canvas.restoreState()


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2.0 * cm, rightMargin=2.0 * cm, topMargin=1.8 * cm,
                            bottomMargin=1.9 * cm,
                            title="The Recoverability Frontier of Damaged Information-Bearing Systems (v2)",
                            author="Devanik Debnath; Xylia", subject="Preprint v2.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    from pypdf import PdfReader
    print("wrote", OUT, "pages", len(PdfReader(OUT).pages))
