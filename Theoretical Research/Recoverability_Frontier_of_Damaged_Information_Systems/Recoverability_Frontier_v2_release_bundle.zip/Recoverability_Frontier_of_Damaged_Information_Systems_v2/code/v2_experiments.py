#!/usr/bin/env python3
"""
Recoverability Frontier v2: additional experiments E7-E12.
Reuses primitives from recoverability_experiments.py (v1). Fixed seed 20261109.
Abstract, stylised systems only. No organism, person or identity is modelled.
"""
import json
import math
import os

import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import cdist

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from recoverability_experiments import (cluster_cloud, crossing, rank_bits,
                                        theory_full_rank, topo_signature, wilson)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results_v2")
FIG = os.path.join(ROOT, "figures_v2")
os.makedirs(RES, exist_ok=True)
os.makedirs(FIG, exist_ok=True)
SEED = 20261109
rng = np.random.default_rng(SEED)
C1, C2, C3, C4 = "#1f4e79", "#c0504d", "#4f8f3a", "#8064a2"
plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "legend.fontsize": 7.5, "figure.dpi": 110})


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=160, bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".svg"), bbox_inches="tight")
    plt.close(fig)


def dump(obj, name):
    with open(os.path.join(RES, name + ".json"), "w") as f:
        json.dump(obj, f, indent=2)


def pack_rows(M):
    """Pack each 0/1 row into a non-negative Python int. Packing is linear, so XOR of
    rows corresponds to XOR of ints and GF(2) rank is preserved for any width."""
    return [int.from_bytes(np.packbits(r.astype(np.uint8)).tobytes(), "big") for r in M]


def success_code(k, n, s, gen):
    G = gen.integers(0, 2, size=(k, n), dtype=np.int64)
    S = gen.choice(n, size=s, replace=False)
    return rank_bits(pack_rows(G[:, S])) == k


# ----------------------------------------------------------------- E7
def E7_finite_size(TR=400):
    """Finite-size scaling of the coding threshold at R = 1/2, and the Gumbel-type limit."""
    out = {"sizes": [], "e50": [], "e25": [], "e75": [], "width": [], "curves": {}}
    grid = np.linspace(0.30, 0.70, 25)
    for n in [24, 48, 96, 192]:
        k = n // 2
        p = []
        for e in grid:
            s = n - int(round(e * n))
            p.append(sum(success_code(k, n, s, rng) for _ in range(TR)) / TR)
        e50 = crossing(grid, p, 0.5)
        e25 = crossing(grid, p, 0.25)
        e75 = crossing(grid, p, 0.75)
        out["sizes"].append(n)
        out["e50"].append(e50)
        out["e25"].append(e25)
        out["e75"].append(e75)
        out["width"].append(e25 - e75 if (e25 == e25 and e75 == e75) else float("nan"))
        out["curves"][str(n)] = {"e": grid.tolist(), "p": p}
    w = np.array(out["width"], float)
    slope = float(np.polyfit(np.log(out["sizes"]), np.log(np.abs(w)), 1)[0])
    out["width_loglog_slope"] = slope
    # Limit: P_full(k, k+delta) -> prod_{j>delta}(1-2^(-j)) for delta >= 0, and 0 for delta < 0
    k = 96
    deltas = list(range(-2, 7))
    out["gumbel"] = {"delta": deltas,
                     "exact_k96": [theory_full_rank(k, k + d) for d in deltas],
                     "limit": [0.0 if d < 0 else float(np.prod([1 - 2.0 ** (-j) for j in range(d + 1, 200)]))
                               for d in deltas]}
    return out


# ----------------------------------------------------------------- E8
def separability(X, labels_true):
    """Within-cluster 95th percentile of the widest single-linkage link versus the
    smallest between-cluster distance (5th percentile over draws is taken by the caller)."""
    within = []
    for c in np.unique(labels_true):
        Xc = X[labels_true == c]
        within.append(np.max(linkage(Xc, "single")[:, 2]))
    between = np.inf
    cl = [X[labels_true == c] for c in np.unique(labels_true)]
    for i in range(len(cl)):
        for j in range(i + 1, len(cl)):
            between = min(between, float(np.min(cdist(cl[i], cl[j]))))
    return max(within), between


def E8_topology_calibration(sigmas=(0.0, 0.15, 0.3, 0.45, 0.6), draws=60, TR=200):
    """Fixed cut (1.0, tuned on clean data) versus a noise-calibrated cut."""
    grid = np.round(np.linspace(0.0, 0.8, 9), 2)
    out = {"sigma": list(sigmas), "d": grid.tolist(), "cut_cal": [], "sep_index": [],
           "fixed": {}, "calibrated": {}}
    X0 = cluster_cloud(rng)
    lab0 = np.repeat(np.arange(3), 80)
    for sigma in sigmas:
        w, b = [], []
        for _ in range(draws):
            Xc = X0 + sigma * rng.standard_normal(X0.shape)
            ww, bb = separability(Xc, lab0)
            w.append(ww)
            b.append(bb)
        w95 = float(np.percentile(w, 95))
        b05 = float(np.percentile(b, 5))
        sep = b05 / w95
        cut = math.sqrt(w95 * b05) if sep > 1 else float("nan")
        out["sep_index"].append(sep)
        out["cut_cal"].append(cut)
        for name, cutv in [("fixed", 1.0), ("calibrated", cut)]:
            pres = []
            for d in grid:
                k = int(round((1 - d) * len(X0)))
                ok = 0
                if cutv != cutv:               # no valid calibrated cut at this noise level
                    pres.append(float("nan"))
                    continue
                for _ in range(TR):
                    idx = rng.choice(len(X0), size=k, replace=False)
                    Xd = X0[idx] + sigma * rng.standard_normal((k, 2))
                    Z = linkage(Xd, "single")
                    lab = fcluster(Z, t=cutv, criterion="distance")
                    sizes = np.bincount(lab)[1:]
                    ok += int(np.sum(sizes >= 5) == 3)
                pres.append(ok / TR)
            out[name][str(sigma)] = pres
    return out


# ----------------------------------------------------------------- E9
def E9_control_grid(sets=20):
    """Empirical generic reachability cliff over a grid of (n, T), against ceil(n/T)."""
    ns, Ts = [8, 12, 16, 20, 24], [1, 2, 3, 4, 6, 8]
    out = {"n": ns, "T": Ts, "m_star": [], "predicted": []}
    for n in ns:
        row_m, row_p = [], []
        for T in Ts:
            A = rng.standard_normal((n, n))
            A *= 0.9 / np.max(np.abs(np.linalg.eigvals(A)))
            B = rng.standard_normal((n, n))
            B /= np.linalg.norm(B, axis=0)
            P = [np.linalg.matrix_power(A, p) for p in range(T + 1)]
            m_star = n
            for m in range(1, n + 1):
                reach = 0
                for _ in range(sets):
                    idx = rng.choice(n, size=m, replace=False)
                    M = np.hstack([P[T - 1 - t] @ B[:, idx] for t in range(T)])
                    reach += int(np.linalg.matrix_rank(M) == n)
                if reach / sets >= 0.95:
                    m_star = m
                    break
            row_m.append(m_star)
            row_p.append(math.ceil(n / T))
        out["m_star"].append(row_m)
        out["predicted"].append(row_p)
    out["agreement"] = float(np.mean(np.array(out["m_star"]) == np.array(out["predicted"])))
    return out


# ---------------------------------------------------------------- E10
def E10_time_energy(n=20, m=6, sets=30, targets=10):
    """Minimum input energy against horizon T for a fixed number of active actuators."""
    A = rng.standard_normal((n, n))
    A *= 0.9 / np.max(np.abs(np.linalg.eigvals(A)))
    B = rng.standard_normal((n, 10))
    B /= np.linalg.norm(B, axis=0)
    out = {"m": m, "n": n, "T": [], "reach": [], "median_energy": [], "p25": [], "p75": []}
    for T in range(3, 19):
        P = [np.linalg.matrix_power(A, p) for p in range(T + 1)]
        reach, costs = [], []
        for _ in range(sets):
            idx = rng.choice(10, size=m, replace=False)
            M = np.hstack([P[T - 1 - t] @ B[:, idx] for t in range(T)])
            ok = np.linalg.matrix_rank(M) == n
            reach.append(float(ok))
            if ok:
                G = M @ M.T
                for _ in range(targets):
                    x0 = rng.standard_normal(n)
                    z = rng.standard_normal(n)
                    r = z - P[T] @ x0
                    costs.append(float(r @ np.linalg.solve(G, r)))
        out["T"].append(T)
        out["reach"].append(float(np.mean(reach)))
        c = np.array(costs) if costs else np.array([np.nan])
        out["median_energy"].append(float(np.nanmedian(c)))
        out["p25"].append(float(np.nanpercentile(c, 25)))
        out["p75"].append(float(np.nanpercentile(c, 75)))
    return out


# ---------------------------------------------------------------- E11
def reverse_waterfill_rate(lams, D_total):
    """Gaussian vector rate-distortion R(D) in bits by reverse water-filling."""
    lo, hi = 0.0, float(np.max(lams))
    for _ in range(200):
        th = 0.5 * (lo + hi)
        if np.sum(np.minimum(th, lams)) > D_total:
            hi = th
        else:
            lo = th
    th = 0.5 * (lo + hi)
    return float(np.sum(np.maximum(0.0, 0.5 * np.log2(lams / th))))


def E11_info_gap(n=40, noise=0.1, draws=40, D_target=0.2):
    idx = np.arange(n)
    o_grid = np.round(np.linspace(0.05, 1.0, 20), 3)
    out = {"n": n, "o": o_grid.tolist(), "rho": {}}
    for rho in [0.2, 0.6, 0.9]:
        Sigma = rho ** np.abs(idx[:, None] - idx[None, :]).astype(float)
        lams = np.linalg.eigvalsh(Sigma)
        R_req = reverse_waterfill_rate(lams, D_target * n) / n        # bits per coordinate
        I_obs, D_lin = [], []
        for o in o_grid:
            m = max(1, int(round(o * n)))
            iv, dv = [], []
            for _ in range(draws):
                S = rng.choice(n, size=m, replace=False)
                SS = Sigma[np.ix_(S, S)] + noise * np.eye(m)
                iv.append((np.linalg.slogdet(SS)[1] - m * math.log(noise)) / (2 * math.log(2)))
                dv.append(lmmse_D_local(Sigma, S, noise))
            I_obs.append(float(np.mean(iv)) / n)
            D_lin.append(float(np.mean(dv)))
        info_suff = first_ge(o_grid, I_obs, R_req)
        lmmse_suff = first_le(o_grid, D_lin, D_target)
        out["rho"][str(rho)] = {"I_per_coord": I_obs, "D_lin": D_lin, "R_req": R_req,
                                "o_info_sufficient": info_suff, "o_lmmse_sufficient": lmmse_suff}
    return out


def lmmse_D_local(Sigma, S, noise):
    n = Sigma.shape[0]
    SS = Sigma[np.ix_(S, S)] + noise * np.eye(len(S))
    K = Sigma[:, S] @ np.linalg.solve(SS, Sigma[S, :])
    return float(np.trace(Sigma - K) / n)


def first_ge(x, y, level):
    for xi, yi in zip(x, y):
        if yi >= level:
            return float(xi)
    return float("nan")


def first_le(x, y, level):
    for xi, yi in zip(x, y):
        if yi <= level:
            return float(xi)
    return float("nan")


# ---------------------------------------------------------------- E12
def E12_shared_substrate(TR=300, n_units=48, k_info=24, m_act=10, kappa=2.0):
    """Shared-substrate test of the independence assumption.
    Each unit is damaged independently with probability x (Bernoulli, so every success
    event that is monotone in survivors is an increasing event on a product space).
    Unit i carries code symbol i, five cloud points (5i..5i+4) and possibly one actuator.
    Joint success is evaluated on the same damage draw; the product uses the marginals."""
    # control system with a precomputed success table over actuator subsets
    n_s, T = 20, 8
    A = rng.standard_normal((n_s, n_s))
    A *= 0.9 / np.max(np.abs(np.linalg.eigvals(A)))
    B = rng.standard_normal((n_s, m_act))
    B /= np.linalg.norm(B, axis=0)
    P = [np.linalg.matrix_power(A, p) for p in range(T + 1)]
    targets = [(rng.standard_normal(n_s), rng.standard_normal(n_s)) for _ in range(10)]
    def mean_cost(mask):
        idx = [j for j in range(m_act) if mask >> j & 1]
        M = np.hstack([P[T - 1 - t] @ B[:, idx] for t in range(T)])
        if np.linalg.matrix_rank(M) < n_s:
            return float("nan")
        G = M @ M.T
        cs = []
        for x0, z in targets:
            r = z - P[T] @ x0
            cs.append(float(r @ np.linalg.solve(G, r)))
        return float(np.mean(cs))
    full_cost = mean_cost((1 << m_act) - 1)
    succ = np.zeros(1 << m_act, dtype=bool)
    for mask in range(1 << m_act):
        c = mean_cost(mask)
        succ[mask] = (not math.isnan(c)) and c <= kappa * full_cost
    # actuators sit on the first m_act units
    act_units = np.arange(m_act)
    x_grid = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
    out = {"x": x_grid, "P_code": [], "P_ctrl": [], "P_topo": [], "joint3": [],
           "joint_code_ctrl": [], "product3": [], "product_code_ctrl": [],
           "dev3": [], "dev_cc": [], "joint3_lo": [], "joint3_hi": [],
           "joint_cc_lo": [], "joint_cc_hi": []}
    for x in x_grid:
        c_ok = t_ok = ctl_ok = j3 = jcc = 0
        for _ in range(TR):
            dmg = rng.random(n_units) < x          # True = damaged
            surv = ~dmg
            s_code = int(surv.sum())
            G = rng.integers(0, 2, size=(k_info, n_units), dtype=np.int64)
            S = np.flatnonzero(surv)
            code_ok = False
            if s_code >= k_info:
                code_ok = rank_bits(pack_rows(G[:, S])) == k_info
            act_mask = 0
            for j, u in enumerate(act_units):
                if surv[u]:
                    act_mask |= 1 << j
            ctl = bool(succ[act_mask])
            keep = np.repeat(surv, 5)              # 240 points, five per unit
            Xc = cluster_cloud_fixed[keep]
            topo = topo_signature(Xc)[0] == 3 if len(Xc) > 10 else False
            c_ok += code_ok
            t_ok += topo
            ctl_ok += ctl
            j3 += code_ok and topo and ctl
            jcc += code_ok and ctl
        pc, pt, pk = c_ok / TR, t_ok / TR, ctl_ok / TR
        j3p, jccp = j3 / TR, jcc / TR
        out["P_code"].append(pc)
        out["P_topo"].append(pt)
        out["P_ctrl"].append(pk)
        out["joint3"].append(j3p)
        out["joint_code_ctrl"].append(jccp)
        out["product3"].append(pc * pt * pk)
        out["product_code_ctrl"].append(pc * pk)
        out["dev3"].append(j3p - pc * pt * pk)
        out["dev_cc"].append(jccp - pc * pk)
        lo3, hi3 = wilson(j3, TR)
        lcc, hcc = wilson(jcc, TR)
        out["joint3_lo"].append(lo3)
        out["joint3_hi"].append(hi3)
        out["joint_cc_lo"].append(lcc)
        out["joint_cc_hi"].append(hcc)
    out["control_success_table_size"] = int(succ.sum())
    return out


cluster_cloud_fixed = None


# ================================================================ figures
def fig_finite_size(E7):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    cols = [C1, C2, C3, C4]
    for col, n in zip(cols, E7["sizes"]):
        c = E7["curves"][str(n)]
        ax[0].plot(c["e"], c["p"], "o-", ms=2.5, color=col, label=f"n = {n}")
    ax[0].axvline(0.5, color="grey", ls=":", lw=0.8)
    ax[0].set_xlabel("erasure fraction ε")
    ax[0].set_ylabel("P(full recovery)")
    ax[0].set_title("(a) Sharpening of the R = 1/2 threshold")
    ax[0].legend(fontsize=6.5)
    w = np.array(E7["width"], float)
    sz = np.array(E7["sizes"], float)
    ax[1].loglog(sz, w, "o", color=C1, label="measured 25–75% width")
    ref = w[0] * (sz / sz[0]) ** -1.0
    ax[1].loglog(sz, ref, "--", color="grey", label="slope −1 (prediction)")
    ax[1].set_xlabel("code length n")
    ax[1].set_ylabel("transition width in ε")
    ax[1].set_title(f"(b) Width scaling, fitted slope {E7['width_loglog_slope']:.2f}")
    ax[1].legend(fontsize=6.5)
    fig.tight_layout()
    save(fig, "fig09_finite_size_scaling")


def fig_gumbel(E7):
    fig, ax = plt.subplots(figsize=(4.2, 2.8))
    d = E7["gumbel"]["delta"]
    ax.plot(d, E7["gumbel"]["exact_k96"], "o", color=C1, label="exact, k = 96")
    ax.plot(d, E7["gumbel"]["limit"], "-", color=C2, lw=1.0, label="limit ∏_{j>δ}(1−2^{−j})")
    ax.set_xlabel("surplus symbols δ = s − k")
    ax.set_ylabel("P(full rank)")
    ax.set_title("Infinite-product limit of full rank")
    ax.legend()
    fig.tight_layout()
    save(fig, "fig10_gumbel_limit")


def fig_topology_cal(E8):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    sig = np.array(E8["sigma"])
    ax[0].plot(sig, E8["sep_index"], "o-", color=C1)
    ax[0].axhline(1.0, color="grey", ls=":", lw=0.8)
    ax[0].set_xlabel("jitter σ")
    ax[0].set_ylabel("separability index (between / within)")
    ax[0].set_title("(a) Noise–separation boundary")
    d = np.array(E8["d"])
    for s, col in zip(["0.15", "0.45"], [C2, C3]):
        ax[1].plot(d, E8["fixed"][s], "o--", ms=2.5, color=col, alpha=0.6, label=f"fixed cut, σ={s}")
        ax[1].plot(d, E8["calibrated"][s], "s-", ms=2.5, color=col, label=f"calibrated cut, σ={s}")
    ax[1].set_xlabel("damage fraction")
    ax[1].set_ylabel("P(3 clusters preserved)")
    ax[1].set_title("(b) Fixed versus calibrated scale")
    ax[1].legend(fontsize=5.8)
    fig.tight_layout()
    save(fig, "fig11_topology_calibration")


def fig_control_grid(E9):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    M = np.array(E9["m_star"], float)
    Pp = np.array(E9["predicted"], float)
    im0 = ax[0].imshow(M, cmap="viridis", origin="lower", aspect="auto")
    ax[0].set_xticks(range(len(E9["T"])))
    ax[0].set_xticklabels(E9["T"])
    ax[0].set_yticks(range(len(E9["n"])))
    ax[0].set_yticklabels(E9["n"])
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax[0].text(j, i, f"{int(M[i, j])}", ha="center", va="center", color="white", fontsize=7)
    ax[0].set_xlabel("horizon T")
    ax[0].set_ylabel("states n")
    ax[0].set_title("(a) Empirical cliff m*(n, T)")
    fig.colorbar(im0, ax=ax[0], fraction=0.046)
    diff = M - Pp
    ax[1].imshow(diff, cmap="RdBu", origin="lower", aspect="auto", vmin=-2, vmax=2)
    ax[1].set_xticks(range(len(E9["T"])))
    ax[1].set_xticklabels(E9["T"])
    ax[1].set_yticks(range(len(E9["n"])))
    ax[1].set_yticklabels(E9["n"])
    for i in range(diff.shape[0]):
        for j in range(diff.shape[1]):
            ax[1].text(j, i, f"{int(diff[i, j]):+d}", ha="center", va="center", fontsize=7)
    ax[1].set_xlabel("horizon T")
    ax[1].set_title(f"(b) m* − ⌈n/T⌉, agreement {E9['agreement']:.0%}")
    fig.tight_layout()
    save(fig, "fig12_control_cliff_grid")


def fig_time_energy(E10):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    T = np.array(E10["T"])
    ax[0].plot(T, E10["reach"], "o-", color=C1)
    ax[0].axvline(math.ceil(E10["n"] / E10["m"]) - 0.5, color="grey", ls=":", lw=0.8)
    ax[0].set_xlabel("horizon T")
    ax[0].set_ylabel("reachable fraction")
    ax[0].set_title(f"(a) Reachability, m = {E10['m']} actuators")
    med = np.array(E10["median_energy"])
    ax[1].semilogy(T, med, "o-", color=C2, label="median")
    ax[1].fill_between(T, E10["p25"], E10["p75"], color=C2, alpha=0.15, label="interquartile")
    ax[1].set_xlabel("horizon T")
    ax[1].set_ylabel("minimum input energy")
    ax[1].set_title("(b) Time–energy trade-off")
    ax[1].legend()
    fig.tight_layout()
    save(fig, "fig13_time_energy_tradeoff")


def fig_info_gap(E11):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    o = np.array(E11["o"])
    for rho, col in zip(["0.2", "0.6", "0.9"], [C1, C2, C3]):
        r = E11["rho"][rho]
        ax[0].plot(o, r["I_per_coord"], "o-", ms=2.5, color=col, label=f"I(Z;Y)/n, ρ={rho}")
        ax[0].axhline(r["R_req"], color=col, ls="--", lw=0.8)
    ax[0].set_xlabel("observed fraction o")
    ax[0].set_ylabel("bits per coordinate")
    ax[0].set_title("(a) Information held vs required (dashed)")
    ax[0].legend(fontsize=6.5)
    rhos = list(E11["rho"].keys())
    lm = [E11["rho"][r]["o_lmmse_sufficient"] for r in rhos]
    inf = [E11["rho"][r]["o_info_sufficient"] for r in rhos]
    x = np.arange(len(rhos))
    ax[1].bar(x - 0.18, inf, 0.36, color=C1, label="information-sufficient")
    ax[1].bar(x + 0.18, lm, 0.36, color=C2, label="LMMSE-sufficient (D ≤ 0.2)")
    ax[1].set_xticks(x)
    ax[1].set_xticklabels([f"ρ={r}" for r in rhos])
    ax[1].set_ylabel("observed fraction needed")
    ax[1].set_title("(b) Estimation gap")
    ax[1].legend(fontsize=6.5)
    fig.tight_layout()
    save(fig, "fig14_information_estimation_gap")


def fig_joint(E12):
    fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
    x = np.array(E12["x"])
    ax[0].plot(x, E12["joint3"], "o-", color=C1, label="joint, all three layers")
    ax[0].fill_between(x, E12["joint3_lo"], E12["joint3_hi"], color=C1, alpha=0.15)
    ax[0].plot(x, E12["product3"], "s--", color=C2, label="product of marginals")
    ax[0].set_xlabel("unit damage probability x")
    ax[0].set_ylabel("success probability")
    ax[0].set_title("(a) Joint versus composite")
    ax[0].legend(fontsize=6.5)
    ax[1].plot(x, E12["dev3"], "o-", color=C1, label="all three: joint − product")
    ax[1].plot(x, E12["dev_cc"], "s-", color=C3, label="code × control: joint − product")
    ax[1].axhline(0, color="k", lw=0.6)
    ax[1].set_xlabel("unit damage probability x")
    ax[1].set_ylabel("dependence gap")
    ax[1].set_title("(b) Sign and size of the gap")
    ax[1].legend(fontsize=6.5)
    fig.tight_layout()
    save(fig, "fig15_shared_substrate_dependence")


def main():
    global cluster_cloud_fixed
    cluster_cloud_fixed = cluster_cloud(np.random.default_rng(SEED + 7))
    E7 = E7_finite_size()
    dump(E7, "E7_finite_size")
    E8 = E8_topology_calibration()
    dump(E8, "E8_topology_calibration")
    E9 = E9_control_grid()
    dump(E9, "E9_control_grid")
    E10 = E10_time_energy()
    dump(E10, "E10_time_energy")
    E11 = E11_info_gap()
    dump(E11, "E11_information_estimation_gap")
    E12 = E12_shared_substrate()
    dump(E12, "E12_shared_substrate")
    fig_finite_size(E7)
    fig_gumbel(E7)
    fig_topology_cal(E8)
    fig_control_grid(E9)
    fig_time_energy(E10)
    fig_info_gap(E11)
    fig_joint(E12)
    summary = {
        "seed": SEED,
        "E7_e50": dict(zip(E7["sizes"], [round(v, 4) for v in E7["e50"]])),
        "E7_width": dict(zip(E7["sizes"], [round(v, 4) for v in E7["width"]])),
        "E7_width_loglog_slope": round(E7["width_loglog_slope"], 3),
        "E8_sep_index": dict(zip(E8["sigma"], [round(v, 3) for v in E8["sep_index"]])),
        "E8_cut_cal": dict(zip(E8["sigma"], [None if v != v else round(v, 3) for v in E8["cut_cal"]])),
        "E9_agreement": round(E9["agreement"], 3),
        "E10_reach_by_T": dict(zip(E10["T"], E10["reach"])),
        "E11_o_info": {r: v["o_info_sufficient"] for r, v in E11["rho"].items()},
        "E11_o_lmmse": {r: v["o_lmmse_sufficient"] for r, v in E11["rho"].items()},
        "E12_dev3": [round(v, 4) for v in E12["dev3"]],
        "E12_dev_cc": [round(v, 4) for v in E12["dev_cc"]],
        "E12_joint3": [round(v, 4) for v in E12["joint3"]],
        "E12_product3": [round(v, 4) for v in E12["product3"]],
    }
    dump(summary, "summary_v2")
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
