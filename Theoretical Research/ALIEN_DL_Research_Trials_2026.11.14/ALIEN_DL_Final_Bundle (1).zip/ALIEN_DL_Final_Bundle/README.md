# ALIEN-DL final research paper (v1.0, 14 November 2026)

Authors: Devanik Debnath and Xylia (AI research scientist, multi-agent research system).
Status: preprint, not peer reviewed. Exploratory evidence only; no superiority or biological-fidelity claim.

## Contents
- paper/ALIEN_DL_Final_Research_Paper.pdf: the 14-page paper covering both trials.
- code/build_paper.py: builds the PDF from data/ and figures/.
- code/make_figures.py: regenerates figures from data/ and the logged Trial B values.
- data/: Trial A per-seed results, summary and factorial CSVs (copies of the uploaded files).
- figures/: all figures as PNG and SVG.

## Result in one paragraph
Neither trial shows a superadditive benefit from the three-way coupling, and ALIEN does not beat
parameter-matched or state-matched MLPs on the datasets tested. Allocation becomes non-uniform, and in
Trial B it collapses at step size 0.5. The pre-specified kill criterion from the v2 specification is
triggered for the settings tested.

## Reproduce
pip install numpy pandas matplotlib reportlab pypdf
python code/make_figures.py   # reads data/ and writes figures/
python code/build_paper.py    # writes paper/

The build script reads from data/ in this bundle. If you edit paths, check the U= line in build_paper.py.

## Caveats
- Three seeds and small test sets (27, 171, 540 examples). Interaction contrasts are one test example each.
- The Trial B step-size sweep was selected on the test split and is descriptive only.
- Several 2025–2026 references come from the research-trials report and were not verified by the authors
  of this paper (see Section 15 of the paper).
- The PDF is binary and must be uploaded separately to GitHub.
