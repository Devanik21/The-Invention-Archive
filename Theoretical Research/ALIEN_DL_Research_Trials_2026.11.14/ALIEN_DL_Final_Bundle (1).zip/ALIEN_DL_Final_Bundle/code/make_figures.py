import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import os
OUT="/home/claude/ALIEN_final/figures"; U="/mnt/user-data/uploads"
C1,C2,C3,C4="#1f4e79","#c0504d","#4f8f3a","#8064a2"
plt.rcParams.update({"font.size":9,"axes.titlesize":9.5,"axes.labelsize":9,"legend.fontsize":7.5,"figure.dpi":110})
def save(fig,n):
    fig.savefig(f"{OUT}/{n}.png",dpi=160,bbox_inches="tight"); fig.savefig(f"{OUT}/{n}.svg",bbox_inches="tight"); plt.close(fig)
bench=pd.read_csv(f"{U}/benchmark_results.csv"); fac=pd.read_csv(f"{U}/factorial_results.csv")

# F1 architectures
fig,ax=plt.subplots(1,2,figsize=(7.6,3.6))
for a in ax: a.set_xlim(0,10); a.set_ylim(0,8); a.axis("off")
def bx(a,x,y,w,h,t,c):
    a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.05",fc=c,ec="#333",lw=0.7,alpha=0.92)); a.text(x+w/2,y+h/2,t,ha="center",va="center",fontsize=6.4)
def ar(a,x1,y1,x2,y2): a.annotate("",xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle="->",lw=0.7,color="#333"))
a=ax[0]; a.set_title("A. Xylia prototype (PyTorch)",fontsize=8.5)
bx(a,1,6.6,8,1.0,"input x  (standardised)  ->  tanh","#dbe5f1")
bx(a,1,4.6,8,1.4,"per-synapse dynamics, 3 micro-steps\nr: recovery (R couples pi)   u: facilitation","#f2dcdb")
bx(a,1,2.7,8,1.3,"q_ij = theta_ij * u * r * struct_ij * x_i\n(P: theta-update scaled by pi;  A: zeta gate)","#ebf1de")
bx(a,1,0.8,8,1.2,"compartment = tanh(sum_i q + bias) -> readout","#e4dfec")
for y1,y2 in [(6.6,6.0),(4.6,4.0),(2.7,2.0)]: ar(a,5,y1,5,y2)
a=ax[1]; a.set_title("B. Lite trial (NumPy + autograd)",fontsize=8.5)
bx(a,1,6.4,8,1.1,"input x in [0,1]  (min-max scaled)","#dbe5f1")
bx(a,1,4.4,8,1.5,"per-synapse r, u: T=5 steps\nr' = rho*pi*(1-r) - a_r*u*r*x\nu' = (U0-u)/tau + a_u*(1-u)*x","#f2dcdb")
bx(a,1,2.4,8,1.4,"hidden_j = tanh( sum_i sum_t theta_ij u r x_i / d + b_j )\npi_ij = d * softmax_i(logit_ij)   (per unit j)","#ebf1de")
bx(a,1,0.6,8,1.1,"logits = W2 h + b2   (softmax cross-entropy)","#e4dfec")
for y1,y2 in [(6.4,5.9),(4.4,3.8),(2.4,1.7)]: ar(a,5,y1,5,y2)
save(fig,"fig01_architectures")

# F2 main results both trials
fig,ax=plt.subplots(figsize=(7.4,3.2))
ds=["wine","breast_cancer","digits"]; lab=["Wine","Breast Cancer","Digits"]
mod=[("alien","ALIEN (A)",C2),("mlp_matched","MLP param-matched",C1),("mlp_fixed","MLP width 32",C3)]
x=np.arange(3); w=0.26
for i,(m,l,c) in enumerate(mod):
    v=[bench[(bench.dataset==d)&(bench.model==m)].accuracy.mean() for d in ds]
    s=[bench[(bench.dataset==d)&(bench.model==m)].accuracy.std() for d in ds]
    ax.bar(x+(i-1)*w,v,w,yerr=s,capsize=2,color=c,label=l)
ax.set_xticks(x); ax.set_xticklabels(lab); ax.set_ylim(0.8,1.02); ax.set_ylabel("test accuracy (3 seeds)")
ax.set_title("Trial A: test accuracy, mean and SD over seeds 7, 21, 42"); ax.legend(ncol=3,fontsize=6.8,loc="lower center",bbox_to_anchor=(0.5,1.0))
save(fig,"fig02_trialA_main")

# F3 factorial per seed
fig,ax=plt.subplots(1,2,figsize=(7.6,3.2))
w_=fac[fac.dataset=="wine"].copy(); w_["cfg"]=w_.apply(lambda r:f"{int(r.R)}{int(r.P)}{int(r.A)}",axis=1)
order=["000","001","010","011","100","101","110","111"]
m=w_.groupby("cfg").accuracy.mean().reindex(order); s=w_.groupby("cfg").accuracy.std().reindex(order)
ax[0].bar(order,m,yerr=s,capsize=2,color=C1); ax[0].set_ylim(0.85,1.0); ax[0].set_xlabel("R P A configuration"); ax[0].set_ylabel("Wine test accuracy")
ax[0].set_title("(a) Factorial means, 3 seeds"); ax[0].tick_params(axis="x",rotation=45)
for i,c in enumerate(order):
    v=w_[w_.cfg==c].accuracy.values
    ax[1].scatter([i]*len(v),v,color=[C7 for C7 in [C2]*len(v)] if False else C4,s=14,zorder=3)
ax[1].set_xticks(range(8)); ax[1].set_xticklabels(order,rotation=45); ax[1].set_ylim(0.75,1.02)
ax[1].set_title("(b) Per-seed values (one test example = 0.037)"); ax[1].axhline(1-1/27,color="grey",ls=":",lw=0.7)
save(fig,"fig03_factorial_wine")

# F4 allocation diagnostics (trial A, full ALIEN)
fig,ax=plt.subplots(1,3,figsize=(7.6,2.7))
al=bench[bench.model=="alien"]
for a,d,l in zip(ax,ds,lab):
    g=al[al.dataset==d].allocation_gini.values
    a.bar(range(len(g)),g,color=C3); a.set_xticks(range(len(g))); a.set_xticklabels([f"s{s}" for s in al[al.dataset==d].seed]); a.set_ylim(0,1)
    a.set_title(f"{l}: allocation Gini"); a.set_ylabel("Gini (higher = more unequal)")
fig.tight_layout(); save(fig,"fig04_allocation_gini")

# F5 lite collapse and sweep
fig,ax=plt.subplots(1,2,figsize=(7.4,3.0))
eta=[0.05,0.5]; mx=[6.72,63.36]; acc=[0.9506,0.9500]; accA=[0.9599,0.9500]
ax[0].bar([str(e) for e in eta],mx,color=C2); ax[0].set_xlabel("allocation step eta_b"); ax[0].set_ylabel("largest share pi (of d = 64)")
ax[0].set_title("(a) Largest share, transmission+allocation (digits)")
ax[1].bar(["eta=0.05","eta=0.5"],accA,color=C1,label="transmission + allocation"); ax[1].axhline(0.9586,color="k",ls="--",lw=0.8,label="frozen allocation 0.9586")
ax[1].set_ylim(0.93,0.97); ax[1].set_ylabel("digits test accuracy (3 seeds)"); ax[1].set_title("(b) Accuracy at each step size"); ax[1].legend(fontsize=6.5)
fig.tight_layout(); save(fig,"fig05_lite_collapse")

# F6 cost
fig,ax=plt.subplots(figsize=(5.4,2.8))
t=bench.groupby(["dataset","model"]).train_seconds.mean().unstack()
x=np.arange(3)
for i,(m,c,l) in enumerate([("alien",C2,"ALIEN"),("mlp_matched",C1,"MLP param-matched")]):
    ax.bar(x+(i-0.5)*0.36,[t.loc[d,m] for d in ds],0.36,color=c,label=l)
ax.set_xticks(x); ax.set_xticklabels(lab); ax.set_ylabel("mean train seconds (CPU, 1 thread)"); ax.legend(fontsize=6.8)
ax.set_title("Compute cost, Trial A"); fig.tight_layout(); save(fig,"fig06_cost")

# F7 contrasts with per-seed points
fig,ax=plt.subplots(figsize=(6.2,2.8))
labs=["R x P | A=0","R x A | P=0","P x A | R=0","three-way R x P x A"]
vals=[[0,0,0],[0,0,-0.037],[0,0,0],[0,0,0.037]]
for i,v in enumerate(vals):
    ax.scatter([i]*3,v,color=C4,s=18,zorder=3)
    ax.plot([i-0.2,i+0.2],[np.mean(v)]*2,color="k",lw=1)
ax.axhline(0,color="grey",lw=0.7); ax.set_xticks(range(4)); ax.set_xticklabels(labs,fontsize=6.5)
ax.set_ylabel("contrast (accuracy)"); ax.set_title("Paired interaction contrasts, Wine, per seed (bar = mean)")
ax.set_ylim(-0.06,0.06); fig.tight_layout(); save(fig,"fig07_contrasts")
print("figures:",sorted(os.listdir(OUT)))
