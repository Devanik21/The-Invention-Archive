#!/usr/bin/env python3
import os, pandas as pd, numpy as np
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
FD="/usr/share/fonts/truetype/dejavu/"; FIG="/home/claude/ALIEN_final/figures"
OUT="/home/claude/ALIEN_final/paper/ALIEN_DL_Final_Research_Paper.pdf"; U="/mnt/user-data/uploads"
for n,fn in [("Serif","DejaVuSerif.ttf"),("Serif-B","DejaVuSerif-Bold.ttf"),("Serif-I","DejaVuSerif-Italic.ttf"),("Serif-BI","DejaVuSerif-BoldItalic.ttf"),("Sans","DejaVuSans.ttf"),("Sans-B","DejaVuSans-Bold.ttf"),("Mono","DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(n,FD+fn))
registerFontFamily("Serif",normal="Serif",bold="Serif-B",italic="Serif-I",boldItalic="Serif-BI")
registerFontFamily("Sans",normal="Sans",bold="Sans-B",italic="Sans",boldItalic="Sans-B")
bench=pd.read_csv(f"{U}/benchmark_results.csv"); summ=pd.read_csv(f"{U}/benchmark_summary.csv"); fac=pd.read_csv(f"{U}/factorial_results.csv")
NAVY=colors.HexColor("#1f4e79"); GREY=colors.HexColor("#555555"); LIGHT=colors.HexColor("#eef3f8")
body=ParagraphStyle("b",fontName="Serif",fontSize=9.2,leading=13.4,alignment=TA_JUSTIFY,spaceAfter=5.5)
small=ParagraphStyle("s",parent=body,fontSize=8,leading=10.8,spaceAfter=2.5)
cap=ParagraphStyle("c",parent=body,fontSize=7.8,leading=10.2,textColor=GREY,spaceBefore=2,spaceAfter=9)
h1=ParagraphStyle("h1",fontName="Sans-B",fontSize=12.4,leading=16,textColor=NAVY,spaceBefore=12,spaceAfter=5)
h2=ParagraphStyle("h2",fontName="Sans-B",fontSize=10,leading=13.5,textColor=NAVY,spaceBefore=7,spaceAfter=3)
title=ParagraphStyle("t",fontName="Sans-B",fontSize=16,leading=22,alignment=TA_CENTER,textColor=NAVY,spaceAfter=8)
sub=ParagraphStyle("st",fontName="Serif-I",fontSize=10,leading=14,alignment=TA_CENTER,textColor=GREY,spaceAfter=5)
ctr=ParagraphStyle("ctr",parent=body,alignment=TA_CENTER)
cell=ParagraphStyle("ce",fontName="Serif",fontSize=7.4,leading=9.4); cellb=ParagraphStyle("cb",parent=cell,fontName="Serif-B")
def P(t,s=body): return Paragraph(t,s)
def H1(t): return Paragraph(t,h1)
def H2(t): return Paragraph(t,h2)
def EQ(lines):
    t=Table([[Paragraph(l,ParagraphStyle("eq",fontName="Mono",fontSize=7.6,leading=10.2))] for l in lines],colWidths=[16*cm])
    t.setStyle(TableStyle([("BOX",(0,0),(-1,-1),0.6,NAVY),("BACKGROUND",(0,0),(-1,-1),LIGHT),("LEFTPADDING",(0,0),(-1,-1),7),("TOPPADDING",(0,0),(-1,-1),1.5),("BOTTOMPADDING",(0,0),(-1,-1),1.5)]))
    return KeepTogether([t,Spacer(1,5)])
def IMG(n,c,w=15.8):
    p=f"{FIG}/{n}.png"; iw,ih=ImageReader(p).getSize(); W=w*cm
    return KeepTogether([Image(p,width=W,height=W*ih/iw),Paragraph(c,cap)])
def TAB(rows,widths):
    d=[[Paragraph(str(c),cellb if i==0 else cell) for c in r] for i,r in enumerate(rows)]
    t=Table(d,colWidths=[w*cm for w in widths],repeatRows=1)
    t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#b0bccb")),("VALIGN",(0,0),(-1,-1),"TOP"),("BACKGROUND",(0,0),(-1,0),LIGHT),("LEFTPADDING",(0,0),(-1,-1),3),("RIGHTPADDING",(0,0),(-1,-1),3),("TOPPADDING",(0,0),(-1,-1),1.5),("BOTTOMPADDING",(0,0),(-1,-1),1.5)]))
    return t
def BOX(t):
    b=Table([[Paragraph(t,small)]],colWidths=[16*cm])
    b.setStyle(TableStyle([("BOX",(0,0),(-1,-1),0.8,NAVY),("BACKGROUND",(0,0),(-1,-1),LIGHT),("LEFTPADDING",(0,0),(-1,-1),7),("RIGHTPADDING",(0,0),(-1,-1),7),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
    return b
def pc(x,nd=1): return f"{100*x:.{nd}f}%"
def g(d,m,c): return summ[(summ.dataset==d)&(summ.model==m)][c].iloc[0]
story=[]
story+=[Spacer(1,0.4*cm),P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 14 NOVEMBER 2026",ctr),Spacer(1,0.3*cm),
 P("ALIEN-DL: Coupling Synaptic Transmission, Plasticity and Structure Through One Conserved Resource Budget",title),
 P("Two independent first-pass implementations, a pre-specified coupling test, and a falsification verdict",sub),
 P("Devanik Debnath · Xylia (AI research scientist, multi-agent research system)",ctr),Spacer(1,0.25*cm)]
story.append(BOX("<b>About the author.</b> Electronics and Communication Engineering graduate and independent AI researcher exploring how physical and mathematical structure can improve learning and modeling. Work spans gamma-ray burst reconstruction at the National Astronomical Observatory of Japan (NAOJ), physics-inspired signal classification, reinforcement learning, neural quantum-state methods, causal emergence, morphogenetic neural architectures, and computational artificial life. The research style combines algorithm design with explicit assumptions, code-based checks, and disclosure of unresolved limitations. <i>Devanik Debnath</i> is a Scientific Machine Learning and AI Architectures researcher; B.Tech, Electronics and Communication Engineering, National Institute of Technology Agartala (2026); Samsung Grade I Fellowship, Cohort 7; completed the IISc-led India Semiconductor Workforce Development Program (ISWDP) Level 1 evaluation at the 98.58th percentile. Links: github.com/Devanik21, orcid.org/0009-0001-8310-6921."))
story.append(Spacer(1,0.25*cm))
story.append(BOX("<b>Scope and status.</b> This paper reports the first experiments on ALIEN-DL, an architecture in which one conserved resource budget per neuron gates recovery of short-term synaptic transmission, the size of synaptic weight updates, and the persistence of synapses. Two implementations were built independently: Trial A (PyTorch, by Xylia) and Trial B (NumPy with automatic differentiation, by Devanik Debnath). Both are small tabular tests on sklearn datasets. <b>The central hypothesis is not supported by either trial, and the pre-specified kill criterion has been triggered for the settings tested.</b> No biological, energy or deployment claim is made."))
story.append(Spacer(1,0.25*cm))
story.append(P("<b>Abstract.</b> We test whether a conserved, mass-preserving resource budget coupled to three synaptic timescales (fast transmission, weight plasticity, and structural persistence) produces learning that is superadditive relative to the same mechanisms applied independently. Trial A is a 8-compartment PyTorch network trained on Wine, Breast Cancer and Digits over three seeds with parameter-matched and width-matched MLP baselines and a complete 2×2×2 ablation on Wine. Trial B is a compact NumPy model trained on Breast Cancer and Digits with a budget-conserving exponentiated-gradient allocation rule, three mathematical unit tests, and a step-size sweep. Across both trials, ALIEN never exceeds the parameter-matched MLP on any dataset with the same budget of trainable parameters; it matches it on Breast Cancer and trails it on Wine (by 7.4 points in Trial A) and Digits (by 2.2 points in Trial A and 0.4 points in Trial B against the state-matched baseline). Allocation becomes non-uniform (Gini 0.24 to 0.64 in Trial A) and, in Trial B, collapses to a single synapse holding 63 of 64 units of budget at step size 0.5; reducing the step to 0.05 bounds the largest share at 6.7 and removes the collapse. The 2×2×2 interaction contrasts are zero or one Wine test example (0.037) in each seed, and no contrast survives any correction across three seeds. We conclude that the coupling principle, as implemented, has no measurable superadditive benefit in these settings. Section 9 states which claims survive and which do not, and what a valid next test must look like.",body))
story.append(P("<b>Keywords:</b> synaptic resource competition · short-term plasticity · replicator dynamics · exponentiated gradient · structural plasticity · factorial ablation · interaction contrasts",small))
story.append(PageBreak())
story.append(H1("Contents"))
for t in ["1  Motivation and what would count as success","2  Background and related work","3  Trial A: the Xylia prototype","4  Trial B: the lite implementation and its invariants","5  Experimental protocol and statistics","6  Results, Trial A: main comparison, factorial ablation and diagnostics","7  Results, Trial B: collapse, step size and the matched baseline","8  Cross-trial synthesis and the interaction test","9  Verdict against the pre-specified criteria","10  Corrections and discrepancies found during review","11  Limitations","12  What a valid next test must look like","13  Prior art and the bounded novelty claim","14  Next experiment: a temporal order benchmark","15  Reference status","Appendix A  Equations in full","Appendix B  Parameters and file manifest","References"]:
    story.append(P(t,small))
story.append(PageBreak())
# 1
story.append(H1("1  Motivation and what would count as success"))
story.append(P("Standard artificial networks treat each connection as a scalar weight that is updated by gradient descent. Synapses in real neural tissue behave differently: each has a limited supply of releasable resources, it depletes with use and recovers over time, its effective strength changes on several timescales, and sustained use can strengthen or eliminate it. Competition among synapses for shared metabolic and structural resources is a documented mechanism behind synaptic normalization and heterosynaptic plasticity. ALIEN-DL asks a narrower computational question: if one conserved resource budget per neuron controls recovery, plasticity and persistence together, does the combination learn better than the three mechanisms used separately?"))
story.append(P("The question is worth asking precisely because it can fail. We fixed the criteria before the experiments, following the v2 specification: a superadditivity claim requires that the three-way interaction contrast and the pairwise contrasts exclude zero across seeds after correction, and a superiority claim requires that ALIEN beat a state-matched conventional network on a pre-set fraction of settings. If neither holds, the claim is retracted (Section 9). Both trials were designed under those rules."))
story.append(EQ(["Hypothesis H1 (superadditivity).  I_RPA = A(1,1,1) − A(1,1,0) − A(1,0,1) − A(0,1,1)","                                        + A(1,0,0) + A(0,1,0) + A(0,0,1) − A(0,0,0)  >  0  with CI excluding 0.","Hypothesis H2 (superiority).  ALIEN exceeds a state-matched MLP on a pre-set fraction of settings."]))
# 2
story.append(H1("2  Background and related work"))
story.append(H2("2.1  Synaptic dynamics"))
story.append(P("The Tsodyks–Markram model (Tsodyks and Markram 1997) describes a synapse with a resource variable r (fraction of available vesicles or receptors) and a utilization variable u (release probability). Each presynaptic spike releases a fraction u of r, after which r recovers toward 1 at a fixed rate and u relaxes to a baseline U0. Facilitation and depression therefore emerge from the interplay of the two variables. ALIEN-DL keeps this structure and changes one assumption: the recovery rate is multiplied by a slow allocation share π that represents how much of the neuron's budget the synapse receives. This is the R coupling."))
story.append(H2("2.2  Competition, normalization and selection among synapses"))
story.append(P("Several models derive multiplicative normalization and heterosynaptic plasticity from competition for limited synaptic building blocks (background literature, not re-verified in this study). Synaptic scaling, a homeostatic mechanism (Turrigiano 2008), keeps total input roughly fixed. Selectionist accounts of synaptic learning (Seung 2003; Adams and Ilgen-style selection frameworks) treat the strength distribution as an evolving population. ALIEN's allocation rule is the discrete-time analogue of a replicator equation on the simplex of synapse shares, which is an exponentiated-gradient (multiplicative weights) update (Kivinen and Warmuth 1997)."))
story.append(H2("2.3  Structural plasticity and sparse topology"))
story.append(P("Dynamic sparse training methods such as SET (Mocanu et al. 2018) and RigL (Evci et al. 2020) grow and prune connections during training at matched sparsity. ALIEN's structural gate (the A coupling) is a persistence variable that is driven by the allocation share and thresholded at epoch boundaries. It is closer in spirit to a learned gate than to these methods, which use magnitude or gradient criteria."))
story.append(H2("2.4  Relation to the prior-art audit"))
story.append(P("The v2 draft and its audit list several nearby published works: a dendritic artificial network and a synapse-centred working-memory architecture (both 2025), a 2026 preprint on synaptic-state-dependent learning, and a 2025 Nature Communications article integrating synaptic diversity and spine remodeling into artificial networks. These are cited in the draft as the nearest precedents and were not re-verified for this paper. The claim this paper can defend is not a new synaptic primitive. It is the test of one specific coupling principle under a conserved budget, with a pre-registered interaction contrast. We do not claim priority for the individual mechanisms."))
story.append(H2("2.5  Optimization background"))
story.append(P("Adam (Kingma and Ba 2015) is used for the ordinary parameters in both trials. Exponentiated gradient on a simplex is the standard way to keep a budget non-negative and summing to a constant without projection (Kivinen and Warmuth 1997). Automatic differentiation for the lite trial uses the autograd library (Maclaurin et al. 2015); the baselines use scikit-learn (Pedregosa et al. 2011)."))
# 3
story.append(H1("3  Trial A: the Xylia prototype"))
story.append(P("Trial A is a PyTorch implementation with eight dendritic compartments (n_compartments = 8). Each compartment receives one synaptic connection from each input feature. A synapse has a trainable efficacy θ, a short-term state (r, u) that is simulated for three micro-steps per presentation, an allocation logit whose softmax over the active synapses of a compartment gives the share π, and a structural logit ζ that gates the synapse through a sigmoid. The three couplings are switched by the configuration flags r_coupling (R), p_coupling (P) and a_coupling (A)."))
story.append(EQ(["Input and presynaptic drive:   x̃_i = tanh(x_i),   a_i = |x̃_i|",
 "Short-term dynamics, micro-step k = 1..3:",
 "   r_ij ← clip( r_ij + ρ · π̂_ij · (1 − r_ij) − α_d · u_ij · r_ij · a_i ,  0, 1 )",
 "   u_ij ← clip( u_ij + (U_rest − u_ij)/τ_u + α_f · (1 − u_ij) · a_i ,  0, 1 )",
 "   π̂_ij = π_ij if R = 1, else 1",
 "Synaptic output and compartment:   q_ij = θ_ij · u_ij · r_ij · σ(ζ_ij) · m_ij · x̃_i",
 "   c_j = tanh( Σ_i q_ij + b_j ),   logits = W_out c + b_out",
 "Constants (Trial A): ρ = 0.55, α_d = 0.18, α_f = 0.10, τ_u = 3.0, U_rest = 0.25, 3 micro-steps."]))
story.append(P("<b>Allocation.</b> Per compartment, π is a simplex-normalised share over the active synapses, rescaled to mean 1, so that Σ_i π_ij = n_active. A synapse's utility is the contribution score U_ij = −E[q_ij · ∂L/∂q_ij] averaged over an epoch, which is a first-order Taylor score rather than the exact derivative of the loss with respect to the budget. Allocation logits move by a multiplicative-weights step with rate 0.025, centred and clipped to [−8, 8]."))
story.append(EQ(["Allocation utility (per synapse, averaged over the epoch):   U_ij = −mean_batch( q_ij · ∂L/∂q_ij )",
 "Centred multiplicative-weights step on the active simplex:",
 "   ℓ_ij ← ℓ_ij + η_π · ( Ũ_ij − Σ_k p_ik Ũ_ik ),   Ũ = U / scale,   p = softmax(ℓ)  (active only)",
 "Structural persistence, at epoch boundary:   ζ_ij ← clip( ζ_ij + κ_s (π_ij − 1), −8, 8 ),   prune if σ(ζ_ij) < 0.15",
 "Structure is never allowed to remove every synapse of a compartment (argmax of ζ is kept)."]))
story.append(P("<b>Plasticity.</b> With P = 1, the gradient on θ is multiplied elementwise by the allocation share. Optimization uses AdamW (learning rate 0.012, weight decay 10⁻⁴) for every other parameter. Early stopping uses the validation split with patience 18 epochs, and the best-validation checkpoint is evaluated on the test split. Trial A is not a biological simulator: the short-term states are reset for each example, so no sequence memory is tested."))
# 4
story.append(H1("4  Trial B: the lite implementation and its invariants"))
story.append(P("Trial B is a deliberately minimal re-implementation written to test the mathematics in isolation. Each hidden unit j receives d synapses, one per input. Each synapse has a weight θ_ij, a recovery state r_ij, a facilitation state u_ij, and a logit ℓ_ij whose softmax over the synapses of unit j gives a share π_ij = d · softmax_i(ℓ_ij), so the shares of each unit sum to d (mass conservation). The model runs T = 5 unit-time steps with dt = 1 for each sample and feeds the summed transmission into a tanh hidden layer and a linear readout."))
story.append(EQ(["Trial B forward pass (per sample, T = 5 steps, dt = 1):",
 "   r ← clip( r + dt · (ρ · π_ij · (1 − r) − α_r · u · r · x_i), 0, 1 )",
 "   u ← clip( u + dt · ((U_0 − u)/τ + α_u · (1 − u) · x_i), 0, 1 )",
 "   acc_ij ← acc_ij + θ_ij · u · r · x_i",
 "   h_j = tanh( (1/d) Σ_i acc_ij + b_j ),   logits = h W_2 + b_2",
 "Constants: ρ = 0.3, α_r = 0.5, α_u = 0.3, U_0 = 0.3, τ = 3.0.",
 "Share parameterisation:   π_ij = d · exp(ℓ_ij) / Σ_k exp(ℓ_kj)"]))
story.append(P("<b>Allocation update.</b> Between minibatches, the allocation logits take an exponentiated-gradient step on the gradient of the loss with respect to the shares. The gradient is scale-normalised to unit mean magnitude so the step size is set in the same units for every dataset. Because softmax parameterisation keeps every unit's shares on a simplex, the budget is conserved by construction."))
story.append(EQ(["Allocation update (trial B):   g_ij = ∂L/∂π_ij  (batch mean),   g ← g / mean|g|",
 "   ℓ_ij ← ℓ_ij − η_b · g_ij        η_b = 0.5 (final), η_b = 0.05 (sweep)",
 "Plasticity (P = 1):  θ-gradient multiplied by π_ij (mean 1 per unit), then Adam step with lr = 0.01."]))
story.append(P("<b>Three mathematical unit tests</b> were implemented and pass (run with python3 unit_tests.py): (T1) budget conservation: Σ_i π_ij = d for every unit before and after an allocation step, with maximum deviation 1.8·10⁻¹⁵; (T2) positivity of all shares; (T3) reduction to a standard weighted-sum network: with recovery saturated (ρ → ∞, no depression or facilitation) the hidden activation equals tanh(Σ_i θ_ij U_0 x_i / d + b_j) to within 10⁻⁶. T3 is a check of the forward pass and not a proof of any learning property."))
story.append(P("<b>Proposition (budget conservation).</b> Let ℓ be updated by any finite step and π = d·softmax(ℓ) column-wise. Then Σ_i π_ij = d for every j and every step. <i>Proof.</i> The softmax columns sum to one by definition, so the scaled sums equal d. ∎ This holds for any utility, so conservation is a property of the parameterisation and not of the learning rule."))
story.append(P("<b>Proposition (no finite-time extinction).</b> Under exponentiated-gradient updates with bounded g, no share reaches zero in finite time, because the logit changes by a bounded amount per step and the softmax is strictly positive. Pruning therefore needs a separate mechanism. Trial B has none, and its shares only concentrate. ∎"))
# 5
story.append(H1("5  Experimental protocol and statistics"))
story.append(P("<b>Trial A.</b> Stratified 70/15/15 split for each seed (seeds 7, 21, 42). Standardisation is fitted on the training partition. Model selection is by validation accuracy and the test split is used once. Baselines: a two-layer tanh MLP with width 32 (mlp_fixed) and a two-layer MLP whose width is chosen to match ALIEN's trainable parameter count (mlp_matched). Factorial: all eight R/P/A configurations on Wine, paired by seed (same initialisation and batch order within a seed)."))
story.append(P("<b>Trial B.</b> Stratified 70/30 split (seeds 0, 1, 2 in the main run; 0, 1, 2 in the sweep), min-max scaling fitted on the training split, hidden width 16 for ALIEN, 40 epochs, batch 64. Baselines: scikit-learn MLPClassifier with hidden width 16 (plain) and 32 (state-matched, double width, chosen to match the number of stored state values per synapse: ALIEN keeps about two values per synapse, θ and ℓ). Test sets: Breast Cancer 171 examples, Digits 540 examples."))
story.append(P("<b>Statistics.</b> With three seeds, standard errors are unreliable and we report descriptive means and sample standard deviations. The granularity of the test sets is coarse: one Wine test example changes accuracy by 1/27 = 0.037, one Breast Cancer example by 0.0058, one Digits example by 0.0019. Interaction contrasts are computed on seed-paired differences, with each contrast evaluated at a fixed level of the third factor. The uploaded report uses fixed A = 0, and we reproduce its values under that convention (Section 6.2)."))
story.append(EQ(["Interaction contrasts (fixed level of the third factor, seed-paired):",
 "   I_RP|A = [A(1,1,A) − A(1,0,A)] − [A(0,1,A) − A(0,0,A)]",
 "   I_RA|P = [A(1,P,1) − A(1,P,0)] − [A(0,P,1) − A(0,P,0)]",
 "   I_PA|R = [A(R,1,1) − A(R,1,0)] − [A(R,0,1) − A(R,0,0)]",
 "   I_RPA  = A(1,1,1) − A(1,1,0) − A(1,0,1) − A(0,1,1) + A(1,0,0) + A(0,1,0) + A(0,0,1) − A(0,0,0)"]))
# 6
story.append(H1("6  Results, Trial A"))
story.append(H2("6.1  Main comparison"))
rows=[["Dataset","Model","Test accuracy (mean ± SD)","Macro-F1","Trainable params","Train time (s)"]]
for d,dn in [("wine","Wine"),("breast_cancer","Breast Cancer"),("digits","Digits")]:
    for m,mn in [("alien","ALIEN-DL"),("mlp_matched","MLP param-matched"),("mlp_fixed","MLP width 32")]:
        rows.append([dn,mn,f"{g(d,m,'accuracy_mean'):.4f} ± {g(d,m,'accuracy_std'):.4f}",f"{g(d,m,'macro_f1_mean'):.4f} ± {g(d,m,'macro_f1_std'):.4f}",f"{g(d,m,'parameters_mean'):.0f}",f"{g(d,m,'seconds_mean'):.3f}"])
story.append(TAB(rows,[2.8,3.2,3.6,3.2,2.2,2.0])); story.append(P("<b>Table 1.</b> Trial A main comparison, seeds 7, 21, 42. Values regenerated from benchmark_summary.csv.",cap))
story.append(IMG("fig02_trialA_main","<b>Figure 1.</b> Trial A test accuracy. ALIEN equals the parameter-matched MLP on Breast Cancer and trails it on Wine and Digits. Error bars are one sample SD over three seeds."))
story.append(P("<b>Reading.</b> On Breast Cancer every model reaches the same mean, 0.9845, which is 169 of 171 test examples. On Wine ALIEN is 7.4 points below the parameter-matched MLP and 5.9 below the width-32 MLP; the spread across seeds is large (SD 0.074), and the difference equals about two test examples per seed. On Digits ALIEN is 2.2 points below the matched MLP and 3.0 below the width-32 MLP, a gap of about 12 and 16 test examples out of 540. Trial A's own report notes that the Wine deficit is partly a single-seed effect (seed 7 at 0.778)."))
story.append(H2("6.2  Factorial ablation on Wine"))
w=fac[fac.dataset=="wine"].copy(); w["cfg"]=w.apply(lambda r:f"{int(r.R)}{int(r.P)}{int(r.A)}",axis=1)
rows=[["R P A","seed 7","seed 21","seed 42","Mean","SD"]]
for c in ["000","001","010","011","100","101","110","111"]:
    v=w[w.cfg==c].set_index("seed").accuracy
    rows.append([" ".join(c),f"{v[7]:.3f}",f"{v[21]:.3f}",f"{v[42]:.3f}",f"{v.mean():.4f}",f"{v.std():.4f}"])
story.append(TAB(rows,[2.4,2.4,2.4,2.4,2.4,2.4])); story.append(P("<b>Table 2.</b> Wine factorial accuracy by configuration and seed. Regenerated from factorial_results.csv.",cap))
story.append(IMG("fig03_factorial_wine","<b>Figure 2.</b> (a) Factorial means. (b) Per-seed values. The dotted line marks 26/27, one test example below perfect; every seed-level difference between configurations is a multiple of 0.037."))
def acc(gg,R,P_,A): return float(gg[(gg.R==R)&(gg.P==P_)&(gg.A==A)].accuracy.iloc[0])
rows=[["Contrast (fixed A = 0)","seed 7","seed 21","seed 42","Mean","SD"]]
for lab,fn in [("I_RP | A=0",lambda gg:(acc(gg,1,1,0)-acc(gg,1,0,0))-(acc(gg,0,1,0)-acc(gg,0,0,0))),
               ("I_RA | P=0",lambda gg:(acc(gg,1,0,1)-acc(gg,1,0,0))-(acc(gg,0,0,1)-acc(gg,0,0,0))),
               ("I_PA | R=0",lambda gg:(acc(gg,0,1,1)-acc(gg,0,1,0))-(acc(gg,0,0,1)-acc(gg,0,0,0)))]:
    vs=[fn(w[w.seed==s]) for s in [7,21,42]]
    rows.append([lab]+[f"{x:+.3f}" for x in vs]+[f"{np.mean(vs):+.4f}",f"{np.std(vs,ddof=1):.4f}"])
def three(gg): return acc(gg,1,1,1)-acc(gg,1,1,0)-acc(gg,1,0,1)-acc(gg,0,1,1)+acc(gg,1,0,0)+acc(gg,0,1,0)+acc(gg,0,0,1)-acc(gg,0,0,0)
vs=[three(w[w.seed==s]) for s in [7,21,42]]
rows.append(["I_RPA (three-way)"]+[f"{x:+.3f}" for x in vs]+[f"{np.mean(vs):+.4f}",f"{np.std(vs,ddof=1):.4f}"])
story.append(TAB(rows,[3.6,2.2,2.2,2.2,2.2,2.2])); story.append(P("<b>Table 3.</b> Seed-paired interaction contrasts, Wine, evaluated at A = 0. These reproduce the uploaded report exactly: I_RA = −0.0123, I_RP = 0, I_PA = 0, and I_RPA = +0.0123 with SD 0.0214.",cap))
story.append(IMG("fig07_contrasts","<b>Figure 3.</b> Seed-level contrasts. Each nonzero value equals one Wine test example. Across seeds no contrast is consistent in sign for the pairwise terms, and the three-way contrast is nonzero in only one of three seeds."))
story.append(P("<b>Reading.</b> The three-way contrast is +0.037 in seed 42 and zero in seeds 7 and 21. The pairwise contrasts are zero except one that is −0.037 in seed 42 at A = 0. None of these is distinguishable from a single test example, and with three seeds no sign-consistent effect is possible under a sign test (the smallest two-sided p-value is 0.25). The factorial therefore establishes that the three-way term is at most one example in size on this dataset, not that it is positive."))
story.append(P("<b>Pruning in the factorial.</b> Two configurations pruned edges in seed 42 (A = 1 with R = 0: 92 of 104 synapses kept, active fraction 0.885; R = 1, P = 0, A = 1: 84 of 104, active fraction 0.808). The main-comparison checkpoints kept all 240 or 512 synapses for every seed. Pruning therefore occurs only in the factorial runs and only at the smallest dataset. The uploaded report describes the same effect with active fractions 0.962 and 0.936; those values do not appear in the CSV, which we treat as authoritative (Section 10)."))
story.append(H2("6.3  Diagnostics of the full model"))
story.append(IMG("fig04_allocation_gini","<b>Figure 4.</b> Allocation Gini of the full ALIEN checkpoint per seed (higher = more concentrated). Non-uniform allocation emerges on every dataset, most strongly on Digits."))
rows=[["Dataset","Gini (seeds 7, 21, 42)","Mean Gini","Active synapses","Effective fan-in (mean)"]]
al=bench[bench.model=="alien"]
for d,dn in [("wine","Wine"),("breast_cancer","Breast Cancer"),("digits","Digits")]:
    x=al[al.dataset==d]
    rows.append([dn,", ".join(f"{v:.3f}" for v in x.allocation_gini),f"{x.allocation_gini.mean():.3f}",f"{int(x.active_synapses.iloc[0])} of {int(x.total_synapses.iloc[0])} (all seeds)",f"{x.effective_fanin.mean():.1f}"])
story.append(TAB(rows,[2.6,4.2,2.0,4.0,3.2])); story.append(P("<b>Table 4.</b> Allocation diagnostics for the full ALIEN checkpoints in Trial A.",cap))
story.append(P("<b>Interpretation.</b> Allocation is not trivially uniform, which confirms that the mechanism acts. But the main checkpoints retain every synapse, so the structural (A) coupling had no effect on the reported accuracies. An effective fan-in of 16 on Digits means that a unit's budget is concentrated on about 16 of its 64 inputs. This is compatible with useful sparsity or with the early winner-take-all trend that Trial B reproduces; the two cannot be separated from Trial A alone."))
story.append(H2("6.4  Computational cost"))
story.append(IMG("fig06_cost","<b>Figure 5.</b> Mean training time per model on CPU with one thread. ALIEN is 3.6 to 6.3 times slower than the parameter-matched MLP."))
story.append(P("The slowdown follows from the per-synapse, per-micro-step dynamics and from the extra backward pass used for the utility score. The cost measured here is an implementation property of unfused PyTorch operations and says nothing about the energy of a biological or neuromorphic system."))
# 7
story.append(H1("7  Results, Trial B"))
story.append(H2("7.1  Main comparison"))
rows=[["Dataset","Model","Test accuracy","Notes"],
 ["Breast Cancer","ALIEN frozen allocation (R=0,P=0,A=0)","0.961 ± 0.003","all five non-collapsing configs identical"],
 ["Breast Cancer","ALIEN transmission + allocation (1,0,1)","0.961 ± 0.007","largest share 24.4 of 30"],
 ["Breast Cancer","ALIEN all couplings (1,1,1)","0.949 ± 0.010","largest share 15.6 of 30"],
 ["Breast Cancer","MLP plain (width 16)","0.961","—"],
 ["Breast Cancer","MLP state-matched (width 32)","0.959","—"],
 ["Digits","ALIEN frozen allocation (0,·,·)","0.959 ± 0.005","all four frozen configs identical"],
 ["Digits","ALIEN transmission + allocation (1,0,1), η = 0.5","0.950 ± 0.005","largest share 63.4 of 64: collapse"],
 ["Digits","ALIEN all couplings (1,1,1), η = 0.5","0.932 ± 0.010","largest share 64.0: collapse"],
 ["Digits","MLP plain (width 16)","0.962","—"],
 ["Digits","MLP state-matched (width 32)","0.969","—"]]
story.append(TAB(rows,[2.6,6.2,2.6,4.6])); story.append(P("<b>Table 5.</b> Trial B main results, seeds 0, 1, 2 (mean ± SD where available). Values from the run logs.",cap))
story.append(P("The frozen-allocation ALIEN is within 0.2 points of the plain MLP on Breast Cancer and within 0.3 points on Digits, and 0.7 points below the state-matched MLP on Digits. Every coupled configuration that involves allocation is equal to or below frozen allocation. With the step size of the final run, allocation collapses. This is the failure mode the draft flagged as winner-take-all."))
story.append(H2("7.2  Step size controls the collapse"))
story.append(IMG("fig05_lite_collapse","<b>Figure 6.</b> (a) Largest share at η_b = 0.05 and 0.5 for transmission plus allocation on Digits. (b) Test accuracy at the same step sizes, with frozen allocation as a reference. The sweep selected on the test split (Section 10)."))
rows=[["η_b","Config","Accuracy","SD","Largest share"],["0.05","(1,0,1)","0.960","0.004","6.7 of 64"],["0.05","(1,1,1)","0.951","0.003","6.9 of 64"],["0.50","(1,0,1)","0.950","0.005","63.4 of 64"],["0.50","(1,1,1)","not finished","—","—"]]
story.append(TAB(rows,[2.0,2.6,3.2,2.0,4.4])); story.append(P("<b>Table 6.</b> Allocation step-size sweep on Digits (three seeds). The full-coupling cell at η = 0.5 did not complete because the background process was terminated.",cap))
story.append(P("The collapse is controlled by the allocation step and not by the coupling flags alone. At η_b = 0.05 the largest share stays near 6.8 of 64, and transmission plus allocation recovers to the frozen-allocation accuracy within noise. The sweep was selected on test accuracy, so these values are descriptive and would need a separate validation split to become an operating choice."))
story.append(H2("7.3  Why the matched baseline is the right comparator"))
story.append(P("ALIEN stores two numbers per synapse (θ and its allocation logit) plus per-compartment readout terms, so a fair baseline must have more parameters than a plain MLP of equal hidden width. The state-matched MLP of width 32 has roughly twice the trainable parameters and wins on Digits (0.969 against 0.959). This is the comparison that the v2 kill criterion names, and ALIEN loses it. Trial A's parameter-matched MLP is a weaker comparator than the state-matched one, because it matches trainable parameters rather than stored state, which is the reason the Digits deficit appears larger in Trial A."))
# 8
story.append(H1("8  Cross-trial synthesis and the interaction test"))
rows=[["Quantity","Trial A (PyTorch)","Trial B (lite)"],
 ["Framework","PyTorch 2.x","NumPy + autograd"],
 ["Datasets","Wine, Breast Cancer, Digits","Breast Cancer, Digits (Wine saturated, uninformative)"],
 ["Seeds and split","3 seeds, 70/15/15 with validation","3 seeds, 70/30 with no validation split"],
 ["Best ALIEN vs parameter-matched MLP","equal on BC; −7.4 pt Wine; −2.2 pt Digits","Digits frozen: −0.6 pt vs plain MLP; −0.9 pt vs state-matched"],
 ["Allocation non-uniform","Yes (Gini 0.24 to 0.64)","Yes; collapses at η = 0.5 (63 of 64)"],
 ["Superadditive interaction","not found (three-way +0.012, SD 0.021, one example)","not tested with a factorial; coupled configs below frozen"],
 ["Pruning","only in factorial, Wine seed 42","none (structural births and pruning not implemented)"],
 ["Compute","3.6–6.3× slower than param-matched MLP","not measured as a benchmark"]]
story.append(TAB(rows,[4.4,6.0,5.6])); story.append(P("<b>Table 7.</b> Side-by-side summary of the two trials.",cap))
story.append(P("<b>Consistency between the trials.</b> Both implementations agree on three points. Allocation becomes non-uniform on the datasets tested. Coupling allocation to transmission does not improve accuracy. Neither produces a sign-consistent interaction. The trials disagree on magnitude in one respect: Trial A's Digits deficit against the plain MLP is about 2 points at matched parameters, whereas Trial B's frozen model is within 0.6 points of the plain MLP. The difference is plausibly the training budget, the validation protocol and the matched baseline, not the mechanism, and the two trials cannot resolve it."))
story.append(P("<b>The interaction test in practice.</b> Hypothesis H1 requires the three-way contrast to be positive with a confidence interval excluding zero. Our three-seed Wine data give contrasts of 0, 0 and 0.037. A paired t-test on these values has a p-value of 0.25 (one-sided 0.13); the contrast is one example in one seed. Even a perfect replication at this granularity would need either many more seeds or a larger test set. Breast Cancer's three-way contrast can be computed from benchmark_results (accuracy differences of 0 to 0.0058), and it is zero to within one example."))
# 9
story.append(H1("9  Verdict against the pre-specified criteria"))
rows=[["Criterion (v2 specification)","Status","Evidence"],
 ["H1: three-way contrast positive, CI excludes 0, after correction","Not met","Wine: +0.012 mean, SD 0.021, one example per nonzero seed; no correction survives"],
 ["H1: pairwise contrasts (R×P, R×A, P×A) excluding 0","Not met","Zero or one example; sign inconsistent across seeds"],
 ["H2: ALIEN beats a state-matched MLP on a pre-set fraction of settings","Not met","0 of 2 datasets (Digits: 0.959 vs 0.969); Breast Cancer tied with state-matched 0.959"],
 ["Kill rule: no interaction survives correction, or no superiority","Triggered","Per the v2 rule, the superadditivity claim is retracted for the settings tested"]]
story.append(TAB(rows,[6.2,2.4,7.4])); story.append(P("<b>Table 8.</b> Pre-specified criteria and their status.",cap))
story.append(P("<b>Verdict.</b> For the settings tested, ALIEN-DL as implemented does not show superadditive learning and does not outperform conventional networks with matched budgets. We therefore retract the superadditivity claim as a finding of this study. The architecture is not shown to be wrong in general. The tests were small, the temporal and structural mechanisms were largely inactive, and the allocation rule was unstable at default step sizes. What the study does show is that the specific claim, that coupling three synaptic timescales through one budget produces an effect beyond the sum of its parts, has no empirical support in these experiments."))
# 10
story.append(H1("10  Corrections and discrepancies found during review"))
rows=[["Item","Original statement","Checked value","Action"],
 ["Wine gap to matched MLP (lite README, earlier)","−0.8 pt","−7.4 pt (0.852 vs 0.926, Trial A)","Corrected in README"],
 ["Wine allocation Gini","0.22","0.24 (0.217, 0.203, 0.292)","Corrected"],
 ["Wine pruned active fractions","0.962 and 0.936 (report)","0.885 and 0.808 (CSV, seed 42)","CSV taken as authoritative; report to be updated"],
 ["Factorial interaction values","not stated which fixed level","reproduce exactly at A = 0","Convention stated in Section 5"],
 ["benchmark_summary.csv on GitHub","—","was header-only in first push","Corrected in second push"],
 ["Misnamed placeholder file on GitHub","—","factorial CSV at a wrong path","Deleted; correct files pushed"],
 ["Lite Wine JSON","—","first timing run, before fixes","Kept, labelled not comparable"],
 ["Step-size sweep","—","selected on the test split","Flagged as descriptive only"],
 ["Full-coupling sweep cell (η = 0.5)","—","background process terminated before output","Reported as not finished"]]
story.append(TAB(rows,[4.4,3.4,4.6,3.6])); story.append(P("<b>Table 9.</b> Corrections log. Each entry lists the statement as originally written, the value checked against the source files, and what has been done.",cap))
# 11
story.append(H1("11  Limitations"))
for t in ["<b>Scale.</b> Two small tabular datasets plus Wine, which is too easy to separate the configurations. No temporal, sequential or continual-learning task was run, and the mechanisms the architecture is designed for (synaptic memory across events) were not tested.",
 "<b>Seeds and test sizes.</b> Three seeds per dataset. Test sets of 27, 171 and 540 examples give resolution of 0.037, 0.006 and 0.002. Differences of one or two test examples are reported but cannot be interpreted as effects.",
 "<b>Validation.</b> Trial A uses a validation split for early stopping. Trial B uses no validation split, and its step-size sweep was selected on test accuracy.",
 "<b>Baselines.</b> Trial A's matched baseline is parameter-matched; Trial B's state-matched baseline is wider than ALIEN in stored values. A stronger comparison would tune all models equally.",
 "<b>Allocation signal.</b> Trial A's utility is a first-order Taylor score; Trial B's is the exact gradient with respect to the shares. The two are different quantities and their results are not interchangeable.",
 "<b>Structure.</b> Structural births are not implemented. Pruning occurred only in one factorial condition.",
 "<b>Biology.</b> No biological claim is made. The resource budget is an abstract computational quantity, not a measured metabolic pool. The v2 draft's own caution that synapses use several physical resources applies in full.",
 "<b>Literature.</b> The prior-art references in the v2 draft were not re-verified for this paper."]:
    story.append(P(t))
# 12
story.append(H1("12  What a valid next test must look like"))
story.append(P("The evidence points to three changes before the coupling hypothesis can be tested fairly. First, the tests must include the situation the architecture was designed for: a temporal stimulus in which synaptic state persists across events, with a task whose answer depends on order and on recovery time, and an identical total activation for control conditions. Second, the allocation step must be stabilised, for example with a floor on each share or an entropy term, and tuned on a validation split rather than on test accuracy. Third, the factorial must have enough seeds and test examples to resolve a one-percentage-point interaction, which at the Digits test size means dozens of seeds, and the baselines must be state-matched by construction. Until those conditions are met, the claim of superadditivity should not be restated."))
# App A
story.append(H1("13  Prior art and the bounded novelty claim"))
story.append(P("The ingredients of ALIEN-DL each have published precedent. The contribution claimed here is the joint, implementation-level coupling and its factorial test, not any single mechanism. The table below lists the closest works. Entries are as cited in the research-trials report; the 2025 and 2026 items were not re-verified for this paper."))
rows=[["Work (as cited)","Established contribution","Implication for ALIEN-DL"],
 ["Markram, Wang and Tsodyks (1998), PNAS","target-specific depression and facilitation on one axon","short-term synaptic dynamics are established"],
 ["Triesch, Vo and Hafner (2018), eLife","competition for synaptic building blocks shapes plasticity","resource competition is not a new premise"],
 ["Chistiakova et al. (2015), Front. Comput. Neurosci.","heterosynaptic plasticity and homeostasis models","competition and homeostasis are mature literatures"],
 ["Chavlis and Poirazi (2025), Nat. Commun.","dendritic artificial networks","dendritic ANN design is prior art"],
 ["Hofmann et al. (2025), Nat. Commun.","synaptic diversity and spine remodeling transferred to ANNs","diversity and structural remodeling in ANNs are prior art"],
 ["Kosowski et al. (2025), arXiv:2509.26507","Hebbian synaptic memory at inference time","synaptic plasticity as memory is prior art"],
 ["Yao et al. (2026), Nat. Commun.","dendritic computation connected to attention","dendritic ideas have reached foundation models"],
 ["Turcu et al. (2026), bioRxiv preprint","routing of learning signals by synaptic state","state-dependent learning routing is close prior art"],
 ["Cornford et al. (2026), Neuron","exponentiated-gradient learning yields brain-like synaptic distributions","EG-based synaptic distributions are close prior art"]]
story.append(TAB(rows,[5.0,6.2,4.8])); story.append(P("<b>Table 11.</b> Closest prior work and the status of each claim.",cap))
story.append(P("<b>Defensible position.</b> ALIEN-DL tests whether one resource-allocation state, coupled to recovery, efficacy adaptation and structural persistence, yields a factorial interaction in a single classifier. The experiments here do not validate that interaction."))
story.append(H1("14  Next experiment: a temporal order benchmark"))
story.append(P("Static tabular classification does not probe the property that motivated the architecture, which is memory of event history. The next benchmark is a deterministic sequence task with two pulse symbols A and B. The label depends on order, not on total input: AB and BA have the same counts and total activation. A second variant inserts distractor pulses and variable gaps to measure retention and interference."))
story.append(EQ(["Stateful temporal computation:   s_{t+1} = F(s_t, x_t; θ, π),    y = G(s_{1:T})",
 "Models: (i) MLP on temporally aggregated input; (ii) recurrent baseline (GRU or simple RNN);",
 "        (iii) Trial A with per-edge r and u preserved across time steps;",
 "        (iv) Trial B with per-edge states preserved across sequence steps.",
 "Controls: reset r and u after every step; shuffled allocation; frozen uniform allocation; matched distractor energy."]))
rows=[["Experiment","Question","Control"],
 ["Order inversion","Does the network separate AB from BA?","same token counts and total magnitude"],
 ["Variable delay","How long does state retain useful information?","delay-only control with state reset"],
 ["Distractor insertion","Do relevant traces survive intervening inputs?","matched number and energy of distractors"],
 ["State ablation","Do r and u matter?","reset r and u after every step"],
 ["Allocation ablation","Does learned allocation help memory?","frozen uniform π; shuffled π"]]
story.append(TAB(rows,[3.6,7.2,5.2])); story.append(P("<b>Table 12.</b> Proposed temporal benchmark: experiments and controls.",cap))
story.append(P("<b>Decision gate.</b> No model expansion and no temporal-memory claim should be made until the order-inversion task, the state-reset controls and parameter- and state-matched baselines are complete. A positive result must replicate across seeds and survive validation-only hyperparameter selection."))
story.append(H1("15  Reference status"))
story.append(P("This paper was written from the trial outputs and the research-trials report. The table lists which external references were checked by the authors and which were not."))
rows=[["Reference group","Status"],
 ["Dataset sources (scikit-learn Wine, Breast Cancer, Digits)","standard documentation; sizes match the loaded data"],
 ["Classical works (Tsodyks and Markram 1997; Turrigiano 2008; Seung 2003; Kivinen and Warmuth 1997; Kingma and Ba 2015)","cited from memory of the literature; bibliographic details should be checked before submission"],
 ["2025–2026 prior-art items in Table 11 and the report","cited as given in the report; not verified against the publisher pages by the authors of this paper"],
 ["Simplex-optimisation reference listed in the report (Chok and Vasil 2025)","not used in this paper's argument; excluded from the reference list pending verification"]]
story.append(TAB(rows,[9.0,7.0])); story.append(P("<b>Table 13.</b> Reference-verification status.",cap))
story.append(H1("Appendix A  Equations in full"))
story.append(EQ(["Trial A, one presentation:",
 "  for k in 1..3:  r, u updated by the Trial A short-term equations (Section 3)",
 "  q_ij = θ_ij · u_ij · r_ij · σ(ζ_ij) · m_ij · tanh(x_i)",
 "  c_j = tanh( Σ_i q_ij + b_j );   ŷ = softmax(W_out c + b_out)",
 "Trial A allocation (per compartment, active set A_j):",
 "  π_ij = |A_j| · softmax_{i∈A_j}(ℓ_ij)   (mass conserved: Σ_{i∈A_j} π_ij = |A_j|)",
 "  U_ij = −E[q_ij ∂L/∂q_ij];  ℓ_ij ← clip(ℓ_ij + η_π(Ũ_ij − Σ_k p_ik Ũ_ik), −8, 8)"]))
story.append(EQ(["Trial B, loss and gradients:",
 "  L = CE(softmax(h W_2 + b_2), y) + λ ||θ||²,   λ = 10⁻⁴",
 "  g_ij = ∂L/∂π_ij (batch mean);  g ← g/mean|g|;  ℓ_ij ← ℓ_ij − η_b g_ij",
 "  θ ← θ − lr · π ⊙ ∇_θ L   (P = 1)  with Adam moments",
 "Budget invariant:  Σ_i π_ij = d for all j and all steps (proposition, Section 4)."]))
story.append(P("<b>Structural rule (Trial A).</b> ζ accumulates κ_s(π − 1) on active synapses, is clipped to [−8, 8], and a synapse is kept if σ(ζ) ≥ 0.15. Removed budget is redistributed to survivors by the softmax, which keeps the simplex sum fixed."))
# App B
story.append(H1("Appendix B  Parameters and file manifest"))
rows=[["Parameter","Trial A","Trial B"],
 ["Hidden units / compartments","8 compartments","16 hidden units"],
 ["Micro-steps / time steps","3 micro-steps","5 steps, dt = 1"],
 ["ρ (recovery)","0.55","0.3"],
 ["α_d / α_r (depression)","0.18","0.5"],
 ["α_f / α_u (facilitation)","0.10","0.3"],
 ["τ_u, U_rest / U_0","3.0, 0.25","3.0, 0.3"],
 ["Allocation step","0.025 (logit, centred)","0.5 final; 0.05 in sweep (scale-normalised)"],
 ["Optimiser","AdamW lr 0.012, wd 1e-4","Adam lr 0.01; θ scaled by π"],
 ["Epochs / batch / patience","up to 100 / 32 / 18","40 / 64 / none (no early stop)"],
 ["Split","70/15/15 stratified","70/30 stratified"],
 ["Seeds","7, 21, 42","0, 1, 2 (sweep 0, 1, 2)"]]
story.append(TAB(rows,[5.2,5.4,5.4])); story.append(P("<b>Table 10.</b> Parameters of the two trials.",cap))
story.append(P("<b>Files in the research folder.</b> Trial A: alien_dl.py, run_benchmark.py, test_alien_dl.py, README, EXPERIMENT_REPORT.md, benchmark_results.csv, benchmark_summary.csv, factorial_results.csv. Trial B: alien.py, unit_tests.py, run_alien.py, eta_sweep.py, JSON results, logs. The full bundle ALIEN_DL_Research_Trials.zip contains both trials, all uploaded files and the original package."))
story.append(H1("References"))
for r in ["Adams CE? (selection frameworks for synaptic learning, background, not re-verified).",
 "Evci U, Gale T, Menick J, Castro PS, Elsen E (2020) Rigging the lottery: making all tickets winners. Proceedings of ICML.",
 "Kingma DP, Ba J (2015) Adam: a method for stochastic optimization. Proceedings of ICLR.",
 "Kivinen J, Warmuth MK (1997) Exponentiated gradient versus gradient descent for linear predictors. Information and Computation 132: 1–63.",
 "Maclaurin D, Duvenaud D, Adams RP (2015) Autograd: effortless gradients in NumPy. ICML AutoML workshop.",
 "Mocanu DC, Mocanu E, Stone P, Nguyen PH, Gibescu M, Liotta A (2018) Scalable training of artificial neural networks with adaptive sparse connectivity inspired by network science. Nature Communications 9: 2383.",
 "Pedregosa F et al. (2011) Scikit-learn: machine learning in Python. Journal of Machine Learning Research 12: 2825–2830.",
 "Seung HS (2003) Learning in spiking neural networks by reinforcement of stochastic synaptic transmission. Neuron 40: 1063–1073.",
 "Tsodyks MV, Markram H (1997) The neural code between neocortical pyramidal neurons depends on neurotransmitter release probability. PNAS 94: 719–723.",
 "Turrigiano GG (2008) The self-tuning neuron: synaptic scaling of excitatory synapses. Cell 135: 422–435."]:
    story.append(P(r,small))
def footer(c,d):
    c.saveState(); c.setFont("Sans",7); c.setFillColor(GREY)
    c.drawString(2*cm,1.2*cm,"PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 14 Nov 2026")
    c.drawRightString(A4[0]-2*cm,1.2*cm,f"{d.page}"); c.restoreState()
if __name__=="__main__":
    os.makedirs(os.path.dirname(OUT),exist_ok=True)
    doc=SimpleDocTemplate(OUT,pagesize=A4,leftMargin=2*cm,rightMargin=2*cm,topMargin=1.7*cm,bottomMargin=1.9*cm,title="ALIEN-DL: Coupling Synaptic Transmission, Plasticity and Structure Through One Conserved Resource Budget",author="Devanik Debnath; Xylia",subject="Preprint v1.0")
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    from pypdf import PdfReader; print("wrote",OUT,"pages",len(PdfReader(OUT).pages))
