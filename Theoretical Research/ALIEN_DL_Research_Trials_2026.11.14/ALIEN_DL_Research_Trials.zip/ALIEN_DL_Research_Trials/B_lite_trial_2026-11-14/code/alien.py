"""ALIEN-DL lite: a conserved-resource synaptic classifier (numpy + autograd).
Hidden unit j receives d synapses, one per input i. Each synapse has weight theta_ij, resource
recovery r_ij, release probability u_ij, and a resource share pi_ij. Within each hidden unit the shares
are a budget: sum_i pi_ij = d (mass conserved). Dynamics run for T steps per sample:
  r <- r + dt*(rho*pi*(1-r) - alpha_r*u*r*x)          (allocation-coupled recovery)
  u <- u + dt*((U0-u)/tau_u + alpha_u*(1-u)*x)
  q  = theta*u*r*x,   drive_j = sum_i sum_t q_ij / d,   h = tanh(drive + b1),  logits = h W2 + b2
Coupling switches (see run_alien.py):
  R : shares enter recovery (forward pass)            -> without R, shares are inert
  P : plasticity gradient on theta scaled by pi        (normalised, mean 1)
  A : shares adapt by exponentiated gradient on dL/dpi (budget preserved by softmax)"""
import autograd.numpy as np
from autograd import grad

RHO, ALPHA_R, ALPHA_U, U0, TAU_U, DT, T_STEPS = 0.3, 0.5, 0.3, 0.3, 3.0, 1.0, 5


def init(d, H, K, rng):
    p = {"theta": rng.normal(0, 0.5, (d, H)), "b1": np.zeros(H),
         "W2": rng.normal(0, 0.3, (H, K)), "b2": np.zeros(K)}
    return p


def shares(logits):
    """pi_ij = d * softmax over synapses i within each hidden unit j (sums to d per unit)."""
    z = logits - np.max(logits, axis=0, keepdims=True)
    e = np.exp(z)
    return logits.shape[0] * e / np.sum(e, axis=0, keepdims=True)


def forward_hidden(p, pi, x, R=1):
    """x: (B, d) with values in [0,1]. Returns hidden activations (B, H)."""
    B, d = x.shape
    H = p["theta"].shape[1]
    pi_eff = pi if R else np.ones_like(pi)
    pre = x[:, :, None]                                  # (B, d, 1)
    r = np.ones((B, d, H)) * 1.0
    u = np.ones((B, d, H)) * U0
    acc = np.zeros((B, d, H))
    for _ in range(T_STEPS):
        rec = RHO * pi_eff[None] * (1.0 - r) - ALPHA_R * u * r * pre
        r = np.minimum(np.maximum(r + DT * rec, 0.0), 1.0)
        du = (U0 - u) / TAU_U + ALPHA_U * (1.0 - u) * pre
        u = np.minimum(np.maximum(u + DT * du, 0.0), 1.0)
        acc = acc + p["theta"][None] * u * r * pre
    drive = np.sum(acc, axis=1) / d                      # (B, H)
    return np.tanh(drive + p["b1"])


def logits_fn(p, pi, x, R=1):
    h = forward_hidden(p, pi, x, R)
    return h @ p["W2"] + p["b2"]


def loss_fn(p, pi, x, y_onehot, R=1, l2=1e-4):
    z = logits_fn(p, pi, x, R)
    z = z - np.max(z, axis=1, keepdims=True)
    logp = z - np.log(np.sum(np.exp(z), axis=1, keepdims=True))
    ce = -np.mean(np.sum(y_onehot * logp, axis=1))
    return ce + l2 * np.sum(p["theta"] ** 2)


grad_params = grad(loss_fn, 0)     # w.r.t. trainable parameters (dict)
grad_pi = grad(loss_fn, 1)         # w.r.t. resource shares


def predict(p, pi, x, R=1):
    return np.argmax(logits_fn(p, pi, x, R), axis=1)
