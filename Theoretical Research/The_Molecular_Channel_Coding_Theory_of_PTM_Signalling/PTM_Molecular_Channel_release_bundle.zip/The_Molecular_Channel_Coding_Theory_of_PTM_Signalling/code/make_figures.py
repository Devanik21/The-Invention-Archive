#!/usr/bin/env python3
import json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures"); os.makedirs(FIG, exist_ok=True)
C1, C2, C3, C4 = "#1f4e79", "#c0504d", "#4f8f3a", "#8064a2"
plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "legend.fontsize": 7.5, "figure.dpi": 110})
def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=160, bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".svg"), bbox_inches="tight"); plt.close(fig)
L = lambda n: json.load(open(os.path.join(RES, n)))
E2, E3, E4, E5, E6 = L("E2_time_turnover.json"), L("E3_crosstalk.json"), L("E4_energy_frontier.json"), L("E5_codes.json"), L("E6_learned_decoder.json")

# fig01 architecture of the molecular channel
fig, ax = plt.subplots(figsize=(7.4, 3.3)); ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis("off")
def box(x, y, w, h, t, c):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.05", fc=c, ec="#333", lw=0.8, alpha=0.92))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=7.2)
def arr(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", lw=0.9, color="#333"))
box(0.1, 3.4, 2.1, 1.0, "Input x\nbinary kinase pattern s ∈ {0,1}ⁿ", "#dbe5f1")
box(2.9, 3.4, 2.6, 1.0, "CME generator Q_s\non-rate ακ s_i(1+c·Σz_j)\noff-rate βκ", "#f2dcdb")
box(6.2, 3.4, 1.7, 1.0, "State Z(t)\nproteoform z∈{0,1}ⁿ", "#ebf1de")
box(8.2, 3.4, 1.7, 1.0, "Reader Y\nfull readout", "#e4dfec")
arr(2.2, 3.9, 2.9, 3.9); arr(5.5, 3.9, 6.2, 3.9); arr(7.9, 3.9, 8.2, 3.9)
box(0.1, 1.6, 4.6, 1.2, "Information  C = max_P I(X;Y)   (Blahut–Arimoto)\nexact, from W = exp(Q_s t)", "#fde9d9")
box(5.1, 1.6, 4.8, 1.2, "Dissipation  Φ = ∫ Σ exit rates dτ\nC depends only on κt (scaling law)", "#daeef3")
box(0.1, 0.05, 9.8, 1.1, "Codes and decoders: MAP error vs codebook distance; neural decoder vs exact Bayes limit", "#ffffff")
arr(2.4, 1.6, 2.4, 1.15); arr(7.5, 1.6, 7.5, 1.15)
save(fig, "fig01_channel_architecture")

# fig02 capacity vs time for three turnover rates
t = np.array(E2["t"])
fig, ax = plt.subplots(figsize=(5.4, 3.1))
for k, col in zip(E2["kappa"], [C3, C1, C2]):
    ax.semilogx(t, E2["C"][str(k)], "o-", ms=3, color=col, label=f"κ = {k}")
ax.axhline(E2["C_max_bits"] * 0 + 1.879128, color="k", ls="--", lw=0.8, label="stationary ceiling 1.8791")
ax.set_xlabel("observation time t"); ax.set_ylabel("capacity (bits)")
ax.set_title("Capacity of the 4-site PTM channel"); ax.legend(fontsize=6.5)
fig.tight_layout(); save(fig, "fig02_capacity_vs_time")

# fig03 collapse onto kappa*t
fig, ax = plt.subplots(figsize=(5.4, 3.1))
for k, col in zip(E2["kappa"], [C3, C1, C2]):
    ax.plot(np.array(t) * k, E2["C"][str(k)], "o", ms=3.5, color=col, label=f"κ = {k}")
ax.set_xscale("log"); ax.set_xlabel("κ t (total cycle budget, log scale)"); ax.set_ylabel("capacity (bits)")
ax.set_title("Scaling law: all points lie on one curve"); ax.legend(fontsize=6.5)
fig.tight_layout(); save(fig, "fig03_scaling_collapse")

# fig04 crosstalk
fig, ax = plt.subplots(figsize=(5.0, 3.0))
ax.bar([str(c) for c in E3["c"]], E3["C"], color=C1)
for i, v in enumerate(E3["C"]): ax.text(i, v + 0.03, f"{v:.2f}", ha="center", fontsize=7)
ax.set_xlabel("crosstalk coefficient c"); ax.set_ylabel("capacity at t = 2 (bits)")
ax.set_title("Positive crosstalk raises capacity"); ax.set_ylim(0, 3.2)
fig.tight_layout(); save(fig, "fig04_crosstalk")

# fig05 dissipation-capacity frontier
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
for tt, col in zip([0.5, 1.0, 2.0, 4.0], [C3, C1, C4, C2]):
    rr = [r for r in E4["rows"] if r["t"] == tt]
    ax[0].plot([r["cycles_mean"] for r in rr], [r["C"] for r in rr], "o-", ms=3, color=col, label=f"t = {tt}")
    ax[1].plot([r["kappa"] for r in rr], [r["C_per_cycle"] for r in rr], "o-", ms=3, color=col, label=f"t = {tt}")
ax[0].set_xscale("log"); ax[0].set_xlabel("expected cycles per input (dissipation)"); ax[0].set_ylabel("capacity (bits)")
ax[0].set_title("(a) Capacity against dissipation"); ax[0].legend(fontsize=6.5)
ax[1].set_xscale("log"); ax[1].set_yscale("log"); ax[1].set_xlabel("turnover κ"); ax[1].set_ylabel("bits per expected cycle")
ax[1].set_title("(b) Information per cycle"); ax[1].legend(fontsize=6.5)
fig.tight_layout(); save(fig, "fig05_dissipation_frontier")

# fig06 codebook error
rows = E5["rows"]
fig, ax = plt.subplots(figsize=(7.2, 3.0))
names = [r["name"] for r in rows]; xs = np.arange(len(rows))
ax.bar(xs - 0.2, [r["Pe_c0"] for r in rows], 0.4, color=C1, label="no crosstalk (c = 0)")
ax.bar(xs + 0.2, [r["Pe_c1"] for r in rows], 0.4, color=C2, label="crosstalk c = 1")
ax.set_xticks(xs); ax.set_xticklabels([f"{r['name']}\nd = {r['d']}" for r in rows], fontsize=6.3)
ax.set_ylabel("MAP error probability"); ax.set_title("Codebook error at t = 2 (uniform prior over codebook)")
ax.legend(fontsize=6.8)
fig.tight_layout(); save(fig, "fig06_codebook_error")

# fig07 learned decoder vs Bayes
fig, ax = plt.subplots(figsize=(5.2, 3.0))
N = [r["N"] for r in E6["rows"]]; acc = [r["acc_mean"] for r in E6["rows"]]; sd = [r["acc_sd"] for r in E6["rows"]]
ax.errorbar(N, acc, yerr=sd, fmt="o-", color=C1, capsize=2, label="one-hidden-layer MLP")
ax.axhline(E6["bayes_accuracy_uniform_prior"], color="k", ls="--", lw=0.8, label="exact Bayes (MAP) accuracy")
ax.set_xscale("log"); ax.set_xlabel("training samples N"); ax.set_ylabel("decoding accuracy")
ax.set_title("Learned decoder approaches the Bayes limit"); ax.legend(fontsize=6.5)
fig.tight_layout(); save(fig, "fig07_learned_decoder")

# fig08 validation: Z-channel closed form
fig, ax = plt.subplots(figsize=(5.0, 2.9))
E1 = L("E1_validation.json")
ax.bar(["Z-channel\nBlahut–Arimoto", "Z-channel\nclosed form"], [E1["z_channel_BA_bits"], E1["z_channel_closed_bits"]], color=[C1, C3])
ax.set_ylabel("capacity (bits)"); ax.set_title("Validation: Blahut–Arimoto against closed form")
fig.tight_layout(); save(fig, "fig08_validation_zchannel")
print("figures written", sorted(os.listdir(FIG))[:3], len(os.listdir(FIG)))
