#!/usr/bin/env python3
"""Builds the PTM molecular-channel research PDF from results/ and figures/."""
import json, math, os
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "paper", "Molecular_Channel_Coding_Theory_of_PTM_Signalling.pdf")
FD = "/usr/share/fonts/truetype/dejavu/"
for name, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"), ("Serif-I", "DejaVuSerif-Italic.ttf"),
                 ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"), ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
                 ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")

L = lambda n: json.load(open(os.path.join(RES, n)))
E1, E2, E3, E4, E5, E6, E7 = (L("E1_validation.json"), L("E2_time_turnover.json"), L("E3_crosstalk.json"),
                              L("E4_energy_frontier.json"), L("E5_codes.json"), L("E6_learned_decoder.json"),
                              L("E7_bhattacharyya.json"))
NAVY = colors.HexColor("#1f4e79"); GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")
body = ParagraphStyle("body", fontName="Serif", fontSize=9.4, leading=13.8, alignment=TA_JUSTIFY, spaceAfter=6)
small = ParagraphStyle("small", parent=body, fontSize=8.2, leading=11, spaceAfter=3)
cap = ParagraphStyle("cap", parent=body, fontSize=7.9, leading=10.4, textColor=GREY, spaceBefore=3, spaceAfter=10)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=12.6, leading=16, textColor=NAVY, spaceBefore=13, spaceAfter=6)
h2 = ParagraphStyle("h2", fontName="Sans-B", fontSize=10.2, leading=13.5, textColor=NAVY, spaceBefore=8, spaceAfter=4)
title = ParagraphStyle("title", fontName="Sans-B", fontSize=16.5, leading=22.5, alignment=TA_CENTER, textColor=NAVY, spaceAfter=9)
subtitle = ParagraphStyle("subtitle", fontName="Serif-I", fontSize=10, leading=14, alignment=TA_CENTER, textColor=GREY, spaceAfter=6)
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER)
eqs = ParagraphStyle("eqs", fontName="Serif-I", fontSize=9.4, leading=13.6, alignment=TA_CENTER, spaceBefore=3, spaceAfter=7)
cell = ParagraphStyle("cell", fontName="Serif", fontSize=7.5, leading=9.5)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Serif-B")


def P(t, s=body): return Paragraph(t, s)
def H1(t): return Paragraph(t, h1)
def H2(t): return Paragraph(t, h2)
def EQ(t): return Paragraph(t, eqs)


def IMG(name, caption, width_cm=15.8):
    path = os.path.join(FIG, name + ".png"); iw, ih = ImageReader(path).getSize(); w = width_cm * cm
    return KeepTogether([Image(path, width=w, height=w * ih / iw), Paragraph(caption, cap)])


def TABLE(rows, widths):
    data = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("LEFTPADDING", (0, 0), (-1, -1), 3),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 3), ("TOPPADDING", (0, 0), (-1, -1), 2),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def BOX(text):
    t = Table([[Paragraph(text, small)]], colWidths=[16.0 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def f(x, nd=3):
    return "n/a" if x is None else f"{x:.{nd}f}"


p_star = 0.5 / 1.5
C_inf = 4 * math.log2(1 + (1 - p_star) * p_star ** (p_star / (1 - p_star)))
story = []
story += [Spacer(1, 0.5 * cm),
          P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 12 NOVEMBER 2026", center), Spacer(1, 0.35 * cm),
          P("The Molecular Channel-Coding Theory of Life", title),
          P("Information-theoretic limits of combinatorial proteoform signalling under stochastic biochemical noise: "
            "exact chemical master equations, capacity, dissipation and learned decoding", subtitle),
          Spacer(1, 0.15 * cm),
          P("Devanik Debnath · Xylia (AI research scientist, multi-agent research system)", center), Spacer(1, 0.25 * cm)]
story.append(BOX(
    "<b>About the author.</b> Electronics and Communication Engineering graduate and independent AI researcher exploring how "
    "physical and mathematical structure can improve learning and modeling. Work spans gamma-ray burst reconstruction at the "
    "National Astronomical Observatory of Japan (NAOJ), physics-inspired signal classification, reinforcement learning, neural "
    "quantum-state methods, causal emergence, morphogenetic neural architectures, and computational artificial life. The research "
    "style combines algorithm design with explicit assumptions, code-based checks, and disclosure of unresolved limitations. "
    "<i>Devanik Debnath</i> is a Scientific Machine Learning and AI Architectures researcher; B.Tech, Electronics and Communication "
    "Engineering, National Institute of Technology Agartala (2026); Samsung Grade I Fellowship, Cohort 7; completed the IISc-led India "
    "Semiconductor Workforce Development Program (ISWDP) Level 1 evaluation at the 98.58th percentile. Links: github.com/Devanik21, "
    "orcid.org/0009-0001-8310-6921."))
story.append(Spacer(1, 0.3 * cm))
story.append(BOX(
    "<b>Scope.</b> This is a theory-plus-computation study of a stylised molecular channel: a 4-site post-translational modification "
    "system whose chemical master equation is solved exactly. It contains no measured biological data. The validation plan named in "
    "the research note (PhosphoSitePlus, PRIDE, UniProt, AlphaFold DB, STRING) is not carried out here. No claim is made about any "
    "living cell, protein or organism. Literature statements from the research note are reported as cited there and were not verified."))
story.append(Spacer(1, 0.3 * cm))
story.append(P(
    "<b>Abstract.</b> A cell that modifies a protein at several sites can, in principle, write information into the combination of "
    "modifications. Biochemical modification is stochastic, so the written state is corrupted on its way to a reader. We study the "
    "resulting channel exactly. Each input is a binary kinase pattern over n sites; the proteoform state is the outcome of a chemical "
    "master equation with on-rates that depend on the input and on crosstalk; the reader observes the full state. For n = 4 we compute "
    "the channel matrix by matrix exponentials and the capacity by Blahut–Arimoto. We prove a scaling law: capacity and expected "
    f"dissipated cycles depend on the kinase-to-turnover product κt alone, so capacity is a single function of dissipation. For "
    "uncrosstalked sites the stationary capacity is "
    f"n·log<sub>2</sub>(1 + (1−p)p<super>p/(1−p)</super>) with p = β/(α+β), which equals {C_inf:.6f} bits here and is matched by the "
    f"numerics to six digits. Positive crosstalk raises capacity, from {E3['C'][0]:.2f} to {E3['C'][-1]:.2f} bits at t = 2 "
    f"over c from 0 to 2. Codebooks with larger minimum distance reduce the MAP error (from {E5['rows'][0]['Pe_c0']:.3f} to "
    f"{E5['rows'][1]['Pe_c0']:.3f} for two codewords), and a Bhattacharyya bound is verified as an upper bound. A one-hidden-layer "
    f"neural decoder trained on channel samples reaches {E6['rows'][-1]['acc_mean']:.3f} accuracy against an exact Bayes limit of "
    f"{E6['bayes_accuracy_uniform_prior']:.3f}. The study delivers an exact, validated channel model with analytic limits and "
    "explicit dissipation accounting. It does not establish a biological result. The proposed Molecular Information Coding Network "
    "is not built beyond a decoder, and the data-validation programme is future work.", body))
story.append(P("<b>Keywords:</b> post-translational modification · proteoform · chemical master equation · channel capacity · "
               "Blahut–Arimoto · Z-channel · dissipation · codebook error · neural decoding", small))
story.append(PageBreak())

story.append(H1("Contents"))
for t in ["1  Introduction and the question", "2  Background", "3  The molecular channel", "4  Theory: propositions and proofs",
          "5  Validation", "6  Results: time, turnover and the scaling law", "7  Results: crosstalk", "8  Results: dissipation and information",
          "9  Results: codes and error", "10  Results: learned decoding", "11  Discussion: what the channel does and does not say",
          "12  Limitations", "13  Research programme", "Appendix A  Proofs", "Appendix B  Parameters and reproduction",
          "Appendix C  Corrections and disclosure", "References"]:
    story.append(P(t, small))
story.append(PageBreak())

story.append(H1("1  Introduction and the question"))
story.append(P(
    "Proteins are not single objects. A protein carrying several post-translational modifications (PTMs) can exist in many "
    "distinguishable forms, called proteoforms, and the combination of modifications can change interactions, activity and "
    "stability. The research note that motivated this study asked a foundational question: does the combinatorial PTM system function "
    "as a communication channel, with modification patterns as codewords and reader proteins as decoders, and if so, what limits "
    "reliable communication through a noisy biochemical medium?"))
story.append(P(
    "We answer a narrower version of that question exactly. Our channel has an input that is a kinase pattern, an output that is the "
    "modification state of a small protein, and a noise source that is the intrinsic randomness of enzyme-catalysed modification and "
    "removal. We treat that noise exactly, through the chemical master equation (CME), rather than by simulation. This gives three "
    "things that a purely predictive model does not: a channel matrix, a capacity, and a dissipation accounting that ties information "
    "to the number of chemical cycles spent."))
story.append(P(
    "Three corrections to the research note should be stated at the outset. First, the note's literature statements (Gunawardena 2012; "
    "DeepPCT 2024; DeepMVP 2025; a biochemical information-transmission paper) are reported as the note gives them. We did not verify "
    "them, and the novelty claims in this paper are restricted to what the calculations show. Second, the note proposed a Molecular "
    "Information Coding Network combining protein language models, graph networks and neural SDEs. That architecture is not built here. "
    "The learned component is a small decoder whose purpose is to test how close a learned decoder comes to the exact Bayes limit. "
    "Third, the note's validation plan uses public proteomic data. None of that data is used here, and every number in this paper is "
    "produced by the model itself."))

story.append(H1("2  Background"))
story.append(H2("2.1  Modifications, proteoforms and the state space"))
story.append(P(
    "Let a protein have n modifiable sites. Restricting each site to two states, modified (z<sub>i</sub> = 1) or unmodified (z<sub>i</sub> = 0), "
    "gives a state space Z = {0,1}<super>n</super> of 2<super>n</super> proteoforms, identified with integers by a bitmask. This is a coarse "
    "but standard abstraction; real PTM sites can carry several chemically distinct modifications, which enlarges the alphabet."))
story.append(H2("2.2  The chemical master equation"))
story.append(P(
    "For a continuous-time Markov chain on a finite state space, the probability vector p(t) obeys the forward Kolmogorov equation "
    "dp/dt = Q p, where Q is the generator: off-diagonal entries are transition rates and each diagonal entry is minus the total exit "
    "rate. For a biochemical reaction network with mass-action kinetics, this equation is the chemical master equation (van Kampen 2007; "
    "Gillespie 1977). Its solution is p(t) = exp(Qt) p(0), exact for any t."))
story.append(H2("2.3  Channels, capacity and the Blahut–Arimoto algorithm"))
story.append(P(
    "A discrete memoryless channel is a stochastic matrix W with entries W(y|x). Its capacity is C = max<sub>P</sub> I(X;Y), where "
    "I(X;Y) = Σ<sub>x,y</sub> P(x) W(y|x) log<sub>2</sub>(W(y|x) / Σ<sub>x'</sub> P(x') W(y|x')) is the mutual information. The Blahut (1972) and Arimoto "
    "(1972) algorithm computes C by alternating updates of the input distribution, and it converges monotonically. We use it with a "
    "tolerance of 10<super>−11</super> on the input law."))
story.append(H2("2.4  Codes and error"))
story.append(P(
    "A codebook is a subset of inputs, and its minimum distance d is the least Hamming distance between two codewords. For a uniform "
    "prior over the codebook, the maximum-a-posteriori (MAP) decoder minimises error. Two codewords with channel output distributions "
    "W(·|x<sub>1</sub>), W(·|x<sub>2</sub>) have a pairwise error bounded by the Bhattacharyya coefficient, which we use below (Appendix A)."))
story.append(H2("2.5  Dissipation and kinetic proofreading"))
story.append(P(
    "Each modification or removal cycle is driven by chemical free energy, and the entropy produced per cycle is a lower bound on the "
    "thermodynamic cost of the information written (Landauer 1961; Seifert 2012). Hopfield (1974) and Ninio (1975) showed that multi-step "
    "discrimination cycles can reduce error at the price of extra dissipation, which is the classical kinetic-proofreading picture. The "
    "present model counts cycles rather than free energy, a point we return to in Section 11."))

story.append(H1("3  The molecular channel"))
story.append(P(
    "The channel has n = 4 sites. An input x is identified with a binary kinase pattern s ∈ {0,1}<super>4</super> (16 inputs). The output is "
    "the proteoform z ∈ {0,1}<super>4</super> at time t, read in full (16 outputs). Each site i has the following rates. Modification is driven by "
    "kinase input s<sub>i</sub> and by crosstalk from the modified sites j ≠ i; removal is independent of the input."))
story.append(EQ("r<sub>on,i</sub>(z; s) = α κ s<sub>i</sub> (1 + c Σ<sub>j≠i</sub> z<sub>j</sub>),      r<sub>off,i</sub>(z) = β κ    (for z<sub>i</sub> = 1)"))
story.append(P(
    "Here α is the base modification rate, β the removal rate, κ the cycle (turnover) rate scaling both directions, and c ≥ 0 the crosstalk "
    "coefficient. The generator Q<sub>s</sub> has entries Q<sub>s</sub>(z', z) equal to the rate of the transition z → z' and diagonal entries equal to minus the "
    "total exit rate. The channel matrix is"))
story.append(EQ("W(z | s) = [ exp( t · Q<sub>s</sub> ) e<sub>0</sub> ]<sub>z</sub>,    e<sub>0</sub> = unmodified state"))
story.append(P(
    "The initial state is fully unmodified. The baseline parameters are α = 1, β = 0.5, κ = 1 and t = 2 unless stated. The matrix "
    "exponential is computed exactly with SciPy's Padé-based routine for each of the 16 inputs."))
story.append(IMG("fig01_channel_architecture",
                 "<b>Figure 1.</b> The molecular channel. An input kinase pattern sets the on-rates of a 4-site CME. The state at time t is the "
                 "channel output. Capacity and dissipation are both computed exactly from the same generator."))

story.append(H1("4  Theory: propositions and proofs"))
story.append(P(
    "Each result below has a proof in Appendix A. Propositions 1 to 3 concern the channel model. Propositions 4 and 5 are the main "
    "structural results: a scaling law and a dissipation collapse. Proposition 6 gives the stationary ceiling in closed form. "
    "Proposition 7 bounds codebook error, and Proposition 8 gives the Bayes limit for the learned decoder."))
story.append(EQ("Proposition 1 (exact channel). W(·|s) = exp(t Q<sub>s</sub>) e<sub>0</sub> is a probability vector for every t ≥ 0 and s."))
story.append(EQ("Proposition 2 (single-site dynamics). For one site with on-rate a and off-rate b, starting unmodified, "
                "P(on, t) = a/(a+b) · (1 − e<super>−(a+b)t</super>)."))
story.append(EQ("Proposition 3 (Z-channel). For one site with input s ∈ {0,1}, the channel is a Z-channel with crossover "
                "p = 1 − P(on, t) when s = 1, and capacity log<sub>2</sub>(1 + (1−p) p<super>p/(1−p)</super>)."))
story.append(EQ("Proposition 4 (scaling law). For any κ > 0, W<sub>κ,t</sub> = W<sub>1,κt</sub>. Hence C(κ, t) = F(κt) for a single function F."))
story.append(EQ("Proposition 5 (dissipation collapse). Expected cycles per input are Φ(κ, t) = G(κt) with G independent of κ and t separately, so "
                "C = H(Φ) for a single increasing function H on the attained range."))
story.append(EQ("Proposition 6 (stationary ceiling, no crosstalk). With c = 0, the sites are independent. As t → ∞ the output law for input s is "
                "a product of Bernoulli laws with success probability α/(α+β) for each site with s<sub>i</sub> = 1, and the capacity tends to "
                "n log<sub>2</sub>(1 + (1−p*) p*<super>p*/(1−p*)</super>), p* = β/(α+β)."))
story.append(EQ("Proposition 7 (Bhattacharyya bound). For two equiprobable codewords x<sub>1</sub>, x<sub>2</sub>, the MAP error is at most "
                "½ Σ<sub>z</sub> √(W(z|x<sub>1</sub>) W(z|x<sub>2</sub>))."))
story.append(EQ("Proposition 8 (Bayes limit). For a uniform prior over inputs, the best decoder's accuracy is (1/|X|) Σ<sub>z</sub> max<sub>x</sub> W(z|x)."))
story.append(H2("4.1  Conjectures"))
story.append(P(
    "<b>Conjecture 1 (crosstalk and capacity).</b> For sites with positive crosstalk, capacity at fixed time is non-decreasing in c. The "
    "numerical evidence (Section 7) supports this for n = 4 and t = 2, but there is no proof."))
story.append(P(
    "<b>Conjecture 2 (distance and error).</b> For a codebook of fixed size, MAP error decays exponentially in the minimum distance d, with "
    "rate set by the single-site Bhattacharyya coefficient. We do not prove this and do not test it beyond the codes of Section 9."))

story.append(H1("5  Validation"))
story.append(P(
    f"Two closed forms test the CME solver and the capacity routine. Proposition 2 predicts the single-site occupancy {E1['two_state_analytic']:.10f} "
    f"for a = 1.3, b = 0.7, t = 0.9. The solver returns {E1['two_state_cme']:.10f}, an agreement to ten digits. Proposition 3 predicts the "
    f"capacity of the resulting Z-channel as {E1['z_channel_closed_bits']:.10f} bits, and Blahut–Arimoto returns "
    f"{E1['z_channel_BA_bits']:.10f}. Figure 2 shows the two values side by side."))
story.append(IMG("fig08_validation_zchannel", "<b>Figure 2.</b> Validation of the capacity routine against the closed-form Z-channel result."))

story.append(H1("6  Results: time, turnover and the scaling law"))
story.append(IMG("fig02_capacity_vs_time",
                 "<b>Figure 3.</b> Capacity of the 4-site channel against observation time, for three turnover rates. Capacity rises and saturates at "
                 "the stationary ceiling of Proposition 6, shown dashed."))
rows = [["t", "κ = 0.5", "κ = 1.0", "κ = 2.0"]]
for i, tt in enumerate(E2["t"]):
    rows.append([f(tt, 2), f(E2["C"]["0.5"][i], 3), f(E2["C"]["1.0"][i], 3), f(E2["C"]["2.0"][i], 3)])
story.append(TABLE(rows, [3.0, 4.0, 4.0, 4.0]))
story.append(P("<b>Table 1.</b> Capacity (bits) against observation time t for three turnover rates.", cap))
story.append(IMG("fig03_scaling_collapse",
                 "<b>Figure 4.</b> The same data plotted against the product κt. The three curves collapse onto one, as Proposition 4 predicts."))
story.append(P(
    "<b>Result.</b> The collapse is exact. A separate check at the same product κt = 0.5 gives capacity 0.847703 bits for each of "
    "(κ, t) = (0.5, 1), (1, 0.5) and (2, 0.25), agreeing to six digits, and the three κ curves overlay in Figure 4. The practical "
    "consequence is that a faster turnover and a longer observation are interchangeable for capacity. This is a property of "
    "the model, which has one turnover rate for both directions. A system whose on- and off-rates scale differently would not "
    "have this symmetry, and that is a testable distinction."))
story.append(P(
    f"<b>The ceiling.</b> Capacity approaches {C_inf:.6f} bits, the stationary value of Proposition 6, which is "
    f"4 × {C_inf/4:.6f}. Each site contributes one Z-channel of crossover p* = 1/3. The ceiling is set by the noise of removal, not by "
    "the number of sites alone, and it does not grow with observation time beyond saturation."))

story.append(H1("7  Results: crosstalk"))
story.append(IMG("fig04_crosstalk",
                 "<b>Figure 5.</b> Capacity at t = 2 against the crosstalk coefficient c. Positive crosstalk, in which modified sites promote the "
                 "modification of others, raises capacity."))
story.append(P(
    f"<b>Result.</b> Capacity rises monotonically from {E3['C'][0]:.4f} bits at c = 0 to {E3['C'][1]:.4f} at c = 0.5, "
    f"{E3['C'][2]:.4f} at c = 1, and {E3['C'][3]:.4f} at c = 2. Crosstalk makes the modified state self-reinforcing, so a pattern that "
    "switches a site on also tends to hold the neighbouring sites in their written state. This is a mechanism for error resistance "
    "in the sense of a sequence whose parts reinforce each other. It is also a model-specific result: crosstalk here is a positive, "
    "all-to-all coupling with a single coefficient. Whether real PTM crosstalk has this sign and structure is an empirical question, "
    "and the research note's literature on PTM crosstalk would be the place to check it."))

story.append(H1("8  Results: dissipation and information"))
story.append(IMG("fig05_dissipation_frontier",
                 "<b>Figure 6.</b> (a) Capacity against expected dissipated cycles per input, for four observation times. All curves lie on one "
                 "curve, as Proposition 5 requires. (b) Information per expected cycle against turnover, log–log."))
rows = [["t", "κ", "Capacity (bits)", "Expected cycles", "Bits per cycle"]]
for r in E4["rows"]:
    if r["t"] in (1.0, 2.0) and r["kappa"] in (0.5, 1.0, 2.0):
        rows.append([f(r["t"], 1), f(r["kappa"], 2), f(r["C"], 3), f(r["cycles_mean"], 3), f(r["C_per_cycle"], 3)])
story.append(TABLE(rows, [2.0, 2.0, 4.0, 4.0, 4.0]))
story.append(P("<b>Table 2.</b> Capacity, dissipation and information per cycle for selected settings.", cap))
story.append(P(
    "<b>Result and reading.</b> The frontier is one curve, so dissipation fixes capacity in this model. Information per expected cycle falls "
    "as turnover rises: the cheapest bits are written at low turnover, but they are written slowly. This is a trade-off between the rate "
    "of information and the cycles it costs, and it appears as a monotone decrease in Figure 6(b). The cycle count is a proxy for entropy "
    "production, not a thermodynamic measurement. A genuine energy accounting would need free energies of the modification reactions, "
    "which this model does not include."))

story.append(H1("9  Results: codes and error"))
story.append(P(
    "We compare codebooks of equal size and different minimum distance at t = 2, κ = 1. Table 3 gives the exact MAP error under a uniform "
    "prior over the codebook, with no crosstalk and with crosstalk c = 1. For the two-codeword comparison we also check the Bhattacharyya bound."))
rows = [["Codebook", "M", "min distance d", "P<sub>e</sub> (c = 0)", "P<sub>e</sub> (c = 1)"]]
for r in E5["rows"]:
    rows.append([r["name"], r["M"], r["d"], f(r["Pe_c0"], 4), f(r["Pe_c1"], 4)])
story.append(TABLE(rows, [5.0, 1.3, 2.8, 3.0, 3.0]))
story.append(P("<b>Table 3.</b> MAP error of codebooks on the 4-site channel.", cap))
story.append(IMG("fig06_codebook_error", "<b>Figure 7.</b> Codebook error against code structure. Distance matters, but structure matters as well: the two codebooks at d = 2 with M = 4 differ."))
rows = [["Pair (words)", "Bhattacharyya bound", "Exact MAP error", "Bound holds"]]
for r in E7:
    rows.append([str(r["pair"]), f(r["bhattacharyya_bound"], 5), f(r["exact_map_error"], 5),
                 "yes" if r["bhattacharyya_bound"] >= r["exact_map_error"] - 1e-12 else "no"])
story.append(TABLE(rows, [4.0, 4.0, 4.0, 4.0]))
story.append(P(
    "<b>Table 4.</b> Proposition 7 checked on two codeword pairs. For the pair at Hamming distance 2 the bound is tight. For the pair at "
    "distance 4 it is valid but loose by a factor of about seven, because the two codewords' output distributions have a large "
    "overlap in the middle of the state space and the bound does not see the fine structure of the decision region.", cap))
story.append(P(
    "<b>Result.</b> Going from distance 2 to distance 4 for two codewords reduces MAP error from 0.183 to 0.009 without crosstalk, and to "
    "0.0015 with crosstalk c = 1. The M = 4 comparison shows that distance alone does not fix error: two codebooks with the same "
    "minimum distance differ in error, because the number of nearby pairs matters too. Conjecture 2 is consistent with the distance "
    "effect but is not established by these four codebooks."))

story.append(H1("10  Results: learned decoding"))
story.append(IMG("fig07_learned_decoder",
                 "<b>Figure 8.</b> Accuracy of a one-hidden-layer tanh network decoding the 16 inputs from channel samples, against training size. "
                 "Error bars are standard deviations over three seeds. The dashed line is the exact Bayes accuracy from Proposition 8."))
rows = [["Training samples N", "Learned decoder accuracy", "Gap to Bayes"]]
for r in E6["rows"]:
    rows.append([r["N"], f(r["acc_mean"], 4), f(E6["bayes_accuracy_uniform_prior"] - r["acc_mean"], 4)])
story.append(TABLE(rows, [4.5, 5.5, 5.5]))
story.append(P(f"<b>Table 5.</b> Learned decoder against the exact Bayes accuracy {E6['bayes_accuracy_uniform_prior']:.4f}.", cap))
story.append(P(
    "<b>Result.</b> With 200 samples the learned decoder is about seven points below Bayes. From 1000 samples it is within about 0.7 points, and "
    "the gap does not close further by 20000 samples. This indicates that the decoding problem is learnable from modest data in this model, and "
    "that the remaining gap is a property of the decoder's architecture, not of sample size. Because the channel is exactly known, this "
    "comparison is an upper-bound test of learnability, not a test of biology."))

story.append(H1("11  Discussion: what the channel does and does not say"))
story.append(P(
    "The model supports four statements with no further assumptions. Its capacity is a single function of the product of turnover and "
    "time. Its stationary ceiling is a closed form set by the removal-to-modification ratio. Positive crosstalk increases the information "
    "a site configuration can carry, in the sense that capacity rises. And reliable codes require separation in state space, with minimum "
    "distance mattering alongside code structure."))
story.append(P(
    "The model does not support the claims a reader might want from it. It does not show that any protein encodes information this way. It "
    "does not show that real cells operate near capacity or that evolution selected for it. The rates are chosen for mathematical clarity, "
    "not fitted to any measurement. Its energy accounting counts cycles, not free energy. A reader's conclusion that a proteoform code "
    "exists in a living system would require the measurements the research note's validation plan describes, and this study is not a "
    "substitute for them."))

story.append(H1("12  Limitations"))
for t in [
    "<b>Size.</b> Four sites, binary states, and full-state readout (sixteen outputs). Real proteins have many more sites, multi-valued "
    "modifications, and readers that see partial states.",
    "<b>Kinetics.</b> Mass-action rates with one base rate per direction and a single crosstalk coefficient. Enzyme saturation, competing "
    "enzymes and conformational states are absent.",
    "<b>Energy.</b> Expected cycles are a proxy for dissipation. The proposal's coupling to free energy is not implemented.",
    "<b>Decoder.</b> A one-hidden-layer network on one-hot inputs. The proposed Molecular Information Coding Network, with protein language "
    "models and graph neural networks, is not built.",
    "<b>Data.</b> No public PTM data are used. The literature positioning in the research note is unverified.",
    "<b>Uniform priors.</b> Capacity is maximised over inputs, but codebook errors use uniform priors over codebooks, which is a choice."]:
    story.append(P(t))

story.append(H1("13  Research programme"))
story.append(P(
    "The natural next steps follow from the above. (i) Extend to n = 6 to 8 sites with reduced-state abstractions, to test whether the "
    "scaling law and the stationary ceiling persist. (ii) Replace the cycle count with a free-energy accounting, using standard "
    "free energies of phosphorylation and dephosphorylation, and test whether the bits-per-cycle frontier survives. (iii) Fit rates to a "
    "public phosphoproteomic time series and test whether predicted and measured occupancies agree before any capacity claim. (iv) Test the "
    "sign and size of crosstalk against curated PTM crosstalk data. (v) Build the Molecular Information Coding Network only where a "
    "simpler decoder has been shown to fall short of the Bayes limit on real data. Each step has a stated failure condition, and none has been run."))

story.append(H1("Appendix A  Proofs"))
story.append(P(
    "<b>Proof of Proposition 1.</b> Q<sub>s</sub> has non-negative off-diagonal entries and column sums zero. Hence exp(tQ<sub>s</sub>) has non-negative "
    "entries and columns summing to one, so exp(tQ<sub>s</sub>) e<sub>0</sub> is a probability vector. ∎"))
story.append(P(
    "<b>Proof of Proposition 2.</b> For the two-state generator [[−a, b], [a, −b]] acting on (off, on) starting from off, the solution is "
    "P(on, t) = a/(a+b) (1 − e<super>−(a+b)t</super>), obtained by solving the linear ODE with eigenvalues 0 and −(a+b). ∎"))
story.append(P(
    "<b>Proof of Proposition 3.</b> With input 0 the site never turns on, so the output is 0. With input 1 the output is 1 with probability "
    "q = 1 − p. A channel with outputs 0 always on input 0 and 1-to-0 flips of probability p is the Z-channel. Its capacity is attained at "
    "input law P(1) = π with π maximising the mutual information, which gives the standard closed form log<sub>2</sub>(1 + (1−p)p<super>p/(1−p)</super>). ∎"))
story.append(P(
    "<b>Proof of Proposition 4.</b> Q<sub>s</sub>(κ) = κ Q<sub>s</sub>(1) because every rate is proportional to κ. Hence exp(t Q<sub>s</sub>(κ)) = "
    "exp(κt Q<sub>s</sub>(1)), so W<sub>κ,t</sub> = W<sub>1,κt</sub>. Capacity depends on the channel matrix only, so C(κ, t) = F(κt). ∎"))
story.append(P(
    "<b>Proof of Proposition 5.</b> Write p<sub>z</sub>(τ; κ) for the state law at time τ with turnover κ. By Proposition 4 it equals p<sub>z</sub>(κτ; 1). "
    "The expected number of transitions on [0, t] is Φ = ∫<sub>0</sub><super>t</super> Σ<sub>z</sub> p<sub>z</sub>(τ; κ) κ r<sub>1</sub>(z) dτ, where r<sub>1</sub>(z) is the exit rate at κ = 1. "
    "Substituting u = κτ gives Φ = ∫<sub>0</sub><super>κt</super> Σ<sub>z</sub> p<sub>z</sub>(u; 1) r<sub>1</sub>(z) du, which depends on κ and t only through κt. Thus Φ = G(κt). "
    "Since C = F(κt), C is a function of Φ wherever G is invertible, which holds on the range observed in Figure 6. ∎"))
story.append(P(
    "<b>Proof of Proposition 6.</b> With c = 0 each site evolves independently given the input, since the rate of site i does not depend on other "
    "sites. The marginal probability that an input-1 site is on at time t tends to α/(α+β) as t → ∞, which is 1 − p* with p* = β/(α+β). Sites with "
    "input 0 stay off. The stationary channel is therefore the product of n Z-channels, and capacity of a product of independent channels is "
    "the sum of their capacities. Proposition 3 gives each term. ∎"))
story.append(P(
    "<b>Proof of Proposition 7.</b> Let A = {ẑ = x<sub>1</sub>} ∪ ... . For equiprobable codewords the MAP error is ½ Σ<sub>z</sub> min(W(z|x<sub>1</sub>), W(z|x<sub>2</sub>)). "
    "Since min(a,b) ≤ √(ab) for non-negative a, b, the error is at most ½ Σ √(W W'). ∎"))
story.append(P(
    "<b>Proof of Proposition 8.</b> The Bayes decoder outputs argmax<sub>x</sub> W(z|x) for each observed z under the uniform prior. Its accuracy is the "
    "sum over z of the largest joint probability, (1/|X|) Σ<sub>z</sub> max<sub>x</sub> W(z|x). ∎"))

story.append(H1("Appendix B  Parameters and reproduction"))
rows = [["Quantity", "Value"],
        ["Sites n", "4 (16 inputs, 16 outputs)"],
        ["Base modification rate α, removal rate β", "1.0, 0.5"],
        ["Turnover κ; observation time t", "0.25 to 4; 0.1 to 16 (log grid)"],
        ["Crosstalk c", "0, 0.5, 1, 2"],
        ["Blahut–Arimoto tolerance; iterations", "1e−11; up to 3000"],
        ["Codebooks", "as listed in Table 3"],
        ["Learned decoder", "one hidden layer, 32 tanh units, 400 full-batch gradient steps, learning rate 0.05, seeds 3"],
        ["Random seed", "20261112"]]
story.append(TABLE(rows, [7.0, 9.0]))
story.append(P(
    "<b>Reproduction.</b> Run <font face='Mono'>python code/ptm_experiments.py</font>, then <font face='Mono'>python code/make_figures.py</font>, then "
    "<font face='Mono'>python code/build_paper.py</font>. The complete run takes a few minutes on one core."))

story.append(H1("Appendix C  Corrections and disclosure"))
for t in [
    "<b>Trapezoid function.</b> The first run failed because NumPy 2 removed np.trapz. It was replaced by np.trapezoid, and the run was repeated.",
    "<b>Codebook labels.</b> Initial labels for two codebooks reported a minimum distance of 1 where the computed distance is 2. The labels now use the computed distance.",
    "<b>Literature.</b> Claims attributed to Gunawardena (2012), DeepPCT (2024), DeepMVP (2025) and other work in the research note were not verified. "
    "Novelty claims are restricted to the calculations presented.",
    "<b>AI assistance.</b> The simulations, figures and manuscript text were produced with the assistance of Claude (Anthropic) under the direction "
    "of the authors, who define the research question and are responsible for the content. Xylia is the authors' AI research scientist. "
    "Competing interests: none declared. Funding: none."]:
    story.append(P(t))

story.append(H1("References"))
for r in [
    "Arimoto S (1972) An algorithm for computing the capacity of arbitrary discrete memoryless channels. IEEE Transactions on Information Theory 18: 14–20.",
    "Blahut RE (1972) Computation of channel capacity and rate-distortion functions. IEEE Transactions on Information Theory 18: 460–473.",
    "Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd ed. Wiley.",
    "Gillespie DT (1977) Exact stochastic simulation of coupled chemical reactions. Journal of Physical Chemistry 81: 2340–2361.",
    "Hopfield JJ (1974) Kinetic proofreading: a new mechanism for reducing errors in biosynthetic processes requiring high specificity. Proceedings of the National Academy of Sciences 71: 4135–4139.",
    "Landauer R (1961) Irreversibility and heat generation in the computing process. IBM Journal of Research and Development 5: 183–191.",
    "Ninio J (1975) Kinetic amplification of enzyme discrimination. Biochimie 57: 587–595.",
    "Seifert U (2012) Stochastic thermodynamics, fluctuation theorems and molecular machines. Reports on Progress in Physics 75: 126001.",
    "van Kampen NG (2007) Stochastic Processes in Physics and Chemistry, 3rd ed. Elsevier.",
    "Gunawardena J (2012) Post-translational modification: nature's escape from genetic imprisonment. Cited as in the research note; not verified here.",
]:
    story.append(P(r, small))


def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("Sans", 7); canvas.setFillColor(GREY)
    canvas.drawString(2.0 * cm, 1.2 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 12 Nov 2026")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"{doc.page}"); canvas.restoreState()


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2.0 * cm, rightMargin=2.0 * cm, topMargin=1.8 * cm, bottomMargin=1.9 * cm,
                            title="The Molecular Channel-Coding Theory of Life", author="Devanik Debnath; Xylia", subject="Preprint v1.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    from pypdf import PdfReader
    print("wrote", OUT, "pages", len(PdfReader(OUT).pages))
