#!/usr/bin/env python3
import json, os
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "paper", "Topological_Psychology_Cusp_Life_Space.pdf")
FD = "/usr/share/fonts/truetype/dejavu/"
for n, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"), ("Serif-I", "DejaVuSerif-Italic.ttf"),
              ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"), ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
              ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(n, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")
L = lambda n: json.load(open(os.path.join(RES, n)))
E1, E2, E3, E4, E5 = (L("E1_topology.json"), L("E2_hysteresis.json"), L("E3_kramers.json"),
                      L("E4_deformation.json"), L("E5_regulation.json"))
NAVY = colors.HexColor("#1f4e79"); GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")
body = ParagraphStyle("b", fontName="Serif", fontSize=9.2, leading=13.4, alignment=TA_JUSTIFY, spaceAfter=5.5)
small = ParagraphStyle("s", parent=body, fontSize=8, leading=10.8, spaceAfter=2.5)
cap = ParagraphStyle("c", parent=body, fontSize=7.8, leading=10.2, textColor=GREY, spaceBefore=2, spaceAfter=9)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=12.4, leading=16, textColor=NAVY, spaceBefore=12, spaceAfter=5)
h2 = ParagraphStyle("h2", fontName="Sans-B", fontSize=10, leading=13.5, textColor=NAVY, spaceBefore=7, spaceAfter=3)
title = ParagraphStyle("t", fontName="Sans-B", fontSize=16, leading=22, alignment=TA_CENTER, textColor=NAVY, spaceAfter=8)
sub = ParagraphStyle("st", fontName="Serif-I", fontSize=10, leading=14, alignment=TA_CENTER, textColor=GREY, spaceAfter=5)
ctr = ParagraphStyle("ctr", parent=body, alignment=TA_CENTER)
cell = ParagraphStyle("ce", fontName="Serif", fontSize=7.4, leading=9.4); cellb = ParagraphStyle("cb", parent=cell, fontName="Serif-B")
def P(t, s=body): return Paragraph(t, s)
def H1(t): return Paragraph(t, h1)
def H2(t): return Paragraph(t, h2)
def EQ(lines):
    t = Table([[Paragraph(l, ParagraphStyle("eq", fontName="Mono", fontSize=7.5, leading=10))] for l in lines], colWidths=[16 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
    return KeepTogether([t, Spacer(1, 5)])
def IMG(n, c, w=15.8):
    p = os.path.join(FIG, n + ".png"); iw, ih = ImageReader(p).getSize(); W = w * cm
    return KeepTogether([Image(p, width=W, height=W * ih / iw), Paragraph(c, cap)])
def TAB(rows, widths):
    d = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(d, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                           ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
    return t
def BOX(t):
    b = Table([[Paragraph(t, small)]], colWidths=[16 * cm])
    b.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return b
story = []
story += [Spacer(1, 0.4 * cm), P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 20 NOVEMBER 2026", ctr), Spacer(1, 0.3 * cm),
          P("Topological Psychology of the Affective Life Space", title),
          P("A cusp-catastrophe model of emotion as control parameters, with hysteresis, escape times, deformation rates and regulation", sub),
          P("Devanik Debnath · Xylia (AI research scientist, multi-agent research system)", ctr), Spacer(1, 0.25 * cm)]
story.append(BOX("<b>About the author.</b> Electronics and Communication Engineering graduate and independent AI researcher exploring how physical and mathematical structure can improve learning and modeling. Work spans gamma-ray burst reconstruction at the National Astronomical Observatory of Japan (NAOJ), physics-inspired signal classification, reinforcement learning, neural quantum-state methods, causal emergence, morphogenetic neural architectures, and computational artificial life. The research style combines algorithm design with explicit assumptions, code-based checks, and disclosure of unresolved limitations. <i>Devanik Debnath</i> is a Scientific Machine Learning and AI Architectures researcher; B.Tech, Electronics and Communication Engineering, National Institute of Technology Agartala (2026); Samsung Grade I Fellowship, Cohort 7; completed the IISc-led India Semiconductor Workforce Development Program (ISWDP) Level 1 evaluation at the 98.58th percentile. Links: github.com/Devanik21, orcid.org/0009-0001-8310-6921."))
story.append(Spacer(1, 0.3 * cm))
story.append(BOX("<b>Scope and boundary.</b> This is a mathematical model of an analogy. It is not a validated theory of emotion, it has no empirical data behind its parameters, and it must not be used to diagnose, predict or assess any person. The emotional coordinate is one-dimensional, the parameter-to-emotion mapping is a hypothesis, and every number comes from the simulations in <font face='Mono'>code/</font> with seed 20261120. Citations marked as unverified in Section 2.3 were not checked against their publishers."))
story.append(Spacer(1, 0.3 * cm))
story.append(P(
    "<b>Abstract.</b> Kurt Lewin proposed in 1936 that behaviour is a function of a psychological life space, a field of coexisting forces in which a person acts. We take that proposal literally as a mathematical object: the affective state of a person is a point in a space, emotions are control parameters that shape the landscape the point moves in, and some parameters change slowly while others are imposed quickly. Using Thom's cusp normal form, we model the affective coordinate under a potential V(x; a, b) = x⁴/4 + a x²/2 − b x, with tension a and provocation b. The bifurcation set 4a³ + 27b² = 0 partitions the parameter plane into a monostable and a bistable region. Crossing the fold produces a discontinuous jump, which we read as an outburst. We prove the bifurcation count, the width of the hysteresis loop, and the scaling of escape times, and we test each numerically. The bifurcation topology is reproduced at 99.99 per cent of grid points, with the three residual points lying on the fold curve or at the cusp point. The hysteresis width from simulation exceeds the analytic value by 6.6 per cent, and the excess is a rate-dependent delay. Mean escape times scale exponentially in inverse noise, with a fitted Kramers slope of {:.3f} against an analytic barrier of 0.25. Outburst timing depends on how fast provocation builds: the overshoot past the fold grows monotonically with ramp speed, and at the fastest ramp no outburst occurs within the window. A regulation experiment that reduces provocation gain shows no measurable change in the time spent in the high branch, which we report as a null result. The framework turns the vocabulary of field theory into testable dynamical statements, and it identifies the data that would be needed to test them on people.".format(E3["fitted_slope"]), body))
story.append(P("<b>Keywords:</b> Lewin · life space · cusp catastrophe · bifurcation · hysteresis · Kramers escape · stochastic dynamics · emotion regulation", small))
story.append(PageBreak())
story.append(H1("Contents"))
for t in ["1  Motivation: from life space to a mathematical space", "2  Background and the status of each source", "3  The model: emotions as control parameters",
          "4  Propositions and proofs", "5  Experiments", "6  Interpretation: what 'topological' means here",
          "7  Hypotheses that can be falsified with data", "8  Limitations and ethical boundary", "9  Open problems",
          "Appendix A  Derivations", "Appendix B  Parameters and reproduction", "References"]:
    story.append(P(t, small))
story.append(PageBreak())
story.append(H1("1  Motivation: from life space to a mathematical space"))
story.append(P(
    "Lewin's field theory begins from a claim about the unit of analysis. Behaviour is not caused by a person or by an environment taken separately. It is a function of the person together with the environment as it is experienced at the moment, which Lewin called the life space (Lewin 1936; Lewin 1951). In the notation that became standard, B = f(LSp): behaviour depends on the whole of the psychological field, including forces that are present but not visible, goals, barriers and valences. The 1936 book states the program directly: psychology needs the concepts of space and topology, not only of time, because the relations that matter are relations of regions and boundaries rather than of magnitudes alone."))
story.append(P(
    "A mathematical reading takes that instruction seriously. If the life space is a space, then an emotional state is a location in it. A location does not contain a feeling; it is a point whose motion is governed by a landscape. The landscape, in turn, is shaped by parameters: standing tensions that change slowly, and stimuli that change quickly. An outburst, on this reading, is not a mysterious event but a particular kind of motion in such a landscape, namely a discontinuous jump that occurs when a parameter crosses a threshold. The vocabulary of catastrophe theory (Thom 1975; Zeeman 1976) was built for exactly this kind of statement, and the stochastic extension through escape-rate theory (Kramers 1940) supplies the statistics."))
story.append(P(
    "The aim of this paper is narrow and falsifiable. We ask whether a one-coordinate cusp model with slow and fast parameters reproduces three qualitative features that are commonly described in the affective literature: path dependence (the same provocation can produce different states depending on history), sensitivity to the rate of provocation, and the effect of regulation as a change of gain. We do not claim that these features occur in people in the form the model predicts. We claim that the model makes precise predictions about them, and we identify what data would test those predictions."))
story.append(H1("2  Background and the status of each source"))
story.append(H2("2.1  Field theory and life space"))
story.append(P("Lewin's program, including the life-space concept and the claim that psychological explanation requires topological and vector concepts, is set out in the 1936 monograph Principles of Topological Psychology (McGraw-Hill, New York). Its translation by Fritz and Grace Heider and its publication details were checked against a bibliographic record. The later volume Field Theory in Social Science (Lewin 1951) develops the same program and was not re-checked for this paper."))
story.append(H2("2.2  Catastrophe theory and escape rates"))
story.append(P("The cusp normal form and its bifurcation set are standard results of singularity theory (Thom 1975; Zeeman 1976). The escape-rate formula for a particle over a potential barrier under thermal noise is due to Kramers (1940). The Langevin formulation and its numerical integration follow standard treatments (Gardiner 2009). These mathematical sources were not re-checked against their publishers for this paper, but the results we use are textbook results and we verified each of them numerically in Section 5."))
story.append(H2("2.3  Affect and regulation (cited for context, not re-verified)"))
story.append(P("The dimensional description of affect (valence, arousal and dominance) is due to Russell and Mehrabian (1977), and the circumplex model of affect to Russell (1980). The constructed-emotion account, in which emotion categories are assembled from more basic components, is developed in Barrett (2017). The process model of emotion regulation, including reappraisal as an antecedent-focused strategy, is due to Gross (1998). Critical transitions in complex systems, including early-warning signals before a fold, are reviewed by Scheffer et al. (2009). The status of each of these citations is listed in Table 1; none was re-checked against its publisher for this paper."))
story.append(H1("3  The model: emotions as control parameters"))
story.append(H2("3.1  State and parameters"))
story.append(P(
    "The state is a single affective intensity x: a coordinate of the life space in which high values correspond to an outburst-like state and low values to a settled one. The two control parameters have different roles. Tension a is an internal standing condition that changes slowly, and it is the parameter whose sign decides whether bistability is possible. Provocation b is an external or internal input that can change fast. Regulation enters as a multiplicative gain on provocation. The three kinds of parameter correspond to three timescales, a hierarchy that is central to the argument."))
story.append(EQ(["State:           x(t) ∈ ℝ      affective intensity (one coordinate of the life space)",
                 "Potential:       V(x; a, b) = x⁴/4 + (a/2) x² − b x",
                 "Dynamics:        dx = −∂V/∂x dt + √(2D) dW(t)     (Langevin, D = noise intensity)",
                 "Equilibria:      x³ + a x − b = 0",
                 "Bifurcation set: 4a³ + 27b² = 0   (cusp; bistable inside, where 4a³ + 27b² < 0)",
                 "Fold location:   b*(a) = 2(−a)^{3/2} / √27 for a < 0"]))
story.append(H2("3.2  Hypotheses mapping the model to the life space"))
story.append(P("The mapping from parameters to psychological quantities is a set of hypotheses. We list them so that each can be tested or rejected separately."))
story.append(EQ(["H1 (tension):      a is the standing reactivity of a person; more negative a means a larger repertoire of bistable states.",
                 "H2 (provocation):  b is the net external-plus-internal pressure at a moment; sustained pressure accumulates in b.",
                 "H3 (regulation):   reappraisal lowers the effective provocation gain: b_eff = γ·b with 0 < γ ≤ 1.",
                 "H4 (outburst):     a high-branch state is an outburst; the transition from low to high branch is the outburst event."]))
story.append(H1("4  Propositions and proofs"))
story.append(P("Each proposition below is stated for the model in Section 3. Proofs follow in Appendix A where they are not immediate."))
story.append(EQ(["Proposition 1 (bifurcation count). For a < 0 and |b| < b*(a), V has two minima and one saddle. For 4a³ + 27b² > 0 it has one minimum.",
                 "Proposition 2 (hysteresis width). Under a quasi-static sweep of b with a < 0 fixed, the upward jump occurs at b = +b*(a) and the downward jump at b = −b*(a). The loop width is 2b*(a).",
                 "Proposition 3 (Kramers scaling). Inside the bistable region, the mean first-passage time from one minimum over the saddle satisfies ln τ ≈ ΔV/D + O(1), with ΔV the barrier height.",
                 "Proposition 4 (deformation delay). For a provocation that grows linearly with speed s, the jump is delayed past the fold by an overshoot that increases with s. Numerical check in Section 5.4."]))
story.append(P("<b>Proof of Proposition 1.</b> The equilibria are the real roots of the cubic x³ + a x − b. Its discriminant is −4a³ − 27b². A cubic with negative discriminant has one real root; a positive discriminant gives three real roots. Stability is decided by V″ = 3x² + a, which is positive at the outer roots when a < 0 and |b| < b*. This gives two minima and one saddle inside the cusp, and one minimum outside. ∎"))
story.append(P("<b>Proof of Proposition 2.</b> On the high branch, the upper root x₊(b) exists while b > −b*(a) and is lost at b = b*(a), where the two roots merge with the saddle. Along the sweep from low to high, the state remains on the low branch until the low minimum disappears at b*. Symmetrically the downward sweep loses the high minimum at −b*. Therefore the two jumps are at ±b* and the loop width is 2b*. ∎"))
story.append(P("<b>Proof sketch of Proposition 3.</b> Standard Kramers theory for the one-dimensional Langevin equation gives an escape rate proportional to exp(−ΔV/D), with ΔV the difference between the potential at the saddle and at the minimum. For the potential of Section 3 at a = −1 and b = 0, ΔV = V(0) − V(1) = 1/4. The prefactor is O(1) in D. The statement is asymptotic in ΔV/D, and Section 5.3 reports how far the finite-noise numerics depart from it."))
story.append(P("<b>Status of Proposition 4.</b> The growth of the overshoot with ramp speed is a known feature of slow passage through a fold in the bifurcation literature, where the delay scales with a power of the sweep rate. We do not re-derive that exponent here. Section 5.4 reports the exponent we measure over the speeds we used, and we treat the general exponent as a conjecture."))
story.append(H1("5  Experiments"))
story.append(P("All experiments use one random seed (20261120) and the parameters in Appendix B. Each result is reported with the sample it rests on. Where an experiment was run once, we say so."))
story.append(H2("5.1  Bifurcation topology (E1)"))
story.append(IMG("fig02_cusp_bifurcation", "<b>Figure 1.</b> (a) The cusp bifurcation set in the (a, b) plane. Inside the shaded wedge there are two minima. (b) Equilibria against provocation at a = −1: stable branches solid, the saddle dashed. The jump at b* is the outburst."))
story.append(IMG("fig03_minima_count_map", "<b>Figure 2.</b> Number of stable states on a 161 × 161 grid over the (a, b) plane. The count matches the analytic prediction of Proposition 1 at all but three grid points."))
rows = [["Quantity", "Value"],
        ["Grid points", f"{E1['points']:,}"],
        ["Agreement with analytic cusp set", f"{100*E1['agreement']:.3f} %"],
        ["Stable-state count histogram", ", ".join(f"{k} minima: {v}" for k, v in E1['minima_count_histogram'].items())],
        ["Residual disagreements", "; ".join(f"(a={a:+.2f}, b={b:+.2f}): counted {k}, predicted {p}" for a, b, k, p in E1['first_disagreements'][:3])]]
story.append(TAB(rows, [5.2, 10.8])); story.append(P("<b>Table 2.</b> Bifurcation-topology check. The three residual points are on the fold curve (4a³ + 27b² = 0 exactly at (−0.75, ±0.25)) or at the cusp point (0, 0), where the count is degenerate.", cap))
story.append(H2("5.2  Hysteresis (E2)"))
story.append(IMG("fig04_hysteresis", "<b>Figure 3.</b> Upward and downward jumps in a slow sweep of provocation at a = −1, with the analytic folds dotted. One stochastic realisation at D = 10⁻⁴."))
story.append(P(f"<b>Result.</b> The upward jump is at b = {E2['b_jump_up_sim']:.4f} against the analytic fold {E2['b_fold_analytic']:.4f}, and the downward jump at {E2['b_jump_down_sim']:.4f} against −{E2['b_fold_analytic']:.4f}. The simulated loop width is {E2['hysteresis_width_sim']:.4f} against {E2['hysteresis_width_analytic']:.4f}, an excess of about {100*(E2['hysteresis_width_sim']/E2['hysteresis_width_analytic']-1):.1f} per cent. The excess is the delay of the jump past the fold, which Section 5.4 examines. The jump locations are a single realisation, so the figures are indicative, not precise."))
story.append(H2("5.3  Escape times and the Kramers scaling (E3)"))
rows = [["Noise D", "1/D", "Mean first-passage time", "Censored fraction"]]
for r in E3["rows"]:
    rows.append([f"{r['D']:.3f}", f"{r['inv_D']:.2f}", f"{r['mfpt']:.2f}", f"{r['censored_fraction']:.2f}"])
story.append(TAB(rows, [3.6, 3.0, 5.0, 4.4])); story.append(P("<b>Table 3.</b> Mean first-passage times over the barrier, 200 replicates per noise level, a = −1, b = 0. Each replicate runs until the state crosses x = −0.2.", cap))
story.append(IMG("fig05_kramers", "<b>Figure 4.</b> ln of mean first-passage time against 1/D. The slope estimates the barrier height; the analytic barrier is 0.25."))
story.append(P(f"<b>Result.</b> The fitted slope is {E3['fitted_slope']:.3f} against the analytic barrier {E3['barrier_analytic']:.2f}, a deviation of {100*E3['relative_error']:.1f} per cent. The deviation is the expected finite-noise correction. The barrier-to-noise ratio ΔV/D ranges only from about 1 to 2.5 over this range, which is far from the asymptotic regime in which Proposition 3 holds. The result supports exponential scaling in 1/D with the correct order of magnitude. It does not establish the barrier to better than about 15 per cent."))
story.append(H2("5.4  Deformation rate: outbursts depend on how fast provocation builds (E4)"))
rows = [["Ramp speed s", "Time of jump", "Provocation at jump", "Overshoot past b*"]]
for r in E4["rows"]:
    if r["t_jump"] == r["t_jump"]:
        rows.append([f"{r['ramp_speed']:.4f}", f"{r['t_jump']:.1f}", f"{r['b_jump']:.4f}", f"{r['overshoot_past_fold']:.4f}"])
    else:
        rows.append([f"{r['ramp_speed']:.4f}", "no jump in window", "—", "censored"])
story.append(TAB(rows, [3.6, 4.2, 4.2, 4.0])); story.append(P(f"<b>Table 4.</b> Outburst timing against the speed of provocation build-up. Fold at b* = {E4['b_fold']:.4f}. One realisation per speed, D = 10⁻⁴.", cap))
story.append(IMG("fig06_deformation_rate", "<b>Figure 5.</b> (a) Overshoot past the fold against ramp speed, log–log. Dotted lines mark speeds with no outburst within the window. (b) Time of outburst by speed."))
ok = [r for r in E4["rows"] if r["t_jump"] == r["t_jump"]]
import math
expo = math.log(ok[-1]["overshoot_past_fold"] / ok[0]["overshoot_past_fold"]) / math.log(ok[-1]["ramp_speed"] / ok[0]["ramp_speed"])
story.append(P(f"<b>Result.</b> Over the three speeds that produced an outburst, the overshoot grows with the ramp speed with a log–log exponent of about {expo:.2f}. At the fastest speed, s = 0.032, the state is still on the low branch when the window closes at b = 1.5 b*. That is the strongest qualitative prediction of the model: a faster build-up does not produce an earlier outburst, it can delay or prevent one within a fixed time window. The paper treats this as a model prediction to test, and as a single-realisation result at this stage. The exponent is a conjecture (Proposition 4) and is not established by three points."))
story.append(H2("5.5  Regulation as provocation gain (E5)"))
rows = [["Gain factor γ", "Fraction of time in high branch"]]
for r in E5["rows"]:
    rows.append([f"{r['gamma']:.1f}", f"{r['fraction_time_high_branch']:.4f}"])
story.append(TAB(rows, [6.0, 10.0])); story.append(P("<b>Table 5.</b> Fraction of time in the high branch under a fixed oscillating provocation schedule, one run per gain, D = 0.012, a = −0.8, T = 3000.", cap))
story.append(IMG("fig07_regulation", "<b>Figure 6.</b> Fraction of time in the high branch against reappraisal gain. The variation is small."))
story.append(P("<b>Result (null).</b> Reducing provocation gain from 1.0 to 0.4 changes the time spent in the high branch by about one percentage point, and the ordering is not monotone. Under the schedule used, provocation swings far enough that both branches are visited at every gain, so a gain reduction shifts the timing of transitions rather than their frequency. Regulation in this model should therefore show up as a change in transition timing and in hysteresis width, not in occupancy. We did not test those quantities, and we do not claim that reappraisal has no effect. The single run per gain is also too little to resolve a difference of this size."))
story.append(H1("6  Interpretation: what 'topological' means here"))
story.append(P(
    "The word topological has a specific meaning in this paper and is easy to misread. We do not measure the topology of brain tissue, and we do not claim that the life space is a manifold with an intrinsic geometry that people can inspect. The topology is the qualitative structure of the set of equilibria as parameters vary: how many stable states exist, where they are created and annihilated, and how the branches connect. That structure is invariant under smooth changes of coordinates and parameters, which is the sense in which the bifurcation set is topological. Propositions 1 and 2 are statements of this kind."))
story.append(P(
    "The 'universe inside a human' metaphor becomes precise in one way. The parameters play the role of coordinates on a space of possible psychological situations, and the bifurcation set is the boundary between regions of that space in which the person has one settled state and regions in which the same circumstances permit two. A life that is repeatedly pushed into the bistable region is, in this model, a life with a larger set of available states and a larger risk of abrupt transitions. That is a claim about structure, and it can be wrong."))
story.append(P(
    "Emotions as parameters have a particular consequence. A parameter that changes slowly sets the shape of the landscape for long periods, and a parameter that changes quickly drives motion on that landscape. Anger, in the model, is not a single quantity. It is the joint state of a landscape deformed by standing tension and a provocation that crosses a fold. Two people with the same provocation can therefore differ in outcome, because their tension differs, and the same person can differ across days, because the tension drifts."))
story.append(H1("7  Hypotheses that can be falsified with data"))
story.append(P("The following predictions follow from the model and would be tested on people with repeated measurement. None has been tested here. Each lists what would count against it."))
rows = [["#", "Prediction", "Required data", "Falsified if"],
 ["P1", "Path dependence: identical provocation sequences starting from different settled states diverge in outcome in a way the cusp predicts.", "repeated affect ratings under matched provocation", "outcomes depend only on the current provocation"],
 ["P2", "Hysteresis: the provocation level at escalation exceeds the level at de-escalation by about 2b*.", "time-stamped escalation and recovery events", "no systematic gap between escalation and recovery thresholds"],
 ["P3", "Rate dependence: slower build-up of provocation delays escalation past the fold, and very fast build-up can prevent an escalation within a window.", "provocation time courses with known build-up rates", "escalation timing does not depend on build-up rate"],
 ["P4", "Gain: reappraisal reduces the effective provocation gain and so shifts escalation thresholds.", "regulation-strategy labels with threshold measures", "no threshold shift under reappraisal"],
 ["P5", "Escape: time to a high-arousal episode grows exponentially in inverse variability of the affective signal.", "episode waiting times and signal variance", "waiting times do not scale with the predicted exponential dependence"]]
story.append(TAB(rows, [0.9, 6.2, 4.3, 4.6])); story.append(P("<b>Table 6.</b> Falsifiable predictions, the data each needs, and the outcome that would count against it.", cap))
story.append(P("Any test must be preregistered, must separate the slow and fast parameters through design, and must report the outcome whichever way it falls. Ecological momentary assessment designs, in which people report affect repeatedly in their own environments, are the natural source of such data, but the appropriate measurement and ethical framework depends on the population and must be set before collection."))
story.append(H1("8  Limitations and ethical boundary"))
for t in [
 "<b>One dimension.</b> Affect is multidimensional. The model collapses valence, arousal and control into one coordinate and cannot represent mixed or opposing emotions in a single state.",
 "<b>No data.</b> None of the parameters is fitted to any measurement. The results show that the model behaves as its mathematics predicts. They do not show that people behave this way.",
 "<b>Single realisations.</b> Hysteresis, deformation and regulation results rest on one stochastic run each. They are indicative only.",
 "<b>Asymptotic statements.</b> Kramers scaling holds asymptotically in the barrier-to-noise ratio, and the numerics sit outside that regime.",
 "<b>Mapping.</b> The identification of a with tension, b with provocation and the high branch with outburst is a hypothesis. Other identifications are possible and would give different predictions.",
 "<b>Ethical boundary.</b> The model must not be used to classify, diagnose or predict the behaviour of any individual, or to assess risk of violence. Its value is as a structure for stating and testing hypotheses about populations and processes, under appropriate ethical oversight."]:
    story.append(P(t))
story.append(H1("9  Open problems"))
for t in [
 "<b>Multidimensional extension.</b> Extend the state to a vector of valence, arousal and control, and determine which bifurcation sets persist.",
 "<b>Delay constant.</b> Establish the exponent of the overshoot against ramp speed analytically, and test whether the exponent is universal across the family of potentials considered.",
 "<b>Regulation as timing.</b> Quantify the effect of gain reduction on transition timing and hysteresis width, which the present occupancy measure does not capture.",
 "<b>Inference.</b> Given repeated affect measurements, estimate the tension and provocation time courses and test the cusp against a non-cusp alternative with the same number of parameters."]:
    story.append(P(t))
story.append(H1("Appendix A  Derivations"))
story.append(EQ(["Discriminant. For x³ + a x − b = 0 the discriminant is Δ = −4a³ − 27b². Δ < 0 gives one real root.",
                 "Fold. Δ = 0 gives b = ±2(−a)^{3/2}/√27 for a < 0; this is the fold b*(a).",
                 "Barrier at a = −1. V(x) = x⁴/4 − x²/2 has minima at ±1, saddle at 0, and V(0) − V(±1) = 1/4.",
                 "Hysteresis loop width. Jumps at ±b*, so the width is 2b* = 2(−a)^{3/2}·2/√27 for a < 0."]))
story.append(H1("Appendix B  Parameters and reproduction"))
rows = [["Experiment", "Parameters", "Sampling"],
 ["E1 topology", "a, b ∈ [−2, 2], 161 × 161 grid", "exact roots"],
 ["E2 hysteresis", "a = −1, D = 10⁻⁴, dt = 0.01, sweep to ±1.5 b*, T_half = 900", "one realisation"],
 ["E3 Kramers", "a = −1, b = 0, D ∈ {0.10 … 0.25}, dt = 0.01, threshold x = −0.2", "200 replicates per D"],
 ["E4 deformation", "a = −1, D = 10⁻⁴, speeds 0.0005 … 0.032, end at 1.5 b*", "one realisation per speed"],
 ["E5 regulation", "a = −0.8, D = 0.012, dt = 0.01, T = 3000, γ ∈ {1, 0.8, 0.6, 0.4}", "one run per γ"]]
story.append(TAB(rows, [3.4, 9.6, 3.0])); story.append(P("<b>Table 7.</b> Experimental parameters, seed 20261120.", cap))
story.append(P("<b>Reproduction.</b> Run <font face='Mono'>python code/experiments.py</font>, then <font face='Mono'>python code/make_figures.py</font>, then <font face='Mono'>python code/build_paper.py</font>. The complete run takes several minutes on one core."))
story.append(H1("References"))
rows = [["Reference", "Status for this paper"],
 ["Lewin K (1936) Principles of Topological Psychology. McGraw-Hill.", "publication details checked against a bibliographic record"],
 ["Lewin K (1951) Field Theory in Social Science. Harper.", "cited for context; not re-checked"],
 ["Thom R (1975) Structural Stability and Morphogenesis. Benjamin.", "cited for the cusp normal form; not re-checked"],
 ["Zeeman EC (1976) Catastrophe theory. Scientific American 234(4): 65–83.", "cited for context; not re-checked"],
 ["Kramers HA (1940) Brownian motion in a field of force and the diffusion model of chemical reactions. Physica 7: 284–304.", "cited for the escape-rate formula; not re-checked"],
 ["Gardiner C (2009) Stochastic Methods, 4th ed. Springer.", "cited for numerical methods; not re-checked"],
 ["Russell JA, Mehrabian A (1977) Evidence for a three-factor theory of emotions. J Res Pers 11: 273–294.", "not re-checked"],
 ["Russell JA (1980) A circumplex model of affect. J Pers Soc Psychol 39: 1161–1178.", "not re-checked"],
 ["Barrett LF (2017) How Emotions Are Made. Houghton Mifflin Harcourt.", "not re-checked"],
 ["Gross JJ (1998) The emerging field of emotion regulation. Rev Gen Psych 2: 271–299.", "not re-checked"],
 ["Scheffer M et al. (2009) Early-warning signals for critical transitions. Nature 461: 53–59.", "not re-checked"]]
story.append(TAB(rows, [11.0, 5.0])); story.append(P("<b>Table 8.</b> References and their verification status. The authors have not re-verified these against publisher pages for this paper.", cap))
def footer(c, d):
    c.saveState(); c.setFont("Sans", 7); c.setFillColor(GREY)
    c.drawString(2 * cm, 1.2 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 20 Nov 2026")
    c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"{d.page}"); c.restoreState()
if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.9 * cm,
                            title="Topological Psychology of the Affective Life Space", author="Devanik Debnath; Xylia", subject="Preprint v1.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    from pypdf import PdfReader
    print("wrote", OUT, "pages", len(PdfReader(OUT).pages))
