# Topological Psychology of the Affective Life Space (v1.0, 20 November 2026)

Authors: Devanik Debnath and Xylia (AI research scientist, multi-agent research system).
Status: preprint, not peer reviewed. A mathematical model of an analogy. No data behind the parameters.
Not for diagnosis, prediction or assessment of any individual.

## Contents
- paper/Topological_Psychology_Cusp_Life_Space.pdf: 11-page paper.
- code/cusp_affect.py: the potential, equilibria, fold locations and Langevin integrator.
- code/experiments.py: experiments E1 to E5 (seed 20261120).
- code/make_figures.py and code/build_paper.py: figures and PDF.
- results/: JSON output of each experiment and the run log.
- figures/: all figures as PNG and SVG.

## Results in brief
- E1: stable-state count matches the cusp set at 99.99 per cent of 161 x 161 grid points. The three residual points lie on the fold or at the cusp point.
- E2: hysteresis loop width 0.820 in simulation against 0.770 analytic; the excess is a rate-dependent delay.
- E3: Kramers scaling of mean first-passage times in 1/D; fitted slope 0.287 against the analytic barrier 0.25.
- E4: overshoot past the fold grows with ramp speed (log-log exponent about 0.77 over three speeds); at the fastest speed no outburst occurs within the window.
- E5: regulation as provocation gain shows no measurable change in the time spent in the high branch (null, single run per gain).

## Caveats
- Single realisations for E2, E4 and E5. E3 uses 200 replicates per noise level.
- The Kramers slope is 15 per cent from the analytic barrier at the barrier-to-noise ratios used.
- The exponent in E4 is a conjecture from three points, not an established law.
- Citations in the paper's reference table were not re-verified against publisher pages, except Lewin (1936) against a bibliographic record.

## Reproduce
pip install numpy matplotlib reportlab pypdf
python code/experiments.py
python code/make_figures.py
python code/build_paper.py
