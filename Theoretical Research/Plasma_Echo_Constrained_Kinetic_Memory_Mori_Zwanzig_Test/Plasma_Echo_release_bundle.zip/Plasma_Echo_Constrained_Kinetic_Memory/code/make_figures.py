#!/usr/bin/env python3
import json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures"); os.makedirs(FIG, exist_ok=True)
sys.path.insert(0, HERE)
import vlasov as V
from echo_experiments import run, K0, L, DT, echo_features
C1, C2, C3, C4 = "#1f4e79", "#c0504d", "#4f8f3a", "#8064a2"
plt.rcParams.update({"font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9, "legend.fontsize": 7.5, "figure.dpi": 110})


def save(fig, name):
    fig.savefig(os.path.join(FIG, name + ".png"), dpi=160, bbox_inches="tight")
    fig.savefig(os.path.join(FIG, name + ".svg"), bbox_inches="tight")
    plt.close(fig)


E1 = json.load(open(os.path.join(RES, "E1_validation.json")))
E2 = json.load(open(os.path.join(RES, "E2_echo_scan.json")))
E3 = json.load(open(os.path.join(RES, "E3_collisions.json")))
E4 = json.load(open(os.path.join(RES, "E4_memory_test.json")))

# fig01: validation
s = V.Vlasov(L, 64, 6.0, 256)
f = (1 + 0.01 * np.cos(K0 * s.x))[:, None] * s.fM[None, :]
t, amp = [], []
for n in range(int(40 / DT)):
    t.append(n * DT); amp.append(abs(s.mode(f, 1))); f = s.step(f, DT)
t = np.array(t); amp = np.array(amp)
f = (1 + 0.01 * np.cos(K0 * s.x))[:, None] * s.fM[None, :]
c20 = s.C2(f); c2 = []
for n in range(int(40 / DT)):
    c2.append(s.C2(f) / c20 - 1); f = s.step(f, DT)
c2 = np.array(c2)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.9))
ax[0].semilogy(t, amp, color=C1, lw=1.0, label="|ρ_k(t)|, k = 0.5")
ax[0].semilogy(t, amp[0] * np.exp(-E1["gamma_theory_k0.5"] * t), "--", color="grey", lw=0.9, label="γ = 0.1533 (theory)")
ax[0].set_xlabel("time"); ax[0].set_ylabel("mode amplitude")
ax[0].set_title(f"(a) Landau damping, fitted γ = {E1['gamma_fitted']:.4f}"); ax[0].legend()
ax[1].plot(t, c2, color=C2, lw=1.0)
ax[1].set_xlabel("time")
ax[1].set_title(f"(b) C₂ relative drift ≤ {E1['C2_max_relative_drift_40']:.1e}")
ax[1].set_ylim(-0.002, 0.002)
fig.tight_layout(); save(fig, "fig01_validation")

# fig02: echo timeline for tau=3, eps=0.3
A = run(3.0, 0.3, 11.0, second=True); B = run(3.0, 0.3, 11.0, second=False)
D = np.abs(A["echo_mode"] - B["echo_mode"])
fig, ax = plt.subplots(figsize=(6.2, 2.9))
ax.plot(A["t"], D, color=C1, lw=1.2, label="echo amplitude |ρ₁(A) − ρ₁(B)|")
ax.axvline(3.0, color="grey", ls=":", lw=0.9, label="pulse 2, τ = 3")
ax.axvline(6.0, color=C2, ls="--", lw=0.9, label="naive echo time 2τ = 6")
pk = A["t"][np.argmax(D * (A["t"] > 3.3))]
ax.axvline(pk, color=C3, ls="-", lw=0.9, label=f"measured peak {pk:.2f}")
ax.set_xlabel("time"); ax.set_ylabel("echo amplitude")
ax.set_title("Two-pulse density echo, mode m₂ − m₁ = 1")
ax.legend(fontsize=6.8)
fig.tight_layout(); save(fig, "fig02_echo_timeline")

# fig03: timing offset vs tau
rows = E2["rows"]
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.9))
for eps, col in zip(E2["epss"], [C1, C3, C4, C2, "#444444"]):
    rr = [r for r in rows if r["eps"] == eps]
    ax[0].plot([r["tau"] for r in rr], [r["offset_from_2tau"] for r in rr], "o-", ms=3, color=col, label=f"ε = {eps}")
ax[0].axhline(0, color="k", lw=0.6)
ax[0].set_xlabel("pulse separation τ"); ax[0].set_ylabel("t_echo − 2τ")
ax[0].set_title("(a) Echo timing relative to 2τ"); ax[0].legend(fontsize=6.3)
rr = [r for r in rows if r["tau"] == 3.0]
ax[1].loglog([r["eps"] for r in rr], [r["amp"] for r in rr], "o", color=C1)
e = np.array([r["eps"] for r in rr]); a = np.array([r["amp"] for r in rr])
ax[1].loglog(e, a[0] * (e / e[0]) ** 2, "--", color="grey", lw=0.9, label="slope 2")
ax[1].set_xlabel("pulse amplitude ε"); ax[1].set_ylabel("echo amplitude")
ax[1].set_title(f"(b) Amplitude scaling, fitted slope {E2['eps_scaling_slope_tau3']:.2f}"); ax[1].legend()
fig.tight_layout(); save(fig, "fig03_echo_timing_scaling")

# fig04: collisions
rr = E3["rows"]
fig, ax = plt.subplots(figsize=(4.8, 2.9))
nu = [r["nu"] for r in rr]; ratio = [r["amp_ratio"] for r in rr]
ax.plot(nu, ratio, "o-", color=C2)
ax.set_xlabel("collision rate ν (BGK)"); ax.set_ylabel("echo amplitude / collisionless")
ax.set_title("Collisional suppression of the echo (τ = 3, ε = 0.3)")
fig.tight_layout(); save(fig, "fig04_collisional_suppression")

# fig05: memory comparison
rows = E4["rows"]
cads = E4["cadences"]
fig, ax = plt.subplots(figsize=(6.6, 2.9))
w = 0.38
xs = np.arange(len(cads))
for j, (model, col) in enumerate([("memoryless_p1", C2), ("memory_p", C1)]):
    vals = []; errs = []
    for c in cads:
        v = [r["nrmse_echo_window"] for r in rows if r["cadence"] == c and r["model"] == model]
        vals.append(np.mean(v)); errs.append(np.std(v))
    ax.bar(xs + (j - 0.5) * w, vals, w, yerr=errs, color=col, capsize=2, label=model)
ax.set_xticks(xs); ax.set_xticklabels([f"Δ = {c}" for c in cads])
ax.set_ylabel("one-step NRMSE, echo window (mean over held-out cases)")
ax.set_title("Memory versus memoryless closure, held-out cases")
ax.legend()
fig.tight_layout(); save(fig, "fig05_memory_vs_closure")
print("figures written")
