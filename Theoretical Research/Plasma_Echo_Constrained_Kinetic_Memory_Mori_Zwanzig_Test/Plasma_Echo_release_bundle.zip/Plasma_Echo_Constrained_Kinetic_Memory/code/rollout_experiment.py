#!/usr/bin/env python3
"""E5: autonomous multi-step rollout of the echo window. Each model is fitted on the
collisionless training cases, given the true history up to t0 = tau + 0.5, and then runs
forward on its own predictions until t = 2 tau + 3. Compared with a persistence baseline
(hold the last observed value) and with the memoryless closure. Linear models only."""
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
sys.path.insert(0, HERE)
from echo_experiments import DT
from memory_experiment import TRAIN, TEST, CADENCES, T_MEM, series, fit


def rollout(coef, hist, p, n_steps):
    buf = list(hist[-p:])
    out = []
    for _ in range(n_steps):
        past = np.array(buf[::-1])
        x = np.concatenate([[1.0], past.real, past.imag])
        pr = x @ coef
        z = pr[0] + 1j * pr[1]
        out.append(z)
        buf = buf[1:] + [z]
    return np.array(out)


def run_E5():
    tr = [series(*c) for c in TRAIN]
    te = {c: series(*c) for c in TEST}
    rows = []
    for cad in CADENCES:
        stride = int(round(cad / DT))
        p_mem = max(2, int(round(T_MEM / cad)))
        fits = {"memoryless_p1": (1, fit([z[::stride] for _, z in tr], 1)),
                "memory_p": (p_mem, fit([z[::stride] for _, z in tr], p_mem))}
        for c in TEST:
            t, z = te[c]
            ts, zs = t[::stride], z[::stride]
            tau = c[0]
            i0 = max(int(np.argmax(ts >= tau + 0.5)), p_mem)
            i1 = int(np.argmax(ts >= 2 * tau + 3.0))
            if i1 <= i0:
                i1 = len(ts)
            truth = zs[i0:i1]
            scale = np.sqrt(np.mean(np.abs(truth) ** 2)) + 1e-12
            for name, (p, coef) in fits.items():
                hist = zs[i0 - p:i0]
                pred = rollout(coef, hist, p, len(truth))
                nr = float(np.sqrt(np.mean(np.abs(pred - truth) ** 2)) / scale)
                rows.append({"cadence": cad, "case": list(c), "model": name, "p": p, "rollout_nrmse": nr})
            pers = np.repeat(zs[i0 - 1], len(truth))
            rows.append({"cadence": cad, "case": list(c), "model": "persistence", "p": 0,
                         "rollout_nrmse": float(np.sqrt(np.mean(np.abs(pers - truth) ** 2)) / scale)})
    return rows


if __name__ == "__main__":
    rows = run_E5()
    json.dump({"rows": rows, "cadences": CADENCES, "test": TEST}, open(os.path.join(RES, "E5_rollout.json"), "w"), indent=2)
    for r in rows:
        print(r["cadence"], r["case"], r["model"], round(r["rollout_nrmse"], 3), flush=True)
