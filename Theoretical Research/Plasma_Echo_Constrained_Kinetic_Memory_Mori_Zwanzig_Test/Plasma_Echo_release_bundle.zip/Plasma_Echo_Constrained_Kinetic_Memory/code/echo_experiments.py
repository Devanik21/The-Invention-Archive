#!/usr/bin/env python3
"""Plasma-echo experiments E1-E3 (Vlasov-Poisson, 1D1V, normalised units).
E1: Landau damping validation and invariant C2 drift.
E2: two-pulse density echo: peak time and amplitude versus separation tau and pulse amplitude eps.
E3: echo suppression by weak BGK collisions nu.
Writes results/*.json. Abstract numerical study; no experimental claim."""
import json, os, sys
import numpy as np
from scipy.signal import find_peaks
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); os.makedirs(RES, exist_ok=True)
sys.path.insert(0, HERE)
import vlasov as V

K0 = 0.5
L = 2 * np.pi / K0
DT = 0.05


def run(tau, eps, T_end, nu=0.0, Nv=256, vmax=6.0, nx=64, m1=1, m2=2, second=True, record_c2=False):
    s = V.Vlasov(L, nx, vmax, Nv)
    f = np.tile(s.fM, (s.Nx, 1))
    kx = lambda m: K0 * m * s.x
    f = f * (1 + eps * np.cos(kx(m1)))[:, None]
    times = np.arange(0, T_end, DT)
    mode_echo, rho1, c2 = [], [], []
    pulsed = False
    c20 = s.C2(f)
    for t in times:
        if second and (not pulsed) and t >= tau:
            f = f * (1 + eps * np.cos(kx(m2)))[:, None]
            pulsed = True
        mode_echo.append(np.fft.fft(f.sum(axis=1) * s.dv)[m2 - m1] / s.Nx)
        rho1.append(np.fft.fft(f.sum(axis=1) * s.dv)[m1] / s.Nx)
        if record_c2:
            c2.append(s.C2(f) / c20 - 1)
        f = s.step(f, DT, nu)
    out = {"t": times, "echo_mode": np.array(mode_echo), "rho1": np.array(rho1)}
    if record_c2:
        out["c2_rel_drift"] = np.array(c2)
    return out


def echo_features(tau, eps, nu=0.0, **kw):
    T_end = 2 * tau + 5
    A = run(tau, eps, T_end, nu=nu, second=True, **kw)
    B = run(tau, eps, T_end, nu=nu, second=False, **kw)
    t = A["t"]
    D = np.abs(A["echo_mode"] - B["echo_mode"])
    sel = t > tau + 0.3
    pk = int(np.argmax(D * sel))
    return {"t_echo": float(t[pk]), "amp": float(D[pk]), "pre_pulse_mode": float(np.abs(A["rho1"][t < tau]).max())}


def E1_validation():
    s = V.Vlasov(L, 64, 6.0, 256)
    alpha = 0.01
    f = (1 + alpha * np.cos(K0 * s.x))[:, None] * s.fM[None, :]
    c20 = s.C2(f)
    t, amp, c2 = [], [], []
    for n in range(int(40 / DT)):
        t.append(n * DT)
        amp.append(abs(s.mode(f, 1)))
        c2.append(s.C2(f) / c20 - 1)
        f = s.step(f, DT)
    t = np.array(t); amp = np.array(amp)
    p, _ = find_peaks(amp)
    sel = (t[p] > 5) & (t[p] < 25)
    gam = -float(np.polyfit(t[p][sel], np.log(amp[p][sel]), 1)[0])
    return {"gamma_fitted": gam, "gamma_theory_k0.5": 0.1533,
            "relative_error": abs(gam - 0.1533) / 0.1533,
            "C2_max_relative_drift_40": float(np.max(np.abs(c2)))}


def E2_echo_scan():
    taus = [2.0, 2.5, 3.0, 3.5, 4.0, 5.0]
    epss = [0.1, 0.2, 0.3, 0.45, 0.6]
    rows = []
    for tau in taus:
        for eps in epss:
            r = echo_features(tau, eps)
            rows.append({"tau": tau, "eps": eps, **r, "offset_from_2tau": r["t_echo"] - 2 * tau})
    # eps scaling at fixed tau
    tau = 3.0
    amps = [r["amp"] for r in rows if r["tau"] == tau]
    slope = float(np.polyfit(np.log(epss), np.log(amps), 1)[0])
    return {"rows": rows, "taus": taus, "epss": epss, "eps_scaling_slope_tau3": slope}


def E3_collisions():
    nus = [0.0, 0.005, 0.01, 0.02, 0.05, 0.1]
    rows = []
    for nu in nus:
        r = echo_features(3.0, 0.3, nu=nu)
        rows.append({"nu": nu, **r})
    base = rows[0]["amp"]
    for r in rows:
        r["amp_ratio"] = r["amp"] / base
    return {"rows": rows}


def main():
    E1 = E1_validation()
    print("E1", E1, flush=True)
    json.dump(E1, open(os.path.join(RES, "E1_validation.json"), "w"), indent=2)
    E2 = E2_echo_scan()
    print("E2 slope", E2["eps_scaling_slope_tau3"], flush=True)
    json.dump(E2, open(os.path.join(RES, "E2_echo_scan.json"), "w"), indent=2)
    E3 = E3_collisions()
    print("E3", [(r["nu"], round(r["amp_ratio"], 3), round(r["t_echo"], 2)) for r in E3["rows"]], flush=True)
    json.dump(E3, open(os.path.join(RES, "E3_collisions.json"), "w"), indent=2)


if __name__ == "__main__":
    main()
