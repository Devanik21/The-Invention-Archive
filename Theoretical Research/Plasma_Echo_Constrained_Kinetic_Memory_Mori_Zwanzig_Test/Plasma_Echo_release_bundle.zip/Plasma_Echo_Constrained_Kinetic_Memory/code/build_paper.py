#!/usr/bin/env python3
"""Builds the plasma-echo research PDF from results/ and figures/."""
import json, os
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "paper", "Plasma_Echo_Constrained_Kinetic_Memory.pdf")
FD = "/usr/share/fonts/truetype/dejavu/"
for name, fn in [("Serif", "DejaVuSerif.ttf"), ("Serif-B", "DejaVuSerif-Bold.ttf"), ("Serif-I", "DejaVuSerif-Italic.ttf"),
                 ("Serif-BI", "DejaVuSerif-BoldItalic.ttf"), ("Sans", "DejaVuSans.ttf"), ("Sans-B", "DejaVuSans-Bold.ttf"),
                 ("Mono", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, FD + fn))
registerFontFamily("Serif", normal="Serif", bold="Serif-B", italic="Serif-I", boldItalic="Serif-BI")
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")

E1 = json.load(open(os.path.join(RES, "E1_validation.json")))
E2 = json.load(open(os.path.join(RES, "E2_echo_scan.json")))
E3 = json.load(open(os.path.join(RES, "E3_collisions.json")))
E4 = json.load(open(os.path.join(RES, "E4_memory_test.json")))

NAVY = colors.HexColor("#1f4e79"); GREY = colors.HexColor("#555555"); LIGHT = colors.HexColor("#eef3f8")
body = ParagraphStyle("body", fontName="Serif", fontSize=9.6, leading=14.2, alignment=TA_JUSTIFY, spaceAfter=6.5)
small = ParagraphStyle("small", parent=body, fontSize=8.3, leading=11.3, spaceAfter=3)
cap = ParagraphStyle("cap", parent=body, fontSize=8.0, leading=10.6, textColor=GREY, spaceBefore=3, spaceAfter=11)
h1 = ParagraphStyle("h1", fontName="Sans-B", fontSize=13, leading=17, textColor=NAVY, spaceBefore=14, spaceAfter=7)
h2 = ParagraphStyle("h2", fontName="Sans-B", fontSize=10.5, leading=14, textColor=NAVY, spaceBefore=9, spaceAfter=4)
title = ParagraphStyle("title", fontName="Sans-B", fontSize=17, leading=23, alignment=TA_CENTER, textColor=NAVY, spaceAfter=10)
subtitle = ParagraphStyle("subtitle", fontName="Serif-I", fontSize=10.5, leading=14.5, alignment=TA_CENTER, textColor=GREY, spaceAfter=6)
center = ParagraphStyle("center", parent=body, alignment=TA_CENTER)
eqs = ParagraphStyle("eqs", fontName="Serif-I", fontSize=9.6, leading=14, alignment=TA_CENTER, spaceBefore=3, spaceAfter=8)
cell = ParagraphStyle("cell", fontName="Serif", fontSize=7.7, leading=9.8)
cellb = ParagraphStyle("cellb", parent=cell, fontName="Serif-B")


def P(t, s=body): return Paragraph(t, s)
def H1(t): return Paragraph(t, h1)
def H2(t): return Paragraph(t, h2)
def EQ(t): return Paragraph(t, eqs)


def IMG(name, caption, width_cm=16.0):
    path = os.path.join(FIG, name + ".png")
    iw, ih = ImageReader(path).getSize(); w = width_cm * cm
    return KeepTogether([Image(path, width=w, height=w * ih / iw), Paragraph(caption, cap)])


def TABLE(rows, widths):
    data = [[Paragraph(str(c), cellb if i == 0 else cell) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#b0bccb")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("LEFTPADDING", (0, 0), (-1, -1), 3),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 3), ("TOPPADDING", (0, 0), (-1, -1), 2),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def BOX(text):
    t = Table([[Paragraph(text, small)]], colWidths=[16.0 * cm])
    t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.8, NAVY), ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def f(x, nd=3):
    return "n/a" if x is None else f"{x:.{nd}f}"


tau3 = [r for r in E2["rows"] if r["tau"] == 3.0]
offs = [(r["tau"], r["eps"], r["offset_from_2tau"]) for r in E2["rows"] if r["eps"] == 0.3]
mem = E4["rows"]
E5 = json.load(open(os.path.join(RES, "E5_rollout.json")))
roll = E5["rows"]
def ravg(cad, model, case=None):
    v = [r["rollout_nrmse"] for r in roll if r["cadence"] == cad and r["model"] == model and (case is None or r["case"] == case)]
    return sum(v) / len(v)
def mavg(cad, model):
    v = [r["nrmse_echo_window"] for r in mem if r["cadence"] == cad and r["model"] == model]
    return sum(v) / len(v), min(v), max(v)

story = []
story += [Spacer(1, 0.6 * cm),
          P("PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · 10 NOVEMBER 2026", center), Spacer(1, 0.4 * cm),
          P("Plasma-Echo-Constrained Kinetic Memory", title),
          P("A Mori–Zwanzig memory test for separating reversible phase mixing from collisional loss of recoverable structure", subtitle),
          Spacer(1, 0.2 * cm),
          P("Devanik Debnath · Xylia (AI research scientist, multi-agent research system)", center), Spacer(1, 0.3 * cm)]
story.append(BOX(
    "<b>About the author.</b> Electronics and Communication Engineering graduate and independent AI researcher exploring how "
    "physical and mathematical structure can improve learning and modeling. Work spans gamma-ray burst reconstruction at the "
    "National Astronomical Observatory of Japan (NAOJ), physics-inspired signal classification, reinforcement learning, neural "
    "quantum-state methods, causal emergence, morphogenetic neural architectures, and computational artificial life. The research "
    "style combines algorithm design with explicit assumptions, code-based checks, and disclosure of unresolved limitations. "
    "<i>Devanik Debnath</i> is a Scientific Machine Learning and AI Architectures researcher; B.Tech, Electronics and Communication "
    "Engineering, National Institute of Technology Agartala (2026); Samsung Grade I Fellowship, Cohort 7; completed the IISc-led India "
    "Semiconductor Workforce Development Program (ISWDP) Level 1 evaluation at the 98.58th percentile. Links: github.com/Devanik21, "
    "orcid.org/0009-0001-8310-6921."))
story.append(Spacer(1, 0.35 * cm))
story.append(BOX(
    "<b>Scope.</b> This is a numerical study of an electrostatic one-dimensional, one-velocity Vlasov–Poisson model in normalised "
    "units. It reports no laboratory or space measurement. The observational programme proposed in the research note (MMS "
    "distribution functions) has not been carried out. Every number comes from <font face='Mono'>code/</font> "
    "with the stated parameters and seeds (deterministic solver, no random seed needed for the echo experiments)."))
story.append(Spacer(1, 0.35 * cm))
story.append(P(
    "<b>Abstract.</b> A collisionless plasma can hide a disturbance that appears to disappear by Landau damping, while its "
    "velocity-space structure still carries phase information that can later rephase into an echo. A fluid model that tracks only "
    "low-order moments cannot represent that hidden memory. We test a specific proposal: whether a memory-based learned model of "
    "unresolved kinetic dynamics, built on the Mori–Zwanzig projection idea, predicts echo-window behaviour better than a memoryless "
    "closure, on cases held out from training, and whether weak collisions suppress the echo in a measurable way. We validated a "
    "semi-Lagrangian Vlasov–Poisson solver against the standard Landau damping rate (fitted 0.1545 against 0.1533 at wavenumber 0.5; "
    f"relative error {100*E1['relative_error']:.1f}%) with invariant C<sub>2</sub> drifting by at most {100*E1['C2_max_relative_drift_40']:.2f}%. "
    "A two-pulse density echo appears after the second pulse, with amplitude scaling as the pulse amplitude to an exponent of "
    f"{E2['eps_scaling_slope_tau3']:.2f}, consistent with a second-order process. Weak BGK collisions reduce the echo monotonically, to "
    f"{100*E3['rows'][-1]['amp_ratio']:.0f}% of its collisionless value at collision rate 0.1. The echo time, however, is ambiguous: the "
    "difference signal has several maxima from beat structure, so the peak timing reported here is preliminary and is not the naive "
    "2τ. On held-out cases, a delay-embedding memory model predicts the echo window with one-step normalised error far below the "
    "memoryless closure at every cadence tested, including at a collision rate it was not trained on. Autonomous multi-step rollout "
    "is much weaker: the memory model retains skill in two of three held-out cases at fine cadence, and fails for the largest-amplitude "
    "case, while the memoryless closure and persistence have no rollout skill at all. Nonlinear neural operators were not tested. The "
    "paper states which claims survive and which do not.", body))
story.append(P("<b>Keywords:</b> Vlasov–Poisson · Landau damping · plasma echo · Mori–Zwanzig · memory kernels · semi-Lagrangian methods · "
               "collisional relaxation · reduced-order modelling", small))
story.append(PageBreak())

story.append(H1("Contents"))
for t in ["1  The claim under test", "2  Background", "3  Model and numerical method", "4  Validation",
          "5  Results: echo phenomenology", "6  Results: collisions", "7  Results: memory versus memoryless closure",
          "8  What the results support, and what they do not", "9  Relation to the literature",
          "10  Falsification criteria and their status", "11  Limitations", "12  Research programme and next steps",
          "Appendix A  Equations, invariants and the memory formalism", "Appendix B  Parameters and reproduction",
          "Appendix C  Corrections and disclosure", "References"]:
    story.append(P(t, small))
story.append(PageBreak())

story.append(H1("1  The claim under test"))
story.append(P(
    "The research note that motivated this study proposed three things. It proposed that the memory of unresolved velocity-space "
    "dynamics could be learned, rather than assumed away by a fluid closure. It proposed that plasma echoes, which reveal phase "
    "information that Landau damping appears to erase, could serve as a stringent calibration and falsification target for such a "
    "model. And it proposed that weak collisions could be used to find the boundary between reversible phase mixing and "
    "collision-dependent loss of recoverable structure. Those are three distinct claims, and this paper tests each one separately."))
story.append(P(
    "The note also contained statements about external literature, including a recent neural-operator paper on Mori–Zwanzig-"
    "inspired memory for Landau damping, a 2025 entropy-cascade paper, and an observational paper accepted in October 2026. I did not "
    "verify those sources in this study. The conclusions below do not depend on them, and I flag where the literature positioning "
    "would need to be checked before any priority claim."))

story.append(H1("2  Background"))
story.append(P(
    "In the collisionless limit the one-dimensional electrostatic plasma obeys the Vlasov equation for the distribution f(x, v, t), "
    "coupled to Poisson's equation for the self-consistent field E. Landau (1946) showed that a small-amplitude Langmuir wave on a "
    "Maxwellian plasma is damped even without collisions, because particles with velocity near the wave phase speed exchange energy "
    "with the wave. The damping is a phase-mixing effect in velocity space: the perturbation in f develops increasingly fine velocity "
    "structure, and the density moment averages that structure away. For wavenumber k = 0.5 in normalised units, the linear damping "
    "rate of the standard Maxwellian problem is γ ≈ 0.1533."))
story.append(P(
    "The fine structure does not disappear. Under the Vlasov flow the L² norm C<sub>2</sub> = ∫∫ f² dx dv is conserved, because the flow is "
    "measure preserving and the Liouville equation makes f constant along characteristics. A density moment that has lost its "
    "visible amplitude can therefore still carry information about the phase of earlier perturbations. A second perturbation can "
    "rephase that information into a density signal, which is the plasma echo (Malmberg and Wharton 1964; Gould, O'Neil and "
    "Malmberg 1967). The echo is a second-order effect in the perturbation amplitudes."))
story.append(P(
    "The Mori–Zwanzig formalism (Mori 1965; Zwanzig 1961, 2001) gives a formal reason why a reduced description of a few observed "
    "variables cannot be Markovian. Projecting the full dynamics onto the observed subspace produces a generalised Langevin equation "
    "with a memory kernel and a noise term. The memory is the influence of the unresolved degrees of freedom on the observed ones. "
    "This is the formal basis of the proposal: learn the memory kernel from data, rather than assume it is zero."))

story.append(H1("3  Model and numerical method"))
story.append(P(
    "The equations, in normalised units with ion background uniform and the electron plasma frequency set to one, are:"))
story.append(EQ("∂f/∂t + v ∂f/∂x + E ∂f/∂v = ν (ρ(x,t) f_M(v) − f),    ∂E/∂x = 1 − ρ,    ρ = ∫ f dv"))
story.append(P(
    "The collision term is a BGK relaxation towards the local Maxwellian, with rate ν. Setting ν = 0 gives the collisionless "
    "Vlasov–Poisson system. The domain is periodic in x with length L = 4π, which fixes wavenumber k = 0.5 for the fundamental "
    "mode, and velocity is truncated to |v| ≤ 6. The solver uses Strang splitting: a spectral (exact) shift in x for the free "
    "streaming, a semi-Lagrangian linear interpolation in v for the acceleration, and an explicit BGK step. The grid has 64 points in x "
    "and 256 in v, and the time step is 0.05. Resolution and timestep were checked by doubling each: the echo peak time changed by "
    "less than 0.03 and the echo amplitude by under 3%."))
story.append(P(
    "Two specific limitations of the numerics are noted here because they bear on the results. Linear interpolation in velocity is "
    "diffusive, so C<sub>2</sub> is not exactly conserved, and the fine velocity structure is resolved only down to the grid scale. The "
    "conservation check in Section 4 quantifies the first limitation; the echo convergence check quantifies the second."))

story.append(H1("4  Validation"))
story.append(IMG("fig01_validation",
                 "<b>Figure 1.</b> Validation. (a) Decay of the density mode at wavenumber 0.5 from a small Maxwellian perturbation, "
                 "against the theoretical rate 0.1533. (b) Relative drift of the invariant C<sub>2</sub> over forty time units."))
story.append(P(
    f"<b>Result.</b> The fitted damping rate is {E1['gamma_fitted']:.4f}, against the reference 0.1533, a relative error of "
    f"{100*E1['relative_error']:.2f}%. The maximum relative drift of C<sub>2</sub> over forty time units is "
    f"{E1['C2_max_relative_drift_40']:.2e}. The solver therefore reproduces the linear kinetic benchmark, and the invariant is "
    "preserved well within the tolerance needed for the echo comparisons."))

story.append(H1("5  Results: echo phenomenology"))
story.append(P(
    "The echo protocol is as follows. A density modulation at mode m₁ = 1 (wavenumber 0.5) is imposed at t = 0. A second density "
    "modulation at mode m₂ = 2 (wavenumber 1.0) is imposed at t = τ. The echo is sought at mode m₂ − m₁ = 1. Because the first pulse "
    "alone also produces a decaying mode-1 density, the echo is isolated by subtracting a control run in which only the first pulse "
    "is applied. This subtraction was not done in our first attempt, and that first attempt read the first pulse's own signal as an "
    "echo (Appendix C)."))
story.append(IMG("fig02_echo_timeline",
                 "<b>Figure 2.</b> Echo amplitude |ρ₁(A) − ρ₁(B)| for τ = 3 and ε = 0.3, where A has both pulses and B has only the first. "
                 "The signal begins at pulse 2 and has several maxima. The green line marks the largest, which the code selects. The "
                 "other maxima near 5.6 and 10.4 indicate beat structure from two components with different phase."))
story.append(P(
    "<b>Timing is ambiguous.</b> Figure 2 shows that the difference signal is not a single localised burst. It has at least three "
    "maxima in the window examined. The code reports the largest, which occurs about two time units after 2τ. The naive free-streaming "
    "estimate of the echo time is 2τ, and that estimate does not match the largest maximum. Whether the echo proper is the largest "
    "maximum, one of the others, or a superposition cannot be decided from this observable alone. The offsets reported in Table 1 "
    "are therefore the timing of the selected maximum, not a validated echo time."))
rows = [["τ", "ε", "Largest-maximum time", "2τ", "Offset"]]
for r in E2["rows"]:
    if r["eps"] in (0.1, 0.3, 0.6):
        rows.append([f(r["tau"], 1), f(r["eps"], 2), f(r["t_echo"], 2), f(2 * r["tau"], 1), f(r["offset_from_2tau"], 2)])
story.append(TABLE(rows, [2.0, 2.0, 4.6, 2.5, 3.0]))
story.append(P("<b>Table 1.</b> Time of the largest maximum of the echo-difference signal, relative to the naive 2τ. "
               "Treat the offsets as descriptive of this observable, not as an established echo time.", cap))
story.append(P(
    f"<b>Amplitude scaling.</b> At fixed τ = 3 the echo amplitude scales with the pulse amplitude with fitted log–log slope "
    f"{E2['eps_scaling_slope_tau3']:.2f}, over ε from 0.1 to 0.6. A pure second-order term would give slope 2. The shortfall is "
    "consistent with saturation at larger ε and with the beat structure contaminating the maximum. The qualitative result, that the "
    "echo is a nonlinear effect of order two in the pulse amplitudes, is supported."))
story.append(IMG("fig03_echo_timing_scaling",
                 "<b>Figure 3.</b> (a) Offset of the largest-maximum time from 2τ across pulse separations and amplitudes. (b) Echo "
                 "amplitude against pulse amplitude at τ = 3, log–log, with a slope-2 reference."))

story.append(H1("6  Results: collisions"))
story.append(P(
    "We repeated the τ = 3, ε = 0.3 case with BGK collision rates ν from 0 to 0.1. The echo amplitude, measured on the same "
    "selected maximum, decreases monotonically with ν. The timing barely moves, which is consistent with the timing being set by the "
    "collisionless part of the dynamics."))
rows = [["ν", "Echo amplitude ratio to ν = 0", "Largest-maximum time"]]
for r in E3["rows"]:
    rows.append([f(r["nu"], 3), f(r["amp_ratio"], 3), f(r["t_echo"], 2)])
story.append(TABLE(rows, [3.0, 6.0, 5.0]))
story.append(P("<b>Table 2.</b> Collisional suppression of the echo at τ = 3, ε = 0.3.", cap))
story.append(IMG("fig04_collisional_suppression",
                 "<b>Figure 4.</b> Echo amplitude relative to the collisionless case against BGK collision rate."))
story.append(P(
    f"<b>Interpretation.</b> At ν = 0.1 the echo retains {100*E3['rows'][-1]['amp_ratio']:.0f}% of its collisionless amplitude. The "
    "suppression is monotone and smooth, which fits the picture that collisions transfer velocity-space structure to scales the "
    "grid cannot resolve, where it is lost. The study does not measure entropy and does not establish an irreversibility boundary. "
    "What it establishes is a monotone, collision-rate-dependent loss of the echo signal in this model. Whether that loss is "
    "thermodynamic irreversibility, or a numerical dissipation of the scheme, is a question that a grid-convergence study at fixed ν "
    "would have to answer, and we have not run it."))

story.append(H1("7  Results: memory versus memoryless closure"))
story.append(P(
    "This is the central test of the proposal. Seven training cases spanned pulse separations 2, 3 and 4 and amplitudes 0.2 to 0.6, "
    "all collisionless. Three held-out cases were used for testing: τ = 2.5 with ε = 0.3, τ = 3.5 with ε = 0.6, and a collisional "
    "case at τ = 3, ε = 0.3, ν = 0.02. The observable is the complex density mode ρ₁(t), sampled at cadences of 0.25, 0.5 and 1.0. "
    "Two linear models are fitted by least squares to predict the next sample from previous samples: a memoryless closure with one "
    "lag, and a memory model whose number of lags spans a fixed memory time of four units. Scoring is the one-step normalised root "
    "mean square error over the echo window."))
story.append(EQ("ρ̂(t_{n+1}) = c₀ + Σ_{j=1}^{p} [ a_j Re ρ(t_{n+1−j}) + b_j Im ρ(t_{n+1−j}) ]   (fitted, complex output)"))
rows = [["Cadence Δ", "Memoryless (p = 1), mean NRMSE", "Memory model, mean NRMSE", "Memory lags p", "Best and worst memory case"]]
for cad in E4["cadences"]:
    mm, _, _ = mavg(cad, "memoryless_p1")
    mo, lo, hi = mavg(cad, "memory_p")
    p = [r["p"] for r in mem if r["cadence"] == cad and r["model"] == "memory_p"][0]
    rows.append([f(cad, 2), f(mm, 3), f(mo, 3), p, f"{f(lo, 3)} to {f(hi, 3)}"])
story.append(TABLE(rows, [2.2, 3.6, 3.4, 2.4, 4.4]))
story.append(P("<b>Table 3.</b> One-step normalised error over the echo window, averaged over the three held-out cases.", cap))
story.append(IMG("fig05_memory_vs_closure",
                 "<b>Figure 5.</b> Memory versus memoryless closure on held-out cases, one-step error, for three sampling cadences. Error "
                 "bars are standard deviations across the three held-out cases."))
story.append(P(
    "<b>Result.</b> At every cadence the memory model reduces the one-step error by a large factor relative to the memoryless closure. "
    "At cadence 1.0 the memoryless closure has essentially no predictive skill, with error near the signal scale, while the memory "
    "model is substantially better. The collisional held-out case, which the model never saw during training, is predicted within the "
    "same range as the collisionless cases."))
story.append(P(
    "<b>Limits of this result.</b> Three caveats matter. First, one-step prediction with sixteen lags of a smooth, nearly linear "
    "oscillation is much easier than predicting an entire echo trajectory from the initial condition. The result says that a linear "
    "memory of the observed moment predicts its next value well; it does not say that the model would roll out an echo. Second, the "
    "model is linear, so it cannot represent the nonlinear mechanism that produces the echo except through correlations in the "
    "history. Third, the training data are only seven cases of one mode configuration. A nonlinear neural operator, which the proposal "
    "named as the target, was not trained, and the comparison is between two linear models."))

story.append(H2("7.1  Autonomous rollout"))
story.append(P(
    "One-step prediction can be good while the model still fails to reproduce a trajectory, because each step is anchored to the true "
    "history. To test that, each model was started from the true history at t = τ + 0.5 and run forward on its own predictions until "
    "t = 2τ + 3, and the trajectory was compared with the simulation. The baseline is persistence, which holds the last observed value."))
rows = [["Cadence Δ", "Memoryless closure", "Memory model", "Persistence"]]
for cad in E5["cadences"]:
    rows.append([f(cad, 2), f(ravg(cad, "memoryless_p1"), 3), f(ravg(cad, "memory_p"), 3), f(ravg(cad, "persistence"), 3)])
story.append(TABLE(rows, [3.0, 4.5, 4.5, 4.5]))
story.append(P("<b>Table 3b.</b> Rollout normalised error, averaged over the three held-out cases.", cap))
rows = [["Held-out case (τ, ε, ν)", "Δ", "Memoryless", "Memory model", "Persistence"]]
for case in E5["test"]:
    for cad in E5["cadences"]:
        rows.append([str(tuple(case)), f(cad, 2),
                     f(ravg(cad, "memoryless_p1", case), 3), f(ravg(cad, "memory_p", case), 3), f(ravg(cad, "persistence", case), 3)])
story.append(TABLE(rows, [4.2, 1.6, 3.0, 3.2, 3.0]))
story.append(P("<b>Table 3c.</b> Rollout error by held-out case and cadence.", cap))
story.append(P(
    "<b>Result.</b> The memoryless closure and persistence give rollout errors near one in every case, meaning no skill. The memory "
    "model is informative in the (2.5, 0.3, 0) and (3.0, 0.3, 0.02) cases at cadences 0.25 and 0.5, with errors of about 0.20 to 0.28. "
    "In the (3.5, 0.6, 0) case it is no better than the closure at fine cadence and worse at cadence 1.0. The collisional case is "
    "predicted at fine cadence even though the model was trained only on collisionless runs. The one-step advantage reported in Table 3 "
    "therefore overstates the model's ability to reproduce an echo trajectory. The honest statement is that the linear memory model "
    "captures the echo-window dynamics in some held-out cases, and not in others, and that the failure is tied to the case rather than "
    "to the cadence alone."))

story.append(H1("8  What the results support, and what they do not"))
story.append(P("The following table separates the claims made in the research note from what this study shows."))
rows = [["Claim", "Status here", "Basis"],
        ["Solver reproduces Landau damping", "Supported", "Rate within 0.8% of reference; invariant drift 0.1%"],
        ["Two-pulse density echo appears at mode m₂ − m₁", "Supported", "Difference signal peaks after the second pulse"],
        ["Echo occurs at naive time 2τ", "Not supported as stated", "Largest maximum lies about 2 units after 2τ; beat structure"],
        ["Echo amplitude is second order in pulse amplitude", "Supported, approximately", "Fitted slope 1.72 against 2"],
        ["Weak collisions suppress the echo monotonically", "Supported in this model", "Ratio falls from 1.00 to 0.58 at ν = 0.1"],
        ["Suppression is thermodynamic irreversibility", "Not tested", "No entropy measured; no grid-convergence test at fixed ν"],
        ["Memory model beats memoryless closure on held-out echo cases", "Supported, one-step; partly in rollout", "Large one-step error reduction; rollout skill case-dependent"],
        ["Memory model reproduces the echo trajectory", "Partly: 2 of 3 held-out cases, fine cadence", "Rollout NRMSE 0.20 to 0.28; fails for (3.5, 0.6, 0)"],
        ["Learned nonlinear neural operator", "Not built", "Linear models only"],
        ["Observational test on MMS data", "Not carried out", "No data analysed"]]
story.append(TABLE(rows, [6.4, 3.8, 5.8]))
story.append(P("<b>Table 4.</b> Status of each claim.", cap))

story.append(H1("9  Relation to the literature"))
story.append(P(
    "The physics here is classical. The Landau damping result is Landau (1946), and the plasma echo was established experimentally "
    "and theoretically by Malmberg and Wharton (1964) and Gould, O'Neil and Malmberg (1967). The projection formalism is Mori (1965) "
    "and Zwanzig (1961, 2001). Semi-Lagrangian methods for the Vlasov equation are described in Cheng and Knorr (1976) and Sonnendrücker "
    "et al. (1999). The BGK collision model is Bhatnagar, Gross and Krook (1954). None of the novelty in this study lies in these "
    "results. The novelty claimed, if any, is in the combination of a learned memory test against echo-window behaviour with "
    "explicit cadence and held-out collisional tests. Priority against the external papers mentioned in the research note would "
    "require verifying those papers, which this study did not do."))

story.append(H1("10  Falsification criteria and their status"))
story.append(P(
    "The research note set a principal falsification criterion: if the learned model cannot predict held-out echo responses more "
    "reliably than existing closures while respecting the relevant invariants, the framework has not shown what it intended. Applied "
    "here, the first half of that criterion is passed in one-step prediction and partly in autonomous rollout (Section 7.1). The second half, respecting invariants, is only partly "
    "tested: C<sub>2</sub> is conserved by the solver, but the learned memory model was not constrained to respect it, and we did not "
    "check whether its predictions preserve it. Passing one-step prediction and partial rollout does not establish the criterion, and we say so."))
story.append(P(
    "A stronger criterion for the next stage is: predict the full echo trajectory from the initial condition and the first pulse, "
    "across held-out amplitudes and separations, with a rollout error that beats the memoryless closure by a fixed margin, and with C<sub>2</sub> "
    "drift below a stated tolerance. We recommend this as the pre-registered test."))

story.append(H1("11  Limitations"))
for t in [
    "<b>Model.</b> One spatial dimension, one velocity dimension, electrostatic, normalised units, a single Maxwellian background. Real "
    "plasmas are three-dimensional, electromagnetic in general, and often non-Maxwellian.",
    "<b>Echo observable.</b> The echo is defined on a density mode and selected as a maximum. The beat structure of the signal makes "
    "the timing ambiguous. A better observable, such as a Hermite-moment decomposition or a phase-space diagnostic, is needed.",
    "<b>Collisions.</b> The BGK operator is a relaxation model, not a Landau–Fokker–Planck collision operator, and it does not conserve "
    "momentum or energy exactly. The suppression result depends on that choice.",
    "<b>Memory model.</b> Linear autoregression with delay embedding is a Mori–Zwanzig-inspired baseline. It is not a neural operator. It was "
    "evaluated in one-step prediction and in autonomous rollout, with skill that is case-dependent.",
    "<b>Sample size.</b> Seven training cases and three test cases. The memory-versus-closure gap is large, but the statistical uncertainty "
    "from so few cases is substantial and is not quantified beyond the spread across cases.",
    "<b>Numerics.</b> Linear velocity interpolation is diffusive, and the velocity grid of 256 points limits resolution of fine "
    "structure. The echo convergence check was done in two directions; a full grid-convergence study of the collisional suppression "
    "was not done."]:
    story.append(P(t))

story.append(H1("12  Research programme and next steps"))
story.append(P(
    "The research note proposed four phases. Phase I, the reference solver and benchmarks, is complete for the linear Landau case and "
    "partly complete for the echo. Phase II, a memory operator tested against echo predictions, has a linear baseline in place but no "
    "nonlinear operator, and no rollout test. Phase III, the irreversibility boundary, has a monotone collisional suppression result "
    "but no grid-convergence study and no entropy diagnostic. Phase IV, an observational cross-check on MMS distribution functions, "
    "has not started. The rollout test has now been run (Section 7.1) and shows partial skill. The next concrete steps are: a better "
    "echo observable based on Hermite decomposition, to resolve the timing ambiguity; a rollout test over a wider set of amplitudes to "
    "locate where the linear memory model fails; a grid-convergence study of the collisional suppression; and an invariant-preserving "
    "constraint on the learned model."))

story.append(H1("Appendix A  Equations, invariants and the memory formalism"))
story.append(P(
    "<b>Invariant.</b> For the collisionless Vlasov equation, f is constant along characteristics. The flow map is area preserving in "
    "(x, v), so the L² norm C<sub>2</sub> = ∫∫ f² dx dv is conserved. The collision term changes C<sub>2</sub>, because the relaxation "
    "towards f_M reduces the L² distance to the Maxwellian; this is consistent with the monotone echo suppression reported above, "
    "though the numerical result does not by itself prove the mechanism."))
story.append(P(
    "<b>Memory formalism (formal).</b> Let P project onto the observed moments and Q = I − P. The Mori–Zwanzig decomposition gives a "
    "generalised Langevin equation for the observed variables z(t): dz/dt = Ω z(t) − ∫<sub>0</sub><super>t</super> K(t − s) z(s) ds + F(t), where "
    "K is a memory kernel and F a fluctuating term orthogonal to the observables. A delay-embedding linear model with p lags is a finite "
    "approximation to the convolution with K truncated at lag p. The result that memory helps is equivalent, in this approximation, to "
    "the statement that K has support beyond one sampling interval."))
story.append(P(
    "<b>What the formalism does not give.</b> It does not determine K from the observables alone for a nonlinear system, and it does not "
    "guarantee that a fitted K preserves invariants. Those are the reasons the falsification criteria in Section 10 include an invariant "
    "check."))

story.append(H1("Appendix B  Parameters and reproduction"))
rows = [["Quantity", "Value"],
        ["Domain length L, wavenumber of fundamental mode", "4π, k = 0.5"],
        ["Grid", "Nx = 64, Nv = 256, |v| ≤ 6"],
        ["Time step", "0.05"],
        ["Pulse modes m₁, m₂", "1, 2 (wavenumbers 0.5 and 1.0)"],
        ["Pulse separations τ (echo scan)", "2.0, 2.5, 3.0, 3.5, 4.0, 5.0"],
        ["Pulse amplitudes ε (echo scan)", "0.1, 0.2, 0.3, 0.45, 0.6"],
        ["Collision rates ν (collision scan)", "0, 0.005, 0.01, 0.02, 0.05, 0.1"],
        ["Memory cadences Δ", "0.25, 0.5, 1.0; memory time 4.0"],
        ["Training cases", "7 collisionless (τ, ε) combinations; see code"],
        ["Held-out cases", "(2.5, 0.3, 0), (3.5, 0.6, 0), (3.0, 0.3, 0.02)"]]
story.append(TABLE(rows, [9.0, 7.0]))
story.append(P("<b>Table 5.</b> Parameters. The solver is deterministic and uses no random numbers.", cap))
story.append(P(
    "<b>Reproduction.</b> Run <font face='Mono'>python code/echo_experiments.py</font>, then <font face='Mono'>python code/rollout_experiment.py</font>, then "
    "<font face='Mono'>python code/memory_experiment.py</font>, then <font face='Mono'>python code/make_figures.py</font>, then "
    "<font face='Mono'>python code/build_paper.py</font>. The full sequence takes several minutes on one core."))

story.append(H1("Appendix C  Corrections and disclosure"))
for t in [
    "<b>First echo attempt.</b> The first echo measurement did not subtract the first pulse's own decaying signal. It reported a peak "
    "in the pulse-one-only mode amplitude and was wrong. The corrected protocol subtracts a control run.",
    "<b>Echo timing.</b> Early runs suggested the echo time was near 2τ. A closer look at the difference signal showed multiple maxima "
    "from beat structure. The reported timing is the largest maximum and is not a validated echo time, as stated in Section 5.",
    "<b>Rollout.</b> The one-step result of Section 7 was reported first and is too favourable. Autonomous rollout, run afterwards, shows "
    "partial skill only, and the paper now reports both.",
    "<b>Literature.</b> External papers mentioned in the research note were not verified. Priority claims against them should wait for "
    "that verification.",
    "<b>AI assistance.</b> The simulations, figures and manuscript text were produced with the assistance of Claude (Anthropic) under "
    "the direction of the authors, who define the research question and are responsible for the content. Xylia is the authors' AI "
    "research scientist. Competing interests: none declared. Funding: none."]:
    story.append(P(t))

story.append(H1("References"))
for r in [
    "Bhatnagar PL, Gross EP, Krook M (1954) A model for collision processes in gases. Physical Review 94: 511–525.",
    "Cheng CZ, Knorr G (1976) The integration of the Vlasov equation in configuration space. Journal of Computational Physics 22: 330–351.",
    "Gould RW, O'Neil TM, Malmberg JH (1967) Plasma echo. Physical Review Letters 19: 219–222.",
    "Landau LD (1946) On the vibrations of the electronic plasma. Journal of Physics USSR 10: 25–34.",
    "Malmberg JH, Wharton CB (1964) Collisionless damping of electron plasma waves. Physical Review Letters 13: 184–186.",
    "Mori H (1965) Transport, collective motion, and Brownian motion. Progress of Theoretical Physics 33: 423–455.",
    "Sonnendrücker E, Roche J, Bertrand P, Ghizzo A (1999) The semi-Lagrangian method for the numerical resolution of the Vlasov equation. Journal of Computational Physics 149: 201–220.",
    "Zwanzig R (1961) Memory effects in irreversible thermodynamics. Physical Review 124: 983–992.",
    "Zwanzig R (2001) Nonequilibrium Statistical Mechanics. Oxford University Press."]:
    story.append(P(r, small))


def footer(canvas, doc):
    canvas.saveState(); canvas.setFont("Sans", 7); canvas.setFillColor(GREY)
    canvas.drawString(2.0 * cm, 1.2 * cm, "PREPRINT · NOT PEER REVIEWED · VERSION 1.0 · Debnath & Xylia · 10 Nov 2026")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"{doc.page}"); canvas.restoreState()


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=2.0 * cm, rightMargin=2.0 * cm, topMargin=1.8 * cm, bottomMargin=1.9 * cm,
                            title="Plasma-Echo-Constrained Kinetic Memory", author="Devanik Debnath; Xylia", subject="Preprint v1.0")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    from pypdf import PdfReader
    print("wrote", OUT, "pages", len(PdfReader(OUT).pages))
