"""1D1V electrostatic Vlasov-Poisson solver, semi-Lagrangian (Strang split), periodic in x.
Units: electron plasma, ions uniform background, normalised so that omega_p = 1.
  df/dt + v df/dx + E df/dv = nu (rho_M(x) f_M(v) - f)      (BGK-type relaxation, optional)
  dE/dx = 1 - rho,  rho = int f dv,  E has zero mean.
"""
import numpy as np


class Vlasov:
    def __init__(self, L, Nx, vmax, Nv):
        self.L, self.Nx, self.Nv = L, Nx, Nv
        self.x = np.arange(Nx) * L / Nx
        self.v = np.linspace(-vmax, vmax, Nv)
        self.dv = self.v[1] - self.v[0]
        self.k = 2 * np.pi * np.fft.fftfreq(Nx, d=L / Nx)
        self.fM = np.exp(-self.v**2 / 2) / np.sqrt(2 * np.pi)

    def rho_E(self, f):
        rho = f.sum(axis=1) * self.dv
        rhok = np.fft.fft(rho - 1.0)           # subtract ion background
        Ek = np.zeros_like(rhok)
        nz = self.k != 0
        Ek[nz] = -1j * rhok[nz] / self.k[nz]    # dE/dx = -(rho-1)  ->  E_k = -i rho_k / k ... sign fixed below
        E = np.real(np.fft.ifft(Ek))
        return rho, E

    def advect_x(self, f, dt):
        fk = np.fft.fft(f, axis=0)
        fk *= np.exp(-1j * self.k[:, None] * self.v[None, :] * dt)
        return np.real(np.fft.ifft(fk, axis=0))

    def advect_v(self, f, E, dt):
        out = np.empty_like(f)
        vq = self.v[None, :] - E[:, None] * dt       # departure velocities
        for i in range(self.Nx):
            out[i] = np.interp(vq[i], self.v, f[i], left=0.0, right=0.0)
        return out

    def step(self, f, dt, nu=0.0):
        f = self.advect_x(f, 0.5 * dt)
        rho, E = self.rho_E(f)
        f = self.advect_v(f, E, dt)
        f = self.advect_x(f, 0.5 * dt)
        if nu > 0.0:
            rho = f.sum(axis=1) * self.dv
            f = f + dt * nu * (rho[:, None] * self.fM[None, :] - f)
        return f

    def energy(self, f):
        rho, E = self.rho_E(f)
        return 0.5 * np.mean(E**2) + 0.5 * np.mean(np.sum(f * self.v[None, :]**2, axis=1) * self.dv)

    def C2(self, f):
        return float(np.sum(f**2) * self.dv * (self.x[1] - self.x[0]))

    def mode(self, f, m):
        rho = f.sum(axis=1) * self.dv
        return np.fft.fft(rho)[m] / self.Nx
