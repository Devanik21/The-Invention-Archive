#!/usr/bin/env python3
"""E4: memory test. Predicts the coarse-sampled complex density mode rho_1(t) with
(a) a memoryless closure (AR with p = 1 lag) and (b) a delay-embedding memory model
(AR with p = round(T_mem / cadence) lags), both fitted by least squares on training
cases and scored on held-out (tau, eps, nu) cases. Linear models only; no neural net."""
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "results")
sys.path.insert(0, HERE)
from echo_experiments import run, K0, DT

TRAIN = [(2.0, 0.2, 0.0), (2.0, 0.45, 0.0), (3.0, 0.2, 0.0), (3.0, 0.45, 0.0), (4.0, 0.3, 0.0),
         (4.0, 0.6, 0.0), (3.0, 0.3, 0.0)]
TEST = [(2.5, 0.3, 0.0), (3.5, 0.6, 0.0), (3.0, 0.3, 0.02)]
CADENCES = [0.25, 0.5, 1.0]
T_MEM = 4.0


def series(tau, eps, nu):
    r = run(tau, eps, 2 * tau + 6, nu=nu, second=True)
    return r["t"], r["rho1"]


def design(z, p):
    """Rows of [1, Re z_{n-1..n-p}, Im z_{n-1..n-p}] and targets z_n."""
    X, y = [], []
    for n in range(p, len(z)):
        past = z[n - p:n][::-1]
        X.append(np.concatenate([[1.0], past.real, past.imag]))
        y.append(z[n])
    return np.array(X), np.array(y)


def fit(z_list, p):
    Xs, ys = zip(*[design(z, p) for z in z_list])
    X = np.vstack(Xs); y = np.concatenate(ys)
    # complex target via real and imaginary parts jointly
    Yr = np.c_[y.real, y.imag]
    coef, *_ = np.linalg.lstsq(X, Yr, rcond=None)
    return coef


def predict_one_step(coef, z, p):
    X, y = design(z, p)
    pr = X @ coef
    return pr[:, 0] + 1j * pr[:, 1], y


def window_nrmse(z, t, p, coef, tau):
    pred, y = predict_one_step(coef, z, p)
    tt = t[p:]
    mask = (tt >= tau) & (tt <= 2 * tau + 3)
    err = np.abs(pred - y)[mask]
    scale = np.sqrt(np.mean(np.abs(y[mask]) ** 2)) + 1e-12
    return float(np.sqrt(np.mean(err ** 2)) / scale)


def run_E4():
    tr = [series(*c) for c in TRAIN]
    te = [series(*c) for c in TEST]
    out = {"train": TRAIN, "test": TEST, "cadences": CADENCES, "T_mem": T_MEM, "rows": []}
    for cad in CADENCES:
        stride = int(round(cad / DT))
        p_mem = max(2, int(round(T_MEM / cad)))
        models = {"memoryless_p1": 1, "memory_p": p_mem}
        for name, p in models.items():
            ztr = [z[::stride] for (_, z) in tr]
            coef = fit(ztr, p)
            for c, (t, z) in zip(TEST, te):
                zs = z[::stride]; ts = t[::stride]
                nr = window_nrmse(zs, ts, p, coef, c[0])
                out["rows"].append({"cadence": cad, "model": name, "p": p, "case": list(c), "nrmse_echo_window": nr})
    return out


if __name__ == "__main__":
    out = run_E4()
    json.dump(out, open(os.path.join(RES, "E4_memory_test.json"), "w"), indent=2)
    for r in out["rows"]:
        print(r["cadence"], r["model"], r["p"], r["case"], round(r["nrmse_echo_window"], 3), flush=True)
