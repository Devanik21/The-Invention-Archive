#!/usr/bin/env bash
# Publishes the Deep SLR release into The-Invention-Archive, then runs CI.
# Requires: git, and push access to Devanik21/The-Invention-Archive (your credentials).
set -euo pipefail
REPO_URL="https://github.com/Devanik21/The-Invention-Archive.git"
DEST="Theoretical Research/Thinking_Linear_Regression_Deep_SLR_Stress_Test"
SRC="$(cd "$(dirname "$0")" && pwd)/deep_slr"
WORK="$(mktemp -d)"

git clone --depth 1 "$REPO_URL" "$WORK/repo"
cd "$WORK/repo"
mkdir -p "$DEST" .github/workflows
cp -R "$SRC/." "$DEST/"
cp "$SRC/.github/workflows/deep-slr-reproduce.yml" .github/workflows/
rm -rf "$DEST/.github" "$DEST/.pytest_cache"
find "$DEST" -name __pycache__ -type d -exec rm -rf {} +

git add "$DEST" .github/workflows/deep-slr-reproduce.yml
git commit -m "Add Deep SLR (Thinking Linear Regression) stress-test release"
git push origin HEAD
echo "Pushed. Actions run: https://github.com/Devanik21/The-Invention-Archive/actions"
