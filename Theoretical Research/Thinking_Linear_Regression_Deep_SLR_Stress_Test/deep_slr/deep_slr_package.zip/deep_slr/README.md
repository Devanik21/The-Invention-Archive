# Thinking Linear Regression ("Deep SLR"): research package

**Authors:** Devanik Debnath and Xylia (equal contribution). Xylia is the authors' AI research
scientist (multi-agent research system). AI assistance: Claude (Anthropic), under the direction of the authors.

This repository contains the model, baselines, experiments, figures, tables, paper and notebook for a
stress test of a simple inference-time "critic loop" added to ordinary least squares.

**Headline (honest) result.** The loop has a closed form and is exactly OLS inside the training data
(max difference about 1e-15). Outside the data it is a boundary-anchored, budgeted shrinkage. It helps on
saturating, concave and Engel-curve extrapolation, hurts on linear, logistic and diabetes data, does not
detect regime shifts, and gains nothing from more than one step. See `paper/deep_slr_paper.pdf`.

## Layout

| Path | Contents |
|---|---|
| `deep_slr/model.py` | `ThinkingLinearRegression`: fit, closed-form predict, explicit loop, trace |
| `deep_slr/baselines.py` | OLS, clipped OLS, Huber, quadratic, kNN, Gaussian process |
| `deep_slr/data.py` | Five toy families with known truth; Engel and diabetes-BMI real data (offline) |
| `deep_slr/experiments.py` | Nested tuning, 30-seed benchmark, paired statistics with Holm correction, budget curves |
| `deep_slr/plots.py` | All figures and LaTeX tables, generated only from `results/` |
| `scripts/run_all.py` | Reproduces everything (about 40 s on one CPU core) |
| `scripts/build_notebook.py` | Builds and executes `deep_slr_research.ipynb` |
| `tests/test_tlr.py` | Verification: in-support identity, closed form = loop, monotone gap, validation |
| `results/` | CSVs and JSON produced by the experiments |
| `figures/` | PNG and PDF figures |
| `paper/` | LaTeX source, compiled `deep_slr_paper.pdf`, and generated tables |
| `deep_slr_research.ipynb` | Executed research notebook |

## Reproduce

```bash
pip install -r requirements.txt
python tests/test_tlr.py            # verification (7 tests)
python scripts/run_all.py           # full 30-seed run; regenerates results, figures, tables
python scripts/build_notebook.py --execute   # rebuild the notebook with outputs
cd paper && pdflatex deep_slr_paper.tex && pdflatex deep_slr_paper.tex
```

Seeds are fixed (0 to 29). The GPR uses `random_state=0`. Results are deterministic on the recorded versions.

## Data

No network is used. Real data come from packages bundled with `statsmodels` (`engel`) and `scikit-learn`
(`load_diabetes`). Toy data are generated from the formulas in `deep_slr/data.py`. The motivating
examples in early drafts (an ice-cream toy, a housing example) are illustrative only and are not used as evidence.

## Scope and limitations

Univariate inputs only. Two real datasets, both one-dimensional. Nested tuning uses only within-support
data, so it cannot see shifts beyond the data. The literature review was not systematic, so novelty claims
are "to our knowledge" and must be verified before submission. See Section 7 of the paper.

## Citation

See `CITATION.cff`. Please credit both authors equally.
